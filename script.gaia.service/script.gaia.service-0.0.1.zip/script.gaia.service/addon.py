# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import xbmc
import xbmcvfs
import xbmcaddon

import os
import sys
from importlib import util

developer = xbmcaddon.Addon().getAddonInfo('version') == '999.999.999'
if developer:
	import time as timer
	timeStart = timer.time()
	
def importFile(id, path):
	file = util.spec_from_file_location(id, path)
	module = util.module_from_spec(file)
	sys.modules[id] = module
	file.loader.exec_module(module)
	return module
	
def importGaia():
    addon = xbmcaddon.Addon('plugin.video.gaia')
    path = xbmcvfs.translatePath(os.path.join(addon.getAddonInfo('path'), 'lib', '__init__.py'))
    return importFile(id = 'lib', path = path)
    
def importExternal():
    addon = xbmcaddon.Addon('script.gaia.externals')
    path = xbmcvfs.translatePath(os.path.join(addon.getAddonInfo('path'), 'lib', 'externals', '__init__.py'))
    return importFile(id = 'externals', path = path)

importGaia()
importExternal()
from lib.modules import tools

parameters = tools.System.commandResolve(initialize = True)
action = parameters.get('action')

if developer: tools.Logger.log('EXECUTION STARTED [Action: %s]' % str(action))

####################################################
# REFRESH
####################################################

if action == 'refresh':
	from lib.modules.playback import Playback
	#Playback.instance().launch(refresh = True, reload = True, delay = True, wait = False)
	#Playback.instance().reload(media='show', progress=True)
	
	from lib.meta.manager import MetaManager
	x=MetaManager.instance().metadataMovie(imdb='tt0499549')
	tools.Logger.log('.............................: '+str(x)[:1000])
	
	'''from lib.modules.compression import Compressor
	x=bytes(tools.Hash.random() * 10000000, 'utf-8')
	ttt=tools.Time(start=True)
	for i in range(3):
		t=tools.Time(start=True)
		Compressor.compress(data = x, type = Compressor.TypeLzma)
		tools.Logger.log("SSSS: "+str(t.elapsed(True)))
	tools.Logger.log("SSSS////: "+str(ttt.elapsed(True)))'''

####################################################
# FINAL
####################################################

if developer: tools.Logger.log('EXECUTION FINISHED [Action: %s | Duration: %.3f secs]' % (action, timer.time() - timeStart))
