# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.modules import tools
from lib.modules import interface

class Clipboard(object):

	@classmethod
	def __message(self, id, value, type = None):
		message = ''
		if not type: type = interface.Translation.string(33035)
		if not id == None: message += (interface.Translation.string(id) % type) + ':' + interface.Format.newline()
		message += interface.Format.italic(interface.Format.split(value))
		return message

	@classmethod
	def copy(self, value, notify = False, type = None):
		if not value:
			return False

		try:
			# On certain systems (eg: iOS) the "platform" module in pyperclip fails.
			# Only import here and not globally, to save time because pyperclip takes about 300ms to load.
			try: from lib.externals import pyperclip
			except: pass
			pyperclip.copy(value)

			id = 33033
		except:
			id = None
			if tools.Platform.systemTypeLinux():
				tools.Logger.error("On Linux, xsel or xclip must be installed to copy to the clipboard. On Debian/Ubuntu this can be installed with: \"sudo apt install xsel\" or \"sudo apt install xclip\"")

		if notify == True:
			title = interface.Translation.string(33032)
			message = self.__message(id = id, value = value, type = type)
			interface.Dialog.confirm(title = title, message = message)

		return True

	@classmethod
	def paste(self, notify = False, type = None):
		try:
			# Only import here and not globally, to save time because pyperclip takes about 300ms to load.
			try: from lib.externals import pyperclip
			except: pass
			value = pyperclip.paste()
			if notify == True:
				title = interface.Translation.string(33032)
				message = self.__message(id = 33034, value = value, type = type)
				interface.Dialog.confirm(title = title, message = message)
			return value
		except:
			return None

	@classmethod
	def copyLink(self, value, notify = False):
		type = interface.Translation.string(33381).lower()
		return self.copy(value = value, notify = notify, type = type)

	@classmethod
	def pasteLink(self, notify = False):
		type = interface.Translation.string(33381).lower()
		return self.paste(notify = notify, type = type)

	@classmethod
	def copyName(self, value, notify = False):
		type = interface.Translation.string(33390).lower()
		return self.copy(value = value, notify = notify, type = type)
