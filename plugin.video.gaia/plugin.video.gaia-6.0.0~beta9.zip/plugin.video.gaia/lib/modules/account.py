# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.modules.tools import Settings, Time, Tools, System, Logger
from lib.modules.interface import Dialog, Loader, Format, Translation
from lib.modules.network import Networker, Geolocator

###################################################################
# AUTHENTICATION
###################################################################

class Account(object):

	ModeOauth				= 'oauth'			# OAuth
	ModeUsername			= 'username'		# Username & Password
	ModeEmail				= 'email'			# Email & Passsword
	ModeKey					= 'key'				# API Key
	ModePin					= 'pin'				# API Pin
	ModeId					= 'id'				# Identifier or Username

	AttributeToken			= 'token'			# OAuth access_token
	AttributeRefresh		= 'refresh'			# OAuth refresh-token
	AttributeCode			= 'code'			# OAuth user_code
	AttributeDevice			= 'device'			# OAuth device_code
	AttributeLink			= 'link'			# OAuth verification_url
	AttributeExpiration		= 'expiration'		# OAuth expires_in
	AttributeInterval		= 'interval'		# OAuth interval
	AttributeLabel			= 'label'
	AttributeUsername		= 'username'
	AttributeEmail			= 'email'
	AttributePassword		= 'password'
	AttributeKey			= 'key'
	AttributePin			= 'pin'
	AttributeSecret			= 'secret'
	AttributeId				= 'id'
	AttributeType			= 'type'
	AttributeVersion		= 'version'

	SettingsAccount			= 'account'
	SettingsPremium			= 'premium'
	SettingsEnabled			= 'enabled'
	SettingsAuthentication	= 'authentication'

	DefaultExpiration		= 900				# 15 minutes
	DefaultInterval			= 3					# 3 seconds
	DefaultCancel			= 0.5				# 500 milliseconds

	Data					= {}

	# level: at which Kodi settings level the account should be visible.
	# rank: a value in [1,5] that shows how important the account is to the functionality of Gaia.
	def __init__(self,
		id,
		type = None,
		mode = None,

		name = None,
		description = None,
		free = None,

		linkDirect = None,
		linkRedirect = None,

		level = None,
		rank = None,
		category = None,
	):
		self.mId = id
		self.mType = type
		self.mMode = mode

		self.mName = Translation.string(name)
		self.mDescription = Translation.string(description)
		self.mFree = free

		if linkDirect and not Networker.linkIs(linkDirect): linkDirect = Settings.getString(linkDirect, raw = True)
		if linkRedirect and not Networker.linkIs(linkRedirect): linkRedirect = Settings.getString(linkRedirect, raw = True)
		self.mLinkDirect = linkDirect if linkDirect else linkRedirect
		self.mLinkRedirect = linkRedirect if linkRedirect else linkDirect

		self.mLevel = level
		self.mRank = rank
		self.mCategory = Account.SettingsAccount if category is None else category

		self.mIdentifier = self.mCategory + '_' + self.mId

	@classmethod
	def headerBearer(self, token):
		return {'Authorization' : 'Bearer ' + token}

	def settings(self):
		id = Settings.idDataLabel(self.settingsIdAuthentication()) if self.enabled() else self.settingsIdEnabled()
		Settings.launch(id)

	def settingsId(self, attribute):
		return '%s.%s.%s' % (self.mCategory, self.mId, attribute)

	def settingsIdEnabled(self):
		return self.settingsId(attribute = Account.SettingsEnabled)

	def settingsIdAuthentication(self):
		return self.settingsId(attribute = Account.SettingsAuthentication)

	def settingsVisible(self):
		return self.mLevel is None or self.mLevel <= Settings.level()

	def name(self):
		return self.mName

	def description(self):
		return self.mDescription

	def free(self):
		return self.mFree

	def linkDirect(self):
		return self.mLinkDirect

	def linkRedirect(self):
		return self.mLinkRedirect

	def level(self):
		return self.mLevel

	def rank(self):
		return self.mRank

	def category(self):
		return self.mCategory

	def data(self):
		if not self.mIdentifier in Account.Data:
			if self.authenticated(): Account.Data[self.mIdentifier] = Settings.getData(id = self.settingsIdAuthentication())
			else: Account.Data[self.mIdentifier] = False
		data = Account.Data[self.mIdentifier]
		if data: return data
		else: return False

	def dataToken(self, default = None):
		try: return self.data()[Account.AttributeToken]
		except: return default

	def dataBearer(self, token = None, default = None):
		if not token: token = self.dataToken()
		if token: return self.headerBearer(token = token)
		return default

	def dataRefresh(self, default = None):
		try: return self.data()[Account.AttributeRefresh]
		except: return default

	def dataLabel(self, default = None):
		try: return self.data()[Account.AttributeLabel]
		except: return default

	def dataUsername(self, default = None):
		try: return self.data()[Account.AttributeUsername]
		except: return default

	def dataEmail(self, default = None):
		try: return self.data()[Account.AttributeEmail]
		except: return default

	def dataPassword(self, default = None):
		try: return self.data()[Account.AttributePassword]
		except: return default

	def dataKey(self, default = None):
		try: return self.data()[Account.AttributeKey]
		except: return default

	def dataPin(self, default = None):
		try: return self.data()[Account.AttributePin]
		except: return default

	def dataSecret(self, default = None):
		try: return self.data()[Account.AttributeSecret]
		except: return default

	def dataId(self, default = None):
		try: return self.data()[Account.AttributeId]
		except: return default

	def dataType(self, default = None):
		try: return self.data()[Account.AttributeType]
		except: return default

	def dataVersion(self, default = None):
		try: return self.data()[Account.AttributeVersion]
		except: return default

	def enabled(self):
		return Settings.getBoolean(id = self.settingsIdEnabled())

	def enable(self, enable = True):
		return Settings.set(id = self.settingsIdEnabled(), value = enable)

	def disable(self, disable = True):
		return self.enable(enable = not disable)

	def authenticated(self):
		return self.enabled() and not Settings.defaultIs(id = self.settingsIdAuthentication())

	def reset(self):
		Settings.defaultData(id = self.settingsIdAuthentication())
		Settings.set(self.settingsIdEnabled(), False)
		Account.Data[self.mIdentifier] = None

	def update(self, token = None, refresh = None, label = None, username = None, email = None, password = None, key = None, pin = None, secret = None, id = None, type = None, version = None, data = None):
		if not data: data = self.data()
		if not token is None: data[Account.AttributeToken] = token
		if not refresh is None: data[Account.AttributeRefresh] = refresh
		if not label is None: data[Account.AttributeLabel] = label
		if not username is None: data[Account.AttributeUsername] = username
		if not email is None: data[Account.AttributeEmail] = email
		if not password is None: data[Account.AttributePassword] = password
		if not key is None: data[Account.AttributeKey] = key
		if not pin is None: data[Account.AttributePin] = pin
		if not secret is None: data[Account.AttributeSecret] = secret
		if not id is None: data[Account.AttributeId] = id
		if not type is None: data[Account.AttributeType] = type
		if not version is None: data[Account.AttributeVersion] = version

		if data:
			label = None
			try: label = data[Account.AttributeLabel]
			except: pass
			if not label:
				try: label = data[Account.AttributeUsername]
				except: pass
				if not label:
					try: label = data[Account.AttributeEmail]
					except: pass
					if not label: label = Format.FontPassword
			data[Account.AttributeLabel] = label
			label = Format.fontBold(label)

			Account.Data[self.mIdentifier] = data
			Settings.set(id = self.settingsIdEnabled(), value = True)
			Settings.setData(id = self.settingsIdAuthentication(), value = data, label = label)
		else:
			self.reset()

	def register(self):
		link = self.linkRedirect()
		if link:
			System.openLink(link)
			return None # Ask in settings.py if the account should be authenticated now.
		return False

	def authenticate(self,
		functionNew = None,			# Function executed before the authentication begins if and only if no account was previously authenticated. Must return False if the process should be aborted.
		functionBefore = None,		# Function executed before the authentication begins. Must return False if the process should be aborted.
		functionAfter = None,		# Function executed after the authentication finishes.
		functionRevoke = None,		# Function executed after the authentication the user selected the revoke option.
		functionInitial = None,		# Function executed to before the first step in the authentication process to show a help description.
		functionFinal = None,		# Function executed to after the whole authentication process for a final message.

		functionUser = None,		# Function executed to before the user input dialog is shown (username/email).
		functionSecret = None,		# Function executed to before the secret input dialog is shown (password/key/pin) was entered.

		# Retrieves the authnetication data externally, like from another addon.
		# If external data is returned by this function, the user will be asked if this dataa should be used, or new data be entered.
		functionExternal = None,

		# Function executed to initiate the authentication proccess. Must return False on failures or a dictionary on success.
		# For OAuth: Return True or {AttributeLink : <required>, AttributeCode : <required>, AttributeDevice : <optional>, AttributeExpiration : <optional>, AttributeInterval : <optional>}.
		# For Basic: Return True/False/None.
		functionInitiate = None,

		# Function executed to check if the authentication was completed. Must return None on not completed yet, False on failures, or a dictionary on success.
		# For OAuth: Return False, None, or dictionary: {AttributeToken : <required>, AttributeRefresh : <optional>, AttributeUsername : <optional>, AttributeEmail : <optional>}.
		# For Basic: Return True, False, None, or dictinary {AttributeUsername : <optional>, AttributeEmail : <optional>}.
		functionVerify = None,

		# Shows a message dialog, similarly to the functions above.
		# Can be a string which will show a confirmation dialog.
		# Or can be a dictionary with optional parameters passed to the dialog: {'type' : Dialog.TypeNotification, 'message' : 'xyz', 'icon' : Dialog.IconError}
		messageNew = None,
		messageBefore = None,
		messageAfter = None,
		messageRevoke = None,
		messageVerify = None,
		messageInitial = None,
		messageFinal = None,
		messageUser = None,
		messageSecret = None,

		settings = True,
	):
		def _authenticateReturn(result = None):
			self._authenticateMessage(messageAfter)
			if functionAfter: functionAfter(result)
			if settings: self.settings()
			return result

		if not self.authenticated():
			self._authenticateMessage(messageNew)
			if functionNew and functionNew() is False: return _authenticateReturn()

		self._authenticateMessage(messageBefore)
		if functionBefore and functionBefore() is False: return _authenticateReturn()

		if self.authenticated():
			choice = Dialog.options(title = self._authenticateTitle(33101), message = 32511, labelConfirm = 32512, labelDeny = 33743, labelCustom = 32513)
			if choice == Dialog.ChoiceCustom:
				self._authenticateMessage(messageRevoke)
				if functionRevoke and functionRevoke() is False: return _authenticateReturn()
				self.reset()
				Dialog.notification(title = self._authenticateTitle(33101), message = 32514, icon = Dialog.IconWarning, duplicates = True)
				return _authenticateReturn()
			elif not choice == Dialog.ChoiceYes:
				return _authenticateReturn()

		result = None
		authenticate = True
		if functionExternal:
			result = functionExternal()
			if result:
				choice = Dialog.options(title = self._authenticateTitle(33101), message = 35829, labelConfirm = 33743, labelDeny = 35675, labelCustom = 35447)
				if choice == Dialog.ChoiceNo:
					authenticate = False
					if functionVerify:
						Loader.show()
						data = functionVerify(result)
						Loader.hide()
						if data:
							if Tools.isDictionary(data): result.update(data)
						else:
							result = False
				elif not choice == Dialog.ChoiceCustom:
					return _authenticateReturn()

		if authenticate:
			self._authenticateMessage(messageInitial)
			if functionInitial and functionInitial() is False: return _authenticateReturn()

			if self.mMode == Account.ModeOauth: result = self._authenticateOauth(functionInitiate = functionInitiate, functionVerify = functionVerify)
			elif self.mMode == Account.ModeUsername: result = self._authenticateUsername(functionInitiate = functionInitiate, functionVerify = functionVerify, functionUser = functionUser, functionSecret = functionSecret, messageVerify = messageVerify, messageUser = messageUser, messageSecret = messageSecret)
			elif self.mMode == Account.ModeEmail: result = self._authenticateEmail(functionInitiate = functionInitiate, functionVerify = functionVerify, functionUser = functionUser, functionSecret = functionSecret, messageVerify = messageVerify, messageUser = messageUser, messageSecret = messageSecret)
			elif self.mMode == Account.ModeKey: result = self._authenticateKey(functionInitiate = functionInitiate, functionVerify = functionVerify, functionSecret = functionSecret, messageUser = messageUser, messageVerify = messageVerify, messageSecret = messageSecret)
			elif self.mMode == Account.ModePin: result = self._authenticatePin(functionInitiate = functionInitiate, functionVerify = functionVerify, functionSecret = functionSecret, messageUser = messageUser, messageVerify = messageVerify, messageSecret = messageSecret)
			elif self.mMode == Account.ModeId: result = self._authenticateId(functionInitiate = functionInitiate, functionVerify = functionVerify, functionSecret = functionSecret, messageUser = messageUser, messageVerify = messageVerify, messageSecret = messageSecret)

			self._authenticateMessage(messageFinal)
			if functionFinal and functionFinal() is False: return _authenticateReturn()

		if result:
			self.update(data = result)
			Dialog.notification(title = self._authenticateTitle(33101), message = 35462, icon = Dialog.IconSuccess, duplicates = True)
		elif result is False:
			Dialog.notification(title = self._authenticateTitle(33101), message = 33218, icon = Dialog.IconError, duplicates = True)

		return _authenticateReturn(result)

	def _authenticateTitle(self, title):
		result = ''
		if self.mName: result += self.mName + ' '
		result += Translation.string(title)
		return result

	def _authenticateMessage(self, message):
		if message:
			if Tools.isString(message) or Tools.isInteger(message):
				Dialog.confirm(title = self._authenticateTitle(33101), message = message)
			else:
				if not 'title' in message: message['title'] = self._authenticateTitle(33101)
				if message['type'] == Dialog.TypeNotification: message['duplicates'] = True
				Dialog.show(**message)

	def _authenticateOauth(self, functionInitiate, functionVerify, parameters = None):
		try:
			Loader.show()
			dataInitiate = functionInitiate()
			if not dataInitiate:
				Loader.hide()
				return False

			try: expiration = dataInitiate[Account.AttributeExpiration]
			except: expiration = None
			if not expiration: expiration = Account.DefaultExpiration
			try: interval = dataInitiate[Account.AttributeInterval]
			except: interval = None
			if not interval: interval = Account.DefaultInterval
			link = dataInitiate[Account.AttributeLink]
			code = dataInitiate[Account.AttributeCode]

			# Show the link and token on top for skins that don't scroll text in a progress dialog.
			base = '%s: %s' + Format.newline()
			message = ''
			message += base % (Translation.string(33381), link)
			message += base % (Translation.string(33206), code)
			message = Format.fontBold(message) + Translation.string(33494)

			from lib.modules.clipboard import Clipboard
			Clipboard.copy(code)

			Loader.hide()
			dialog = Dialog.progress(title = self._authenticateTitle(33101), message = message, background = False)

			dataCheck = None
			iterations1 = int(expiration / interval)
			iterations2 = int(interval / Account.DefaultCancel)
			for i in range(iterations1):
				canceled = False
				for j in range(iterations2): # Make cancel more responsive.
					if dialog.iscanceled():
						canceled = True
						break
					Time.sleep(Account.DefaultCancel)
				if canceled: break

				dataCheck = functionVerify(dataInitiate)
				if dataCheck or dataCheck is False: break # None is returned if still busy.
			try: dialog.close()
			except: pass

			return dataCheck
		except:
			Loader.hide()
			Logger.error()
			return False

	def _authenticateBasic(self, id = None, username = None, email = None, password = None, key = None, pin = None, functionInitiate = None, functionVerify = None, functionUser = None, functionSecret = None, messageVerify = None, messageUser = None, messageSecret = None):
		if functionInitiate and functionInitiate() is False: return None

		result = {}
		if id: result[Account.AttributeId] = self.dataId()
		if username: result[Account.AttributeUsername] = self.dataUsername()
		if email: result[Account.AttributeEmail] = self.dataEmail()
		if password: result[Account.AttributePassword] = self.dataPassword()
		if key: result[Account.AttributeKey] = self.dataKey()
		if pin: result[Account.AttributePin] = self.dataPin()

		while True:
			if username or email or id:
				self._authenticateMessage(messageUser)
				if functionUser and functionUser() is False: return None
				if username:
					result[Account.AttributeUsername] = Dialog.input(title = self._authenticateTitle(33267), type = Dialog.InputAlphabetic, default = result[Account.AttributeUsername] if Account.AttributeUsername in result else None)
					if not result[Account.AttributeUsername]: return None # Cancel
				elif email:
					result[Account.AttributeEmail] = Dialog.input(title = self._authenticateTitle(32304), type = Dialog.InputAlphabetic, default = result[Account.AttributeEmail] if Account.AttributeEmail in result else None)
					if not result[Account.AttributeEmail]: return None # Cancel
				elif id:
					result[Account.AttributeId] = Dialog.input(title = self._authenticateTitle(32305), type = Dialog.InputAlphabetic, default = result[Account.AttributeId] if Account.AttributeId in result else None)
					if not result[Account.AttributeId]: return None # Cancel
			if password or key or pin:
				self._authenticateMessage(messageSecret)
				if functionSecret and functionSecret() is False: return None
				if password:
					result[Account.AttributePassword] = Dialog.input(title = self._authenticateTitle(32307), type = Dialog.InputAlphabetic, default = result[Account.AttributePassword] if Account.AttributePassword in result else None)
					if not result[Account.AttributePassword]: return None # Cancel
				elif key:
					result[Account.AttributeKey] = Dialog.input(title = self._authenticateTitle(33100), type = Dialog.InputAlphabetic, default = result[Account.AttributeKey] if Account.AttributeKey in result else None)
					if not result[Account.AttributeKey]: return None # Cancel
				elif pin:
					result[Account.AttributePin] = Dialog.input(title = self._authenticateTitle(33103), type = Dialog.InputAlphabetic, default = result[Account.AttributePin] if Account.AttributePin in result else None)
					if not result[Account.AttributePin]: return None # Cancel

			failed = False
			if result:
				if not functionVerify: return result
				Loader.show()
				data = functionVerify(result)
				Loader.hide()
				if data:
					if Tools.isDictionary(data): result.update(data)
					return result
				else:
					failed = True
			Dialog.notification(title = self._authenticateTitle(33101), message = 33978, icon = Dialog.IconError, duplicates = True)
			if failed: self._authenticateMessage(messageVerify)

		return False

	def _authenticateUsername(self, functionVerify = None, functionUser = None, functionInitiate = None, functionSecret = None, messageVerify = None, messageUser = None, messageSecret = None):
		return self._authenticateBasic(username = True, password = True, functionInitiate = functionInitiate, functionVerify = functionVerify, functionUser = functionUser, functionSecret = functionSecret, messageVerify = messageVerify, messageUser = messageUser, messageSecret = messageSecret)

	def _authenticateEmail(self, functionUser = None, functionInitiate = None, functionVerify = None, functionSecret = None, messageVerify = None, messageUser = None, messageSecret = None):
		return self._authenticateBasic(email = True, password = True, functionInitiate = functionInitiate, functionVerify = functionVerify, functionUser = functionUser, functionSecret = functionSecret, messageVerify = messageVerify, messageUser = messageUser, messageSecret = messageSecret)

	def _authenticateKey(self, functionSecret = None, functionInitiate = None, functionVerify = None, messageUser = None, messageVerify = None, messageSecret = None):
		return self._authenticateBasic(key = True, functionInitiate = functionInitiate, functionVerify = functionVerify, functionSecret = functionSecret, messageVerify = messageVerify, messageUser = messageUser, messageSecret = messageSecret)

	def _authenticatePin(self, functionSecret = None, functionInitiate = None, functionVerify = None, messageUser = None, messageVerify = None, messageSecret = None):
		return self._authenticateBasic(pin = True, functionInitiate = functionInitiate, functionVerify = functionVerify, functionSecret = functionSecret, messageVerify = messageVerify, messageUser = messageUser, messageSecret = messageSecret)

	def _authenticateId(self, functionSecret = None, functionInitiate = None, functionVerify = None, messageUser = None, messageVerify = None, messageSecret = None):
		return self._authenticateBasic(id = True, functionInitiate = functionInitiate, functionVerify = functionVerify, functionSecret = functionSecret, messageVerify = messageVerify, messageUser = messageUser, messageSecret = messageSecret)

class Premium(Account):

	def __init__(self,
		id,
		mode = None,

		name = None,
		description = None,
		free = None,

		linkDirect = None,
		linkRedirect = None,

		level = None,
		rank = None,
	):
		Account.__init__(self,
			id = id,
			mode = mode,

			name = name,
			description = description,
			free = free,

			linkDirect = linkDirect,
			linkRedirect = linkRedirect,

			level = level,
			rank = rank,
			category = Account.SettingsPremium,
		)

###################################################################
# YOUTUBE
###################################################################

class Youtube(Account):

	def __init__(self):
		from lib.modules.video import Video
		Account.__init__(self,
			id = 'youtube',
			mode = Account.ModeKey,

			name = 35296,
			description = 33988,

			linkDirect = Video.LinkRegister,
			linkRedirect = Video.LinkHelp,

			level = 1,
			rank = 4,
		)

	def authenticate(self, settings = True):
		from lib.modules.video import Video
		return Video().authentication(settings = settings)

	# This function called from video.py is necessary for the settings wizard.
	def _authenticate(self, messageNew = None, messageVerify = None, functionExternal = None, functionVerify = None, settings = True):
		return Account.authenticate(self, messageNew = messageNew, messageVerify = messageVerify, functionExternal = functionExternal, functionVerify = functionVerify, settings = settings)

###################################################################
# FANART
###################################################################

class Fanart(Account):

	Link = 'https://fanart.tv'
	LinkApi = 'https://fanart.tv/get-an-api-key/'

	def __init__(self):
		Account.__init__(self,
			id = 'fanart',
			mode = Account.ModeKey,

			name = 35260,
			description = 33934,

			linkDirect = Fanart.Link,
			linkRedirect = 'internal.link.fanart',

			level = 2,
			rank = 2,
		)

	def client(self):
		return System.obfuscate(Settings.getString('internal.key.fanart', raw = True))

	def headers(self, key = None):
		# It seems that the client (user) key is not required by Fanart. Only the API (addon) key is required.
		# The key can be anything and Fanart always returns the correct data.
		# So currently no Fanart user account is neccessary for Fanart to work, but still add this here in case they check the key in the future.
		headers = {'api-key' : self.client()}

		if not key: key = self.dataKey()
		if key: headers['client-key'] = key

		return headers

	def verify(self, data):
		result = Networker().requestJson(link = 'http://webservice.fanart.tv/v3/movies/tt0499549', headers = self.headers(key = data['key']))
		try: return 'imdb_id' in result
		except: return False

	def authenticate(self, settings = True):
		return Account.authenticate(self, functionVerify = self.verify, settings = settings, messageNew = {
			'type' : Dialog.TypeDetails, 'text' : False, 'items' : [
				{'type' : 'text', 'value' : 'Authenticate with your Personal API key which can be generated on Fanart\'s website:'},
				{'type' : 'link', 'value' : Fanart.LinkApi},
			]})

###################################################################
# TRAKT
###################################################################

class Trakt(Account):

	Link = 'https://trakt.tv'

	def __init__(self):
		Account.__init__(self,
			id = 'trakt',
			mode = Account.ModeOauth,

			name = 32315,
			description = 33931,

			linkDirect = Trakt.Link,
			linkRedirect = 'internal.link.trakt',

			level = 0,
			rank = 5,
		)

	def authenticate(self, settings = True):
		from lib.modules import trakt
		return trakt.authentication(settings = settings)

	# This function called from trakt.py is necessary for the settings wizard.
	def _authenticate(self, functionInitiate = None, functionVerify = None, settings = True):
		return Account.authenticate(self, functionInitiate = functionInitiate, functionVerify = functionVerify, settings = settings)

###################################################################
# IMDB
###################################################################

class Imdb(Account):

	Link		= 'https://imdb.com'
	LinkLogin	= 'https://imdb.com/login'
	LinkUser	= 'https://imdb.com/user'

	def __init__(self):
		Account.__init__(self,
			id = 'imdb',
			mode = Account.ModeId,

			name = 32034,
			description = 33910,

			linkDirect = Imdb.Link,
			linkRedirect = 'internal.link.imdb',

			level = 1,
			rank = 2,
		)

	def verify(self, data):
		from lib.modules.tools import Regex

		id = data[Account.AttributeId].lower()
		if not id.startswith('ur'): id = 'ur' + id
		data[Account.AttributeId] = id

		networker = Networker()
		result = networker.requestText(link = Networker.linkJoin(Imdb.LinkUser, id))
		if networker.responseSuccess() and result:
			username = Regex.extract(data = result, expression = '<title>(.*?)\'?s?\s*profile.*?<\/title>')
			if username:
				data[Account.AttributeUsername] = username
				return data
			return True
		return False

	def authenticate(self, settings = True):
		return Account.authenticate(self, functionVerify = self.verify, settings = settings, messageNew = {'type' : Dialog.TypeDetails, 'items' : [
			{'type' : 'text', 'value' : 'Authenticate IMDb with your user ID which can be found on IMDb\'s website.'},
			{'type' : 'link', 'value' : Imdb.LinkLogin},
			{'type' : 'list', 'number' : True, 'value' : [
				{'title' : 'Account Login', 'value' : 'Log into IMDb\'s website with your account.'},
				{'title' : 'Show Lists', 'value' : 'Open the menu under your username in the top right corner and navigate to [I]Your lists[/I].'},
				{'title' : 'Retrieve ID', 'value' : 'Your ID will show in the URL bar of your browser. The ID starts with the letters [I]ur[/I]  followed by digits.'},
			]},
			{'type' : 'text', 'value' : 'IMDb user lists are [I]private[/I]  by default. Lists you want to use in Gaia must be changed to [I]public[/I].'},
			{'type' : 'list', 'number' : True, 'value' : [
				{'title' : 'Show List', 'value' : 'Open the menu under your username in the top right corner and navigate to [I]Your lists[/I].'},
				{'title' : 'Open List', 'value' : 'Open the list of your choice. Besides your custom lists, your checkins and watchlist can also be accessed from the links under the heading.'},
				{'title' : 'Edit List', 'value' : 'Select the [I]Edit[/I]  option from the list\'s top right menu and then click the [I]Settings[/I] link.'},
				{'title' : 'Change Privacy', 'value' : 'Change the [I]Privacy[/I]  option to [I]Public[/I]. Click the [I]Save[/I]  button.'},
			]},
		]})

###################################################################
# TMDB
###################################################################

class Tmdb(Account):

	Link		= 'https://themoviedb.org'
	LinkApi		= 'https://www.themoviedb.org/settings/api'
	LinkVerify	= 'https://api.themoviedb.org/3/configuration?api_key='

	def __init__(self):
		Account.__init__(self,
			id = 'tmdb',
			mode = Account.ModeKey,

			name = 33508,
			description = 33933,

			linkDirect = Tmdb.Link,
			linkRedirect = 'internal.link.tmdb',

			level = 3,
			rank = 1,
		)

	def key(self):
		default = System.obfuscate(Settings.getString('internal.key.tmdb', raw = True))
		return self.dataKey(default)

	def verify(self, data):
		result = Networker().requestJson(link = Tmdb.LinkVerify + data[Account.AttributeKey])
		return bool(result and (not 'success' in result or result['success']))

	def authenticate(self, settings = True):
		messageNew = {'type' : Dialog.TypeDetails, 'text' : False, 'items' : [
			{'type' : 'text', 'value' : 'TMDb does not require user authentication and instead the addon will handle its own internal authentication. You will therefore not lose any addon functionality if you do not authenticate your own account. If you, however, still want to use your own custom API key, you can register a new development project on TMDb\'s website and generate a new API key for it:'},
			{'type' : 'link', 'value' : Tmdb.LinkApi},
		]}
		return Account.authenticate(self, functionVerify = self.verify, settings = settings, messageNew = messageNew)

###################################################################
# TVDB
###################################################################

class Tvdb(Account):

	Link			= 'https://themoviedb.org'
	LinkSubscribe	= 'https://thetvdb.com/subscribe'

	def __init__(self):
		Account.__init__(self,
			id = 'tvdb',
			mode = Account.ModePin,

			name = 35668,
			description = 33946,

			linkDirect = Tvdb.Link,
			linkRedirect = 'internal.link.tvdb',

			level = 3,
			rank = 1,
		)

	def key(self):
		return System.obfuscate(Settings.getString('internal.key.tvdb', raw = True))

	def verify(self, data):
		from lib.metadata.tvdb import Tvdb
		return Tvdb.authenticationVerify(pin = data[Account.AttributePin])

	def authenticate(self, settings = True):
		messageNew = {'type' : Dialog.TypeDetails, 'text' : False, 'items' : [
			{'type' : 'text', 'value' : 'TVDb does not require user authentication and instead the addon will handle its own internal authentication. You will therefore not lose any addon functionality if you do not authenticate your own account. If you, however, still want to use your own custom API pin, you can subscribe on TVDb\'s website to generate a new pin:'},
			{'type' : 'link', 'value' : Tvdb.LinkSubscribe},
		]}
		return Account.authenticate(self, functionVerify = self.verify, settings = settings, messageNew = messageNew)

###################################################################
# OPENSUBTITLES
###################################################################

class Opensubtitles(Account):

	Link = 'https://opensubtitles.org'

	def __init__(self):
		Account.__init__(self,
			id = 'opensubtitles',
			mode = Account.ModeUsername,

			name = 35683,
			description = 33987,

			linkDirect = Opensubtitles.Link,
			linkRedirect = 'internal.link.opensubtitles',

			level = 1,
			rank = 3,
		)

	def verify(self, data):
		from lib.modules.subtitle import Subtitle
		return Subtitle.verify(username = data[Account.AttributeUsername], password = data[Account.AttributePassword])

	def authenticate(self, settings = True):
		return Account.authenticate(self, functionVerify = self.verify, settings = settings, messageNew = {
			'type' : Dialog.TypeDetails, 'text' : False, 'items' : [
				{'type' : 'text', 'value' : 'Authenticate with your OpenSubtitles username and password:'},
				{'type' : 'link', 'value' : Opensubtitles.Link},
			]})

###################################################################
# ORION
###################################################################

class Orion(Premium):

	def __init__(self):
		from lib.modules.orionoid import Orionoid
		Premium.__init__(self,
			id = 'orion',
			mode = Account.ModeKey,

			name = 35400,
			description = 35408,
			free = True,

			linkDirect = Orionoid().link(),
			linkRedirect = 'internal.link.orion',

			level = 0,
			rank = 5,
		)

	def register(self):
		from lib.modules.orionoid import Orionoid
		Orionoid().accountPromotion(background = False) # Do not run in background, otherwise the account status in Gaia's settings wizard is not updated with the new value after Orion's dialogs close.
		return True # New account already authenticated.

	def authenticate(self, settings = True):
		from lib.modules.orionoid import Orionoid
		return Orionoid().accountAuthenticate(settings = settings, background = False) # Do not run in background, otherwise the account status in Gaia's settings wizard is not updated with the new value after Orion's dialogs close.

###################################################################
# PREMIUMIZE
###################################################################

class Premiumize(Premium):

	Link		= 'https://premiumize.me'
	LinkFree	= 'https://premiumize.me/free'

	def __init__(self):
		Premium.__init__(self,
			id = 'premiumize',
			mode = Premium.ModeOauth,

			name = 33566,
			description = 33939,

			linkDirect = Premiumize.Link,
			linkRedirect = 'internal.link.premiumize',

			level = 0,
			rank = 4,
		)

	def authenticate(self, settings = True):
		from lib.debrid.premiumize import Interface
		Interface().accountAuthentication(settings = settings)

	def _authenticate(self, functionInitiate, functionVerify, settings = True):
		return Premium.authenticate(self, functionInitiate = functionInitiate, functionVerify = functionVerify, settings = settings, messageNew = {
			'type' : Dialog.TypeDetails, 'text' : False, 'items' : [
				{'type' : 'text', 'value' : 'Premiumize offers paid and free accounts. Paid accounts are fast and unlimited. Free accounts are restricted and must be activated manually at:'},
				{'type' : 'link', 'value' : Premiumize.LinkFree},
			]})

###################################################################
# OFFCLOUD
###################################################################

class Offcloud(Premium):

	Link	= 'https://offcloud.com'
	LinkApi	= 'https://offcloud.com/#/account'

	def __init__(self):
		Premium.__init__(self,
			id = 'offcloud',
			mode = Premium.ModeKey,

			name = 35200,
			description = 35262,

			linkDirect = Offcloud.Link,
			linkRedirect = 'internal.link.offcloud',

			level = 0,
			rank = 4,
		)

	def authenticate(self, settings = True):
		from lib.debrid.offcloud import Interface
		Interface().accountAuthentication(settings = settings)

	def _authenticate(self, functionVerify, settings = True):
		return Premium.authenticate(self, functionVerify = functionVerify, settings = settings, messageNew = {
			'type' : Dialog.TypeDetails, 'text' : False, 'items' : [
				{'type' : 'text', 'value' : 'Authenticate with your API key which can be found on OffCloud\'s website under the Account tab:'},
				{'type' : 'link', 'value' : Offcloud.LinkApi},
			]})

###################################################################
# REALDEBRID
###################################################################

class Realdebrid(Premium):

	Link = 'https://real-debrid.com'

	def __init__(self):
		Premium.__init__(self,
			id = 'realdebrid',
			mode = Premium.ModeOauth,

			name = 33567,
			description = 33945,

			linkDirect = Realdebrid.Link,
			linkRedirect = 'internal.link.realdebrid',

			level = 0,
			rank = 4,
		)

	def authenticate(self, settings = True):
		from lib.debrid.realdebrid import Interface
		Interface().accountAuthentication(settings = settings)

	def _authenticate(self, functionInitiate, functionVerify, settings = True):
		return Premium.authenticate(self, functionInitiate = functionInitiate, functionVerify = functionVerify, settings = settings)

###################################################################
# EASYNEWS
###################################################################

class Easynews(Premium):

	Link		= 'https://easynews.com'
	LinkLogin	= 'https://members.easynews.com/login'

	def __init__(self):
		Premium.__init__(self,
			id = 'easynews',
			mode = Premium.ModeUsername,

			name = 33794,
			description = 33948,

			linkDirect = Easynews.Link,
			linkRedirect = 'internal.link.easynews',

			level = 0,
			rank = 3,
		)

	def authenticate(self, settings = True):
		from lib.debrid.easynews import Interface
		Interface().accountAuthentication(settings = settings)

	def _authenticate(self, functionVerify, settings = True):
		return Premium.authenticate(self, functionVerify = functionVerify, settings = settings, messageNew = {
			'type' : Dialog.TypeDetails, 'text' : False, 'items' : [
				{'type' : 'text', 'value' : 'Authenticate with your EasyNews username and password:'},
				{'type' : 'link', 'value' : Easynews.LinkLogin},
			]})


###################################################################
# GEOLOCATION
###################################################################

class Geolocation(Account):

	TypePrimary		= 'primary'
	TypeSecondary	= 'secondary'
	TypeTertiary 	= 'tertiary'

	Services	= {
		1 : {
			'name' : 36148,
			'service' : Geolocator.ServiceIpgeolocationio,
			'link' : 'https://ipgeolocation.io',
			'limit' : {
				'month' : 30000,
				'day' : 1000,
			},
		},
		2 : {
			'name' : 36149,
			'service' : Geolocator.ServiceGeoapifycom,
			'link' : 'https://geoapify.com',
			'limit' : {
				'day' : 3000,
				'second' : 5,
			},
		},
		3 : {
			'name' : 36150,
			'service' : Geolocator.ServiceIpinfodbcom,
			'link' : 'https://ipinfodb.com',
			'limit' : {
				'second' : 2,
			},
		},
		4 : {
			'name' : 36151,
			'service' : Geolocator.ServiceIpdataco,
			'link' : 'https://ipdata.co',
			'limit' : {
				'day' : 1500,
			},
		},
		5 : {
			'name' : 36152,
			'service' : Geolocator.ServiceBigdatacloudnet,
			'link' : 'https://bigdatacloud.net',
			'limit' : {
				'month' : 10000,
			},
		},
		6 : {
			'name' : 36153,
			'service' : Geolocator.ServiceIpapicom,
			'link' : 'http://ipapi.com',
			'limit' : {
				'month' : 1000,
			},
		},
		7 : {
			'name' : 36154,
			'service' : Geolocator.ServiceIpstackcom,
			'link' : 'http://ipstack.com',
			'limit' : {
				'month' : 100,
			},
		},
	}

	def __init__(self, type):
		try:
			self.mService = Geolocation.Services[Settings.getInteger(self.settingsId(category = 'network', id = type))]
			name = self.mService['name']
			linkDirect = self.mService['link']
			linkRedirect = 'internal.link.' + self.mService['service']
		except:
			self.mService = None
			name = None
			linkDirect = None
			linkRedirect = None

		Account.__init__(self,
			id = type,
			mode = Account.ModeKey,

			name = name,
			description = 33968,

			linkDirect = linkDirect,
			linkRedirect = linkRedirect,

			level = 2,
			rank = 1,
			category = 'network',
		)

	def settingsId(self, category = None, id = None, attribute = None):
		setting = '%s.geolocation.%s' % (category if category else self.mCategory, id if id else self.mId)
		if attribute: setting += '.' + attribute
		return setting

	def settingsIdEnabled(self):
		return self.settingsId()

	def enabled(self):
		return Settings.getInteger(id = self.settingsIdEnabled()) > 0

	def verify(self, data):
		result = Geolocator.detectGlobal(service = self.mService['service'], key = data['key'])
		if Geolocator.dataValid(result):
			data[Account.AttributeType] = self.mService['service'] # Always include the service type, so that if the users changes the "type" in the spin-list in the settings without reauthenticating, the actual type will still be retrieved from the database.
			return data
		return False

	def authenticate(self, settings = True):
		from lib.modules.tools import Math

		limit = []
		if 'month' in self.mService['limit']: limit.append('%s requests per month' % Math.thousand(self.mService['limit']['month']))
		if 'day' in self.mService['limit']: limit.append('%s requests per day' % Math.thousand(self.mService['limit']['day']))
		if 'minute' in self.mService['limit']: limit.append('%s requests per minute' % Math.thousand(self.mService['limit']['minute']))
		if 'second' in self.mService['limit']: limit.append('%s requests per second' % Math.thousand(self.mService['limit']['second']))

		count = len(limit)
		concatenate = Translation.string(33872).lower()
		if count == 1: limit = limit[0]
		elif count == 2: limit = '%s %s %s' % (limit[0], concatenate, limit[1])
		elif count == 3: limit = ', '.join([limit[0], limit[1], '%s %s' % (concatenate, limit[2])])
		elif count == 4: limit = ', '.join([limit[0], limit[1], limit[2], '%s %s' % (concatenate, limit[3])])

		messageNew = {'type' : Dialog.TypeDetails, 'text' : False, 'items' : [
			{'type' : 'text', 'value' : '%s is a public IP and geolocation lookup service. Free and paid accounts are available. Free accounts have limits of %s. A custom lookup service is only necessary if you use the [I]Generic[/I]  VPN detection feature, which continuously checks the public IP address to determine if the VPN is connected or not. If you do not use the VPN detection, you do not have to authenticate a personal account and instead rely on free internal services.' % (self.name(), limit)},
			{'type' : 'link', 'value' : self.linkDirect()},
		]}

		return Account.authenticate(self, functionVerify = self.verify, settings = settings, messageNew = messageNew)
