# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.modules.tools import Settings, Time, Hash, Media, System, File, Logger, Converter
from lib.modules.database import Database
from lib.modules.concurrency import Pool, Lock
from lib.modules import trakt

class Playback(Database):

	Table				= 'playback'

	# Values used by Trakt scrobble.
	ActionStart			= 'start'
	ActionPause			= 'pause'
	ActionStop			= 'stop'

	# Progress
	# Percent when video is considered to have started or ended.
	ProgressStart		= 0.01
	ProgressEndMovie	= 0.92
	ProgressEndShow		= 0.96

	# Interval
	# Interval in seconds when progress is updated with new values.
	IntervalExternal	= 300	# Trakt - 5 Minutes
	IntervalInternal	= 30	# Local - 30 Seconds.
	IntervalSeek		= 60	# Seeking position during playback. 60 Seconds.

	# Data
	DataProgress		= None

	def __init__(self):
		Database.__init__(self, Database.NamePlayback)
		self.mLock = Lock()
		self.mProgressPosition = None
		self.mProgressPause = 0
		self.mProgressInternal = {'action' : None, 'time' : 0}
		self.mProgressExternal = {'action' : None, 'time' : 0}

	def _initialize(self):
		self._create('''
			CREATE TABLE IF NOT EXISTS %s
			(
				idImdb TEXT UNIQUE,
				idTmdb TEXT UNIQUE,
				idTvdb TEXT UNIQUE,

				numberSeason INTEGER,
				numberEpisode INTEGER,

				timeStarted INTEGER,
				timeUpdated INTEGER,
				timeFinished INTEGER,

				duration INTEGER,

				progressAction TEXT,
				progressPercent REAL,
				progressDuration INTEGER,

				playCount INTEGER,
				playData INTEGER
			);
			''' % Playback.Table
		)

	def _lock(self):
		try: self.mLock.acquire()
		except: pass

	def _unlock(self):
		try: self.mLock.release()
		except: pass

	def _traktEnabled(self):
		if trakt.getTraktCredentialsInfo() is False: return False
		else: return Settings.getBoolean('playback.track.enabled') and Settings.getInteger('playback.track.progress.alternative') == 1

	def _query(self, imdb = None, tmdb = None, tvdb = None, season = None, episode = None):
		query = []

		if imdb: query.append('idImdb = "%s"' % str(imdb))
		if tmdb: query.append('idTmdb = "%s"' % str(tmdb))
		if tvdb: query.append('idTvdb = "%s"' % str(tvdb))
		query = ['(%s)' % ' OR '.join(query)]

		if not season is None: query.append('numberSeason = %s' % int(season))
		if not episode is None: query.append('numberEpisode = %s' % int(episode))

		return ' WHERE ' + (' AND '.join(query))

	def _retrieve(self, imdb = None, tmdb = None, tvdb = None, season = None, episode = None, single = False):
		data = self._select('''
			SELECT
				idImdb,
				idTmdb,
				idTvdb,

				numberSeason,
				numberEpisode,

				timeStarted,
				timeUpdated,
				timeFinished,

				duration,

				progressAction,
				progressPercent,
				progressDuration,

				playCount,
				playData
			FROM %s %s;
		''' % (Playback.Table, self._query(imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode)))

		result = None
		if data:
			result = []
			for item in data:
				result.append({
					'id' : {
						'imdb' : item[0],
						'tmdb' : item[1],
						'tvdb' : item[2],
					},
					'number' : {
						'season' : item[3],
						'episode' : item[4],
					},
					'time' : {
						'started' : item[5],
						'updated' : item[6],
						'finished' : item[7],
					},
					'duration' : item[8],
					'progress' : {
						'action' : item[9],
						'percent' : item[10],
						'duration' : item[11],
					},
					'play' : {
						'count' : item[12],
						'data' : Converter.jsonFrom(item[13]) if item[13] else [],
					},
				})

		return result[0] if result and single else result

	def progress(self, media, imdb = None, tmdb = None, tvdb = None, season = None, episode = None, adjust = False, internal = None, external = None):
		progress = None
		try:
			if external is None: external = True
			if internal is None: internal = True

			limit = None
			if adjust: limit = (Playback.ProgressStart, Playback.ProgressEndShow if Media.typeTelevision(media) else Playback.ProgressEndMovie)

			if external and self._traktEnabled():
				progress = trakt.scrobbleProgress(type = media, imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode, limit = (limit[0] * 100, limit[1] * 100) if limit else limit) # Set limit here for show/season progress.
				if progress: progress /= 100.0
				#Logger.log("MMMMMMMMMMMMMMMMMM1: "+str(progress))#gaiaremove

			if internal and progress is None:
				progress = self._retrieve(imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode, single = True)
				#Logger.log("MMMMMMMMMMMMMMMMMM2: "+str(progress))#gaiaremove
				if progress: progress = progress['progress']['percent']

			if progress and limit:
				if progress < limit[0] or progress > limit[1]: progress = 0
		except: Logger.error()
		return progress if progress else 0

	def progressUpdate(self, action, duration, current, media, imdb = None, tmdb = None, tvdb = None, season = None, episode = None, force = False, internal = None, external = None, wait = False):
		try:
			time = Time.timestamp() # Before the lock to get the time of the action, not the time the lock was released.
			self._lock() # This function can be called from player.py concurrently.

			if not force:
				# Update if there is a big jump in current playback position, such as seeking or changing chapters.
				if not action == Playback.ActionStart or (not self.mProgressPosition is None and not current is None and (abs(current - self.mProgressPosition) < Playback.IntervalSeek)):
					# The video is paused when the player buffers.
					# Only update every few minutes, otherwise there are too many Trakt calls.
					difference = None
					if internal is None:
						if action == self.mProgressInternal['action']: difference = time - self.mProgressInternal['time']
						elif action == Playback.ActionPause: difference = time - self.mProgressPause
						if difference: internal = difference > Playback.IntervalInternal
					if external is None:
						if action == self.mProgressExternal['action']: difference = time - self.mProgressExternal['time']
						elif action == Playback.ActionPause: difference = time - self.mProgressPause
						if difference: external = difference > Playback.IntervalExternal

			if internal is None: internal = True
			if external is None: external = True

			if force or internal or external:
				self.mProgressPosition = current
				if internal:
					self.mProgressInternal['action'] = action
					self.mProgressInternal['time'] = time
				if external:
					self.mProgressExternal['action'] = action
					self.mProgressExternal['time'] = time
				if action == Playback.ActionPause: self.mProgressPause = time

				if wait: self._progressUpdate(time = time, action = action, duration = duration, current = current, media = media, imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode, internal = internal, external = external)
				else: Pool.thread(target = self._progressUpdate, kwargs = {'time' : time, 'action' : action, 'duration' : duration, 'current' : current, 'media' : media, 'imdb' : imdb, 'tmdb' : tmdb, 'tvdb' : tvdb, 'season' : season, 'episode' : episode, 'internal' : internal, 'external' : external}, start = True)
			else:
				self._unlock()
		except:
			Logger.error()
			self._unlock()

	def _progressUpdate(self, action, duration, current, media, imdb = None, tmdb = None, tvdb = None, season = None, episode = None, internal = True, external = True, time = None):
		try:
			duration = int(duration)
			current = int(current)
			if current <= 0 or duration <= 0: percent = 0
			else: percent = current / float(duration)

			if internal:
				#Logger.log("YYYYYYYYYYYY1: "+str(action)+" * "+str(percent))#gaiaremove
				if time is None: time = Time.timestamp()
				self._insert('''
					INSERT OR IGNORE INTO %s
						(idImdb, idTmdb, idTvdb, numberSeason, numberEpisode, timeStarted)
					VALUES
						(?, ?, ?, ?, ?, ?);
				''' % Playback.Table, [imdb, tmdb, tvdb, season, episode, time])
				self._update('''
					UPDATE %s SET
						timeUpdated = ?,
						duration = ?,
						progressAction = ?,
						progressPercent = ?,
						progressDuration = ?
					%s;''' % (Playback.Table, self._query(imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode)), [time, duration, action, percent, current])

			if external and self._traktEnabled():
				#Logger.log("YYYYYYYYYYYY2: "+str(action)+" * "+str(percent * 100))#gaiaremove
				trakt.scrobbleUpdate(action = action, progress = percent * 100, type = type, imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode)
		except: Logger.error()
		self._unlock()

	def countUpdate(self, media = None, imdb = None, tmdb = None, tvdb = None, season = None, episode = None, force = False, internal = None, external = None, wait = False):
		time = Time.timestamp()
		self._lock()
		if wait: self._countUpdate(time = time, media = media, imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode, internal = internal, external = external)
		else: Pool.thread(target = self._countUpdate, kwargs = {'time' : time, 'media' : media, 'imdb' : imdb, 'tmdb' : tmdb, 'tvdb' : tvdb, 'season' : season, 'episode' : episode, 'internal' : internal, 'external' : external}, start = True)

	def _countUpdate(self, media = None, imdb = None, tmdb = None, tvdb = None, season = None, episode = None, internal = True, external = True, time = None):
		try:
			if internal:
				if time is None: time = Time.timestamp()

				playCount = 0
				playData = []
				data = self._retrieve(imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode, single = True)
				if data:
					playCount = data['play']['count']
					playData = data['play']['data']
				playCount += 1
				playData.append(time)

				self._insert('''
					INSERT OR IGNORE INTO %s
						(idImdb, idTmdb, idTvdb, numberSeason, numberEpisode, timeStarted)
					VALUES
						(?, ?, ?, ?, ?, ?);
				''' % Playback.Table, [imdb, tmdb, tvdb, season, episode, time])
				self._update('''
					UPDATE %s SET
						timeUpdated = ?,
						playCount,
						playData
					%s;''' % (Playback.Table, self._query(imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode)), [time, playCount, Converter.jsonTo(playData)])

			if external and self._traktEnabled():
				#Logger.log("YYYYYYYYYYYY2: "+str(action)+" * "+str(percent * 100))#gaiaremove
				trakt.scrobbleUpdate(action = action, progress = percent * 100, type = type, imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode)
		except: Logger.error()
		self._unlock()
