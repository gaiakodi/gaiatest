# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.providers.base import base
from lib.modules import network
from lib.modules import tools
from lib.modules.stream import Stream

class ProviderCenter(base.ProviderBase):

	def __init__(self, server):
		base.ProviderBase.__init__(self, supportMovies = True, supportShows = True)

		self.server = server

		self.pack = False # Checked by provider.py
		self.priority = 0
		self.language = ['un']

		self.base_link = self.server.link()
		self.domains = [network.Networker.linkDomain(self.base_link)]

	def instanceEnabled(self):
		return self.server.enabled()

	# gaiaremove - also add self.statisticsUpdateSearch(....)
	def sources(self, url, hostDict, hostprDict):
		sources = []
		try:
			if url == None: raise Exception()
			if not self.server.enabled(): raise Exception()

			data = self._decode(url)

			type = tools.Media.TypeShow if 'tvshowtitle' in data else tools.Media.TypeMovie
			imdb = data['imdb'] if 'imdb' in data else None
			if 'exact' in data and data['exact']:
				exact = True
				title = data['tvshowtitle'] if type == tools.Media.TypeShow else data['title']
				titles = None
				year = None
				season = None
				episode = None
			else:
				exact = False
				title = data['tvshowtitle'] if type == tools.Media.TypeShow else data['title']
				titles = data['alternatives'] if 'alternatives' in data else None
				year = int(data['year']) if 'year' in data and not data['year'] == None else None
				season = int(data['season']) if 'season' in data and not data['season'] == None else None
				episode = int(data['episode']) if 'episode' in data and not data['episode'] == None else None

			if not self._query(title, year, season, episode): return sources

			streams = self.server.search(type = type, title = title, year = year, season = season, episode = episode, exact = exact)
			if not streams: return sources

			# NB: Servers often return multiple streams that have the same links.
			# Often there are STRM streams without any metadata, and then a MKV with metadata that has the same link as the STRM.
			# First add all non-STRM streams to the results, and only add STRM streams if they do not have a link that is already in the results.
			links = []
			for container in ['strm', None]:
				for stream in streams:
					try:
						try: link = stream['stream']['link']
						except: continue
						if link in links: continue

						try:
							if container and container in stream['file']['container'].lower(): continue
						except: pass

						try: name = stream['file']['description']
						except: name = None
						try: name += ' [' + stream['file']['container'] + ']'
						except: pass
						try: size = stream['file']['size']
						except: size = None

						#gaiaremove
						meta = metadata.Metadata(name = name, title = title, titles = titles, year = year, season = season, episode = episode, size = size)
						meta.setType(metadata.Metadata.TypePremium)
						meta.setDirect(True)
						meta.setLink(link)

						try:
							if stream['video']['quality']: meta.setVideoQuality(stream['video']['quality'])
						except: pass
						try:
							if stream['video']['codec']: meta.setVideoCodec(stream['video']['codec'])
						except: pass
						try:
							if stream['video']['3d']: meta.setVideo3D(stream['video']['3d'])
						except: pass

						try:
							if stream['audio']['channels']: meta.setAudioChannels(stream['audio']['channels'])
						except: pass
						try:
							if stream['audio']['codec']: meta.setAudioCodec(stream['audio']['codec'])
						except: pass
						try:
							if stream['audio']['languages']: meta.setAudioLanguages(stream['audio']['languages'])
						except: pass

						try:
							if len(stream['subtitle']['languages']) > 0: meta.setSubtitlesSoft()
						except: pass

						try: source = stream['stream']['source']
						except: source = None

						try: language = stream['audio']['languages'][0]
						except: language = None

						try: quality = stream['video']['quality']
						except: quality = None
						if not quality: quality = meta.videoQuality() # Sometimes only the first file has MediaStreams info. Try to extract the quality from file name.

						sources.append({'url' : link, 'premium' : True, 'direct' : True, 'memberonly' : True, 'source' : source, 'language' : language, 'quality': quality, 'file' : name, 'metadata' : meta, 'external' : True, 'unique' : True})
						links.append(link)
					except:
						tools.Logger.error()

			return sources
		except:
			tools.Logger.error()
			return sources
