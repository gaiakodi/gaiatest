# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys
try: from urllib.parse import parse_qsl
except: from urlparse import parse_qsl

import xbmcaddon
developer = xbmcaddon.Addon().getAddonInfo('version') == '9.9.9'
if developer:
	import time as timer
	timeStart = timer.time()

from lib.modules import tools

params = dict(parse_qsl(sys.argv[2].replace('?', '')))
action = params.get('action')

if developer: tools.Logger.log('EXECUTION STARTED [Action: %s]' % str(action))

# Execute on first launch.
if action is None: tools.System.launch()

name = params.get('name')
title = params.get('title')
year = params.get('year')
imdb = params.get('imdb')
tmdb = params.get('tmdb')
tvdb = params.get('tvdb')
season = params.get('season')
episode = params.get('episode')
tvshowtitle = params.get('tvshowtitle')
premiered = params.get('premiered')
url = params.get('url')
link = params.get('link')
image = params.get('image')
query = params.get('query')

type = params.get('type')
kids = params.get('kids')
kids = 0 if kids is None or kids == '' else int(kids)

source = params.get('source')
if not source is None:
	source = tools.Converter.dictionary(source)
	if tools.Tools.isArray(source): source = source[0]

metadata = params.get('metadata')
if not metadata is None: metadata = tools.Converter.dictionary(metadata)

# LEAVE THIS HERE. Can be used by downloadsList for updating the directory list automatically in a thread.
# Stops downloader directory Updates
#if not action == 'download' and not (action == 'downloadsList' and not params.get('status') is None):
#	from lib.modules import downloader
#	downloader.Downloader.itemsStop()

from lib.modules import shortcuts
shortcuts.Shortcuts.process(params)

# Always check, not only on the main menu (action is None), since skin widgets also call the addon.
#tools.System.observe()

if action is None or action == 'home':
	from lib.indexers import navigator
	navigator.navigator(type = type, kids = kids).root()
	tools.System.restartFinish() # Reset the restart flag here, since an addon restart will end up in this function.

####################################################
# MOVIE
####################################################

elif action.startswith('movies'):

	if action == 'movies':
		from lib.indexers import navigator
		lite = tools.Converter.boolean(params.get('lite'))
		navigator.navigator(type = type, kids = kids).movies(lite = lite)

	elif action == 'moviesFavourites':
		from lib.indexers import navigator
		lite = tools.Converter.boolean(params.get('lite'))
		navigator.navigator(type = type, kids = kids).moviesFavourites(lite = lite)

	elif action == 'moviesRetrieve':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).get(url)

	elif action == 'moviesSearch':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).search(params.get('terms'))

	elif action == 'moviesSearches':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).moviesSearches()

	elif action == 'moviesPerson':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).person(params.get('terms'))

	elif action == 'moviesPersons':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).persons(url)

	elif action == 'moviesHome':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).home()

	elif action == 'moviesArrivals':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).arrivals()

	elif action == 'moviesCollections':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).collections()

	elif action == 'moviesGenres':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).genres()

	elif action == 'moviesLanguages':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).languages()

	elif action == 'moviesCertificates':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).certifications()

	elif action == 'moviesAge':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).age()

	elif action == 'moviesYears':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).years()

	elif action == 'moviesUserlists':
		from lib.indexers import movies
		mode = params.get('mode')
		watchlist = tools.Converter.boolean(params.get('watchlist'))
		movies.movies(type = type, kids = kids).userlists(mode = mode, watchlist = watchlist)

	elif action == 'moviesDrugs':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).moviesDrugs()

	elif action == 'moviesRandom':
		from lib.indexers import movies
		movies.movies(type = type, kids = kids).random()

	elif action == 'moviesCategories':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).moviesCategories()

	elif action == 'moviesLists':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).moviesLists()

	elif action == 'moviesPeople':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).moviesPeople()

	elif action == 'moviesWatch':
		from lib.indexers import movies
		movies.movies.markWatch(imdb = imdb, tmdb = tmdb)

	elif action == 'moviesUnwatch':
		from lib.indexers import movies
		movies.movies.markUnwatch(imdb = imdb, tmdb = tmdb)

####################################################
# TV
####################################################

elif action.startswith('shows'):

	if action == 'shows':
		from lib.indexers import navigator
		lite = tools.Converter.boolean(params.get('lite'))
		navigator.navigator(type = type, kids = kids).shows(lite = lite)

	elif action == 'showsFavourites':
		from lib.indexers import navigator
		lite = tools.Converter.boolean(params.get('lite'))
		navigator.navigator(type = type, kids = kids).showsFavourites(lite = lite)

	elif action == 'showsRetrieve':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).get(url)

	elif action == 'showsSearch':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).search(params.get('terms'))

	elif action == 'showsSearches':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).showsSearches()

	elif action == 'showsGenres':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).genres()

	elif action == 'showsNetworks':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).networks()

	elif action == 'showsCertificates':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).certifications()

	elif action == 'showsAge':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).age()

	elif action == 'showsPerson':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).person(params.get('terms'))

	elif action == 'showsPersons':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).persons(url)

	elif action == 'showsUserlists':
		from lib.indexers import shows
		mode = params.get('mode')
		watchlist = tools.Converter.boolean(params.get('watchlist'))
		shows.shows(type = type, kids = kids).userlists(mode = mode, watchlist = watchlist)

	elif action == 'showsRandom':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).random()

	elif action == 'showsHome':
		from lib.indexers import episodes
		episodes.episodes(type = type, kids = kids).home()

	elif action == 'showsArrivals':
		from lib.indexers import episodes
		episodes.episodes(type = type, kids = kids).arrivals()

	elif action == 'showsCalendar':
		from lib.indexers import episodes
		episodes.episodes(type = type, kids = kids).calendar(url)

	elif action == 'showsCalendars':
		from lib.indexers import episodes
		episodes.episodes(type = type, kids = kids).calendars()

	elif action == 'showsCategories':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).showsCategories()

	elif action == 'showsLists':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).showsLists()

	elif action == 'showsPeople':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).showsPeople()

	elif action == 'showsYears':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).years()

	elif action == 'showsLanguages':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).languages()

	elif action == 'showsWatch':
		from lib.indexers import shows
		shows.shows.markWatch(title = title, imdb = imdb, tvdb = tvdb)

	elif action == 'showsUnwatch':
		from lib.indexers import shows
		shows.shows.markUnwatch(title = title, imdb = imdb, tvdb = tvdb)

	elif action == 'showsBinge':
		from lib.indexers import shows
		shows.shows(type = type, kids = kids).next(scrape = True, title = title, year = year, imdb = imdb, tvdb = tvdb, season = season, episode = episode)

####################################################
# SEASON
####################################################

elif action.startswith('seasons'):

	if action == 'seasonsRetrieve':
		from lib.indexers import seasons
		seasons.seasons(type = type, kids = kids).get(tvshowtitle, year, imdb, tvdb)

	elif action == 'seasonsUserlists':
		from lib.indexers import seasons
		mode = params.get('mode')
		watchlist = tools.Converter.boolean(params.get('watchlist'))
		seasons.seasons(type = type, kids = kids).userlists(mode = mode, watchlist = watchlist)

	elif action == 'seasonsList':
		from lib.indexers import seasons
		seasons.seasons(type = type, kids = kids).seasonList(url)

	elif action == 'seasonsWatch':
		from lib.indexers import seasons
		seasons.seasons.markWatch(title = title, imdb = imdb, tvdb = tvdb, season = season)

	elif action == 'seasonsUnwatch':
		from lib.indexers import seasons
		seasons.seasons.markUnwatch(title = title, imdb = imdb, tvdb = tvdb, season = season)

	elif action == 'seasonsExtras':
		from lib.indexers import seasons
		art = params.get('art')
		if tools.Tools.isString(metadata): metadata = tools.Converter.jsonFrom(metadata)
		if tools.Tools.isString(art): art = tools.Converter.jsonFrom(art)
		seasons.seasons(type = type, kids = kids).extras(metadata = metadata, art = art)

####################################################
# EPISODE
####################################################

elif action.startswith('episodes'):

	if action == 'episodesRetrieve':
		from lib.indexers import episodes
		episodes.episodes(type = type, kids = kids).get(tvshowtitle, year, imdb, tvdb, season, episode)

	elif action == 'episodesUserlists':
		from lib.indexers import episodes
		mode = params.get('mode')
		watchlist = tools.Converter.boolean(params.get('watchlist'))
		episodes.episodes(type = type, kids = kids).userlists(mode = mode, watchlist = watchlist)

	elif action == 'episodesUnfinished':
		from lib.indexers import episodes
		episodes.episodes(type = type, kids = kids).unfinished()

	elif action == 'episodesWatch':
		from lib.indexers import episodes
		episodes.episodes.markWatch(title = title, imdb = imdb, tvdb = tvdb, season = season, episode = episode)

	elif action == 'episodesUnwatch':
		from lib.indexers import episodes
		episodes.episodes.markUnwatch(title = title, imdb = imdb, tvdb = tvdb, season = season, episode = episode)

####################################################
# SYSTEM
####################################################

elif action.startswith('system'):

	if action == 'systemNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).systemNavigator()

	elif action == 'systemInformation':
		tools.System.information()

	elif action == 'systemManager':
		tools.System.manager()

	if action == 'systemBenchmark':
		from lib.modules.tester import Tester
		Tester.benchmarkDialog()

	elif action == 'systemClean':
		tools.System.clean()

	elif action == 'systemRestart':
		tools.System.restart()

	elif action == 'systemPsutil':
		tools.Platform.psutilTest()

####################################################
# UTILITY
####################################################

elif action.startswith('utility'):

	if action == 'utilityNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).utilityNavigator()

####################################################
# NFORMATION
####################################################

elif action.startswith('information'):

	if action == 'informationNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).informationNavigator()

	elif action == 'informationPremium':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).informationPremium()

	elif action == 'informationSplash':
		from lib.modules import interface
		interface.Splash.popupFull()

	elif action == 'informationChangelog':
		from lib.modules import interface
		interface.Changelog.show()

	elif action == 'informationDisclaimer':
		from lib.modules import interface
		interface.Legal.show(exit = True)

	elif action == 'informationAnnouncement':
		tools.Announcements.show(force = True)

	elif action == 'informationAttribution':
		from lib.modules.window import WindowAttribution
		WindowAttribution.show(progress = False)

	elif action == 'informationAbout':
		from lib.modules import interface
		interface.Splash.popupAbout()

####################################################
# PROMOTIONS
####################################################

elif action.startswith('promotions'):

	if action == 'promotionsNavigator':
		tools.Promotions.navigator(force = tools.Converter.boolean(params.get('force')))

	elif action == 'promotionsSelect':
		tools.Promotions.select(provider = params.get('provider'))

####################################################
# PLAYLIST
####################################################

elif action.startswith('playlist'): # Must be before the 'play' section.

	if action == 'playlistShow':
		tools.Playlist.show()

	elif action == 'playlistClear':
		tools.Playlist.clear()

	elif action == 'playlistAdd':
		label = tools.Converter.quoteFrom(params.get('label'))
		art = params.get('art')
		context = params.get('context')
		tools.Playlist.add(link = link, label = label, metadata = metadata, art = art, context = context)

	elif action == 'playlistRemove':
		label = params.get('label')
		tools.Playlist.remove(label = label)

####################################################
# PLAY
####################################################

elif action.startswith('play'):

	if action == 'play':
		if not tools.System.globalLocked(id = 'play'): # Check playcount.py for more details.
			from lib.modules import interface
			from lib.modules import core
			interface.Loader.show() # Immediately show the loader, since slow system will take long to show it in play().
			try: binge = int(params.get('binge'))
			except: binge = None
			try: resume = int(params.get('resume'))
			except: resume = None
			try: autoplay = tools.Converter.boolean(params.get('autoplay'))
			except: autoplay = False
			try: library = tools.Converter.boolean(params.get('library'))
			except: library = False
			try: new = tools.Converter.boolean(params.get('new'))
			except: new = False
			try: add = tools.Converter.boolean(params.get('add'))
			except: add = False
			downloadType = params.get('downloadType')
			downloadId = params.get('downloadId')
			handleMode = params.get('handleMode')
			core.Core(type = type, kids = kids).play(source = source, metadata = metadata, downloadType = downloadType, downloadId = downloadId, handleMode = handleMode, autoplay = autoplay, library = library, new = new, add = add, binge = binge, resume = resume)

	if action == 'playCache':
		from lib.modules import core
		try: binge = int(params.get('binge'))
		except: binge = None
		handleMode = params.get('handleMode')
		core.Core(type = type, kids = kids).playCache(source = source, metadata = metadata, handleMode = handleMode, binge = binge)

	elif action == 'playLocal':
		from lib.modules import core
		try: binge = int(params.get('binge'))
		except: binge = None
		path = params.get('path')
		downloadType = params.get('downloadType')
		downloadId = params.get('downloadId')
		core.Core(type = type, kids = kids).playLocal(path = path, source = source, metadata = metadata, downloadType = downloadType, downloadId = downloadId, binge = binge)

####################################################
# CLEAN
####################################################

elif action.startswith('clean'):

	if action == 'cleanNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).cleanNavigator()

	elif action == 'cleanAll':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).cleanAll()

	elif action == 'cleanCache':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).cleanCache()

	elif action == 'cleanProviders':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).cleanProviders()

	elif action == 'cleanMetadata':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).cleanMetadata()

	elif action == 'cleanHistory':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).cleanHistory()

	elif action == 'cleanShortcuts':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).cleanShortcuts()

	elif action == 'cleanSearches':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).cleanSearches()

	elif action == 'cleanTrailers':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).cleanTrailers()

	elif action == 'cleanDownloads':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).cleanDownloads()

	elif action == 'cleanTemporary':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).cleanTemporary()

####################################################
# VERIFICATION
####################################################

elif action.startswith('verification'):

	if action == 'verificationProviders':
		from lib.modules import interface
		interface.Dialog.notification(title='Not Implemented', message='Feature not implemented yet.', icon=interface.Dialog.IconError)#gaiaremove
		#from lib.modules import verification#gaiaremove
		#verification.Verification().verifyProviders()#gaiaremove

	elif action == 'verificationAccounts':
		from lib.modules import interface
		interface.Dialog.notification(title='Not Implemented', message='Feature not implemented yet.', icon=interface.Dialog.IconError)#gaiaremove
		#from lib.modules import verification
		#verification.Verification().verifyAccounts()

	elif action == 'verificationNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).verificationNavigator()

####################################################
# SEARCH
####################################################

elif action.startswith('search'):

	if action == 'search':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).search()

	elif action == 'searchExact':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).searchExact()

	elif action == 'searchRecent':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).searchRecent()

	elif action == 'searchRecentMovies':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).searchRecentMovies()

	elif action == 'searchRecentShows':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).searchRecentShows()

####################################################
# PROVIDERS
####################################################

elif action.startswith('providers'):

	if action == 'providersPresets':
		from lib.providers.core.manager import Manager
		settings = tools.Converter.boolean(params.get('settings'))
		Manager.presets(settings = settings)

	elif action == 'providersConfigure':
		from lib.modules.interface import Loader
		Loader.show() # Show here already for slow devices.
		from lib.providers.core.manager import Manager
		id = params.get('id')
		type = params.get('type')
		mode = params.get('mode')
		access = params.get('access')
		addon = params.get('addon')
		settings = tools.Converter.boolean(params.get('settings'))
		Manager.settings(id = id, type = type, mode = mode, access = access, addon = addon, settings = settings)

	elif action == 'providersVerify':
		from lib.providers.core.manager import Manager
		Manager.verify()

	elif action == 'providersOptimize':
		from lib.providers.core.manager import Manager
		settings = tools.Converter.boolean(params.get('settings'))
		Manager.optimizeProvider(settings = settings)

####################################################
# DOWNLOADS
####################################################

elif action.startswith('download'):

	if action == 'download':
		try:
			from lib.modules import core
			from lib.modules import downloader
			from lib.modules import interface
			interface.Loader.show()
			downloadType = params.get('downloadType')
			downloadId = params.get('downloadId')
			refresh = tools.Converter.boolean(params.get('refresh'))
			downer = downloader.Downloader(downloadType)
			if downloadId is None:
				image = params.get('image')
				handleMode = params.get('handleMode')
				link = core.Core(type = type, kids = kids).sourceResolve(source, info = True, internal = False, download = True, handleMode = handleMode)['link']
				if link is None:
					interface.Loader.hide()
				else:
					title = tools.Media.title(type = type, metadata = metadata)
					downer.download(media = type, title = title, link = link, image = image, metadata = metadata, source = source, refresh = refresh)
			else:
				downer.download(id = downloadId, forceAction = True, refresh = refresh)
		except:
			interface.Loader.hide()
			tools.Logger.error()

	elif action == 'downloadDetails':
		from lib.modules import downloader
		downloadType = params.get('downloadType')
		downloadId = params.get('downloadId')
		downloader.Downloader(type = downloadType, id = downloadId).details()

	elif action == 'downloads':
		from lib.indexers import navigator
		downloadType = params.get('downloadType')
		navigator.navigator(type = type, kids = kids).downloads(downloadType)

	elif action == 'downloadsManager':
		from lib.modules import downloader
		downloadType = params.get('downloadType')
		if downloadType is None: downloadType = downloader.Downloader.TypeManual
		downer = downloader.Downloader(type = downloadType)
		downer.items(status = downloader.Downloader.StatusAll, refresh = False)

	elif action == 'downloadsBrowse':
		from lib.indexers import navigator
		downloadType = params.get('downloadType')
		downloadError = params.get('downloadError')
		navigator.navigator(type = type, kids = kids).downloadsBrowse(downloadType, downloadError)

	elif action == 'downloadsList':
		downloadType = params.get('downloadType')
		downloadStatus = params.get('downloadStatus')
		if downloadStatus is None:
			from lib.indexers import navigator
			navigator.navigator(type = type, kids = kids).downloadsList(downloadType)
		else:
			from lib.modules import downloader
			downer = downloader.Downloader(downloadType)
			# Do not refresh the list using a thread. Seems like the thread is not always stopped and then it ends with multiple threads updating the list.
			# During the update duration multiple refreshes sometimes happen due to this. Hence, you will see the loader flash multiple times during the 10 secs.
			# Also, with a fresh the front progress dialog also flashes and reset it's focus.
			#downer.items(status = status, refresh = True)
			downer.items(status = downloadStatus, refresh = False)

	elif action == 'downloadsClear':
		downloadType = params.get('downloadType')
		downloadStatus = params.get('downloadStatus')
		if downloadStatus is None:
			from lib.indexers import navigator
			navigator.navigator(type = type, kids = kids).downloadsClear(downloadType)
		else:
			from lib.modules import downloader
			downer = downloader.Downloader(downloadType)
			downer.clear(status = downloadStatus)

	elif action == 'downloadsRefresh':
		from lib.modules import downloader
		downloadType = params.get('downloadType')
		downer = downloader.Downloader(downloadType)
		downer.itemsRefresh()

	elif action == 'downloadsSettings':
		tools.Settings.launch(tools.Settings.CategoryDownload)

	elif action == 'downloadCloud':
		from lib.modules import core
		core.Core(type = type, kids = kids).sourceCloud(source)

####################################################
# AMBILIGHT
####################################################

elif action.startswith('ambilight'):

	if action == 'ambilightNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).ambilightNavigator()

####################################################
# LIGHTPACK
####################################################

elif action.startswith('lightpack'):

	if action == 'lightpackNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).lightpackNavigator()

	elif action == 'lightpackSwitchOn':
		tools.Lightpack().switchOn(message = True)

	elif action == 'lightpackSwitchOff':
		tools.Lightpack().switchOff(message = True)

	elif action == 'lightpackAnimate':
		force = params.get('force')
		force = True if force is None else tools.Converter.boolean(force)
		tools.Lightpack().animate(force = force, message = True, delay = True)

	elif action == 'lightpackSettings':
		tools.Lightpack().settings()

####################################################
# KIDS
####################################################

elif action.startswith('kids'):

	if action == 'kids':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).kids()

	elif action == 'kidsLock':
		tools.Kids.lock()

	elif action == 'kidsUnlock':
		tools.Kids.unlock()

####################################################
# DOCUMENTARIES
####################################################

elif action.startswith('documentaries'):

	if action == 'documentaries':
		from lib.indexers import navigator
		navigator.navigator(type = tools.Media.TypeDocumentary, kids = kids).movies()

####################################################
# SHORTS
####################################################

elif action.startswith('shorts'):

	if action == 'shorts':
		from lib.indexers import navigator
		navigator.navigator(type = tools.Media.TypeShort, kids = kids).movies()

####################################################
# SHORTS
####################################################

elif action.startswith('channels'):

	if action == 'channels':
		from lib.indexers import channels
		channels.channels(type = type, kids = kids).getGroups()

	elif action == 'channelsRetrieve':
		from lib.indexers import channels
		group = params.get('group')
		channels.channels(type = type, kids = kids).getChannels(group = group)

####################################################
# SERVICES
####################################################

elif action.startswith('services'):

	if action == 'servicesNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).servicesNavigator()

	elif action == 'servicesPremiumNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).servicesPremiumNavigator()

	elif action == 'servicesScraperNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).servicesScraperNavigator()

	elif action == 'servicesResolverNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).servicesResolverNavigator()

	elif action == 'servicesDownloaderNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).servicesDownloaderNavigator()

	elif action == 'servicesUtilityNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).servicesUtilityNavigator()

####################################################
# PREMIUMIZE
####################################################

elif action.startswith('premiumize'):

	if action == 'premiumizeAuthentication':
		from lib.debrid import premiumize
		settings = tools.Converter.boolean(params.get('settings'))
		premiumize.Interface().accountAuthentication(settings = settings)

	elif action == 'premiumizeNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).premiumizeNavigator()

	elif action == 'premiumizeDownloadsNavigator':
		from lib.indexers import navigator
		lite = tools.Converter.boolean(params.get('lite'))
		navigator.navigator(type = type, kids = kids).premiumizeDownloadsNavigator(lite = lite)

	elif action == 'premiumizeList':
		from lib.debrid import premiumize
		premiumize.Interface().directoryList()

	elif action == 'premiumizeListAction':
		from lib.debrid import premiumize
		item = params.get('item')
		context = params.get('context')
		premiumize.Interface().directoryListAction(item, context)

	elif action == 'premiumizeItem':
		from lib.debrid import premiumize
		item = params.get('item')
		premiumize.Interface().directoryItem(item)

	elif action == 'premiumizeItemAction':
		from lib.debrid import premiumize
		item = params.get('item')
		premiumize.Interface().directoryItemAction(item)

	elif action == 'premiumizeAdd':
		from lib.debrid import premiumize
		premiumize.Interface().addManual()

	elif action == 'premiumizeInformation':
		from lib.debrid import premiumize
		premiumize.Interface().downloadInformation()

	elif action == 'premiumizeAccount':
		from lib.debrid import premiumize
		premiumize.Interface().account()

	elif action == 'premiumizeWebsite':
		from lib.debrid import premiumize
		premiumize.Core().website(open = True)

	elif action == 'premiumizeVpn':
		from lib.debrid import premiumize
		premiumize.Core().vpn(open = True)

	elif action == 'premiumizeClear':
		from lib.debrid import premiumize
		premiumize.Interface().clear()

	elif action == 'premiumizeSettings':
		tools.Settings.launch(id = 'premium.premiumize.enabled')

####################################################
# PREMIUMIZE
####################################################

elif action.startswith('offcloud'):

	if action == 'offcloudAuthentication':
		from lib.debrid import offcloud
		settings = tools.Converter.boolean(params.get('settings'))
		offcloud.Interface().accountAuthentication(settings = settings)

	elif action == 'offcloudNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).offcloudNavigator()

	elif action == 'offcloudDownloadsNavigator':
		from lib.indexers import navigator
		lite = tools.Converter.boolean(params.get('lite'))
		category = params.get('category')
		navigator.navigator(type = type, kids = kids).offcloudDownloadsNavigator(lite = lite, category = category)

	elif action == 'offcloudList':
		from lib.debrid import offcloud
		category = params.get('category')
		offcloud.Interface().directoryList(category = category)

	elif action == 'offcloudListAction':
		from lib.debrid import offcloud
		item = params.get('item')
		context = params.get('context')
		offcloud.Interface().directoryListAction(item = item, context = context)

	elif action == 'poffcloudItem':
		from lib.debrid import offcloud
		item = params.get('item')
		offcloud.Interface().directoryItem(item)

	elif action == 'offcloudItemAction':
		from lib.debrid import offcloud
		item = params.get('item')
		offcloud.Interface().directoryItemAction(item)

	elif action == 'offcloudAdd':
		from lib.debrid import offcloud
		category = params.get('category')
		offcloud.Interface().addManual(category = category)

	elif action == 'offcloudInformation':
		from lib.debrid import offcloud
		category = params.get('category')
		offcloud.Interface().downloadInformation(category = category)

	elif action == 'offcloudAdd':
		from lib.debrid import offcloud
		offcloud.Interface().addManual()

	elif action == 'offcloudAccount':
		from lib.debrid import offcloud
		offcloud.Interface().account()

	elif action == 'offcloudWebsite':
		from lib.debrid import offcloud
		offcloud.Core().website(open = True)

	elif action == 'offcloudClear':
		from lib.debrid import offcloud
		category = params.get('category')
		offcloud.Interface().clear(category = category)

	elif action == 'offcloudSettings':
		tools.Settings.launch(id = 'premium.offcloud.enabled')

	elif action == 'offcloudSettingsLocation':
		from lib.debrid import offcloud
		offcloud.Interface().settingsLocation()

####################################################
# REALDEBRID
####################################################

elif action.startswith('realdebrid'):

	if action == 'realdebridAuthentication':
		from lib.debrid import realdebrid
		settings = tools.Converter.boolean(params.get('settings'))
		realdebrid.Interface().accountAuthentication(settings = settings)

	elif action == 'realdebridNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).realdebridNavigator()

	elif action == 'realdebridDownloadsNavigator':
		from lib.indexers import navigator
		lite = tools.Converter.boolean(params.get('lite'))
		navigator.navigator(type = type, kids = kids).realdebridDownloadsNavigator(lite = lite)

	elif action == 'realdebridList':
		from lib.debrid import realdebrid
		realdebrid.Interface().directoryList()

	elif action == 'realdebridListAction':
		from lib.debrid import realdebrid
		item = params.get('item')
		realdebrid.Interface().directoryListAction(item)

	elif action == 'realdebridAdd':
		from lib.debrid import realdebrid
		realdebrid.Interface().addManual()

	elif action == 'realdebridInformation':
		from lib.debrid import realdebrid
		realdebrid.Interface().downloadInformation()

	elif action == 'realdebridAccount':
		from lib.debrid import realdebrid
		realdebrid.Interface().account()

	elif action == 'realdebridWebsite':
		from lib.debrid import realdebrid
		realdebrid.Core().website(open = True)

	elif action == 'realdebridClear':
		from lib.debrid import realdebrid
		realdebrid.Interface().clear()

	elif action == 'realdebridSettings':
		tools.Settings.launch(id = 'premium.realdebrid.enabled')

####################################################
# EASYNEWS
####################################################

elif action.startswith('easynews'):

	if action == 'easynewsAuthentication':
		from lib.debrid import easynews
		settings = tools.Converter.boolean(params.get('settings'))
		easynews.Interface().accountAuthentication(settings = settings)

	elif action == 'easynewsNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).easynewsNavigator()

	elif action == 'easynewsAccount':
		from lib.debrid import easynews
		easynews.Interface().account()

	elif action == 'easynewsWebsite':
		from lib.debrid import easynews
		easynews.Core().website(open = True)

	elif action == 'easynewsVpn':
		from lib.debrid import easynews
		easynews.Core().vpn(open = True)

	elif action == 'easynewsSettings':
		tools.Settings.launch(id = 'premium.realdebrid.easynews')

####################################################
# EMBY
####################################################

elif action.startswith('emby'):

	if action == 'embyNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).embyNavigator()

	elif action == 'embySettings':
		from lib.centers import emby
		emby.Emby().settings()

	elif action == 'embyWebsite':
		from lib.centers import emby
		emby.Emby().website(open = True)

####################################################
# JELLYFIN
####################################################

elif action.startswith('jellyfin'):

	if action == 'jellyfinNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).jellyfinNavigator()

	elif action == 'jellyfinSettings':
		from lib.centers import jellyfin
		jellyfin.Jellyfin().settings()

	elif action == 'jellyfinWebsite':
		from lib.centers import jellyfin
		jellyfin.Jellyfin().website(open = True)

####################################################
# ELEMENTUM
####################################################

elif action.startswith('elementum'):

	if action == 'elementumNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).elementumNavigator()

	elif action == 'elementumConnect':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.Elementum.connect(install = False, settings = settings)

	elif action == 'elementumInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		help = tools.Converter.boolean(params.get('help'))
		tools.Elementum.connect(install = True, settings = settings, help = help)

	elif action == 'elementumLaunch':
		tools.Elementum.launch()

	elif action == 'elementumInterface':
		tools.Elementum.interface()

	elif action == 'elementumSettings':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.Elementum.settings(settings = settings)

####################################################
# QUASAR
####################################################

elif action.startswith('quasar'):

	if action == 'quasarNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).quasarNavigator()

	elif action == 'quasarConnect':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.Quasar.connect(install = False, settings = settings)

	elif action == 'quasarInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		help = tools.Converter.boolean(params.get('help'))
		tools.Quasar.connect(install = True, settings = settings, help = help)

	elif action == 'quasarLaunch':
		tools.Quasar.launch()

	elif action == 'quasarInterface':
		tools.Quasar.interface()

	elif action == 'quasarSettings':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.Quasar.settings(settings = settings)

####################################################
# RESOLVER
####################################################

elif action.startswith('resolver'):

	if action == 'resolverAuthentication':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.Resolver.authentication(type = type, settings = settings)

	elif action == 'resolverInstall':
		help = tools.Converter.boolean(params.get('settings'))
		settings = tools.Converter.boolean(params.get('settings'))
		tools.Resolver.install(help = help, settings = settings)

####################################################
# RESOLVEURL
####################################################

elif action.startswith('resolveurl'):

	if action == 'resolveurlNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).resolveurlNavigator()

	elif action == 'resolveurlSettings':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.ResolveUrl.settings(settings = settings)

	elif action == 'resolveurlInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		help = tools.Converter.boolean(params.get('help'))
		tools.ResolveUrl.enable(refresh = True, confirm = True, settings = settings, help = help)

	elif action == 'resolveurlAuthentication':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.ResolveUrl.authentication(type = type, settings = settings)

####################################################
# URLRESOLVER
####################################################

elif action.startswith('urlresolver'):

	if action == 'urlresolverNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).urlresolverNavigator()

	elif action == 'urlresolverSettings':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.UrlResolver.settings(settings = settings)

	elif action == 'urlresolverInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		help = tools.Converter.boolean(params.get('help'))
		tools.UrlResolver.enable(refresh = True, confirm = True, settings = settings, help = help)

	elif action == 'urlresolverAuthentication':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.UrlResolver.authentication(type = type, settings = settings)

####################################################
# OPESCRAPERS
####################################################

elif action.startswith('opescrapers'):

	if action == 'opescrapersNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).opescrapersNavigator()

	elif action == 'opescrapersSettings':
		tools.OpeScrapers.settings()

	elif action == 'opescrapersProviders':
		tools.OpeScrapers.providers()

	elif action == 'opescrapersInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.OpeScrapers.enable(refresh = True, settings = settings)

####################################################
# FENSCRAPERS
####################################################

elif action.startswith('fenscrapers'):

	if action == 'fenscrapersNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).fenscrapersNavigator()

	elif action == 'fenscrapersSettings':
		tools.FenScrapers.settings()

	elif action == 'fenscrapersProviders':
		tools.FenScrapers.providers()

	elif action == 'fenscrapersInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.FenScrapers.enable(refresh = True, settings = settings)

####################################################
# OATSCRAPERS
####################################################

elif action.startswith('oatscrapers'):

	if action == 'oatscrapersNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).oatscrapersNavigator()

	elif action == 'oatscrapersSettings':
		tools.OatScrapers.settings()

	elif action == 'oatscrapersProviders':
		tools.OatScrapers.providers()

	elif action == 'oatscrapersInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.OatScrapers.enable(refresh = True, settings = settings)


####################################################
# CRESCRAPERS
####################################################

elif action.startswith('crescrapers'):

	if action == 'crescrapersNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).crescrapersNavigator()

	elif action == 'crescrapersSettings':
		tools.CreScrapers.settings()

	elif action == 'crescrapersProviders':
		tools.CreScrapers.providers()

	elif action == 'crescrapersInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.CreScrapers.enable(refresh = True, settings = settings)

####################################################
# LAMSCRAPERS
####################################################

elif action.startswith('lamscrapers'):

	if action == 'lamscrapersNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).lamscrapersNavigator()

	elif action == 'lamscrapersSettings':
		tools.LamScrapers.settings()

	elif action == 'lamscrapersProviders':
		tools.LamScrapers.providers()

	elif action == 'lamscrapersInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.LamScrapers.enable(refresh = True, settings = settings)

####################################################
# CIVCRAPERS
####################################################

elif action.startswith('civscrapers'):

	if action == 'civscrapersNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).civscrapersNavigator()

	elif action == 'civscrapersSettings':
		tools.CivScrapers.settings()

	elif action == 'civscrapersProviders':
		tools.CivScrapers.providers()

	elif action == 'civscrapersInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.CivScrapers.enable(refresh = True, settings = settings)

####################################################
# GLOSCRAPERS
####################################################

elif action.startswith('gloscrapers'):

	if action == 'gloscrapersNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).gloscrapersNavigator()

	elif action == 'gloscrapersSettings':
		tools.GloScrapers.settings()

	elif action == 'gloscrapersProviders':
		tools.GloScrapers.providers()

	elif action == 'gloscrapersInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.GloScrapers.enable(refresh = True, settings = settings)

####################################################
# UNISCRAPERS
####################################################

elif action.startswith('uniscrapers'):

	if action == 'uniscrapersNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).uniscrapersNavigator()

	elif action == 'uniscrapersSettings':
		tools.UniScrapers.settings()

	elif action == 'uniscrapersProviders':
		tools.UniScrapers.providers()

	elif action == 'uniscrapersInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.UniScrapers.enable(refresh = True, settings = settings)

####################################################
# NANSCRAPERS
####################################################

elif action.startswith('nanscrapers'):

	if action == 'nanscrapersNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).nanscrapersNavigator()

	elif action == 'nanscrapersSettings':
		tools.NanScrapers.settings()

	elif action == 'nanscrapersProviders':
		tools.NanScrapers.providers()

	elif action == 'nanscrapersInstall':
		tools.NanScrapers.enable(refresh = True)

####################################################
# YOUTUBE
####################################################

elif action.startswith('youtube'):

	if action == 'youtubeAuthentication':
		from lib.modules import video
		settings = tools.Converter.boolean(params.get('settings'))
		video.Video.authentication(settings = settings)

	elif action == 'youtubeNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).youtubeNavigator()

	elif action == 'youtubeSettings':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.YouTube.settings(settings = settings)

	elif action == 'youtubeInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		help = tools.Converter.boolean(params.get('help'))
		tools.YouTube.enable(settings = settings, help = help)

	elif action == 'youtubeQuality':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.YouTube.qualitySelect(settings = settings)

	elif action == 'youtubeLaunch':
		tools.YouTube.launch()

	elif action == 'youtubeWebsite':
		tools.YouTube.website(open = True)

####################################################
# UPNEXT
####################################################

elif action.startswith('upnext'):

	if action == 'upnextNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).upnextNavigator()

	elif action == 'upnextSettings':
		tools.UpNext.settings()

	elif action == 'upnextInstall':
		tools.UpNext.enable(refresh = True)

####################################################
# METAHANDLER
####################################################

elif action.startswith('metahandler'):

	if action == 'metahandlerNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).metahandlerNavigator()

	elif action == 'metahandlerSettings':
		tools.MetaHandler.settings()

	elif action == 'metahandlerInstall':
		tools.MetaHandler.enable(refresh = True)

####################################################
# VPNMANAGER
####################################################

elif action.startswith('vpnmanager'): # Make sure this is placed BEFORE the 'vpn' category.

	if action == 'vpnmanagerNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).vpnmanagerNavigator()

	elif action == 'vpnmanagerLaunch':
		tools.VpnManager.launch()

	elif action == 'vpnmanagerSettings':
		tools.VpnManager.settings()

	elif action == 'vpnmanagerInstall':
		settings = tools.Converter.boolean(params.get('settings'))
		help = tools.Converter.boolean(params.get('help'))
		tools.VpnManager.enable(refresh = True, confirm = True, settings = settings, help = help)

####################################################
# SPEEDTEST
####################################################

elif action.startswith('speedtest'):

	if action == 'speedtestNavigator':
		from lib.indexers import navigator
		from lib.modules import speedtest
		navigator.navigator().speedtestNavigator()

	elif action == 'speedtest':
		from lib.modules import speedtest
		speedtest.SpeedTester.select(params.get('update'))

	elif action == 'speedtestGlobal':
		from lib.modules import speedtest
		speedtest.SpeedTesterGlobal().show(params.get('update'))

	elif action == 'speedtestPremiumize':
		from lib.modules import speedtest
		speedtest.SpeedTesterPremiumize().show(params.get('update'))

	elif action == 'speedtestOffCloud':
		from lib.modules import speedtest
		speedtest.SpeedTesterOffCloud().show(params.get('update'))

	elif action == 'speedtestRealDebrid':
		from lib.modules import speedtest
		speedtest.SpeedTesterRealDebrid().show(params.get('update'))

	elif action == 'speedtestEasyNews':
		from lib.modules import speedtest
		speedtest.SpeedTesterEasyNews().show(params.get('update'))

	elif action == 'speedtestComparison':
		from lib.modules import speedtest
		speedtest.SpeedTester.comparison()

####################################################
# LOTTERY
####################################################

elif action.startswith('lottery'):

	if action == 'lotteryVoucher':
		from lib.modules import api
		api.Api.lotteryVoucher()

####################################################
# INFORMER
####################################################

elif action.startswith('informer'):

	if action == 'informerDialog':
		from lib.informers import Informer
		imdb = params.get('imdb')
		tmdb = params.get('tmdb')
		tvdb = params.get('tvdb')
		title = params.get('title')
		year = params.get('year')
		season = params.get('season')
		episode = params.get('episode')
		Informer.show(type = type, imdb = imdb, tmdb = tmdb, tvdb = tvdb, title = title, year = year, season = season, episode = episode, metadata = metadata)

	elif action == 'informerNavigator':
		from lib.informers import Informer
		id = params.get('id')
		if id: Informer.instance(id).navigator()
		else: Informer.navigators()

	elif action == 'informerSettings':
		from lib.informers import Informer
		id = params.get('id')
		Informer.instance(id).settings()

	elif action == 'informerInstall':
		from lib.informers import Informer
		id = params.get('id')
		refresh = tools.Converter.boolean(params.get('refresh'))
		Informer.instance(id).enable(refresh = refresh)

	elif action == 'informerLaunch':
		from lib.informers import Informer
		id = params.get('id')
		Informer.instance(id).launch()

####################################################
# HISTORY
####################################################

elif action.startswith('history'):

	if action == 'history':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).history()

	elif action == 'historyType':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).historyType()

	elif action == 'historyStream':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).historyStream()

####################################################
# FANART
####################################################

elif action.startswith('fanart'):

	if action == 'fanartAuthentication':
		from lib.modules.account import Fanart
		settings = tools.Converter.boolean(params.get('settings'))
		Fanart().authenticate(settings = settings)

####################################################
# IMDB
####################################################

elif action.startswith('imdb'):

	if action == 'imdbMovies':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).imdbMovies()

	elif action == 'imdbTv':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).imdbTv()

	elif action == 'imdbExport':
		from lib.modules import trakt
		trakt.imdbImport()

	elif action == 'imdbAuthentication':
		from lib.modules.account import Imdb
		settings = tools.Converter.boolean(params.get('settings'))
		Imdb().authenticate(settings = settings)

####################################################
# TVDB
####################################################

elif action.startswith('tvdb'):

	if action == 'tvdbAuthentication':
		from lib.modules.account import Tvdb
		settings = tools.Converter.boolean(params.get('settings'))
		Tvdb().authenticate(settings = settings)

####################################################
# TMDB
####################################################

elif action.startswith('tmdb'):

	if action == 'tmdbAuthentication':
		from lib.modules.account import Tmdb
		settings = tools.Converter.boolean(params.get('settings'))
		Tmdb().authenticate(settings = settings)

####################################################
# TRAKT
####################################################

elif action.startswith('trakt'):

	if action == 'traktMovies':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).traktMovies()

	elif action == 'traktMoviesLists':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).traktMoviesLists()

	elif action == 'traktTv':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).traktTv()

	elif action == 'traktTvLists':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).traktTvLists()

	elif action == 'traktManager':
		from lib.modules import trakt
		refresh = params.get('refresh')
		if refresh is None: refresh = True
		else: refresh = tools.Converter.boolean(refresh)
		trakt.manager(imdb = imdb, tvdb = tvdb, season = season, episode = episode, refresh = refresh)

	elif action == 'traktAuthentication':
		from lib.modules import trakt
		settings = tools.Converter.boolean(params.get('settings'))
		trakt.authentication(settings = settings)

	elif action == 'traktListAdd':
		from lib.modules import trakt
		trakt.listAdd()

	elif action == 'traktNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).traktNavigator()

	elif action == 'traktImport':
		from lib.modules import trakt
		trakt.imdbImport()

	elif action == 'traktSettings':
		tools.Trakt.settings()

	elif action == 'traktInstall':
		tools.Trakt.enable()

	elif action == 'traktLaunch':
		tools.Trakt.launch()

	elif action == 'traktWebsite':
		tools.Trakt.website(open = True)

####################################################
# OPENSUBTITLES
####################################################

elif action.startswith('opensubtitles'):

	if action == 'opensubtitlesAuthentication':
		from lib.modules.account import Opensubtitles
		settings = tools.Converter.boolean(params.get('settings'))
		Opensubtitles().authenticate(settings = settings)

####################################################
# NETWORK
####################################################

elif action.startswith('network'):

	if action == 'networkNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).networkNavigator()

	elif action == 'networkInformation':
		from lib.modules.network import Geolocator
		Geolocator.dialog()

	elif action == 'networkAuthentication':
		from lib.modules.account import Geolocation
		type = params.get('type')
		settings = tools.Converter.boolean(params.get('settings'))
		Geolocation(type = type).authenticate(settings = settings)

####################################################
# VPN
####################################################

elif action.startswith('vpn'):

	if action == 'vpnNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).vpnNavigator()

	elif action == 'vpnVerify':
		from lib.modules import vpn
		settings = tools.Converter.boolean(params.get('settings'))
		vpn.Vpn.verification(settings = settings)

	elif action == 'vpnConfigure':
		from lib.modules.vpn import Vpn
		settings = tools.Converter.boolean(params.get('settings'))
		Vpn.configuration(settings = settings)

	elif action == 'vpnSettings':
		from lib.modules.vpn import Vpn
		Vpn.settingsLaunch()

####################################################
# EXTENSIONS
####################################################

elif action.startswith('extensions'):

	if action == 'extensions':
		id = params.get('id')
		tools.Extension.dialog(id = id)

	elif action == 'extensionsHelp':
		tools.Extension.help(full = True)

	elif action == 'extensionsNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).extensionsNavigator()

	elif action == 'extensionsAvailableNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).extensionsAvailableNavigator()

	elif action == 'extensionsInstalledNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).extensionsInstalledNavigator()

####################################################
# THEME
####################################################

elif action.startswith('theme'):

	if action == 'themeSkinSelect':
		from lib.modules.theme import Theme
		Theme.skinSettings()

	elif action == 'themeIconSelect':
		from lib.modules import interface
		interface.Icon.settings()

####################################################
# BACKUP
####################################################

elif action.startswith('backup'):

	if action == 'backupNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).backupNavigator()

	elif action == 'backupAutomatic':
		tools.Backup.automatic()

	elif action == 'backupImport':
		tools.Backup.manualImport()

	elif action == 'backupExport':
		tools.Backup.manualExport()

####################################################
# SETTINGS
####################################################

elif action.startswith('settings'):

	if action == 'settings':
		from lib.modules import settings
		settings.Selection().show()

	elif action == 'settingsNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).settingsNavigator()

	elif action == 'settingsAdvanced':
		from lib.modules import settings
		settings.Advanced().show()

	elif action == 'settingsWizard':
		from lib.modules import interface
		interface.Dialog.notification(title='Not Implemented', message='Feature not implemented yet.', icon=interface.Dialog.IconError)#gaiaremove
		#from lib.modules import window
		#window.WindowWizard.show()

		#gaiaremove
		#gaiaremove
		'''year = 2009
		imdb = 'tt0499549'
		tmdb = '19995'
		tvdb = '165'
		titles = ['Avatar']

		def libraryMatch(data, titles, ids):#gaiaremove
			matchId = False
			matchTitle = False

			if 'uniqueid' in data and data['uniqueid']:
				for key, value in ids.items():
					if key in data['uniqueid'] and data['uniqueid'][key] == value:
						matchId = True
						break

			if not matchId:
				matchId = 'imdbnumber' in data and data['imdbnumber'] in ids.values()

			if not matchId:
				for title in titles['processed']['all']:
					for value in ['title', 'originaltitle']:
						if value in data and data[value] and tools.Matcher.levenshtein(title, data[value]) > 0.7:
							matchTitle = True
							break
				if not matchTitle:
					for title in titles['processed']['all']:
						if 'label' in data and data['label'] and tools.Matcher.levenshtein(title, resuldatat['label']) > 0.7:
							matchTitle = True
							break
				if not matchTitle:
					for title in titles['processed']['all']:
						if 'file' in data and data['file'] and tools.Matcher.levenshtein(title, tools.File.name(data['file'])) > 0.7:
							matchTitle = True
							break

			return matchId, matchTitle

		def libraryGet(media, titles = None, year = None, imdb = None, tmdb = None, tvdb = None, season = None, episode = None):#gaiaremove
			ids = {}
			if imdb: ids['imdb'] = imdb
			if tmdb: ids['tmdb'] = tmdb
			if tvdb: ids['tvdb'] = tvdb

			years = None
			if year: years = (year, year - 1, year + 1)

			filter = []
			if years:
				filter.extend([{'field' : 'year', 'operator' : 'is', 'value' : '%d' % i} for i in years])
			else:
				for title in titles:
					if not Tools.isArray(title): title = [title]
					filter.extend([{'field' : 'title', 'operator' : 'contains', 'value' : '%s' % i} for i in title])
					filter.extend([{'field' : 'originaltitle', 'operator' : 'contains', 'value' : '%s' % i} for i in title])
			filter = {'or': filter}

			if tools.Media.typeMovie(media):
				results = tools.System.executeJson(method = 'VideoLibrary.GetMovies', parameters = {'filter' : filter, 'properties': ['uniqueid', 'imdbnumber', 'title', 'originaltitle', 'file']})
				if 'result' in results and 'movies' in results['result']:
					results = results['result']['movies']
					for data in results:
						matchId, matchTitle = libraryMatch(data = data, titles = titles, ids = ids)
						if not matchId and not matchTitle: continue
						tools.Logger.log("RRRRRRRRR----: "+tools.Converter.jsonTo(data))

		libraryGet(media = tools.Media.TypeMovie, titles = titles, year = year, imdb = imdb, tmdb = tmdb, tvdb = tvdb)
		'''

		'''x = tools.System.executeJson(method = 'VideoLibrary.GetMovies', parameters = {'filter' : filter, 'properties': ['playcount', 'uniqueid', 'resume', 'imdbnumber', 'title', 'originaltitle', 'file']})
		tools.Logger.log("RRRRRRRRRR1: "+tools.Converter.jsonTo(x))

		x = tools.System.executeJson(method = 'VideoLibrary.SetMovieDetails', parameters = {'movieid' : 188, 'playcount' : 1, 'resume' : {'position' : 900}})
		tools.Logger.log("RRRRRRRRRR2: "+tools.Converter.jsonTo(x))

		x = tools.System.executeJson(method = 'VideoLibrary.GetMovies', parameters = {'filter' : filter, 'properties': ['playcount', 'uniqueid', 'resume', 'imdbnumber', 'title', 'originaltitle', 'file']})
		tools.Logger.log("RRRRRRRRRR3: "+tools.Converter.jsonTo(x))'''

	elif action == 'settingsOptimization':
		from lib.providers.core.manager import Manager
		Manager.optimizeShow()

	elif action == 'settingsBackground':
		id = params.get('id')
		addon = params.get('addon')
		category = params.get('category')
		tools.Settings.launch(id = id, addon = addon, category = category, background = False)

	elif action == 'settingsExternal':
		tools.Settings.externalSave(params)

	elif action == 'settingsLanguage':
		id = params.get('id')
		title = params.get('title')
		if title:
			try: title = int(title)
			except: pass
		none = tools.Converter.boolean(params.get('none'))
		automatic = tools.Converter.boolean(params.get('automatic'))
		set = params.get('set')
		tools.Language.settingsSelect(id = id, title = title, none = none, automatic = automatic, set = set)

	elif action == 'settingsCountry':
		id = params.get('id')
		title = params.get('title')
		if title:
			try: title = int(title)
			except: pass
		none = tools.Converter.boolean(params.get('none'))
		automatic = tools.Converter.boolean(params.get('automatic'))
		tools.Country.settingsSelect(id = id, title = title, none = none, automatic = automatic)

	elif action == 'settingsLayout':
		from lib.modules.interface import Loader
		Loader.show() # Show here already for slow devices.
		from lib.modules.stream import Layout
		Layout().show(settings = True)

	elif action == 'settingsFilters':
		from lib.modules.interface import Loader
		Loader.show() # Show here already for slow devices.
		from lib.modules.stream import Settings
		mode = params.get('mode')
		Settings(mode = mode).show()

	elif action == 'settingsTermination':
		from lib.modules.interface import Loader
		Loader.show() # Show here already for slow devices.
		from lib.modules.stream import Termination
		settings = tools.Converter.boolean(params.get('settings'))
		Termination().show(settings = settings)

	elif action == 'settingsCustom':
		id = params.get('id')
		settings = tools.Converter.boolean(params.get('settings'))
		tools.Settings.custom(id = id, settings = settings)

	elif action == 'settingsBuffer':
		settings = tools.Converter.boolean(params.get('settings'))
		tools.Buffer.settings(settings = settings)

	elif action == 'settingsView':
		from lib.modules.view import View
		media = params.get('media')
		content = params.get('content')
		previous = params.get('previous')
		settings = tools.Converter.boolean(params.get('settings'))
		View.settings(media = media, content = content, previous = previous, settings = settings)

####################################################
# DONATIONS
####################################################

elif action.startswith('donations'):

	if action == 'donationsNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).donationsNavigator()

	elif action == 'donationsCrypto':
		from lib.modules import tools
		tools.Donations.show(type = type)

	elif action == 'donationsOther':
		from lib.modules import tools
		tools.Donations.other()

####################################################
# SHORTCUTS
####################################################

elif action.startswith('shortcuts'):

	if action == 'shortcutsShow':
		from lib.modules import shortcuts
		location = params.get('location')
		id = params.get('id')
		link = params.get('link')
		create = tools.Converter.boolean(params.get('create'))
		delete = tools.Converter.boolean(params.get('delete'))
		shortcuts.Shortcuts().show(location = location, id = id, link = link, name = name, create = create, delete = delete)

	elif action == 'shortcutsNavigator':
		from lib.indexers import navigator
		location = params.get('location')
		navigator.navigator(type = type, kids = kids).shortcutsNavigator(location = location)

	elif action == 'shortcutsOpen':
		from lib.modules import shortcuts
		location = params.get('location')
		id = params.get('id')
		shortcuts.Shortcuts().open(location = location, id = id)

####################################################
# LIBRARY
####################################################

elif action.startswith('library'):

	if action == 'libraryNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).libraryNavigator()

	elif action == 'libraryLocalNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).libraryLocalNavigator()

	elif action == 'libraryBrowseNavigator':
		from lib.indexers import navigator
		error = tools.Converter.boolean(params.get('error'))
		navigator.navigator(type = type, kids = kids).libraryBrowseNavigator(error = error)

	elif action == 'libraryAdd':
		from lib.modules import library
		precheck = tools.Converter.boolean(params.get('precheck'), none = True)
		metadata = params.get('metadata')
		title = tools.Converter.quoteFrom(title)
		library.Library(type = type, kids = kids).add(link = link, title = title, year = year, season = season, episode = episode, imdb = imdb, tmdb = tmdb, tvdb = tvdb, metadata = metadata, precheck = precheck)

	elif action == 'libraryResolve':
		from lib.modules import library
		metadata = params.get('location')
		title = tools.Converter.quoteFrom(title)
		library.Library(type = type, kids = kids).resolve(title = title, year = year, season = season, episode = episode)

	elif action == 'libraryRefresh':
		from lib.modules import library
		library.Library(type = type).refresh()

	elif action == 'libraryUpdate':
		from lib.modules import library
		force = tools.Converter.boolean(params.get('force'))
		library.Library.update(force = force, type = type)

	elif action == 'libraryClean':
		from lib.modules import library
		library.Library(type = type).clean()

	elif action == 'libraryService':
		from lib.modules import library
		library.Library.service(background = False)

	elif action == 'libraryLocal':
		from lib.modules import library
		library.Library(type = type).local()

	elif action == 'librarySettings':
		from lib.modules import library
		library.Library.settings()

####################################################
# SUPPORT
####################################################

elif action.startswith('support'):

	if action == 'supportGuide':
		from lib.modules import support
		support.Support.guide()

	elif action == 'supportBugs':
		from lib.modules import support
		support.Support.bugs()

	elif action == 'supportNavigator':
		from lib.modules import support
		support.Support.navigator()

	elif action == 'supportCategories':
		from lib.modules import support
		support.Support.categories()

	elif action == 'supportReport':
		from lib.modules import support
		support.Support.report()

	elif action == 'supportQuestions':
		from lib.modules import support
		support.Support.questions(int(params.get('id')))

	elif action == 'supportQuestion':
		from lib.modules import support
		support.Support.question(int(params.get('id')))

####################################################
# ORION
####################################################

elif action.startswith('orion'):

	if action == 'orionNavigator':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).orionNavigator()

	elif action == 'orionInitialize':
		try:
			from lib.modules import orionoid
			settings = params.get('settings')
			if settings and not '.' in settings: settings = tools.Converter.boolean(settings)
			orionoid.Orionoid().initialize(settings = settings)
		except: pass

	elif action == 'orionSettings':
		try:
			from lib.modules import orionoid
			id = params.get('id')
			orionoid.Orionoid().addonSettings(id = id)
		except: pass

	elif action == 'orionFilters':
		try:
			from lib.modules import orionoid
			settings = tools.Converter.boolean(params.get('settings'))
			orionoid.Orionoid().settingsFilters(settings = settings)
		except: pass

	elif action == 'orionLaunch':
		try:
			from lib.modules import orionoid
			orionoid.Orionoid().addonLaunch()
		except: pass

	elif action == 'orionUninstall':
		try:
			from lib.modules import orionoid
			orionoid.Orionoid.uninstall()
		except: pass

	elif action == 'orionWebsite':
		try:
			from lib.modules import orionoid
			orionoid.Orionoid().addonWebsite(open = True)
		except: pass

	elif action == 'orionAuthenticate':
		try:
			from lib.modules import orionoid
			settings = tools.Converter.boolean(params.get('settings'))
			orionoid.Orionoid().accountAuthenticate(settings = settings)
		except: pass

	elif action == 'orionAccount':
		try:
			from lib.modules import orionoid
			orionoid.Orionoid().accountDialog()
		except: pass

	elif action == 'orionPromotion':
		try:
			from lib.modules import orionoid
			settings = tools.Converter.boolean(params.get('settings'))
			orionoid.Orionoid().accountPromotion(settings = settings)
		except: pass

	elif action == 'orionVoteUp':
		try:
			from lib.modules import orionoid
			notification = tools.Converter.boolean(params.get('notification'), none = True)
			orionoid.Orionoid().streamVote(idItem = params.get('idItem'), idStream = params.get('idStream'), vote = orionoid.Orionoid.VoteUp, notification = True if notification is None else notification)
		except: pass

	elif action == 'orionVoteDown':
		try:
			from lib.modules import orionoid
			notification = tools.Converter.boolean(params.get('notification'), none = True)
			orionoid.Orionoid().streamVote(idItem = params.get('idItem'), idStream = params.get('idStream'), vote = orionoid.Orionoid.VoteDown, notification = True if notification is None else notification)
		except: pass

	elif action == 'orionRemove':
		try:
			from lib.modules import orionoid
			notification = tools.Converter.boolean(params.get('notification'), none = True)
			orionoid.Orionoid().streamRemove(idItem = params.get('idItem'), idStream = params.get('idStream'), notification = True if notification is None else notification)
		except: pass

####################################################
# SCRAPE
####################################################

elif action.startswith('scrape'):

	if action == 'scrape':
		from lib.modules import core
		from lib.modules import interface
		from lib.modules import video
		try: silent = bool(params.get('silent'))
		except: silent = False
		try: binge = int(params.get('binge'))
		except: binge = None

		# Already show here, since getConstants can take long when retrieving debrid service list.
		if (not video.Trailer.cinemaEnabled() or tools.Settings.getBoolean('playback.autoplay.enabled')) and (not binge == tools.Binge.ModeBackground or binge == tools.Binge.ModeContinue): interface.Loader.show()

		library = tools.Converter.boolean(params.get('library'))
		autoplay = tools.Converter.boolean(params.get('autoplay'), none = True)
		preset = params.get('preset')
		cache = tools.Converter.boolean(params.get('cache'), none = True)
		try: count = tools.Converter.dictionary(params.get('count'))
		except: count = None
		items = params.get('items')
		core.Core(type = type, kids = kids, silent = silent).scrape(title = title, year = year, imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode, tvshowtitle = tvshowtitle, premiered = premiered, metadata = metadata, autoplay = autoplay, library = library, preset = preset, binge = binge, cache = cache, count = count, items = items)

	elif action == 'scrapeAgain':
		from lib.modules import core
		core.Core(type = type, kids = kids).scrapeAgain(link = link)

	elif action == 'scrapeManual':
		from lib.modules import core
		core.Core(type = type, kids = kids).scrapeManual(link = link)

	elif action == 'scrapeAutomatic':
		from lib.modules import core
		core.Core(type = type, kids = kids).scrapeAutomatic(link = link)

	elif action == 'scrapePresetManual':
		from lib.modules import core
		core.Core(type = type, kids = kids).scrapePresetManual(link = link)

	elif action == 'scrapePresetAutomatic':
		from lib.modules import core
		core.Core(type = type, kids = kids).scrapePresetAutomatic(link = link)

	elif action == 'scrapeSingle':
		from lib.modules import core
		core.Core(type = type, kids = kids).scrapeSingle(link = link)

	elif action == 'scrapeBinge':
		from lib.modules import core
		core.Core(type = type, kids = kids).scrapeBinge(link = link)

	elif action == 'scrapeExact':
		from lib.modules import core
		terms = params.get('terms')
		core.Core(type = type, kids = kids).scrapeExact(terms)

	elif action == 'scrapeOptimize':
		from lib.providers.core.manager import Manager
		settings = tools.Converter.boolean(params.get('settings'))
		Manager.optimizeScrape(settings = settings)

####################################################
# STREAMS
####################################################

elif action.startswith('streams'):

	if action == 'streamsShow':
		from lib.modules import core
		from lib.modules import interface
		autoplay = tools.Converter.boolean(params.get('autoplay'))
		if autoplay: interface.Loader.show() # Only for autoplay, since showing the directory has its own loader.
		direct = tools.Converter.boolean(params.get('direct'))
		filter = tools.Converter.boolean(params.get('filterx'))
		library = tools.Converter.boolean(params.get('library'))
		initial = tools.Converter.boolean(params.get('initial'))
		new = tools.Converter.boolean(params.get('new'))
		add = tools.Converter.boolean(params.get('add'))
		process = tools.Converter.boolean(params.get('process'))
		try: binge = int(params.get('binge'))
		except: binge = None
		core.Core(type = type, kids = kids).showStreams(direct = direct, filter = filter, autoplay = autoplay, library = library, initial = initial, new = new, add = add, process = process, binge = binge)

	elif action == 'streamsFilters':
		from lib.modules.core import Core
		Core(type = type, kids = kids).filterStreams()

	elif action == 'streamsInformation':
		from lib.modules.stream import Stream
		Stream(data = source['stream']).dialog()

	elif action == 'streamsVideo':
		from lib.modules import video
		mode = params.get('video')
		art = params.get('art')
		selection = params.get('selection')
		if not selection is None: selection = int(selection)
		if tools.Tools.isString(art): art = tools.Converter.jsonFrom(art)
		getattr(video, mode.capitalize())(type = type, kids = kids).play(title = title, year = year, season = season, link = link, art = art, selection = selection)

####################################################
# CONTEXT
####################################################

elif action.startswith('context'):

	if action == 'contextShow':
		from lib.modules import interface
		context = params.get('context')
		menu = interface.Context()
		menu.jsonFrom(context)
		menu.show()

####################################################
# LINK
####################################################

elif action.startswith('link'):

	if action == 'linkOpen':
		from lib.modules.interface import Loader
		try:
			Loader.show() # Needs some time to load. Show busy.
			from lib.modules.network import Networker, Resolver
			from lib.modules.stream import Stream

			mode = params.get('mode')
			if not mode: mode = 'original'

			if 'link' in params:
				link = params.get('link')
			elif source:
				stream = Stream.load(data = source['stream'])
				if mode == 'original':
					link = stream.linkPrimary()
				elif mode == 'resolved':
					link = stream.linkProvider()
					if not link: link = Resolver.resolve(source = source, clean = True, internal = False, cloud = True, mode = Resolver.ModeProvider)
				elif mode == 'stream':
					link = stream.linkStream()
					if not link:
						link = Resolver.resolve(source = source, clean = True, internal = False, cloud = True, mode = Resolver.ModeService)
						if not link: link = Stream.load(data = source['stream']).linkResolved() # Provider-resolved link added by Resolver.resolve() and therefore reload.
				if not link: link = stream.linkPrimary() # Sometimes resolving does not work. Eg: 404 errors.

			link = Networker.linkClean(link)
			tools.System.openLink(link)
		except: tools.Logger.error()
		Loader.hide()

	elif action == 'linkCopy':
		from lib.modules.interface import Loader
		try:
			Loader.show() # Needs some time to load. Show busy.
			from lib.modules.clipboard import Clipboard
			from lib.modules.network import Networker, Resolver
			from lib.modules.stream import Stream

			mode = params.get('mode')
			if not mode: mode = 'original'

			if 'link' in params:
				link = params.get('link')
			elif source:
				stream = Stream.load(data = source['stream'])
				if mode == 'original':
					link = stream.linkPrimary()
				elif mode == 'resolved':
					link = stream.linkProvider()
					if not link: link = Resolver.resolve(source = source, clean = True, internal = False, cloud = True, mode = Resolver.ModeProvider)
				elif mode == 'stream':
					link = stream.linkStream()
					if not link:
						link = Resolver.resolve(source = source, clean = True, internal = False, cloud = True, mode = Resolver.ModeService)
						if not link: link = Stream.load(data = source['stream']).linkResolved() # Provider-resolved link added by Resolver.resolve() and therefore reload.
				if not link: link = stream.linkPrimary() # Sometimes resolving does not work. Eg: 404 errors.

			link = Networker.linkClean(link)
			Clipboard.copyLink(link, True)
		except: tools.Logger.error()
		Loader.hide()

	elif action == 'linkName':
		from lib.modules.interface import Loader
		try:
			Loader.show() # Needs some time to load. Show busy.
			from lib.modules.clipboard import Clipboard
			from lib.modules.network import Networker
			from lib.modules.stream import Stream
			stream = Stream.load(data = source['stream'])
			name = stream.fileName()
			if not name: name = Networker.linkPath(stream.linkPrimary())
			if not name: name = Networker.linkClean(stream.linkPrimary())
			Clipboard.copyName(name, True)
		except: tools.Logger.error()
		Loader.hide()

	elif action == 'linkAdd':
		from lib.modules.interface import Loader
		Loader.show()
		from lib.modules import core
		core.Core(type = type, kids = kids).addLink(link = url, metadata = metadata)

####################################################
# CLOUDFLARE
####################################################

elif action.startswith('cloudflare'):

	if action == 'cloudflareEngine':
		from lib.modules.cloudflare import Cloudflare
		settings = tools.Converter.boolean(params.get('settings'))
		Cloudflare.settingsEngine(settings = settings)

	elif action == 'cloudflareVerify':
		from lib.modules.cloudflare import Cloudflare
		settings = tools.Converter.boolean(params.get('settings'))
		Cloudflare().verify(settings = settings, notification = True)

####################################################
# NAVIGATOR
####################################################

elif action.startswith('navigator'):

	if action == 'navigatorTools':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).tools()

	elif action == 'navigatorRefresh':
		from lib.modules import interface
		interface.Directory.refresh()

	elif action == 'navigatorFavourites':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).favourites()

	elif action == 'navigatorArrivals':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).arrivals()

	elif action == 'navigatorPreload':
		from lib.indexers import navigator
		navigator.navigator(type = type, kids = kids).preload()

####################################################
# DEBUG
####################################################

elif action.startswith('debug'):
	from lib.modules import tester
	tester.Tester.test()

####################################################
# EXECUTION
####################################################

if developer: tools.Logger.log('EXECUTION FINISHING [Action: %s | Duration: %.3f secs]' % (action, timer.time() - timeStart))

from lib.modules.vpn import Vpn
Vpn.killStop()

from lib.modules.concurrency import Pool
Pool.join()

# Do this at the end, so that timestamps of reloaded requests can be updated and won't be deleted.
# Do this after the thread pool joining, since the cache might still have threads executing (refreshing data in the background).
from lib.modules.cache import Cache
Cache.instance().limitClear(log = developer)

if developer: tools.Logger.log('EXECUTION FINISHED [Action: %s | Duration: %.3f secs]' % (action, timer.time() - timeStart))
