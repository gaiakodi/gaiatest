# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re,os

try: from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database

from lib.modules.tools import System, Time, File
from lib.modules.database import Database
from lib.modules.theme import Theme
from lib.modules import interface

def cleanViews():
	try:
		dbcon = database.connect(Database.pathViews())
		dbcur = dbcon.cursor()
		dbcur.execute("DROP TABLE IF EXISTS views;")
		dbcur.execute("CREATE TABLE IF NOT EXISTS views (""skin TEXT, ""view_type TEXT, ""view_id TEXT, ""UNIQUE(skin, view_type)"");")
		dbcon.commit()
	except:
		pass

def addView(content):
	try:
		skin = Theme.kodiSkin()
		skinPath = Theme.kodiSkinPath()
		xml = os.path.join(skinPath, 'addon.xml')
		data = File.readNow(xml).replace('\n','')
		try: src = re.compile('defaultresolution="(.+?)"').findall(data)[0]
		except: src = re.compile('<res.+?folder="(.+?)"').findall(data)[0]
		src = os.path.join(skinPath, src)
		src = os.path.join(src, 'MyVideoNav.xml')
		data = File.readNow(src).replace('\n','')
		views = re.compile('<views>(.+?)</views>').findall(data)[0]
		views = [int(x) for x in views.split(',')]
		for view in views:
			label = System.infoLabel('Control.GetLabel(%s)' % (view))
			if not (label == '' or label == None): break
		record = (skin, content, str(view))
		File.makeDirectory(tools.System.profile())
		dbcon = database.connect(Database.pathViews())
		dbcur = dbcon.cursor()
		dbcur.execute("CREATE TABLE IF NOT EXISTS views (""skin TEXT, ""view_type TEXT, ""view_id TEXT, ""UNIQUE(skin, view_type)"");")
		dbcur.execute("DELETE FROM views WHERE skin = '%s' AND view_type = '%s'" % (record[0], record[1]))
		dbcur.execute("INSERT INTO views Values (?, ?, ?)", record)
		dbcon.commit()

		viewName = System.infoLabel('Container.Viewmode')
		skinName = tools.System.info(id = skin, value = 'name')
		skinIcon = tools.System.info(id = skin, value = 'icon')

		interface.Dialog.notification(title = 33586, message = interface.Translation.string(33587) + ': ' + str(viewName), icon = interface.Dialog.IconSuccess)
	except:
		return


def setView(content, viewDict=None):
	skin = Theme.kodiSkin()
	for i in range(0, 200):
		if System.visible('Container.Content(%s)' % convertView(content)):
			try:
				record = (skin, content)
				dbcon = database.connect(Database.pathViews())
				dbcur = dbcon.cursor()
				dbcur.execute("SELECT * FROM views WHERE skin = '%s' AND view_type = '%s'" % (record[0], record[1]))
				view = dbcur.fetchone()
				view = view[2]
				if view == None: raise Exception()
				return System.execute('Container.SetViewMode(%s)' % str(view))
			except:
				try: return System.execute('Container.SetViewMode(%s)' % str(viewDict[skin]))
				except: return

		Time.sleep(0.1)


def convertView(content):
	if content == 'documentaries' or content == 'shorts':
		return 'movies'
	elif content == 'shows':
		return 'tvshows'
	else:
		return content
