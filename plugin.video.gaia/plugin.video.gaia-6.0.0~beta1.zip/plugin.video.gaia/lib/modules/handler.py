# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.modules import tools
from lib.modules import cache
from lib.modules import network
from lib.modules import interface
from lib.modules import window

# NB: Only initialize the services once, otherwise it takes about 150ms each time Handler._initialize is called, because the objects have to be created and the settings be read from file.
# NB: Do not declare these variables as class variables in Handler, because if no object of Handler exists, it will delete the class variables.
# NB: This is important for sources -> __init__.py -> addItem.
HandlerServicesDirect = None
HandlerServicesTorrent = None
HandlerServicesUsenet = None
HandlerServicesHoster = None

HandlerDefaultDirect = None
HandlerDefaultTorrent = None
HandlerDefaultUsenet = None
HandlerDefaultHoster = None

Handles = None
HandlesCache = None
HandlesHoster = None

class Handler(object):

	ModeNone = None
	ModeDefault = 'default'
	ModeSelection = 'selection'
	ModeBest = 'best'
	ModeFile = 'file'

	ReturnUnavailable = 'unavailable'
	ReturnExternal = 'external'
	ReturnCancel = 'cancel'

	TypeDirect = 'direct'
	TypeTorrent = 'torrent'
	TypeUsenet = 'usenet'
	TypeHoster = 'hoster'

	def __init__(self, type = None):
		self.mServices = []
		self.mType = None
		self.mDefault = None
		self._initialize(type)

	@classmethod
	def handles(self):
		from lib import debrid
		global Handles
		if Handles is None: Handles = debrid.Debrid.handles(data = True, priority = True)
		return Handles

	@classmethod
	def handlesSingleCache(self):
		from lib import debrid
		global HandlesCache
		if HandlesCache is None:
			HandlesCache = 0
			services = [debrid.premiumize.Core(), debrid.offcloud.Core(), debrid.realdebrid.Core()]
			for service in services:
				if service.accountValid():
					HandlesCache += 1
		return HandlesCache <= 1

	@classmethod
	def handlesSingleHoster(self):
		from lib import debrid
		global HandlesHoster
		if HandlesHoster is None:
			HandlesHoster = 0
			services = [debrid.premiumize.Core(), debrid.offcloud.Core(), debrid.realdebrid.Core()]
			for service in services:
				if service.accountValid():
					HandlesHoster += 1
		return HandlesHoster <= 1

	def _initialize(self, type):
		from lib import debrid
		if type is None: return

		try:
			direct = type['stream'].accessTypeDirect()
			type = type['stream'].sourceType()
		except:
			type = type.lower()
			direct = type == Handler.TypeDirect

		if not type == Handler.TypeTorrent and not type == Handler.TypeUsenet:
			if direct: type = Handler.TypeDirect
			else: type = Handler.TypeHoster
		if type == self.mType:
			return

		self.mType = type
		self.mServices = []
		self.mDefault = None

		global HandlerServicesDirect
		global HandlerServicesTorrent
		global HandlerServicesUsenet
		global HandlerServicesHoster

		global HandlerDefaultDirect
		global HandlerDefaultTorrent
		global HandlerDefaultUsenet
		global HandlerDefaultHoster

		if type == Handler.TypeDirect:
			if HandlerServicesDirect is None:
				HandlerServicesDirect = []
				default = tools.Settings.getInteger('stream.default.direct')
				if default > 0:
					handle = HandleDirect()
					HandlerServicesDirect.append(handle)
					HandlerDefaultDirect = handle
					self.mServices = HandlerServicesDirect
					self.mDefault = HandlerDefaultDirect
			else:
				self.mServices = HandlerServicesDirect
				self.mDefault = HandlerDefaultDirect
		elif type == Handler.TypeTorrent:
			if HandlerServicesTorrent is None:
				HandlerServicesTorrent = []
				default = tools.Settings.getInteger('stream.default.torrent')
				if default > 0:
					premiumizeCore = debrid.premiumize.Core()
					offcloudCore = debrid.offcloud.Core()
					realdebridCore = debrid.realdebrid.Core()
					if default == 1: HandlerDefaultTorrent = Handler.ModeBest
					if premiumizeCore.accountValid() and premiumizeCore.streamingTorrent():
						handle = debrid.premiumize.Handle()
						HandlerServicesTorrent.append(handle)
						if default == 3: HandlerDefaultTorrent = handle
					if offcloudCore.accountValid() and offcloudCore.streamingTorrent():
						handle = debrid.offcloud.Handle()
						HandlerServicesTorrent.append(handle)
						if default == 4: HandlerDefaultTorrent = handle
					if realdebridCore.accountValid() and realdebridCore.streamingTorrent():
						handle = debrid.realdebrid.Handle()
						HandlerServicesTorrent.append(handle)
						if default == 5: HandlerDefaultTorrent = handle
					if tools.Settings.getBoolean('stream.resolveurl.torrent'):
						selection = tools.Settings.getInteger('stream.resolveurl.selection')
						handle = HandleResolveUrl()
						if selection == 0 or selection == 1:
							HandlerServicesTorrent.append(handle)
						if selection == 0 or selection == 2:
							instances = handle.instances(type = type)
							HandlerServicesTorrent.extend(instances)
							if selection == 1 and len(instances) > 0: handle = instances[0]
						if default == 6 and handle: HandlerDefaultTorrent = handle
					if tools.Settings.getBoolean('stream.urlresolver.torrent'):
						selection = tools.Settings.getInteger('stream.urlresolver.selection')
						handle = HandleUrlResolver()
						if selection == 0 or selection == 1:
							HandlerServicesTorrent.append(handle)
						if selection == 0 or selection == 2:
							instances = handle.instances(type = type)
							HandlerServicesTorrent.extend(instances)
							if selection == 1 and len(instances) > 0: handle = instances[0]
						if default == 7 and handle: HandlerDefaultTorrent = handle
					if tools.Settings.getBoolean('stream.elementum.torrent') and tools.Elementum.installed():
						handle = HandleElementum()
						HandlerServicesTorrent.append(handle)
						if default == 8: HandlerDefaultTorrent = handle
					if tools.Settings.getBoolean('stream.quasar.torrent') and tools.Quasar.installed():
						handle = HandleQuasar()
						HandlerServicesTorrent.append(handle)
						if default == 9: HandlerDefaultTorrent = handle
					self.mServices = HandlerServicesTorrent
					self.mDefault = HandlerDefaultTorrent
			else:
				self.mServices = HandlerServicesTorrent
				self.mDefault = HandlerDefaultTorrent
		elif type == Handler.TypeUsenet:
			if HandlerServicesUsenet is None:
				HandlerServicesUsenet = []
				default = tools.Settings.getInteger('stream.default.usenet')
				if default > 0:
					premiumizeCore = debrid.premiumize.Core()
					offcloudCore = debrid.offcloud.Core()
					if default == 1: HandlerDefaultUsenet = Handler.ModeBest
					if premiumizeCore.accountValid() and premiumizeCore.streamingUsenet():
						handle = debrid.premiumize.Handle()
						HandlerServicesUsenet.append(handle)
						if default == 3: HandlerDefaultUsenet = handle
					if offcloudCore.accountValid() and offcloudCore.streamingUsenet():
						handle = debrid.offcloud.Handle()
						HandlerServicesUsenet.append(handle)
						if default == 4: HandlerDefaultUsenet = handle
					self.mServices = HandlerServicesUsenet
					self.mDefault = HandlerDefaultUsenet
			else:
				self.mServices = HandlerServicesUsenet
				self.mDefault = HandlerDefaultUsenet
		elif type == Handler.TypeHoster:
			if HandlerServicesHoster is None:
				HandlerServicesHoster = []
				default = tools.Settings.getInteger('stream.default.hoster')
				if default > 0:
					premiumizeCore = debrid.premiumize.Core()
					offcloudCore = debrid.offcloud.Core()
					realdebridCore = debrid.realdebrid.Core()
					if default == 1: HandlerDefaultHoster = Handler.ModeBest
					if premiumizeCore.accountValid() and premiumizeCore.streamingHoster():
						handle = debrid.premiumize.Handle()
						HandlerServicesHoster.append(handle)
						if default == 3: HandlerDefaultHoster = handle
					if offcloudCore.accountValid() and offcloudCore.streamingHoster():
						handle = debrid.offcloud.Handle()
						HandlerServicesHoster.append(handle)
						if default == 4: HandlerDefaultHoster = handle
					if realdebridCore.accountValid() and realdebridCore.streamingHoster():
						handle = debrid.realdebrid.Handle()
						HandlerServicesHoster.append(handle)
						if default == 5: HandlerDefaultHoster = handle
					if tools.Settings.getBoolean('stream.resolveurl.hoster'):
						selection = tools.Settings.getInteger('stream.resolveurl.selection')
						handle = HandleResolveUrl()
						if selection == 0 or selection == 1:
							HandlerServicesHoster.append(handle)
						if selection == 0 or selection == 2:
							instances = handle.instances(type = type)
							HandlerServicesHoster.extend(instances)
							if selection == 1 and len(instances) > 0: handle = instances[0]
						if default == 6 and handle: HandlerDefaultHoster = handle
					if tools.Settings.getBoolean('stream.urlresolver.hoster'):
						selection = tools.Settings.getInteger('stream.urlresolver.selection')
						handle = HandleUrlResolver()
						if selection == 0 or selection == 1:
							HandlerServicesHoster.append(handle)
						if selection == 0 or selection == 2:
							instances = handle.instances(type = type)
							HandlerServicesHoster.extend(instances)
							if selection == 1 and len(instances) > 0: handle = instances[0]
						if default == 7 and handle: HandlerDefaultHoster = handle
					if tools.Settings.getBoolean('stream.youtube.hoster') and tools.YouTube.installed():
						handle = HandleYoutube()
						HandlerServicesHoster.append(handle)
						if default == 8: HandlerDefaultHoster = handle

					self.mServices = HandlerServicesHoster
					self.mDefault = HandlerDefaultHoster
			else:
				self.mServices = HandlerServicesHoster
				self.mDefault = HandlerDefaultHoster

	def serviceHas(self):
		return self.serviceCount() > 0

	def serviceCount(self):
		return len(self.mServices)

	def service(self, name = None):
		if self.serviceHas():
			if name is None:
				return self.mServices[0]
			else:
				name = name.lower()
				for service in self.mServices:
					if service.id() == name:
						return service
		return None

	def supported(self, item = None, cloud = False):
		if item is None:
			return len(self.mServices) > 0
		else:
			self._initialize(item)
			for service in self.mServices:
				if service.supported(item, cloud = cloud):
					return True
			return False

	def supportedType(self, type):
		if type == Handler.TypeDirect: return self.supportedDirect()
		elif type == Handler.TypeTorrent: return self.supportedTorrent()
		elif type == Handler.TypeUsenet: return self.supportedUsenet()
		elif type == Handler.TypeHoster: return self.supportedHoster()
		else: return False

	def supportedDirect(self):
		global HandlerDefaultDirect
		return len(HandlerDefaultDirect) > 0

	def supportedTorrent(self):
		global HandlerServicesTorrent
		return len(HandlerServicesTorrent) > 0

	def supportedUsenet(self):
		global HandlerServicesUsenet
		return len(HandlerServicesUsenet) > 0

	def supportedHoster(self):
		global HandlerServicesHoster
		return len(HandlerServicesHoster) > 0

	def supportedCount(self, item = None, cloud = False):
		if item is None:
			return len(self.mServices)
		else:
			count = 0
			self._initialize(item)
			for service in self.mServices:
				try:
					if service.supported(item, cloud = cloud):
						count += 1
				except: pass
			return count

	def serviceBest(self, item, cached = True, cloud = False):
		try:
			from lib import debrid
			self._initialize(item)
			services = [i.id() for i in self.mServices if i.supported(item, cloud = cloud)]

			if not item['stream'].accessCacheAny(): cached = False
			if cached: cache = item['stream'].accessCache()

			selections = [
				HandleDirect().id(),
				debrid.premiumize.Handle().id(),
				debrid.offcloud.Handle().id(),
				debrid.realdebrid.Handle().id(),
				HandleResolveUrl().id(),
				HandleUrlResolver().id(),
				HandleElementum().id(),
				HandleQuasar().id(),
			]
			for selection in selections:
				# Try to find a cached link first.
				if selection in services and ((not cached) or (cached and cache[selection])):
					return selection

			# If no service was found that has the link cached, search again for the the best sevice but do not check if it is cached this time.
			if cached: return self.serviceBest(item = item, cached = False, cloud = cloud)

			return None
		except:
			tools.Logger.error()

	def serviceDetermine(self, mode, item, popups = False, all = False, cloud = False):
		try:
			self._initialize(item)

			service = None
			if all: services = self.mServices
			else: services = [i for i in self.mServices if i.supported(item, cloud = cloud)]

			if len(services) == 1:
				service = services[0].id()
			else:
				if popups:
					if mode == Handler.ModeNone or mode == Handler.ModeDefault:
						if self.mDefault == Handler.ModeBest:
							service = self.serviceBest(item = item, cloud = cloud)
						elif self.mDefault == Handler.ModeNone or self.mDefault == Handler.ModeSelection or self.mDefault == Handler.ModeFile:
							service = self.options(item = item, popups = popups, all = all, cloud = cloud)
						else:
							try: service = self.mDefault.id()
							except: service = self.options(item = item, popups = popups, all = all, cloud = cloud)
					elif mode == Handler.ModeBest:
						service = self.serviceBest(item = item, cloud = cloud)
					else:
						service = self.options(item = item, popups = popups, all = all, cloud = cloud)
				elif mode == Handler.ModeDefault: # Autoplay
					try:
						service = self.mDefault.id()
					except:
						service = self.serviceBest(item = item, cloud = cloud)

			if service is None:
				service = self.options(item = item, popups = popups, all = all, cloud = cloud)
			if service is None:
				return Handler.ReturnUnavailable
			elif service == Handler.ReturnCancel or service == Handler.ReturnUnavailable:
				return service
			else:
				if self.service(name = service).supported(item, cloud = cloud):
					return service
				else:
					return self.serviceBest(item = item, cloud = cloud)
		except:
			tools.Logger.error()

	@classmethod
	def serviceExternal(self, service):
		if not tools.Tools.isString(service):
			try: service = service.id()
			except: return False
		return service == HandleElementum().id() or service == HandleQuasar().id()

	def options(self, item, popups = False, all = False, cloud = False):
		try:
			if popups:
				self._initialize(item)

				if self.mType == Handler.TypeTorrent: title = 33473
				elif self.mType == Handler.TypeUsenet: title = 33482
				else: title = 33488

				if all: services = self.mServices
				else: services = [i for i in self.mServices if i.supported(item, cloud = cloud)]
				servicesCount = len(services)

				if servicesCount == 1:
					return services[0].name()
				elif servicesCount > 1:
					items = []
					for i in services:
						stream = item['stream']
						extra = ''
						if stream.accessTypeDirect():
							extra = interface.Format.font(33489, color = interface.Format.colorLighter(color = interface.Format.colorSpecial(), change = 10))
						elif stream.sourceTypePremium():
							extra = interface.Format.font(33768, color = interface.Format.colorLighter(color = interface.Format.colorSpecial(), change = 10))
						elif i.cache(item = item, service = i):
							extra = interface.Format.font(33884, color = interface.Format.colorSpecial())
						elif i.debrid():
							extra = interface.Format.font(33209, color = interface.Format.colorLighter(color = interface.Format.colorSpecial(), change = 30))
						elif i.open():
							extra = interface.Format.font(33211, color = interface.Format.colorLighter(color = interface.Format.colorSpecial(), change = 50))
						elif i.addon():
							extra = interface.Format.font(35614, color = interface.Format.colorLighter(color = interface.Format.colorSpecial(), change = 50))
						if not extra == '':
							extra = interface.Format.fontUppercase(extra)

						label = [i.name()]
						try:
							service = i.serviceName()
							serviceHas = True
						except:
							serviceHas = False

						if serviceHas:
							label[0] = interface.Format.fontColor(label[0], color = interface.Format.colorLighter(color = interface.Format.colorAlternative(), change = 10))
							if service: label.append(service)
							else: label.append(interface.Translation.string(33800))
						elif i.addon():
							label.insert(0, interface.Format.fontColor(35354, color = interface.Format.colorLighter(color = interface.Format.colorAlternative(), change = 20)))
						else:
							label.insert(0, interface.Format.fontColor(35639, color = interface.Format.colorLighter(color = interface.Format.colorAlternative())))

						if extra: label.append(extra)
						label = interface.Format.fontBold(interface.Format.iconSeparator(color = True, pad = True).join(label))
						items.append(label)
					index = interface.Dialog.select(title = title, items = items)
					if index < 0:
						return Handler.ReturnCancel
					else:
						return services[index].id()
		except:
			tools.Logger.error()
		return Handler.ReturnUnavailable

	def handle(self, link, item, name = None, download = False, popups = False, close = True, mode = ModeNone, cloud = False):
		self._initialize(item)

		if popups and name is None:
			name = self.options(item = item, popups = popups, cloud = cloud)
			if name == Handler.ReturnUnavailable or name == Handler.ReturnCancel:
				return {'success' : False, 'error' : name}

		service = self.service(name = name)

		if popups and service is None:
			if self.mType == Handler.TypeTorrent:
				title = 33473
				message = 33483
			elif self.mType == Handler.TypeUsenet:
				title = 33482
				message = 33484
			elif self.mType == Handler.TypeHoster:
				title = 33488
				message = 33485
			if interface.Dialog.option(title = title, message = message, labelConfirm = 33011, labelDeny = 33486):
				tools.Settings.launch(tools.Settings.CategoryStream)
			return Handler.ReturnUnavailable

		result = service.handle(link = link, item = item, download = download, popups = popups, close = close, select = mode == Handler.ModeFile, cloud = cloud)
		result['handle'] = service.id()
		if not result['success']:
			if not result['error'] in [Handler.ReturnUnavailable, Handler.ReturnExternal, Handler.ReturnCancel]:
				if not 'notification' in result or not result['notification']:
					interface.Dialog.notification(title = 33448, message = 35295, icon = interface.Dialog.IconError)
				result['error'] = Handler.ReturnUnavailable
		return result

class Handle(object):

	def __init__(self, name, id = None, abbreviation = None, acronym = None, priority = None, debrid = False, open = False, addon = False):
		self.mId = name.lower() if id is None else id
		self.mName = name
		self.mAbbreviation = abbreviation
		self.mAcronym = acronym
		self.mPriority = priority
		self.mDebrid = debrid
		self.mOpen = open
		self.mAddon = addon

	def data(self):
		return {
			'id' : self.mId,
			'name' : self.mName,
			'abbreviation' : self.mAbbreviation,
			'acronym' : self.mAcronym,
			'priority' : self.mPriority,
			'debrid' : self.mDebrid,
			'open' : self.mOpen,
			'addon' : self.mAddon,
		}

	def id(self):
		return self.mId

	def name(self):
		return self.mName

	def abbreviation(self):
		return self.mAbbreviation

	def acronym(self):
		return self.mAcronym

	def priority(self):
		return self.mPriority

	def debrid(self):
		return self.mDebrid

	def open(self):
		return self.mOpen

	def addon(self):
		return self.mAddon

	def cache(self, item, service = None):
		if tools.Tools.isDictionary(item):
			try: item = item['stream']
			except: pass

		if item.accessCache(self.id()): return True

		try:
			name = item.service()
			if name: return item.accessCache(name.lower())
		except: pass

		# id is None for the "Automatic" ReolveUrl/UrlResolver selection options.
		# In that case check below if any debrid is cached.
		try:
			id = service.serviceId()
			if id and item.accessCache(id): return True
		except:
			id = True

		if not service or id is None:
			debrids = self.debrids()
			if debrids:
				for debrid in debrids:
					if item.accessCache(debrid): return True

		return False

	def supported(self, item, cloud = False):
		try:
			services = self.services()
			if services is None:
				return False
			else:
				from lib.modules.stream import Stream

				stream = None
				if tools.Tools.isDictionary(item):
					try: stream = item['stream']
					except: pass
				elif tools.Tools.isInstance(item, Stream):
					stream = item

				if stream:
					# Some debrid services, like Premiumize, still have some old hoster files cached, although they do not support new downloads for the hoster anymore.
					# If the file is cached, assume it is supported, even if the hoster is not listed in the debrid's service list anymore.
					if self.cache(item = item): return True

					modes = stream.sourceMode(all = True)
					if not modes: return False
				else:
					modes = [item]

				all = []
				for service in services:
					service = service.lower()
					all.append(service)

					# The legacy Orion returns hosters without any symbols (eg: "nitrodownload" instead of "nitro.download").
					plain = tools.Tools.replaceNotAlphaNumeric(service)
					if not plain == service: all.append(plain)

				for mode in modes:
					mode = mode.lower()
					modePlain = tools.Tools.replaceNotAlphaNumeric(mode)

					# External providers do not always set the full hoster domain (eg: vidoza instead of vidoza.net).
					# Do not just check if the domain contains the hoster, since this would match eg: "cloud" and "icloud".
					# Instead check if the domain starts with the hoster and followed by a ".".
					modeExtra = None if '.' in mode else (mode + '.')

					for service in all:
						if mode == service or modePlain == service or (modeExtra and '.' in service and service.startswith(modeExtra)):
							return True

					if mode == self.id(): return True
		except:
			tools.Logger.error()

		return False

	def debrids(self, all = False):
		if all:
			from lib.debrid.debrid import Debrid
			return [i.id() for i in Debrid.handles()]
		return None

	def handle(self, link, item, download = False, popups = False, close = True, select = False, cloud = False):
		pass

	def services(self):
		pass

class HandleDirect(Handle):

	def __init__(self):
		Handle.__init__(self, interface.Translation.string(33489))

	def handle(self, link, item, download = False, popups = False, close = True, select = False, cloud = False):
		from lib import debrid
		provider = item['stream'].sourceProvider().lower()

		# RealDebrid premium links need to be resolved through RealDebrid.
		# Other debrid services have direct links.
		handle = debrid.realdebrid.Handle()
		if provider == handle.id(): return handle.handle(link = link, item = item, download = download, popups = popups, close = close, select = select, cloud = cloud)
		else: return debrid.core.Core.addResult(link = link)

	def supported(self, item, cloud = False):
		if cloud and not item['stream'].sourceProvider().lower() == 'realdebrid': return False
		elif item['stream'].accessTypeDirect(): return True
		else: return False

	def services(self):
		return None

class HandleResolver(Handle):

	# Order of appearance in the selection dialog.
	Debrids = ['premiumize', 'offcloud', 'realdebrid', 'alldebrid', 'debridlink', 'linksnappy', 'megadebrid', 'rapidpremium', 'simplydebrid', 'smoozed']

	def __init__(self, name, module, id = None, abbreviation = None, acronym = None, priority = None, debrid = False, open = False, addon = False, service = None):
		Handle.__init__(self, name = name, id = id, abbreviation = abbreviation, acronym = acronym, priority = priority, debrid = debrid, open = open, addon = addon)

		self.mModule = None
		self.mModuleName = module

		self.mServices = None
		self.mService = service
		self.mServiceId = None
		self.mServiceName = None
		if service:
			service = tools.Regex.remove(data = service, expression = '.*?(\..*)', group = 1) # Remove TLD. Eg: Premiumize.me
			service = tools.Regex.remove(data = service, expression = tools.Regex.Symbol) # Remove symbols. Eg: Real-Debrid
			self.mServiceName = service

		if self.mServiceName:
			self.mServiceId = self.mServiceName.lower()
			self.mId += self.mServiceId

	def module(self):
		# Do not import at the start of the script, otherwise the resolver code will be loaded everytime handler.py is imported, drastically slowing down menus.
		if self.mModule is None:
			try:
				import importlib
				self.mModule = importlib.import_module(self.mModuleName)
			except:
				self.mModule = False
		return self.mModule

	def service(self):
		return self.mService

	def serviceId(self):
		return self.mServiceId

	def serviceName(self):
		return self.mServiceName

	def services(self):
		return self.mServices

	def instances(self, type = None):
		result = None
		try:
			result = []
			module = self.module()
			if module:
				for i in module.relevant_resolvers(order_matters = True, include_universal = True):
					i = i()
					if i.isUniversal():
						try: hosts = i.get_hosts()
						except:
							try: hosts = i.get_all_hosters()
							except: hosts = i.get_hosters()
						if hosts and tools.Tools.isArray(hosts) and tools.Tools.isArray(hosts[0]): hosts = hosts[0]
						if type is None:
							result.append(i)
						elif type == Handler.TypeTorrent:
							if 'torrent' in hosts or 'magnet' in hosts: result.append(i)
						elif type == Handler.TypeUsenet:
							if 'usenet' in hosts or 'nzb' in hosts: result.append(i)
						elif type == Handler.TypeHoster:
							result.append(i)

				# Sort resolvers to have the same order as Gaia.
				sort = []
				for i in result:
					resolver = self.__class__(service = i.name)
					try: index = HandleResolver.Debrids.index(resolver.serviceId())
					except: index = 99999
					sort.append((index, resolver))
				result = [i[1] for i in sorted(sort, key = lambda i: i[0])]
		except:
			tools.Logger.error()
			result = []

		return result

	def handle(self, link, item, download = False, popups = False, close = True, select = False, cloud = False):
		from lib.debrid import core
		try:
			if item and item['stream'].accessTypeDirect():
				return link
			else:
				module = self.module()
				if module:
					if self.service():
						for i in module.relevant_resolvers(order_matters = True):
							if i.name == self.service():
								i = i()
								try:
									i.login()
									host, id = i.get_host_and_id(link)
									linkNew = i.get_media_url(host, id)
									if linkNew: return core.Core.addResult(link = linkNew)
								except: pass
								break
					else:
						# First check if a debrid resolver is available.
						resolvers = [i() for i in module.relevant_resolvers(order_matters = True) if i.isUniversal()]
						if len(resolvers) == 0: resolvers = [i() for i in module.relevant_resolvers(order_matters = True, include_universal = False) if 'rapidgator.net' in i.domains]
						for i in resolvers:
							try:
								i.login()
								host, id = i.get_host_and_id(link)
								linkNew = i.get_media_url(host, id)
								if linkNew: return core.Core.addResult(link = linkNew)
							except: pass

						# If not supported by debrid, try normal resolvers.
						media = module.HostedMediaFile(url = link, include_disabled = True, include_universal = False)
						if media.valid_url() == True: return core.Core.addResult(link = media.resolve(allow_popups = popups))
		except:
			tools.Logger.error()
		return core.Core.addResult(link = None)

	def supported(self, item, cloud = False):
		if cloud: return False
		elif item['stream'].accessTypeDirect(): return True
		elif item['stream'].sourceTypeTorrent(): return True
		else: return Handle.supported(self, item)

	def debrids(self, item = None):
		try:
			result = []
			module = self.module()
			if module:
				resolvers = module.relevant_resolvers(order_matters = True)
				debrids = Handle.debrids(self, all = True)
				for i in debrids:
					for j in resolvers:
						if i in str(j).lower():
							if item:
								j = j()
								link = item['stream'].linkPrimary()
								host, id = j.get_host_and_id(link)
								if j.valid_url(url = link, host = host): result.append(i)
							else:
								result.append(i)
							break
			return result
		except:
			tools.Logger.error()
			return []

	def services(self):
		if self.mServices is None:
			try: from functools import reduce
			except: pass
			try:
				service = self.service()
				result = []

				module = self.module()
				if module:
					resolvers = module.relevant_resolvers(order_matters = True)
					for resolver in resolvers:
						if not service or service == resolver.name:
							resolver = resolver()
							# The "domains" attribute of universal debrid resolvers is not always fully populated with all TLDs.
							# For instance, the ".cc" TLD is missing for clicknupload although other TLDs are present.
							# Use the get_hosts function to retrieve all available domains.
							if resolver.isUniversal():
								try: hosts = resolver.get_hosts()
								except:
									try: hosts = resolver.get_all_hosters()
									except:
										try: hosts = resolver.get_hosters()
										except: hosts = resolver.domains
								if hosts and tools.Tools.isArray(hosts) and tools.Tools.isArray(hosts[0]): hosts = hosts[0]
							else:
								hosts = resolver.domains
							if not '*' in hosts: result.append(hosts)

					result = [i.lower() for i in reduce(lambda x, y: x+y, result)]
					result = [x for y,x in enumerate(result) if x not in result[:y]]

				self.mServices = result
			except:
				tools.Logger.error()
				self.mServices = []
		return self.mServices

class HandleResolveUrl(HandleResolver):

	def __init__(self, service = None):
		HandleResolver.__init__(self, name = interface.Translation.string(35310), module = 'resolveurl', debrid = True, open = True, addon = True, service = service)

class HandleUrlResolver(HandleResolver):

	def __init__(self, service = None):
		HandleResolver.__init__(self, name = interface.Translation.string(33747), module = 'urlresolver', debrid = True, open = True, addon = True, service = service)

class HandleYoutube(Handle):

	def __init__(self):
		Handle.__init__(self, 'YouTube', addon = True)
		self.mServices = None

	def handle(self, link, item, download = False, popups = False, close = True, select = False, cloud = False):
		from lib.debrid import core
		from lib.modules.video import Video
		try:
			interface.Loader.hide()
			interface.Dialog.notification(title = 35296, message = 35365, icon = interface.Dialog.IconSuccess, time = 10000)
			interface.Core.close()

			Video(internal = True).play(link = link)

			interface.Loader.hide()
			tools.Time.sleep(0.5)
			interface.Loader.hide()

			player = interface.Player()
			started = False
			for i in range(30):
				# YouTube can show a download progress dialog, or a list dialog for selecting a specific file from the torrent, and possibly other dialogs.
				# YouTube does not start playing if the Gaia playback window is visible. Therefore check >= IdDialogCustom.
				if player.isPlaying():

					# Use the custom isPlayback() function to wait until the video has actually started.
					# Otherwise no loader or loading window is visible while the YopuTube addon starts the playback.
					for j in range(20):
						if player.isPlayback() or player.statusFinished(): break
						tools.Time.sleep(0.5)
						interface.Loader.hide()

					started = True
					break
				tools.Time.sleep(0.5)
				interface.Loader.hide()

			# Close the stream window, otherwise YouTube opens the player behind it.
			if player.isPlaying() and window.WindowStreams.enabled():
				window.WindowStreams.close()

			# Assume that YouTube failed to start/resolve the torrent. YouTube only shows an error in the Kodi log file.
			if not started:
				interface.Dialog.notification(title = 35296, message = 35366, icon = interface.Dialog.IconWarning, time = 4000)
				return core.Core.addResult(error = Handler.ReturnUnavailable)

			return core.Core.addResult(error = Handler.ReturnExternal) # Return because YouTube will handle the playback.
		except:
			tools.Logger.error()

	def services(self):
		if self.mServices is None:
			from lib.modules.video import Video
			self.mServices = []
			if Video.enabled(external = True) and Video.authenticated(external = True): self.mServices.extend(Video.domains())
		return self.mServices

class HandleElementum(Handle):

	def __init__(self):
		Handle.__init__(self, 'Elementum', addon = True)
		self.mServices = None

	def handle(self, link, item, download = False, popups = False, close = True, select = False, cloud = False):
		from lib.debrid import core
		try:
			parameters = {}

			# Link
			parameters['uri'] = network.Networker.linkQuote(link)

			# Type
			type = None
			if 'type' in item and not item['type'] is None:
				if item['type'] == tools.Media.TypeShow:
					type = 'episode'
				else:
					type = 'movie'
			elif 'tvshowtitle' in item:
				type = 'episode'
			else:
				type = 'movie'
			parameters['type'] = type

			# Information
			information = item['information'] if 'information' in item else None

			# Show
			if type == 'episode':
				if 'season' in information:
					parameters['season'] = information['season']
				if 'episode' in information:
					parameters['episode'] = information['episode']

			# TMDB
			try:
				from lib.modules.account import Tmdb
				key = Tmdb().key()
				if key:
					if type == 'episode' and 'tvdb' in information and information['tvdb']: # Shows - IMDB ID for episodes does not work on tmdb
						result = cache.Cache.instance().cacheLong(network.Networker().requestJson, link = 'http://api.themoviedb.org/3/find/%s?api_key=%s&external_source=tvdb_id' % (information['tvdb'], key))
						result = result['tv_episode_results']
						if tools.Tools.isArray(result): result = result[0]
						parameters['tmdb'] = str(result['id'])
						parameters['show'] = str(result['show_id'])
					elif type == 'movie' and 'imdb' in information and information['imdb']:
						result = cache.Cache.instance().cacheLong(network.Networker().requestJson, link = 'http://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % (information['imdb'], key))
						result = result['movie_results']
						if tools.Tools.isArray(result): result = result[0]
						parameters['tmdb'] = str(result['id'])
			except:
				tools.Logger.error()

			# This will add the torrent to Elementum, but after Elementum's buffer phase, playback is not started and nothing happens.
			# This is because of the source-selection dialog that causes Kodi's addon handle to be -1 (aka no handle). This will cause the Kodi player to not launch.
			# Use the RPC instead.
			# action = 'torrents/add' if download else 'play'
			#parameters = network.Networker.linkEncode(parameters)
			#tools.System.execute('RunPlugin(plugin://plugin.video.elementum/%s?%s)' % (action, parameters))

			interface.Dialog.notification(title = 35316, message = 35319, icon = interface.Dialog.IconSuccess, time = 10000)
			interface.Core.close()
			interface.Loader.hide() # Make sure Gaia's loaders are hidden, so that we only detect Elementum loaders below.

			if download: network.Networker().request(link = tools.Elementum.linkAdd(parameters))
			else: network.Networker().request(link = tools.Elementum.linkPlay(parameters))

			started = False
			tools.Time.sleep(1)
			for i in range(0, 90): # Do not check forever, in case Elementum fails to add/resolve the torrent.
				if interface.Dialog.dialogProgressVisible():
					started = True
					break
				elif i > 10 and not interface.Loader.visible(): # Elementum failed and closes the loader. Give some time for the loader to show up in the first plaace.
					break
				tools.Time.sleep(0.5)

			player = interface.Player()
			tools.Time.sleep(0.5)
			interface.Loader.hide()

			while True:
				# Elementum can show a download progress dialog, or a list dialog for selecting a specific file from the torrent, and possibly other dialogs.
				# Elementum does not start playing if the Gaia playback window is visible. Therefore check >= IdDialogCustom.
				if not interface.Dialog.dialogVisible(window = False) or interface.Dialog.dialogId() >= interface.Dialog.IdDialogCustom or player.isPlaying(): break
				tools.Time.sleep(0.5)

			# Elementum does not start playback after initial buffering.
			# If requesting the link again after buffering is done, Elementum does start playback.
			if not download:
				if not player.isPlaying(): interface.Loader.show()
				tools.Time.sleep(3)
				if not player.isPlaying(): network.Networker().request(link = tools.Elementum.linkPlay({'resume' : parameters['uri']}))
				interface.Loader.hide()

			# Close the stream window, otherwise Elementum opens the player behind it.
			if player.isPlaying() and window.WindowStreams.enabled():
				window.WindowStreams.close()

			# Assume that Elementum failed to start/resolve the torrent. Elementum only shows an error in the Kodi log file.
			if not started:
				interface.Dialog.notification(title = 35316, message = 35364, icon = interface.Dialog.IconWarning, time = 4000)
				return core.Core.addResult(error = Handler.ReturnUnavailable)

			return core.Core.addResult(error = Handler.ReturnExternal) # Return because Elementum will handle the playback.
		except:
			tools.Logger.error()

	def services(self):
		if self.mServices is None:
			self.mServices = []
			if tools.Settings.getInteger('stream.default.torrent') > 0 and tools.Settings.getBoolean('stream.elementum.torrent'):
				self.mServices.append('torrent')
		return self.mServices

class HandleQuasar(Handle):

	def __init__(self):
		Handle.__init__(self, 'Quasar', addon = True)
		self.mServices = None

	def handle(self, link, item, download = False, popups = False, close = True, select = False, cloud = False):
		from lib.debrid import core
		try:
			parameters = {}

			# Link
			parameters['uri'] = network.Networker.linkQuote(link)

			# Type
			type = None
			if 'type' in item and not item['type'] is None:
				if item['type'] == tools.Media.TypeShow:
					type = 'episode'
				else:
					type = 'movie'
			elif 'tvshowtitle' in item:
				type = 'episode'
			else:
				type = 'movie'
			parameters['type'] = type

			# Information
			information = item['information'] if 'information' in item else None

			# Show
			if type == 'episode':
				if 'season' in information:
					parameters['season'] = information['season']
				if 'episode' in information:
					parameters['episode'] = information['episode']

			# TMDB
			try:
				from lib.modules.account import Tmdb
				key = Tmdb().key()
				if key:
					if type == 'episode' and 'tvdb' in information and information['tvdb']: # Shows - IMDB ID for episodes does not work on tmdb
						result = cache.Cache.instance().cacheLong(network.Networker().requestJson, link = 'http://api.themoviedb.org/3/find/%s?api_key=%s&external_source=tvdb_id' % (information['tvdb'], key))
						result = result['tv_episode_results']
						if tools.Tools.isArray(result): result = result[0]
						parameters['tmdb'] = str(result['id'])
						parameters['show'] = str(result['show_id'])
					elif type == 'movie' and 'imdb' in information and information['imdb']:
						result = cache.Cache.instance().cacheLong(network.Networker().requestJson, link = 'http://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % (information['imdb'], key))
						result = result['movie_results']
						if tools.Tools.isArray(result): result = result[0]
						parameters['tmdb'] = str(result['id'])
			except:
				tools.Logger.error()

			# This will add the torrent to Quasar, but after Quasar's buffer phase, playback is not started and nothing happens.
			# This is because of the source-selection dialog that causes Kodi's addon handle to be -1 (aka no handle). This will cause the Kodi player to not launch.
			# Use the RPC instead.
			# action = 'torrents/add' if download else 'play'
			#parameters = network.Networker.linkEncode(parameters)
			#tools.System.execute('RunPlugin(plugin://plugin.video.quasar/%s?%s)' % (action, parameters))

			interface.Dialog.notification(title = 33570, message = 35320, icon = interface.Dialog.IconSuccess, time = 10000)
			interface.Core.close()
			interface.Loader.hide() # Make sure Gaia's loaders are hidden, so that we only detect Elementum loaders below.

			if download: network.Networker().request(link = tools.Quasar.linkAdd(parameters))
			else: network.Networker().request(link = tools.Quasar.linkPlay(parameters))

			started = False
			tools.Time.sleep(1)
			for i in range(0, 90): # Do not check forever, in case Quasar fails to add/resolve the torrent.
				if interface.Dialog.dialogProgressVisible():
					started = True
					break
				elif i > 10 and not interface.Loader.visible(): # Quasar failed and closes the loader. Give some time for the loader to show up in the first plaace.
					break
				tools.Time.sleep(0.5)

			player = interface.Player()
			tools.Time.sleep(0.5)
			interface.Loader.hide()

			while True:
				# Quasar can show a download progress dialog, or a list dialog for selecting a specific file from the torrent, and possibly other dialogs.
				# Quasar does not start playing if the Gaia playback window is visible. Therefore check >= IdDialogCustom.
				if not interface.Dialog.dialogVisible(window = False) or interface.Dialog.dialogId() >= interface.Dialog.IdDialogCustom or player.isPlaying(): break
				tools.Time.sleep(0.5)

			# Quasar does not start playback after initial buffering.
			# If requesting the link again after buffering is done, Quasar does start playback.
			if not download:
				if not player.isPlaying(): interface.Loader.show()
				tools.Time.sleep(3)
				if not player.isPlaying(): network.Networker().request(link = tools.Quasar.linkPlay({'resume' : parameters['uri']}))
				interface.Loader.hide()

			# Close the stream window, otherwise Quasar opens the player behind it.
			if player.isPlaying() and window.WindowStreams.enabled():
				window.WindowStreams.close()

			# Assume that Quasar failed to start/resolve the torrent. Quasar only shows an error in the Kodi log file.
			if not started:
				interface.Dialog.notification(title = 33570, message = 35364, icon = interface.Dialog.IconWarning, time = 4000)
				return core.Core.addResult(error = Handler.ReturnUnavailable)

			return core.Core.addResult(error = Handler.ReturnExternal) # Return because Quasar will handle the playback.
		except:
			tools.Logger.error()

	def services(self):
		if self.mServices is None:
			self.mServices = []
			if tools.Settings.getInteger('stream.quasar.torrent') > 0 and tools.Settings.getBoolean('stream.quasar.torrent'):
				self.mServices.append('torrent')
		return self.mServices
