# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.modules import tools

try:
	from urllib.parse import urlparse, urlsplit, urlencode, parse_qs, quote, quote_plus, unquote, unquote_plus
except:
	from urlparse import urlparse, urlsplit, parse_qs
	from urllib import urlencode, quote, quote_plus, unquote, unquote_plus

class Networker(object):

	MethodGet					= 'GET'
	MethodPost					= 'POST'
	MethodPut					= 'PUT'
	MethodDelete				= 'DELETE'
	MethodHead					= 'HEAD'

	DataNone					= None
	DataPost					= 'post'
	DataJson					= 'json'
	DataForm					= 'form'
	DataMulti					= 'multi'

	AgentNone					= None
	AgentAddon					= 'addon'
	AgentDesktopRandom			= 'desktoprandom'
	AgentDesktopFixed			= 'desktopfixed'
	AgentMobileRandom			= 'mobilerandom'
	AgentMobileFixed			= 'mobilefixed'

	MimeJson					= 'application/json'
	MimeMulti					= 'multipart/form-data'
	MimeForm					= 'application/x-www-form-urlencoded'

	# https://webcheatsheet.com/html/character_sets_list.php
	CharsetUtf8					= 'utf-8'
	CharsetWin1251				= 'windows-1251'

	HeaderAuthorization			= 'Authorization'
	HeaderUserAgent				= 'User-Agent'
	HeaderContentType			= 'Content-Type'
	HeaderContentDisposition	= 'Content-Disposition'
	HeaderCookie				= 'Cookie'
	HeaderRange					= 'Range'
	HeaderRequestToken			= 'X-Request-Token'

	CookiePhp					= 'PHPSESSID'

	StatusNone					= None
	StatusUnknown				= 'unknown'
	StatusOnline				= 'online'
	StatusOffline				= 'offline'
	StatusCloudflare			= 'cloudflare'

	ErrorUnknown				= 'unknown'		# Unknown error.
	ErrorConnection				= 'connection'	# The connection could not be establish (eg: invalid URL, cannot reolve host, domain down).
	ErrorRequest				= 'request'		# The request failed (eg: HTTP errors).
	ErrorCloudflare				= 'cloudflare'	# The request could not bypass Cloudflare (eg: unsolvable challenges, captcha).
	ErrorCertificate			= 'certificate'	# SSL retrieval or validation errors.

	CloudflareUnknown			= 'unknown'		# Unknown Cloudflare error.
	CloudflareChallenge			= 'challenge'	# Cloudflare new kind of challenge.
	CloudflareSolve				= 'solve'		# Cloudflare challenge cannot be solved.
	CloudflareLoop				= 'loop'		# Cloudflare recursive depth loop.
	Cloudflare1020				= '1020'		# Cloudflare code 1020 block.
	CloudflareIuam				= 'iuam'		# Cloudflare problem extracting IUAM paramters.
	CloudflareCaptcha			= 'captcha'		# Cloudflare various captcha errors.

	# Must be the same as in cloudflare.py.
	# Must have the same values as in settings.xml.
	ValidateStrict				= 3	# Full verification. If anything is wrong with the SSL, the request will fail.
	ValidateModerate			= 2	# Strict verification. Like ValidateStrict, but allows expired and incorrect-domain SSL.
	ValidateLenient				= 1	# Lenient verification. Like ValidateModerate, but uses the old insecure TLSv1 which avoids certain SSL errors (eg: sslv3 alert handshake failure).
	ValidateNone				= 0	# Not implemented yet. Not sure if it can be switched off completley. Currently will fall back to ValidateLenient.

	AuthorizationBasic			= 'Basic'
	AuthorizationBearer			= 'Bearer'

	TimeoutLong					= 45
	TimeoutMedium				= 30
	TimeoutShort				= 15

	###################################################################
	# CONSTRUCTOR
	###################################################################

	def __init__(self):
		self.mRequest = None
		self.mResponse = None

	###################################################################
	# INTERNAL
	###################################################################

	def _clean(self):
		self.mRequest = {
			'method' : None, # The request HTTP method.
			'link' : None, # The request URL.
			'data' : None, # The request POST data.
			'headers' : None, # The request headers.
		}
		self.mResponse = {
			'request' : None, # The original request.
			'success' : None, # Whether or not the request was successful.
			'link' : None, # The final redirect URL
			'status' : {
				'code' : None, # The HTTP status code.
				'message' : None, # The HTTP status description.
				'duration' : None, # How long in milliseconds the request took to complete. This only measures the time it takes to receive a reply and not the time it takes to download the data.
			},
			'error' : {
				'type' : None, # The type of the error occured.
				'code' : None, # The code of the error occured. Is the HTTP status code if it is a request error, otherwise it is another error code string.
				'message' : None, # The description of the error occured. Is the HTTP status description if it is a request error, otherwise it is an exception message.
			},
			'meta' : {
				'type' : None, # The MIME type extracted from the headers.
				'name' : None, # The file name extracted from the headers.
				'size' : None, # The file size extracted from the headers.
			},
			'data' : {
				'bytes' : None, # The response raw byte data.
				'unicode' : None, # The response raw byte data converted to unicode. The "text" parameter sometimes incorrectly removes special characters (like the yellow star).
				'text' : None, # The response unicode text data.
				'json' : None, # The response JSON data if applicable.
			},
			'headers' : None, # The response headers.
			'cookies' : None, # The response cookies.
		}

	###################################################################
	# LINK
	###################################################################

	# Replaces special characters with %XX.
	# If plus parameter is True, spaces are replaced with + instead of %20.
	# Safe specifies a string of characters that should not be encoded.
	# If check, will check if the data is already encoded to avoid multiple encoding.
	@classmethod
	def linkQuote(self, data, plus = False, safe = None, check = False):
		if check and not self.linkUnquote(data = data, plus = plus) == data: return data
		if safe: return quote_plus(data, safe = safe) if plus else quote(data, safe = safe)
		else: return quote_plus(data) if plus else quote(data)

	# Replaces %XX with special characters.
	# If plus parameter is True, + are also replaced with spaces instead of only %20.
	@classmethod
	def linkUnquote(self, data, plus = False):
		return unquote_plus(data) if plus else unquote(data)

	# Encodes a dictionary into a GET parameter string.
	@classmethod
	def linkEncode(self, data, duplicates = True):
		return urlencode(data, doseq = duplicates)

	# Decodes a GET parameter string into a dictionary.
	# If case parameter is True, a case-insenstive request dictionary is returned instead of a native dictionary.
	# If multi parameter is True and multiple parameters with the same name exists, the parameters in the result dictionary aare returned as a list.
	@classmethod
	def linkDecode(self, data, case = False, multi = False):
		result = {}
		parameters = parse_qs(data.lstrip('?'), keep_blank_values = True)
		for key, values in parameters.items():
			if key.endswith('[]'): key = key.replace('[]', '')
			for value in values:
				if multi:
					if key in result: result[key].append(value)
					else: result[key] = [value]
				else:
					result[key] = value
		if case:
			from lib.externals.requests.structures import CaseInsensitiveDict
			result = CaseInsensitiveDict(result)
		return result

	@classmethod
	def _linkClean(self, link, strip = True):
		headers = {}
		if link:
			index = link.find('|')
			if index >= 0:
				headers = link[index + 1:]
				if strip: link = link[:index]
				headers = self.linkDecode(headers, case = True)
			link = link.replace(' ', '%20')
		return link, headers

	# Cleans a link.
	# If strip parameter is True, any headers in the link will be removed.
	@classmethod
	def linkClean(self, link, strip = True):
		link, headers = self._linkClean(link = link, strip = strip)
		return link

	# Extract the headers from a URL with the format: http://whatever.com/whatever|key1=value1&&key2=value2
	# If the headers parameter is provided, it will build a new link and append the headers to the URL.
	# If the decode parameter is True, the ;-joined headers will be split and returned as a dictionary instead of a string. Is useful for cookies, but also splits headers like User-Agent.
	@classmethod
	def linkHeaders(self, link, headers = None, cookies = None, decode = False):
		if headers is None and cookies is None:
			link, headers = self._linkClean(link = link)
			if decode: headers = {key : self._headersSplit(headers = value) for key, value in headers.items()} if headers else headers
			return headers
		else:
			from lib.externals.requests.structures import CaseInsensitiveDict
			if headers is None: headers = {}
			if cookies: headers['Cookie'] = cookies
			headers = {key.title() : (self._headersJoin(headers = value) if tools.Tools.isInstance(value, (dict, CaseInsensitiveDict)) else value) for key, value in headers.items()}
			if headers: link += '|' + self.linkEncode(headers)
			return link

	# Extract the cookies from a URL with the format: http://whatever.com/whatever|Cookie=whatever
	# If the cookies parameter is provided, it will build a new link and append the cookies to the URL.
	# If the decode parameter is False, the cookies will be returned as an encoded string instead of a dictionary.
	@classmethod
	def linkCookies(self, link, cookies = None, headers = None, decode = True):
		if cookies is None:
			headers = self.linkHeaders(link = link, decode = decode)
			return headers['Cookie'] if 'Cookie' in headers else {}
		else:
			return self.linkHeaders(link = link, cookies = cookies)

	# Create a GET link with a dictionary of parameters.
	@classmethod
	def linkCreate(self, link = None, parameters = None, duplicates = True, encode = True):
		if tools.Tools.isArray(link): link = self.linkJoin(*link)
		if parameters:
			if not tools.Tools.isString(parameters):

				# For links that require a fixed parameter order (eg: NewzNab).
				if tools.Tools.isArray(parameters):
					try: from collections import OrderedDict
					except: from lib.externals.ordereddict.ordereddict import OrderedDict
					parameters = OrderedDict(parameters)

				if encode:
					parameters = self.linkEncode(data = parameters, duplicates = duplicates)
				else:
					# urllib.urlencode only has the "quote_via" parameter since Python 3.5.
					# So we have to create it manually to accomodate older Kodi versions.
					url = []
					for key, value in parameters.items():
						keyNew = str(key) + '[]'
						found = False
						if not duplicates:
							for i in url:
								if i[0] == key or i[0] == keyNew:
									found = True
									break
						if not found:
							if tools.Tools.isArray(value):
								for i in value: url.append((keyNew, i))
							else:
								url.append((key,value))
					parameters = '&'.join([str(i[0]) + '=' + str(i[1]) for i in url])
			if link is None: link = parameters
			else: link += ('&' if '?' in link else '?') + parameters
		return link

	# Join parts into a link.
	@classmethod
	def linkJoin(self, *parts):
		if len(parts) == 0: return None
		result = parts[0].rstrip('/')
		for i in range(1, len(parts)):
			if parts[i]:
				if tools.Tools.isArray(parts[i]):
					for j in range(len(parts[i])):
						if parts[i][j]: result = result.rstrip('/') + '/' + str(parts[i][j]).lstrip('/')
				else: result = result.rstrip('/') + '/' + str(parts[i]).lstrip('/')
		return result

	# Get the file extension of a link if available.
	@classmethod
	def linkExtension(self, link):
		path = self.linkPath(link = link)
		path = path.split('?')[0].split('&')[0].split('|')[0].rsplit('.')
		if len(path) <= 1: return None
		return path[-1].replace('/', '').lower()

	@classmethod
	def linkIs(self, link, magnet = False):
		return tools.Tools.isString(link) and (tools.Regex.match(data = link, expression = '^\s*(http|ftp)s?:\/{2}') or (magnet and self.linkIsMagnet(link)))

	@classmethod
	def linkIsMagnet(self, link):
		return tools.Tools.isString(link) and tools.Regex.match(data = link, expression = '^\s*magnet:')

	@classmethod
	def linkIsIp(self, link):
		return tools.Tools.isString(link) and tools.Regex.match(data = link, expression = '^\s*((http|ftp)s?:\/{2})?\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')

	# Checks if a link is a local domain or IP address.
	@classmethod
	def linkIsLocal(self, link):
		try:
			import ipaddress
			if ipaddress.ip_address(link.lower()).is_private: return True
		except: pass
		return tools.Tools.isString(link) and tools.Regex.match(data = link, expression = '^\s*((http|ftp)s?:\/{2})?(localhost|127\.0\.0\.1|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.16\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|::1|0:0:0:0:0:0:0:1|fc[0-9a-f]{0,22}::|fd[0-9a-f]{0,22}::)')

	# Extracts the domain from the link.
	@classmethod
	def linkDomain(self, link, subdomain = False, topdomain = True, ip = True, scheme = False):
		# Manual string manipulation is not perfect. Cannot handle certain things like msulti-TLD (eg: co.uk).
		'''
		try:
			if self.linkIsMagnet(link): return None
			try: result = link.split('://')[1].split('/')[0].split(':')[0].strip()
			except: result = link.strip()
			isIp = self.linkIsIp(result)
			if not ip and isIp: return None
			if not subdomain and not isIp: result = '.'.join(result.split('.')[-2:])
			if not topdomain and not isIp: result = '.'.join(result.split('.')[:-1])
			return result.lower()
		except: return None
		'''

		if self.linkIsMagnet(link): return None
		from lib.externals import tldextract
		parts = tldextract.extract(link)

		result = parts[1]
		if not ip and self.linkIsIp(result): return None

		try:
			if topdomain is True and parts[2]: result = result + '.' + parts[2]
			elif topdomain: result = result + '.' + topdomain
		except: pass

		try:
			if subdomain is True and parts[0]: result = parts[0] + '.' + result
			elif subdomain: result = subdomain + '.' + result
		except: pass

		if scheme: result = self.linkScheme(link = link, syntax = True) + result

		return result.lower()

	# Add/replace the subdomain in the link.
	@classmethod
	def linkSubdomain(self, link, subdomain):
		domain = self.linkDomain(link = link, subdomain = subdomain, topdomain = True, ip = True, scheme = True)
		path = self.linkPath(link = link)
		return self.linkJoin(domain, path)

	# Extracts the path from the link (excluding the protocol, domain, and parameters).
	@classmethod
	def linkPath(self, link, parameters = False, strip = True):
		parse = urlparse(link)
		path = parse.path
		if parameters:
			query = tools.Converter.unicode(parse.query)
			if query: path += '?' + query
		if strip: path = path.lstrip('/')
		return path

	# Extracts the GET parameters from a link.
	# If decode parameter is False, the parameters are returned as a string instead of a dictionary.
	# If case parameter is True, a case-insenstive request dictionary is returned instead of a native dictionary.
	@classmethod
	def linkParameters(self, link, decode = True, case = False, multi = False, split = False):
		result = urlsplit(link) if split else urlparse(link)
		result = tools.Converter.unicode(result.query)
		if decode: result = self.linkDecode(data = result, case = case, multi = multi)
		return result

	# Extracts the link protocol/scheme.
	# syntax: add ://
	@classmethod
	def linkScheme(self, link, syntax = False):
		result = urlparse(link).scheme
		if syntax: result = result + '://'
		return result

	@classmethod
	def linkParse(self, link):
		return urlparse(link)

	###################################################################
	# AUTHORIZATION
	###################################################################

	# Creates an authorization header string.
	# Either provide the value, or the username and password.
	@classmethod
	def authorization(self, type, value = None, username = None, password = None):
		if value is None:
			if not username is None and not password is None:
				value = tools.Converter.base64To('%s:%s' % (username, password))
		if value is None: return None
		else: return '%s %s' % (type, value)

	# Creates an authorization header dictionary.
	@classmethod
	def authorizationHeader(self, type, value = None, username = None, password = None):
		authorization = self.authorization(type = type, value = value, username = username, password = password)
		if authorization: return {Networker.HeaderAuthorization : authorization}
		else: return None

	###################################################################
	# HTML
	###################################################################

	# Decodes HTML entities (eg: "&eacute;" -> "é").
	@classmethod
	def htmlDecode(self, data):
		try:
			try: from HTMLParser import HTMLParser
			except: from html.parser import HTMLParser
			data = HTMLParser().unescape(data)
		except:
			pass
		return data

	###################################################################
	# HEADERS
	###################################################################

	@classmethod
	def _headersClean(self, headers):
		return {key.title() : value for key, value in headers.items()}

	@classmethod
	def _headersMerge(self, headers1, headers2):
		return tools.Tools.dictionaryMerge(headers1, headers2)

	@classmethod
	def _headersJoin(self, headers):
		from lib.externals.requests.structures import CaseInsensitiveDict
		if tools.Tools.isArray(headers): headers = '; '.join([str(value) for value in headers])
		elif tools.Tools.isInstance(headers, (dict, CaseInsensitiveDict)): headers = '; '.join([str(key) + '=' + str(value) for key, value in headers.items()])
		return headers

	@classmethod
	def _headersSplit(self, headers):
		if tools.Tools.isString(headers):
			if '=' in headers:
				headers = headers.split(';')
				headers = [value.strip().split('=') for value in headers]
				headers = {value[0].strip() : (value[1].strip() if len(value) > 1 else None) for value in headers}
			elif ';' in headers:
				headers = headers.split(';')
				headers = [value.strip() for value in headers]
		return headers

	@classmethod
	def _headersCookie(self, cookies, headers = None):
		if not cookies is None and not tools.Tools.isString(cookies):
			cookies = dict(cookies)
			cookies = self._headersJoin(headers = cookies)
		if not headers is None and 'Cookie' in headers and headers['Cookie']:
			if cookies: cookies = headers['Cookie'] + '; ' + cookies
			else: cookies = headers['Cookie']
		return cookies

	@classmethod
	def _headersAgent(self, agent = None):
		if agent == Networker.AgentAddon:
			return tools.Platform.agent()
		elif agent == Networker.AgentMobileFixed:
			return 'Mozilla/5.0 (Linux; Android 6.0.1; SM-G920V Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.98 Mobile Safari/537.36'
		elif agent == Networker.AgentMobileRandom:
			import random
			agents = ['Mozilla/5.0 (Linux; Android 6.0.1; SM-G920V Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.98 Mobile Safari/537.36', 'Apple-iPhone/701.341', 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30', 'Mozilla/5.0 (Linux; Android 7.0; Pixel C Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/52.0.2743.98 Safari/537.36']
			return random.choice(agents)
		elif agent == Networker.AgentDesktopFixed:
			return 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0'
		elif agent == Networker.AgentDesktopRandom:
			import random
			browser = [['%s.0' % i for i in range(18, 43)], ['37.0.2062.103', '37.0.2062.120', '37.0.2062.124', '38.0.2125.101', '38.0.2125.104', '38.0.2125.111', '39.0.2171.71', '39.0.2171.95', '39.0.2171.99', '40.0.2214.93', '40.0.2214.111', '40.0.2214.115', '42.0.2311.90', '42.0.2311.135', '42.0.2311.152', '43.0.2357.81', '43.0.2357.124', '44.0.2403.155', '44.0.2403.157', '45.0.2454.101', '45.0.2454.85', '46.0.2490.71', '46.0.2490.80', '46.0.2490.86', '47.0.2526.73', '47.0.2526.80'], ['11.0']]
			windows = ['Windows NT 10.0', 'Windows NT 7.0', 'Windows NT 6.3', 'Windows NT 6.2', 'Windows NT 6.1', 'Windows NT 6.0', 'Windows NT 5.1', 'Windows NT 5.0']
			features = ['; WOW64', '; Win64; IA64', '; Win64; x64', '']
			agents = ['Mozilla/5.0 ({windows}{feature}; rv:{browser}) Gecko/20100101 Firefox/{browser}', 'Mozilla/5.0 ({windows}{feature}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{browser} Safari/537.36', 'Mozilla/5.0 ({windows}{feature}; Trident/7.0; rv:{browser}) like Gecko']
			index = random.randrange(len(agents))
			return agents[index].format(windows = random.choice(windows), feature = random.choice(features), browser = random.choice(browser[index]))
		return agent

	@classmethod
	def _headersRange(self, range = None):
		if range:
			start = range[0] if range[0] else 0
			size = range[1] if range[1] else 0
			if start > 0 or size > 0:
				if size == 0: range = 'bytes=%d-' % start
				else: range = 'bytes=%d-%d' % (start, start + size - 1)
			else:
				range = None
		return range

	# Extracts the file name from the reponse headers.
	@classmethod
	def _headersName(self, headers):
		try:
			if tools.Tools.isDictionary(headers):
				from lib.externals.requests.structures import CaseInsensitiveDict
				headers = CaseInsensitiveDict(headers)
			return tools.Regex.extract(data = headers['Content-Disposition'], expression = 'filename\s*=\s*[\'"](.*)[\'"]')
		except: pass
		return None

	# Extracts the file size from the reponse headers.
	@classmethod
	def _headersSize(self, headers):
		try:
			if tools.Tools.isDictionary(headers):
				from lib.externals.requests.structures import CaseInsensitiveDict
				headers = CaseInsensitiveDict(headers)

			if 'Content-Range' in headers:
				value = tools.Regex.extract(data = headers['Content-Range'], expression = 'bytes.*\/(.*)')
				if value and value.isdigit(): return int(value)

			if 'Content-Length' in headers:
				value = headers['Content-Length']
				if value.isdigit(): return int(value)

		except: pass
		return None

	# Extracts the file mime type from the reponse headers.
	@classmethod
	def _headersType(self, headers):
		try:
			if tools.Tools.isDictionary(headers):
				from lib.externals.requests.structures import CaseInsensitiveDict
				headers = CaseInsensitiveDict(headers)
			return tools.Regex.extract(data = headers[Networker.HeaderContentType], expression = '(.*?)(?:;|$)')
		except: pass
		return None

	###################################################################
	# DATA
	###################################################################

	@classmethod
	def _dataForm(self, data):
		if data and not tools.Tools.isString(data): data = self.linkEncode(data)
		return Networker.MimeForm, data

	@classmethod
	def _dataJson(self, data):
		if data and not tools.Tools.isString(data):
			data = tools.Converter.jsonTo(data)
		return Networker.MimeJson, data

	@classmethod
	def _dataMulti(self, data):
		boundry = 'X-X-X-' + str(tools.Time.timestamp()) + '-X-X-X'
		content = Networker.MimeMulti + '; boundary=%s' % boundry

		if not tools.Tools.isArray(data): data = [data]
		form = bytearray('', 'utf8')
		for entry in data:
			disposition = '%s: form-data;' % Networker.HeaderContentDisposition
			if 'name' in entry: disposition += '; name="%s"' % entry['name']
			if 'filename' in entry: disposition += '; filename="%s"' % entry['filename']
			disposition += '\n'

			form += bytearray('--%s\n' % boundry, 'utf8')
			form += bytearray(disposition, 'utf8')
			if 'type' in entry: form += bytearray('%s: %s\n' % (Networker.HeaderContentType, entry['type']), 'utf8')
			form += bytearray('\n', 'utf8')
			try: form += bytearray(entry['data'], 'utf8')
			except: form += entry['data']
			form += bytearray('\n', 'utf8')
			form += bytearray('--%s--\n' % boundry, 'utf8')

		return content, form

	###################################################################
	# SETTINGS
	###################################################################

	@classmethod
	def _settingsSecurity(self):
		return tools.Settings.getInteger('network.security.certificates')

	###################################################################
	# REQUEST
	###################################################################

	'''
		NOTE
			If the link prarameter is provided: Make a new request and return the RESPONSE dictionary.
			If the link prarameter is not provided: Do not make a new request and just return the REQUEST dictionary from the previous request.
		PARAMETERS
			link (required): Request URL.
			method (optional): HTTP method. If no method is set and data is passed in, the method will be POST. If no method is set and no data is passed in, the method will be GET.
			data (optional): The POST, JSON, or form data. If the method is GET, the data will be appended as GET parameters to the URL.
			type (optional): The type of the data. If not set, normal POST data is assumed. Alternativley the data can be JSON, HTTP multi-part, or HTTP form data.
			headers (optional): The HTTP headers as a dictionary.
			cookies (optional): The HTTP cookies as a dictionary or string. Cookies can also be set directly in the headers.
			range (optional): The HTTP byte range as a tuple or list with two values, the start byte and the size.
			agent (optional): The HTTP user agent. If not set, a default agent is used. Can be a fixed agent string, or an agent type (AgentAddon, AgentMobileFixed, etc).
			timeout (optional): The request timeout. If not set, the default timeout is used.
			certificate (optional): Whether or not to validate SSL certificates. If not set, the user specified setting is used.
			redirect (optional): Allow HTTP redirects.
			encode (optional): Whether or not to URL encode the GET parameters.
			charset (optional): Which character set to use for encoding.
		RETURNS
			Response dictionary.
			{
				'request' : <Dictionary - The original request.>,
				'success' : <Boolean - Whether or not the request was successful.>,
				'link' : <None/String - The final redirect URL.>,
				'status' : {
					'code' : <None/Integer - The HTTP status code.>,
					'message' : <None/String - The HTTP status description.>,
					'duration' : <None/Integer - How long in milliseconds the request took to complete. This only measures the time it takes to receive a reply and not the time it takes to download the data.>,
				},
				'error' : {
					'type' : <None/String - The type of the error occured.>,
					'code' : <None/Integer/String - The code of the error occured. Is the HTTP status code if it is a request error, otherwise it is another error code string.>,
					'message' : <None/String - The description of the error occured. Is the HTTP status description if it is a request error, otherwise it is an exception message.>,
				},
				'meta' : {
					'type' : <None/String - The MIME type extracted from the headers.>,
					'name' : <None/String - The file name extracted from the headers.>,
					'size' : <None/Integer - The file size extracted from the headers.>,
				},
				'data' : {
					'bytes' : <None/Bytes - The response raw byte data.>,
					'unicode' : <None/String - The response raw byte data converted to unicode.>,
					'text' : <None/String - The response unicode text data.>,
					'json' : <None/Dictionary - The response JSON data if applicable.>,
				},
				'headers' : <None/Dictionary - The response headers (case insenstive keys - can be accessed with any case, since it uses CaseInsensitiveDict).>,
				'cookies' : <None/Dictionary - The response cookies (case sensitive keys - can be accessed with any case, since it uses CaseInsensitiveDict).>,
			}
	'''
	def request(self, link = None, method = None, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None, certificate = None, redirect = True, encode = True, charset = None):
		try:
			if link is None: return self.mRequest

			import copy
			from lib.modules.cloudflare import Cloudflare
			from lib.externals.requests.structures import CaseInsensitiveDict

			self._clean()
			if not timeout: timeout = Networker.TimeoutLong

			link, headersExtra = self._linkClean(link = link)

			method = method if method else Networker.MethodPost if data else Networker.MethodGet
			if method == Networker.MethodGet:
				link = self.linkCreate(link = link, parameters = data, encode = encode)
				data = None
			else: # POST and others.
				if encode is False or charset:
					# Create a POST query manually, since otherwise Requests will re-encode already encoded values in the dictionary.
					# This seems to only apply to encoding that is different to UTF-8. Eg the encoded data coming in as Windows-1251 encoded.
					# There seems to be no parameter in Requests to tell it not to encode the dict values.
					# Therefore create a charset/url-encoded data string, which Requests will not encode again, since it considers it as raw POST data.
					# Will also have to add the the "charset" in the HTTP headers, see below.
					data = self.linkCreate(parameters = data, encode = False)

			if not headers: headers = {}
			headers = self._headersMerge(headers1 = headers, headers2 = headersExtra)
			headers = self._headersClean(headers = headers)

			cookies = self._headersCookie(cookies = cookies, headers = headers)
			if cookies: headers[Networker.HeaderCookie] = cookies

			if not Networker.HeaderUserAgent in headers or not headers[Networker.HeaderUserAgent]:
				agent = self._headersAgent(agent = agent)
				if agent: headers[Networker.HeaderUserAgent] = agent

			if not Networker.HeaderRange in headers or not headers[Networker.HeaderRange]:
				range = self._headersRange(range = range)
				if range: headers[Networker.HeaderRange] = range

			if data:
				content = None
				if type == Networker.DataJson: content, data = self._dataJson(data = data)
				elif type == Networker.DataMulti: content, data = self._dataMulti(data = data)
				elif type == Networker.DataForm: content, data = self._dataForm(data = data)
				elif charset: content, data = self._dataForm(data = data)

				if content and (not Networker.HeaderContentType in headers or not headers[Networker.HeaderContentType]):
					# Important for some providers (like NoNameClub) that use a different encoding charset than UTF-8.
					# If the charset is Windows-1251 and the charset is not added to the headers, the server interprets it as probably UTF-8, and then returns different results.
					# The Provider structure passes and already encoded query to the Networker.
					if charset: content += '; charset=' + charset

					headers[Networker.HeaderContentType] = content

			self.mRequest['method'] = method
			self.mRequest['link'] = link
			self.mRequest['data'] = data
			self.mRequest['headers'] = CaseInsensitiveDict(headers)

			try:

				headers = dict(self._headersClean(headers = headers)) # Headers are case insensitive. But just make them titlecase in case the Cloudflare scraper does something weird.

				validate = self._settingsSecurity()
				if Cloudflare.enabled():
					result = Cloudflare(validate = validate).request(method = method, link = link, headers = headers, data = data, timeout = timeout, certificate = certificate, redirect = redirect, log = False)
					response = result['response']
					responseCookies = result['cookies']
				else:
					from lib.externals.requests import Session
					session = Session()

					if certificate is None: certificate = validate
					if certificate <= Networker.ValidateModerate:
						from lib.externals import urllib3
						urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

						import ssl
						from lib.externals.requests.adapters import HTTPAdapter
						class Certificate(HTTPAdapter):
							def __init__(self, *args, **kwargs):
								self.context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
								self.context.check_hostname = False # Must be set BEFORE verify_mode, otherwise this statement is ignored and an error is thrown: " Cannot set verify_mode to CERT_NONE when check_hostname is enabled."
								self.context.verify_mode = ssl.CERT_NONE
								if certificate <= Networker.ValidateLenient:
									self.context.options &= ~ssl.OP_NO_TLSv1_3 & ~ssl.OP_NO_TLSv1_2 & ~ssl.OP_NO_TLSv1_1
									try: self.context.minimum_version = ssl.TLSVersion.TLSv1
									except: # TLSVersion not known.
										try: self.context.minimum_version = ssl.PROTOCOL_TLSv1
										except: pass # Old versions do not have a minimum_version.
								super(Certificate, self).__init__(**kwargs)
							def init_poolmanager(self, *args, **kwargs):
								kwargs['ssl_context'] = self.context
								return super(Certificate, self).init_poolmanager(*args, **kwargs)
							def proxy_manager_for(self, *args, **kwargs):
								kwargs['ssl_context'] = self.context
								return super(Certificate, self).proxy_manager_for(*args, **kwargs)
						session.mount('https://', Certificate())

					response = session.request(method = 'GET' if method is None else method, url = link, headers = headers, data = data, timeout = timeout, verify = certificate, allow_redirects = redirect)

					# NB: session.response.cookies does not return all of the cookies.
					# Not entirley sure why, but maybe only the cookies of the last request are returned, and not all the cookies in the chain or redirection.
					# Use session.cookies to return ALL cookies.
					try: responseCookies = session.cookies.get_dict()
					except: responseCookies = None

				try: self.mRequest['headers'] = CaseInsensitiveDict(response.request.headers)
				except: pass

				success = response.status_code < 300
				self.mResponse['success'] = success
				self.mResponse['status']['code'] = response.status_code
				self.mResponse['status']['message'] = response.reason
				try: self.mResponse['status']['duration'] = int(response.elapsed.total_seconds() * 1000)
				except: pass

				if not success:
					self.mResponse['error']['type'] = Networker.ErrorRequest
					self.mResponse['error']['code'] = response.status_code
					self.mResponse['error']['message'] = response.reason
				self.mResponse['link'] = response.url

				try: self.mResponse['data']['bytes'] = response.content
				except: pass
				try: self.mResponse['data']['unicode'] = tools.Converter.unicode(response.content)
				except: pass
				try: self.mResponse['data']['text'] = response.text
				except: pass
				try: self.mResponse['data']['json'] = response.json()
				except: pass

				self.mResponse['headers'] = CaseInsensitiveDict(response.headers)
				self.mResponse['headers']['Status'] = response.status_code
				self.mResponse['cookies'] = CaseInsensitiveDict(responseCookies)

				# Some VPNs are straight out blocked by Cloudflare for some domains (eg: ExtraTorrent).
				# No captcha is shown, but Cloudflare shows an error page:
				#
				#	Error 1020
				#	Access denied
				#	What happened?
				#	This website is using a security service to protect itself from online attacks.
				#
				# <h1 class="inline-block md:block mr-2 md:mb-2 font-light text-60 md:text-3xl text-black-dark leading-tight">
		        #    <span data-translate="error">Error</span>
		        #    <span>1020</span>
		        #  </h1>
				#
				# Do not just check the headers (eg: server: cloudflare), since some sites (eg: ApiBay when not sending GET parameters) return the same headers and 403, but it does not show the Cloudflare.
				# https://support.cloudflare.com/hc/en-us/articles/360029779472-Troubleshooting-Cloudflare-1XXX-errors
				if self.mResponse['error']['code'] == 403:
					try:
						if tools.Regex.match(data = self.mResponse['data']['text'], expression = 'cloudflare'):
							if tools.Regex.match(data = self.mResponse['data']['text'], expression = 'error(?:\s*<\/?(?:div|span)>\s*)*1\d{3}'):
								self.mResponse['error']['type'] = Networker.ErrorCloudflare
					except: pass

			except Exception as error:

				# Custom CloudflareException.
				try: self.mResponse['status']['code'] = error.response.status_code
				except: pass
				try: self.mResponse['status']['message'] = error.response.reason
				except: pass
				try: self.mResponse['status']['duration'] = int(error.response.elapsed.total_seconds() * 1000)
				except: pass
				try:
					self.mResponse['headers'] = CaseInsensitiveDict(error.response.headers)
					self.mResponse['headers']['Status'] = error.response.status_code
				except: pass
				try: self.mResponse['cookies'] = CaseInsensitiveDict(error.cookies)
				except:
					try: self.mResponse['cookies'] = CaseInsensitiveDict(error.response.cookies.get_dict())
					except: pass
				try: error = error.exception
				except: pass

				errorType = Networker.ErrorUnknown
				errorCode = None
				errorName = error.__class__.__name__.lower()

				if 'connectionerror' in errorName:
					errorType = Networker.ErrorConnection
				elif 'cloudflare' in errorName:
					errorType = Networker.ErrorCloudflare
					errorCode = Networker.CloudflareUnknown
					if 'challenge' in errorName: errorCode = Networker.CloudflareChallenge
					elif 'solve' in errorName: errorCode = Networker.CloudflareSolve
					elif 'loop' in errorName: errorCode = Networker.CloudflareLoop
					elif '1020' in errorName: errorCode = Networker.Cloudflare1020
					elif 'iuam' in errorName: errorCode = Networker.CloudflareIuam
					elif 'loop' in errorName: errorCode = Networker.CloudflareLoop
					elif 'captcha' in errorName: errorCode = Networker.CloudflareCaptcha
				elif 'ssl' in errorName:
					errorType = Networker.ErrorCertificate

				try: errorMessage = error.message
				except: errorMessage = str(error)

				self.mResponse['success'] = False
				self.mResponse['error']['type'] = errorType
				self.mResponse['error']['code'] = errorCode
				self.mResponse['error']['message'] = errorMessage

				tools.Logger.log('Network Error', '[' + (('Error Type: ' + errorType.title()) if errorType else '') + ((' | Error Code: ' + str(errorCode).title()) if errorCode else '') + ' | Link: ' + link + ']: ', errorMessage)

			self.mResponse['meta']['type'] = self._headersType(headers = self.mResponse['headers'])
			self.mResponse['meta']['name'] = self._headersName(headers = self.mResponse['headers'])
			self.mResponse['meta']['size'] = self._headersSize(headers = self.mResponse['headers'])

			self.mResponse['request'] = copy.deepcopy(self.mRequest)
			return self.mResponse
		except:
			tools.Logger.error()
			return None

	'''
		NOTE
			If the link prarameter is provided: Make a new request and return the RESPONSE data.
			If the link prarameter is not provided: Do not make a new request and just return the REQUEST data from the previous request.
		RETURNS
			The response data object on request success, otherwise None.
	'''
	def requestData(self, link = None, method = None, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None, certificate = None, redirect = True):
		if link is None: return self.mRequest['data']
		response = self.request(link = link, method = method, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout, certificate = certificate, redirect = redirect)
		return response['data']

	'''
		NOTE
			If the link prarameter is provided: Make a new request and return the RESPONSE data.
			If the link prarameter is not provided: Do not make a new request and just return the REQUEST data from the previous request.
		RETURNS
			The response binary data on request success, otherwise None.
	'''
	def requestBytes(self, link = None, method = None, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None, certificate = None, redirect = True):
		if link is None: return self.mRequest['data']
		response = self.request(link = link, method = method, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout, certificate = certificate, redirect = redirect)
		return response['data']['bytes']

	'''
		NOTE
			If the link prarameter is provided: Make a new request and return the RESPONSE data.
			If the link prarameter is not provided: Do not make a new request and just return the REQUEST data from the previous request.
		RETURNS
			The response unicode text data on request success, otherwise None.
	'''
	def requestUnicode(self, link = None, method = None, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None, certificate = None, redirect = True):
		if link is None: return self.mRequest['data']
		response = self.request(link = link, method = method, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout, certificate = certificate, redirect = redirect)
		return response['data']['unicode']

	'''
		NOTE
			If the link prarameter is provided: Make a new request and return the RESPONSE data.
			If the link prarameter is not provided: Do not make a new request and just return the REQUEST data from the previous request.
		RETURNS
			The response unicode text data on request success, otherwise None.
	'''
	def requestText(self, link = None, method = None, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None, certificate = None, redirect = True):
		if link is None: return self.mRequest['data']
		response = self.request(link = link, method = method, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout, certificate = certificate, redirect = redirect)
		return response['data']['text']

	'''
		NOTE
			If the link prarameter is provided: Make a new request and return the RESPONSE JSON data.
			If the link prarameter is not provided: Do not make a new request and just return the REQUEST JSON data from the previous request.
		RETURNS
			The response JSON dictionary on request success and if the returned data is JSON, otherwise None.
	'''
	def requestJson(self, link = None, method = None, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None, certificate = None, redirect = True):
		if link is None: return tools.Converter.jsonFrom(self.mRequest['data'])
		response = self.request(link = link, method = method, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout, certificate = certificate, redirect = redirect)
		return response['data']['json']

	'''
		NOTE
			If the link prarameter is provided: Make a new request and return the RESPONSE headers.
			If the link prarameter is not provided: Do not make a new request and just return the REQUEST headers from the previous request.
		RETURNS
			The response headers as a dictionary (lower case keys) on request success, otherwise None.
	'''
	def requestHeaders(self, link = None, method = None, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None, certificate = None, redirect = True):
		if link is None: return self.mRequest['headers']
		response = self.request(link = link, method = method, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout, certificate = certificate, redirect = redirect)
		return response['headers']

	'''
		NOTE
			If the link prarameter is provided: Make a new request and return the RESPONSE cookies.
			If the link prarameter is not provided: Do not make a new request and just return the REQUEST cookies from the previous request.
		RETURNS
			The response cookies as a dictionary (case sensitive keys) on request success, otherwise None.
	'''
	def requestCookies(self, link = None, method = None, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None, certificate = None, redirect = True):
		if link is None: return self.mRequest['cookies']
		response = self.request(link = link, method = method, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout, certificate = certificate, redirect = redirect)
		return response['cookies']

	'''
		NOTE
			If the link prarameter is provided: Make a new request and return the RESPONSE final redirected URL.
			If the link prarameter is not provided: Do not make a new request and just return the REQUEST URL from the previous request.
		RETURNS
			The response final redirected URL on request success, otherwise None.
	'''
	def requestLink(self, link = None, method = None, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None, certificate = None, redirect = True):
		if link is None: return self.mRequest['link']
		response = self.request(link = link, method = method, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout, certificate = certificate, redirect = redirect)
		result = response['link']
		if result == link:
			try:
				other = response['headers']['location']
				if other: result = other
			except: pass
		return result

	'''
		NOTE
			Check if the link is valid/accessible. By default makes a HEAD request.
			If the link prarameter is provided: Make a new request and return the RESPONSE success.
			If the link prarameter is not provided: Do not make a new request and just return the RESPONSE success from the previous request.
		RETURNS
			The response success status.
	'''
	def requestSuccess(self, link = None, method = MethodHead, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None, certificate = None, redirect = True):
		if link is None: return self.mResponse['success']
		response = self.request(link = link, method = method, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout, certificate = certificate, redirect = redirect)
		return response['success']

	'''
		NOTE
			Get the status of a link. Similar to requestSuccess(), but it also checks the data content.
			First only the headers are retrieved. If the request was successful and the content is TEXT/HTML/JSON, it will download the content and search for certain keywords (eg: "not found").
		RETURNS
			The response status.
	'''
	def requestStatus(self, link, method = None, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None, certificate = None, redirect = True):
		response = self.request(link = link, method = Networker.MethodHead, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout, certificate = certificate, redirect = redirect)

		if not response['success']:
			if response['error']['type'] == Networker.ErrorCloudflare:
				return Networker.StatusCloudflare
			else:
				return Networker.StatusOffline

		if response['meta']['type']:
			if any(i in response['meta']['type'] for i in ['text', 'json']):
				response = self.request(link = link, method = method, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout, certificate = certificate, redirect = redirect)
				text = response['data']['text']
				if text:
					text = text.lower()
					# Do not be too general, like "copyright", beacause other links/texts on the page might also those phrases.
					failures = ['not found', 'permission denied', 'access denied', 'forbidden access', 'file unavailable', 'bad file', 'unauthorized', 'file remove', 'payment required', 'method not allowed', 'not acceptable', 'authentication required', 'request timeout', 'unavailable for legal reasons', 'too many request', 'file removed', 'file has been removed', 'removed file', 'file expired']
					if any(failure in text for failure in failures):
						return Networker.StatusOffline
					else:
						return Networker.StatusUnknown
				else:
					return Networker.StatusOffline

		return Networker.StatusOnline

	###################################################################
	# RESPONSE
	###################################################################

	def response(self):
		return self.mResponse

	def responseData(self):
		return self.mResponse['data']

	def responseDataBytes(self):
		return self.mResponse['data']['bytes']

	def responseDataUnicode(self):
		return self.mResponse['data']['unicode']

	def responseDataText(self):
		return self.mResponse['data']['text']

	def responseDataJson(self):
		return self.mResponse['data']['json']

	def responseHeaders(self):
		return self.mResponse['headers']

	def responseCookies(self):
		return self.mResponse['cookies']

	def responseLink(self):
		return self.mResponse['link']

	def responseSuccess(self):
		return self.mResponse['success']

	def responseStatus(self):
		return self.mResponse['status']

	def responseStatusCode(self):
		return self.mResponse['status']['code']

	def responseStatusMessage(self):
		return self.mResponse['status']['message']

	def responseStatusDuration(self):
		return self.mResponse['status']['duration']

	def responseError(self):
		return self.mResponse['error']

	def responseErrorType(self):
		return self.mResponse['error']['type']

	def responseErrorCode(self):
		return self.mResponse['error']['code']

	def responseErrorMessage(self):
		return self.mResponse['error']['message']

	def responseError2xx(self):
		code = self.mResponse['error']['code']
		return code >= 200 and code < 300

	def responseError3xx(self):
		code = self.mResponse['error']['code']
		return code >= 300 and code < 400

	def responseError4xx(self):
		code = self.mResponse['error']['code']
		return code >= 400 and code < 500

	def responseError5xx(self):
		code = self.mResponse['error']['code']
		return code >= 500 and code < 600

	###################################################################
	# DOWNLOAD
	###################################################################

	# Downloads a file to disk.
	# NB: Be careful with big files, since the entire file is downloaded into memory before saving it to disk.
	def download(self, link, path, method = None, data = None, type = None, headers = None, cookies = None, range = None, agent = None, timeout = None):
		response = self.request(link = link, method = method, data = data, type = type, headers = headers, cookies = cookies, range = range, agent = agent, timeout = timeout)
		if not response['success']: return False
		tools.File.writeNow(path, response['data']['bytes'])
		return True


class Information(object):

	@classmethod
	def retrieve(self, obfuscate = False):
		import os
		import xbmc

		result = {}

		# Local
		localIpAddress = xbmc.getIPAddress()
		localHostName = None
		if localHostName is None or localHostName == '':
			try:
				import platform
				localHostName = platform.node()
			except: pass
		if localHostName is None or localHostName == '':
			try:
				import platform
				localHostName = platform.uname()[1]
			except: pass
		if localHostName is None or localHostName == '':
			try: localHostName = os.uname()[1]
			except: pass
		if localHostName is None or localHostName == '':
			try:
				import socket
				localHostName = socket.gethostname()
			except: pass

		# Global
		globalIpAddress = None
		globalIpName = None
		globalIpType = None
		globalProvider = None
		globalOrganisation = None
		globalSystem = None
		globalContinentCode = None
		globalContinentName = None
		globalCountryCode = None
		globalCountryName = None
		globalRegionCode = None
		globalRegionName = None
		globalCityCode = None # Zip code
		globalCityName = None
		globalLatitude = None
		globalLongitude = None

		if None in [globalIpAddress, globalIpName, globalIpType, globalProvider, globalOrganisation, globalSystem, globalContinentName, globalContinentCode, globalCountryName, globalCountryCode, globalRegionName, globalRegionCode, globalCityName, globalCityCode, globalLatitude, globalLongitude] or '' in [globalIpAddress, globalIpName, globalIpType, globalProvider, globalOrganisation, globalSystem, globalContinentName, globalContinentCode, globalCountryName, globalCountryCode, globalRegionName, globalRegionCode, globalCityName, globalCityCode, globalLatitude, globalLongitude]:
			try:
				result = Networker().requestJson(link = 'https://tools.keycdn.com/geo.json')['data']['geo']
				if 'ip' in result and globalIpAddress in [None, '']: globalIpAddress = result['ip']
				if 'rdns' in result and globalIpName in [None, '']: globalIpName = result['rdns']
				if 'continent_code' in result and globalContinentCode in [None, '']: globalContinentCode = result['continent_code']
				if 'country_name' in result and globalCountryName in [None, '']: globalCountryName = result['country_name']
				if 'country_code' in result and globalCountryCode in [None, '']: globalCountryCode = result['country_code']
				if 'city' in result and globalCityName in [None, '']: globalCityName = result['city']
				if 'postal_code' in result and globalCityCode in [None, '']: globalCityCode = str(result['postal_code'])
				if 'latitude' in result and globalLatitude in [None, '']: globalLatitude = str(result['latitude'])
				if 'longitude' in result and globalLongitude in [None, '']: globalLongitude = str(result['longitude'])
			except: pass

		if None in [globalIpAddress, globalIpName, globalIpType, globalProvider, globalOrganisation, globalSystem, globalContinentName, globalContinentCode, globalCountryName, globalCountryCode, globalRegionName, globalRegionCode, globalCityName, globalCityCode, globalLatitude, globalLongitude] or '' in [globalIpAddress, globalIpName, globalIpType, globalProvider, globalOrganisation, globalSystem, globalContinentName, globalContinentCode, globalCountryName, globalCountryCode, globalRegionName, globalRegionCode, globalCityName, globalCityCode, globalLatitude, globalLongitude]:
			try:
				result = Networker().requestJson(link = 'http://extreme-ip-lookup.com/json/')
				if 'query' in result and globalIpAddress in [None, '']: globalIpAddress = result['query']
				if 'ipName' in result and globalIpName in [None, '']: globalIpName = result['ipName']
				if 'ipType' in result and globalIpType in [None, '']: globalIpType = result['ipType']
				if 'isp' in result and globalProvider in [None, '']: globalProvider = result['isp']
				if 'org' in result and globalOrganisation in [None, '']: globalOrganisation = result['org']
				if 'continent' in result and globalContinentName in [None, '']: globalContinentName = result['continent']
				if 'country' in result and globalCountryName in [None, '']: globalCountryName = result['country']
				if 'countryCode' in result and globalCountryCode in [None, '']: globalCountryCode = result['countryCode']
				if 'region' in result and globalRegionName in [None, '']: globalRegionName = result['region']
				if 'city' in result and globalCityName in [None, '']: globalCityName = result['city']
				if 'lat' in result and globalLatitude in [None, '']: globalLatitude = str(result['lat'])
				if 'lon' in result and globalLongitude in [None, '']: globalLongitude = str(result['lon'])
			except: pass

		if None in [globalIpAddress, globalIpName, globalIpType, globalProvider, globalOrganisation, globalSystem, globalContinentName, globalContinentCode, globalCountryName, globalCountryCode, globalRegionName, globalRegionCode, globalCityName, globalCityCode, globalLatitude, globalLongitude] or '' in [globalIpAddress, globalIpName, globalIpType, globalProvider, globalOrganisation, globalSystem, globalContinentName, globalContinentCode, globalCountryName, globalCountryCode, globalRegionName, globalRegionCode, globalCityName, globalCityCode, globalLatitude, globalLongitude]:
			try:
				result = Networker().requestJson(link = 'http://ip-api.com/json')
				if 'query' in result and globalIpAddress in [None, '']: globalIpAddress = result['query']
				if 'isp' in result and globalProvider in [None, '']: globalProvider = result['isp']
				if 'org' in result and globalOrganisation in [None, '']: globalOrganisation = result['org']
				if 'as' in result and globalSystem in [None, '']: globalSystem = result['as']
				if 'country' in result and globalCountryName in [None, '']: globalCountryName = result['country']
				if 'countryCode' in result and globalCountryCode in [None, '']: globalCountryCode = result['countryCode']
				if 'regionName' in result and globalRegionName in [None, '']: globalRegionName = result['regionName']
				if 'region' in result and globalRegionCode in [None, '']: globalRegionCode = result['region']
				if 'city' in result and globalCityName in [None, '']: globalCityName = result['city']
				if 'zip' in result and globalCityCode in [None, '']: globalCityCode = str(result['zip'])
				if 'lat' in result and globalLatitude in [None, '']: globalLatitude = str(result['lat'])
				if 'lon' in result and globalLongitude in [None, '']: globalLongitude = str(result['lon'])
			except: pass

		if None in [globalIpAddress, globalIpName, globalIpType, globalProvider, globalOrganisation, globalSystem, globalContinentName, globalContinentCode, globalCountryName, globalCountryCode, globalRegionName, globalRegionCode, globalCityName, globalCityCode, globalLatitude, globalLongitude] or '' in [globalIpAddress, globalIpName, globalIpType, globalProvider, globalOrganisation, globalSystem, globalContinentName, globalContinentCode, globalCountryName, globalCountryCode, globalRegionName, globalRegionCode, globalCityName, globalCityCode, globalLatitude, globalLongitude]:
			try:
				result = Networker().requestJson(link = 'http://freegeoip.net/json/')
				if 'ip' in result and globalIpAddress in [None, '']: globalIpAddress = result['ip']
				if 'country_name' in result and globalCountryName in [None, '']: globalCountryName = result['country_name']
				if 'country_code' in result and globalCountryCode in [None, '']: globalCountryCode = result['country_name']
				if 'region_name' in result and globalRegionName in [None, '']: globalRegionName = result['region_name']
				if 'region_code' in result and globalRegionCode in [None, '']: globalRegionCode = result['region_code']
				if 'city' in result and globalCityName in [None, '']: globalCityName = result['city']
				if 'zip' in result and globalCityCode in [None, '']: globalCityCode = str(result['zip'])
				if 'latitude' in result and globalLatitude in [None, '']: globalLatitude = str(result['latitude'])
				if 'longitude' in result and globalLongitude in [None, '']: globalLongitude = str(result['longitude'])
			except: pass

		if obfuscate and not globalIpAddress is None:
			index = globalIpAddress.rfind('.')
			if index > 0:
				globalIpAddress = globalIpAddress[:index]
				globalIpAddress += '.0'
			globalIpName = None

		globalIpAddress = None if globalIpAddress == '' else globalIpAddress
		globalIpName = None if globalIpName == '' else globalIpName
		globalIpType = None if globalIpType == '' else globalIpType
		globalProvider = None if globalProvider == '' else globalProvider
		globalOrganisation = None if globalOrganisation == '' else globalOrganisation
		globalSystem = None if globalSystem == '' else globalSystem
		globalContinentCode = None if globalContinentCode == '' else globalContinentCode
		globalContinentName = None if globalContinentName == '' else globalContinentName
		globalCountryCode = None if globalCountryCode == '' else globalCountryCode
		globalCountryName = None if globalCountryName == '' else globalCountryName
		globalRegionCode = None if globalRegionCode == '' else globalRegionCode
		globalRegionName = None if globalRegionName == '' else globalRegionName
		globalCityCode = None if globalCityCode == '' else globalCityCode
		globalCityName = None if globalCityName == '' else globalCityName
		globalLatitude = None if globalLatitude == '' else globalLatitude
		globalLongitude = None if globalLongitude == '' else globalLongitude

		return {
			'local' : {
				'connection' : {
					'address' : localIpAddress,
					'name' : localHostName,
				},
			},
			'global' : {
				'connection' : {
					'address' : globalIpAddress,
					'name' : tools.Converter.unicodeNormalize(globalIpName),
					'type' : globalIpType,
					'provider' : tools.Converter.unicodeNormalize(globalProvider),
					'organisation' : tools.Converter.unicodeNormalize(globalOrganisation),
					'system' : tools.Converter.unicodeNormalize(globalSystem),
				},
				'location' : {
					'continent' : {
						'code' : tools.Converter.unicodeNormalize(globalContinentCode),
						'name' : tools.Converter.unicodeNormalize(globalContinentName),
					},
					'country' : {
						'code' : tools.Converter.unicodeNormalize(globalCountryCode),
						'name' : tools.Converter.unicodeNormalize(globalCountryName),
					},
					'region' : {
						'code' : tools.Converter.unicodeNormalize(globalRegionCode),
						'name' : tools.Converter.unicodeNormalize(globalRegionName),
					},
					'city' : {
						'code' : globalCityCode,
						'name' : tools.Converter.unicodeNormalize(globalCityName),
					},
					'coordinates' : {
						'latitude' : tools.Converter.unicodeNormalize(globalLatitude),
						'longitude' : tools.Converter.unicodeNormalize(globalLongitude),
					},
				},
			}
		}

	@classmethod
	def dialog(self):
		from lib.modules import interface

		def value(val1, val2 = None):
			if val1 is None:
				return 'Unknown'
			elif val2 is None:
				return val1
			else:
				return '%s (%s)' % (val1, val2)

		interface.Loader.show()
		items = []
		information = self.retrieve()

		# Local
		data = information['local']
		items.append({
			'title' : 33704,
			'items' : [
				{ 'title' : 33706, 'value' : value(data['connection']['address']) },
				{ 'title' : 33707, 'value' : value(data['connection']['name']) },
			]
		})

		# Global
		data = information['global']
		items.append({
			'title' : 33705,
			'items' : [
				{ 'title' : 33706, 'value' : value(data['connection']['address']) },
				{ 'title' : 33708, 'value' : value(data['connection']['name']) },
				{ 'title' : 33709, 'value' : value(data['connection']['type']) },
				{ 'title' : 33710, 'value' : value(data['connection']['provider']) },
				{ 'title' : 33711, 'value' : value(data['connection']['organisation']) },
				{ 'title' : 33712, 'value' : value(data['connection']['system']) },
				{ 'title' : 33713, 'value' : value(data['location']['continent']['name'], data['location']['continent']['code']) },
				{ 'title' : 33714, 'value' : value(data['location']['country']['name'], data['location']['country']['code']) },
				{ 'title' : 33715, 'value' : value(data['location']['region']['name'], data['location']['region']['code']) },
				{ 'title' : 33716, 'value' : value(data['location']['city']['name'], data['location']['city']['code']) },
				{ 'title' : 33717, 'value' : value(data['location']['coordinates']['latitude']) },
				{ 'title' : 33718, 'value' : value(data['location']['coordinates']['longitude']) },
			]
		})

		interface.Loader.hide()
		interface.Dialog.information(title = 33703, items = items)


class Resolver(object):

	ModeNone = 'none' # Do not resolve. Must be string.
	ModeProvider = 'provider' # Resolve through the provider only
	ModeService = 'service' # Resolve through provider and service (such as debrid or URLResolver).
	ModeDefault = ModeService

	@classmethod
	def resolve(self, source, clean = True, timeout = None, info = False, internal = True, cloud = False, mode = ModeDefault): # Use timeout with caution.
		import threading

		resolver = Resolver()
		resolver.mLink = None
		if not mode: mode = Resolver.ModeNone
		thread = threading.Thread(target = resolver._resolve, args = (source, clean, info, internal, cloud, mode))
		thread.start()
		if timeout:
			timestep = 0.1
			for i in range(int(timeout / timestep)):
				tools.Time.sleep(timestep)
			if thread.is_alive():
				return None
		else:
			thread.join()
		return resolver.mLink

	def _resolve(self, source, clean = True, info = False, internal = True, cloud = False, mode = ModeDefault):
		# Resolves the link using the providers and urlresolver.
		from lib.modules import core # Must be imported here due to circular imports.
		self.mLink = core.Core().sourceResolve(source, info = info, internal = internal, cloud = cloud, resolve = mode)['link']
		if clean and self.mLink: self.mLink = Networker.linkClean(self.mLink, strip = False)
		return self.mLink


class Container(object):

	Separator = '_'

	# Types

	# Must be the same as stream.py.
	TypeUnknown = None
	TypeTorrent = 'torrent'
	TypeUsenet = 'usenet'
	TypeHoster = 'hoster'

	# Extensions
	ExtensionData = '.dat'
	ExtensionTorrent = '.torrent'
	ExtensionUsenet = '.nzb'
	ExtensionHoster = '.container'

	# Mimes
	MimeData = 'application/octet-stream'
	MimeTorrent = 'application/x-bittorrent'
	MimeUsenet = 'application/x-nzb'
	MimeHoster = 'application/octet-stream'

	# Paths
	PathTemporary = tools.System.temporary()
	PathTemporaryContainer = tools.File.joinPath(PathTemporary, 'containers')
	PathTemporaryContainerData = tools.File.joinPath(PathTemporaryContainer, 'data')
	PathTemporaryContainerTorrent = tools.File.joinPath(PathTemporaryContainer, TypeTorrent)
	PathTemporaryContainerUsenet = tools.File.joinPath(PathTemporaryContainer, TypeUsenet)
	PathTemporaryContainerHoster = tools.File.joinPath(PathTemporaryContainer, TypeHoster)

	# Version
	Version1		= 1 # BitTorrent v1.
	Version2		= 2 # BitTorrent v2.
	VersionAny		= True
	VersionAll		= None
	VersionDefault	= VersionAny

	# Base
	Base16		= 'base16'	# Base16/Hex
	Base32		= 'base32'	# Base32
	Base64		= 'base64'	# Base64
	BaseNone	= None 		# Keep current base encoding
	BaseDefault	= Base16

	# Length

	LengthSha1Base16			= 40	# SHA1 hex encoded.
	LengthSha1Base32Padded		= 32	# SHA1 base32 encoded (with = padding).
	LengthSha1Base32Unpadded	= 32	# SHA1 base32 encoded (without = padding).
	LengthSha1Base64Padded		= 28	# SHA1 base64 encoded (with = padding).
	LengthSha1Base64Unpadded	= 27	# SHA1 base64 encoded (without = padding).

	LengthSha256Base16			= 64	# SHA1 hex encoded.
	LengthSha256Base32Padded	= 56	# SHA1 base32 encoded (with = padding).
	LengthSha256Base32Unpadded	= 52	# SHA1 base32 encoded (without = padding).
	LengthSha256Base64Padded	= 44	# SHA1 base64 encoded (with = padding).
	LengthSha256Base64Unpadded	= 43	# SHA1 base64 encoded (without = padding).

	LengthSha1		= {LengthSha1Base16 : True, LengthSha1Base32Padded : True, LengthSha1Base32Unpadded : True, LengthSha1Base64Padded : True, LengthSha1Base64Unpadded : True}
	LengthSha256	= {LengthSha256Base16 : True, LengthSha256Base32Padded : True, LengthSha256Base32Unpadded : True, LengthSha256Base64Padded : True, LengthSha256Base64Unpadded : True}
	LengthBase16	= {LengthSha1Base16 : True, LengthSha256Base16 : True}
	LengthBase32	= {LengthSha1Base32Padded : True, LengthSha1Base32Unpadded : True, LengthSha256Base32Padded : True, LengthSha256Base32Unpadded : True}
	LengthBase64	= {LengthSha1Base64Padded : True, LengthSha1Base64Unpadded : True, LengthSha256Base64Padded : True, LengthSha256Base64Unpadded : True}
	LengthUnpadded	= {LengthSha1Base32Unpadded : True, LengthSha1Base64Unpadded : True, LengthSha256Base32Unpadded : True, LengthSha256Base64Unpadded : True}
	LengthUpper		= {LengthSha1Base16 : True, LengthSha1Base32Padded : True, LengthSha1Base32Unpadded : True, LengthSha256Base16 : True, LengthSha256Base32Padded : True, LengthSha256Base32Unpadded : True}

	# Prefix
	PrefixMagnet		= 'magnet:'
	PrefixUrn			= 'urn:'
	PrefixSha1			= 'urn:btih:'
	PrefixSha256		= 'urn:btmh:'

	# Expression
	ExpressionPrefix	= 'urn:bt[im]h:'
	ExpressionHash		= 'xt=urn:bt[im]h:([a-z\d\/\+=]+)(?:$|&)'

	# gaiaremove - update these
	# Common Trackers
	# Last update: 2021-09-28
	# Do not add too many trackers. Anything above 150 trackers in a magnet link will cause a failure on Premiumize, most likeley due to GET/POST size limits. Also makes the magnet unnecessarily large for Orion.
	# Trackers are automatically retrieved from newtrackon.com, but keep this list as backup in case newtrackon.com is not accessible.
	# https://newtrackon.com
	# https://github.com/ngosang/trackerslist
	Trackers = None
	TrackersCommon = [
		'udp://open.stealth.si:80/announce',					# 100% uptime (Norway)
		'udp://tracker.torrent.eu.org:451/announce',			# 100% uptime (France)
		'udp://tracker.birkenwald.de:6969/announce',			# 100% uptime (Germany)
		'http://tracker.files.fm:6969/announce',				# 100% uptime (Germany)
		'udp://tracker.beeimg.com:6969/announce',				# 100% uptime (Switzerland)
		'udp://tracker.zerobytes.xyz:1337/announce',			# 100% uptime (Netherlands)
		'udp://tracker.moeking.eu.org:6969/announce',			# 100% uptime (Netherlands)
		'http://tracker.bt4g.com:2095/announce',				# 100% uptime (United States)
		'https://tracker.nanoha.org:443/announce',				# 100% uptime (United States)
		'udp://tracker.cyberia.is:6969/announce',				# 99.9% uptime (Switzerland)
		'udp://exodus.desync.com:6969/announce',				# 99.9% uptime (United States)
		'https://tracker.lilithraws.cf:443/announce',			# 99.9% uptime (United States)
		'udp://tracker.army:6969/announce',						# 99.8% uptime (United States)
		'udp://tracker.bitsearch.to:1337/announce',				# 99.8% uptime (Netherlands)
		'udp://tracker.opentrackr.org:1337/announce',			# 99.6% uptime (Netherlands)
		'udp://explodie.org:6969/announce',						# 99.5% uptime (United States)
		'http://t.nyaatracker.com:80/announce',					# 98.6% uptime (Canada/France/Singapore)
		'udp://bt1.archive.org:6969/announce',					# 98.3% uptime (United States)
		'udp://9.rarbg.com:2890/announce',						# 97.9% uptime (France)
		'udp://tracker.leech.ie:1337/announce',					# 97.7% uptime (Luxembourg)
		'udp://tracker.openbittorrent.com:80/announce',			# 85.3% uptime (Sweden)
		'https://1337.abcvg.info:443/announce',					# 75.6% uptime (United States/Canada)
		'udp://retracker.netbynet.ru:2710/announce',			# 67.0% uptime (Russia)
		'https://tracker.foreverpirates.co:443/announce',		# 54.4% uptime (United States)
	]

	##############################################################################
	# CONSTRUCTOR
	##############################################################################

	# link: link, magnet, hash, or local path.
	# download: automatically download the torrent or NZB file.
	def __init__(self, link, download = False):
		self.linkSet(link)
		self.downloadSet(download)

	##############################################################################
	# INTERNAL
	##############################################################################

	# GENERAL

	def _type(self, link):
		# Check Magnet
		if self._torrentIsMagnet(link = link):
			return Container.TypeTorrent

		# Check Extensions
		if self._torrentIsExtension(link = link):
			return Container.TypeTorrent
		elif self._usenetIsExtension(link = link):
			return Container.TypeUsenet

		# Check Local Files
		if self._torrentIsFile(link = link, local = True):
			return Container.TypeTorrent
		elif self._usenetIsFile(link = link, local = True):
			return Container.TypeUsenet

		# Check Providers
		if self._torrentIsProvider(link = link):
			return Container.TypeTorrent
		elif self._usenetIsProvider(link = link):
			return Container.TypeUsenet

		# Check Online Files
		if self._torrentIsFile(link = link, local = False):
			return Container.TypeTorrent
		elif self._usenetIsFile(link = link, local = False):
			return Container.TypeUsenet

		# No Type Found
		return Container.TypeUnknown

	def _hash(self, link, type = None):
		if type is None: type = self._type(link)

		if type == Container.TypeTorrent: return self._torrentHash(link)
		elif type == Container.TypeUsenet: return self._usenetHash(link)
		else: return None

	def _extension(self, link, type = None):
		if type is None: type = self._type(link)

		if type == Container.TypeTorrent: return Container.ExtensionTorrent
		elif type == Container.TypeUsenet: return Container.ExtensionUsenet
		elif type == Container.TypeHoster: return Container.ExtensionHoster
		else: return None

	def _mime(self, link, type = None):
		if type is None: type = self._type(link)

		if type == Container.TypeTorrent: return Container.MimeTorrent
		elif type == Container.TypeUsenet: return Container.MimeUsenet
		elif type == Container.TypeHoster: return Container.MimeHoster
		else: return None

	# CACHE

	def _cache(self, link, type = None, lite = False):
		import os

		mime = None
		extension = None
		data = None
		path = None
		name = None
		hash = None
		magnet = None

		if not link is None and not link == '':
			magnet = self._torrentIsMagnet(link)
			if magnet:
				type = Container.TypeTorrent
				hash = self._hash(link = link, type = type)
			else:
				if os.path.exists(link):
					path = link
				else:
					id = self._cacheId(link = link)
					path = self._cacheFind(id = id, type = type)

				if path:
					type = self._type(path)
					name = self._cacheName(path = path)
					data = self._cacheData(path = path)

				if self.mDownload and data is None:
					counter = 0
					while counter < 3:
						counter += 1
						response = Networker().request(link = link)
						data = response['data']['bytes']
						name = response['meta']['name']
						if data is None or data == '':
							# Certain servers (eg: UsenetCrawler) block consecutive or batch calls and mark them as 503 (temporarily unavailable). Simply wait a bit and try again.
							if response['error']['code'] == 503:
								tools.Time.sleep(0.1)
							else:
								break
						else:
							self._cacheInitialize()
							if self._usenetIsData(data):
								data = data.replace(b'\r', b'') # Very important, otherwise the usenet hashes on Premiumize's server and the local hashes won't match, because the local file got some extra \r.

							path = self._cachePath(type = type, id = id, name = name)
							tools.File.writeNow(path, data, bytes = True, native = True)

							type = self._type(path)
							if not type == Container.TypeUnknown:
								pathNew = self._cachePath(type = type, id = id, name = name)
								tools.File.move(path, pathNew)
								path = pathNew

							break

				base = path if link is None else link
				if not name and not base is None:
					name = tools.File.name(base)

			if not lite and path:
				mime = self._mime(link = path, type = type)
				extension = self._extension(link = path, type = type)
				hash = self._hash(link = path, type = type)

		return {'type' : type, 'hash' : hash, 'name' : name, 'mime' : mime, 'magnet' : magnet, 'link' : link, 'path' : path, 'extension' : extension, 'data' : data}

	def _cacheInitialize(self):
		try:
			tools.File.makeDirectory(Container.PathTemporaryContainerData)
			tools.File.makeDirectory(Container.PathTemporaryContainerTorrent)
			tools.File.makeDirectory(Container.PathTemporaryContainerUsenet)
			tools.File.makeDirectory(Container.PathTemporaryContainerHoster)
		except:
			pass

	def _cacheClear(self):
		try:
			tools.File.delete(Container.PathTemporaryContainer, force = True)
		except:
			pass

	def _cacheId(self, link):
		return tools.Hash.sha1(link)

	def _cachePath(self, type, id, name = None):
		path = None
		try:
			if type == Container.TypeTorrent:
				path = Container.PathTemporaryContainerTorrent
				extension = Container.ExtensionTorrent
			elif type == Container.TypeUsenet:
				path = Container.PathTemporaryContainerUsenet
				extension = Container.ExtensionUsenet
			elif type == Container.TypeHoster:
				path = Container.PathTemporaryContainerHoster
				extension = Container.ExtensionHoster
			else:
				path = Container.PathTemporaryContainerData
				extension = Container.ExtensionData

			if name is None:
				name = id
			else:
				name = id + Container.Separator + name

			if not name.endswith(extension):
				name += extension
			path = tools.File.joinPath(path, name)
		except:
			pass
		return path

	def _cacheName(self, path):
		name = tools.File.name(path)
		if name:
			index = name.find(Container.Separator)
			if index >= 0:
				name = name[index + 1:]
		return name

	def _cacheData(self, path):
		if not path or Networker.linkIs(link = path, magnet = True): return None
		return tools.File.readNow(path, bytes = True, native = True)

	def _cacheFind(self, id, type = None):
		try:
			id = id.lower()

			if type == Container.TypeTorrent: containers = [Container.PathTemporaryContainerTorrent]
			elif type == Container.TypeUsenet: containers = [Container.PathTemporaryContainerUsenet]
			elif type == Container.TypeHoster: containers = [Container.PathTemporaryContainerHoster]
			else: containers = [Container.PathTemporaryContainerTorrent, Container.PathTemporaryContainerUsenet, Container.PathTemporaryContainerHoster]
			containers.append(Container.PathTemporaryContainerData)

			for container in containers:
				if tools.File.existsDirectory(container):
					directories, files = tools.File.listDirectory(container)
					for file in files:
						if file.lower().startswith(id):
							return tools.File.joinPath(container, file)
		except:
			pass
		return None

	# TORRENT

	def _torrentData(self, path, info = True, attribute = None):
		if not path or Networker.linkIs(link = path, magnet = True): return None

		# Do not put in a try-catch, since other functions rely on this function to throw an exception.
		from lib.externals import bencode
		# NB: Do not add a try-catch here, since other function rely on this to fail.
		data = tools.File.readNow(path, bytes = True, native = True) # Native, otherwise bencode cannot decode the data.
		data = bencode.bdecode(data)
		if info:
			try: data = data[b'info']
			except:
				try: data = data['info']
				except: pass
		if attribute:
			try: data = data[bytes(attribute, 'utf-8')]
			except:
				try: data = data[attribute]
				except: data = None
		return data

	# Link can be a torrent hash, list of torrent hashes (SHA1 and SHA256), or existing magnet link.
	def _torrentMagnet(self, link, title = None, encode = True, tracker = True, parameters = None):
		try:
			parameters = None

			if self._torrentIsMagnet(link):
				params = self._torrentMagnetParameters(link = link)
				try:
					hash = [tools.Regex.remove(data = i, expression = Container.ExpressionPrefix) for i in params['xt']]
					del params['xt']
				except: pass
				try:
					if title is None and params['dn']: title = params['dn']
					del params['dn']
				except: pass
				try:
					if (tracker is None or tracker is True) and params['tr']: tracker = params['tr']
					del params['tr']
				except: pass
				if parameters is False: params = []
				elif not parameters is None: params.update(parameters)
				parameters = params
			else:
				if Networker.linkIs(link = link, magnet = False):
					if not title: title = self._torrentName(link = link)
					hash = self._torrentHashFile(link = link, version = None)
				elif tools.Tools.isArray(link):
					hash = link
				else:
					hash = [link]

			return self._torrentMagnetCreate(hash = hash, title = title, tracker = tracker, parameters = parameters, encode = encode)
		except: tools.Logger.error()

	@classmethod
	def _torrentMagnetCreate(self, hash, title = None, tracker = True, parameters = None, encode = True):
		try:
			values = []

			# Add hashes.
			if not hash: return None
			if not tools.Tools.isArray(hash): hash = [hash]
			for i in hash:
				length = len(i)
				if length in Container.LengthSha1: prefix = Container.PrefixSha1
				elif length in Container.LengthSha256: prefix = Container.PrefixSha256
				else: prefix = Container.PrefixSha256
				values.append(('xt', prefix + i.upper() if length in Container.LengthUpper else i))

			# Add titles.
			if title:
				if not tools.Tools.isArray(title): title = [title]
				values.extend([('dn', i) for i in title])

			# Add other parameters.
			if parameters:
				if tools.Tools.isDictionary(parameters): parameters = [(key, val) for key, val in parameters.items()]
				values.extend(parameters)

			# Add trackers.
			if tracker:
				if tracker is True: tracker = self.torrentTrackers()
				elif not tools.Tools.isArray(tracker): tracker = [tracker]
				values.extend([('tr', i) for i in tracker])

			# If multiple values were specified for a single key.
			temp = []
			for i in values:
				if tools.Tools.isArray(i[1]): temp.extend([(i[0], j) for j in i[1]])
				else: temp.append(i)
			values = temp

			# URL-encode parameter values, except URNs.
			if encode: values = [(i[0], self._torrentParameterEncode(i[1])) for i in values]

			# Create the magnet.
			link = Container.PrefixMagnet + '?' + ('&'.join([i[0] + '=' + i[1] for i in values]))
			link = link.replace('/', '%2F') # Some magnet links still have the slash / (urlencode does not encode slashes). This seems to be a problem with RealDebrid. Manually escape these slashes.

			return link
		except: tools.Logger.error()

	def _torrentMagnetBase(self, link):
		return self._torrentMagnet(link = link, title = False, tracker = False, parameters = False)

	@classmethod
	def _torrentMagnetParameters(self, link):
		return Networker.linkParameters(link = link, decode = True, multi = True)

	@classmethod
	def _torrentMagnetClean(self, link, tracker = True, decode = True, encode = True, base = BaseDefault):
		if self._torrentIsMagnet(link):

			# Replace &amps; with &.
			if decode: link = tools.Regex.replace(data = link, expression = '(&amp;)([a-z]{2}=)', replacement = '&\g<2>')

			hash = None
			title = None
			parameters = self._torrentMagnetParameters(link = link)
			try:
				hash = [self._torrentHashBase(hash = tools.Regex.remove(data = i, expression = Container.ExpressionPrefix), base = base) for i in parameters['xt']]
				del parameters['xt']
			except: tools.Logger.error()
			try:
				title = parameters['dn']
				del parameters['dn']
			except: pass
			try:
				tracker = parameters['tr']
				del parameters['tr']
			except: pass

			return self._torrentMagnetCreate(hash = hash, title = title, tracker = tracker, parameters = parameters, encode = encode)

		return link

	def _torrentMagnetRename(self, link, title = None, encode = True, replace = True):
		try:
			hash = None
			names = None
			parameters = self._torrentMagnetParameters(link = link)
			try:
				hash = parameters['xt']
				del parameters['xt']
			except: tools.Logger.error()
			try:
				names = parameters['dn']
				del parameters['dn']
			except: pass
			try:
				tracker = parameters['tr']
				del parameters['tr']
			except: pass

			if names:
				for i in range(len(names)):
					name = names[i]
					replacement = replace
					if replacement is None:
						expression = tools.Regex.expression(expression = '\.{2,}\s*$')
						if title and (not name or expression.search(name)) and (title and not expression.search(title)):
							if name:
								current = Networker.linkUnquote(name)
								current = current.strip(' ').rstrip('.').rstrip(' ')
								if title.startswith(current): replacement = True
							else:
								replacement = True
					if replacement is True or (replacement is False and not name) or (not name or (replacement and tools.Regex.match(data = name, expression = replacement))):
						names[i] = title
			else:
				names = [title]

			seen = set()
			names = [i for i in names if not (i in seen or seen.add(i))]

			return self._torrentMagnetCreate(hash = hash, title = names, tracker = tracker, parameters = parameters, encode = encode)

		except: pass
		return link

	def _torrentName(self, link):
		try:
			if self._torrentIsMagnet(link):
				result = parse_qs(urlparse(link).query)['dn']
				if tools.Tools.isArray(result): result = result[0]
				return result
			else:
				path = self._cache(link, lite = True)['path']
				name = self._torrentData(path, info = True, attribute = 'name')
				try: name = str(name, 'utf-8')
				except: name = str(name)
				return name
		except:
			return None

	# local: If true, does not retrieve any data from the internet, only local extensions, names, and files.
	def _torrentIs(self, link, local = False):
		result = self._torrentIsMagnet(link = link) or self._torrentIsExtension(link = link) or self._torrentIsFile(link = link, local = True) or self._torrentIsProvider(link = link)
		if not result and local == False:
			result = self._torrentIsFile(link = link, local = local)
		return result

	@classmethod
	def _torrentIsMagnet(self, link):
		return Networker.linkIsMagnet(link)

	@classmethod
	def _torrentIsExtension(self, link, local = False):
		return link.endswith(Container.ExtensionTorrent)

	def _torrentIsFile(self, link, local = False):
		path = None
		if not local and Networker.linkIs(link):
			path = self._cache(link, lite = True)['path']
		else:
			path = link
		try:
			self._torrentData(path) # Will throw an exception if not torrent
			return True
		except:
			return False

	def _torrentIsProvider(self, link):
		from lib.providers.core.manager import Manager
		link = link.lower()
		providers = Manager.providers(type = Container.TypeTorrent, enabled = True)
		for provider in providers:
			if any(domain in link for domain in provider.linkDomains(subdomain = False)):
				return True
		return False

	def _torrentHash(self, link, version = VersionDefault):
		if self._torrentIsMagnet(link): return self._torrentHashMagnet(link = link, version = version)
		else: return self._torrentHashFile(link = link, version = version)

	@classmethod
	def _torrentHashMagnet(self, link, version = VersionDefault, base = BaseDefault):
		if self._torrentIsMagnet(link):
			hashes = tools.Regex.extract(data = link, expression = Container.ExpressionHash, group = None, all = True)
			if not hashes: return None # If the magnet is malformed and does not contain a hash.

			if version is Container.VersionAny:
				return self._torrentHashBase(hash = hashes[0], base = base)
			elif version == Container.Version1:
				for hash in hashes:
					length = len(hash)
					if length in Container.LengthSha1:
						return self._torrentHashBase(hash = hash, base = base)
			elif version == Container.Version2:
				for hash in hashes:
					length = len(hash)
					if length in Container.LengthSha256:
						return self._torrentHashBase(hash = hash, base = base)
			else:
				return [self._torrentHashBase(hash = hash, base = base) for hash in hashes]

		return None

	def _torrentHashFile(self, link, version = VersionDefault):
		try:
			from lib.externals import bencode
			path = self._cache(link, lite = True)['path']
			try:
				info = self._torrentData(path)
				info = bencode.bencode(info)
				if version is Container.VersionAny: return tools.Hash.sha1(info)
				elif version == Container.Version1: return tools.Hash.sha1(info)
				elif version == Container.Version2: return tools.Hash.sha256(info)
				else: return [tools.Hash.sha256(info), tools.Hash.sha1(info)]
			except:
				return None
		except:
			return None

	@classmethod
	def _torrentHashBase(self, hash, base = BaseDefault):
		if not hash: return hash
		length = len(hash)

		# Detect current base encoding.
		if length in Container.LengthBase32: current = Container.Base32
		elif length in Container.LengthBase64: current = Container.Base64
		else: current = Container.Base16

		# Pad with '=' if not enough padding is present, otherwise base decoding will fail.
		if length in Container.LengthUnpadded and (current == Container.Base32 or current == Container.Base64): hash += '=' * (-length % 4)

		# Convert to upper, otherwise base decoding will fail.
		if current == Container.Base16 or current == Container.Base32: hash = hash.upper()

		if current == base or base == Container.BaseNone: return hash

		# Decode.
		if current == Container.Base16: hash = tools.Converter.base16From(hash)
		elif current == Container.Base32: hash = tools.Converter.base32From(hash)
		elif current == Container.Base64: hash = tools.Converter.base64From(hash)

		# Encode.
		if base == Container.Base16: hash = tools.Converter.base16To(hash)
		elif base == Container.Base32: hash = tools.Converter.base32To(hash)
		elif base == Container.Base64: hash = tools.Converter.base64To(hash)

		return hash

	@classmethod
	def _torrentParameterEncode(self, value):
		if value and not value.startswith(Container.PrefixUrn): # Do not encode URNs (hash prefixes).
			try: value = Networker.linkUnquote(value, plus = not ' ' in value and not '%20' in value) # If already encoded. Only decode '+' if there are no spaces in the name (assuming the + is a space).
			except: pass
			try: value = Networker.linkQuote(value, plus = False) # Do not use quote_plus for title, otherwise adds + to title in some software.
			except: tools.Logger.error()
		return value

	# USENET

	def _usenetData(self, path):
		if not path or Networker.linkIs(link = path, magnet = True): return None
		return tools.File.readNow(path, native = True) # Native, otherwise zome NZBs fail to read.

	# local: If true, does not retrieve any data from the internet, only local extensions, names, and files.
	def _usenetIs(self, link, local = False):
		result = self._usenetIsExtension(link = link) or self._usenetIsFile(link = link, local = True) or self._usenetIsProvider(link = link)
		if not result and local == False:
			result = self._usenetIsFile(link = link, local = local)
		return result

	def _usenetIsExtension(self, link):
		return link.endswith(Container.ExtensionUsenet)

	def _usenetIsFile(self, link, local = False):
		path = None
		if not local and Networker.linkIs(link): path = self._cache(link, lite = True)['path']
		else: path = link
		try:
			data = self._usenetData(path)
			return self._usenetIsData(data)
		except: tools.Logger.error()
		return False

	def _usenetIsData(self, data):
		try:
			if not data is None:
				try: data = tools.Converter.unicode(data)
				except: pass
				try: data = data.lower()
				except: pass
				if '<!doctype nzb' in data or '</nzb>' in data:
					return True
		except: tools.Logger.error()
		return False

	def _usenetIsProvider(self, link):
		from lib.providers.core.manager import Manager
		link = link.lower()
		providers = Manager.providers(type = Container.TypeUsenet, enabled = True)
		for provider in providers:
			if any(domain in link for domain in provider.linkDomains(subdomain = False)):
				return True
		return False

	def _usenetHash(self, link):
		try:
			path = self._cache(link, lite = True)['path']
			try:
				data = self._usenetData(path)
				return tools.Hash.sha1(data)
			except:
				return None
		except:
			return None

	##############################################################################
	# BASICS
	##############################################################################

	def linkSet(self, link):
		if self._torrentIsMagnet(link): self.mLink = link.strip()
		else: self.mLink = Networker.linkClean(link = link, strip = False) # Returns the cleaned link.

	def link(self):
		return self.mLink

	def downloadSet(self, download):
		self.mDownload = download

	def download(self):
		return self.mDownload

	def type(self):
		return self._type(self.mLink)

	def extension(self):
		return self._extension(self.mLink)

	def mime(self):
		return self._mime(self.mLink)

	##############################################################################
	# ADVANCED
	##############################################################################

	# Clear local containers.
	def clear(self):
		self._cacheClear()

	# Get the hash of the container.
	def hash(self, type = None):
		return self._hash(link = self.mLink, type = type)

	# Cache the container.
	def cache(self):
		result = self._cache(link = self.mLink)
		return not result['data'] is None

	# Returns a dictionary with the container details.
	def information(self):
		return self._cache(link = self.mLink)

	def isFile(self):
		return self.torrentIsFile() or self.usenetIs()

	##############################################################################
	# TORRENT
	##############################################################################

	@classmethod
	def torrentTrackers(self):
		if Container.Trackers is None:
			trackers = []

			from lib.modules.cache import Cache
			result = Cache.instance().cacheLong(Networker().requestText, link = 'https://newtrackon.com/api/stable')
			if result:
				result = result.split('\n')
				result = [i.strip() for i in result]
				trackers = [i for i in result if i]

			trackers.extend(Container.TrackersCommon)
			trackers = tools.Tools.listUnique(trackers)
			Container.Trackers = trackers[:25]

		return Container.Trackers

	# Create a magnet from a hash or existing magnet.
	def torrentMagnet(self, title = None, encode = True, tracker = True):
		return self._torrentMagnet(self.mLink, title = title, encode = encode, tracker = tracker)

	# Clean magnet link from name and trackers.
	def torrentMagnetBase(self):
		return self._torrentMagnetBase(self.mLink)

	# hash can be a single hash or a list of hashes (eg: a SHA1 and SHA256 hash).
	# title can be a single name or a list of names.
	# parameters can be a list of tuples or dictionary, where the first-entry/dict-key is the parameter name, and the second-entry/dict-value the parameter value or list of values.
	def torrentMagnetCreate(self, title = None, parameters = [], encode = True, tracker = True):
		return self._torrentMagnetCreate(hash = self.mLink, title = title, parameters = parameters, encode = encode, tracker = tracker)

	# Clean the magnet link:
	#	1. Replace &amps; with &.
	#	2. Replace base32/64-encoded hash with hexadecimal hash.
	#	3. URL-encode all parameters correctly.
	def torrentMagnetClean(self, tracker = True, decode = True, encode = True, base = BaseDefault):
		return self._torrentMagnetClean(self.mLink, tracker = tracker, decode = decode, encode = encode, base = base)

	# Add a name parameter to the magnet.
	# replace = False: Do not add if the magnet already has a name.
	# replace = True: Overwrite if the magnet already has a name.
	# replace = None: Overwrite if the magnet already has a name and the name starts with the new name (excluding trailing dots).
	# replace = string: Overwrite if the magnet already has a name and the name matches a regular expression.
	def torrentMagnetRename(self, title = None, encode = True, replace = True):
		return self._torrentMagnetRename(self.mLink, title = title, encode = encode, replace = replace)

	def torrentName(self):
		return self._torrentName(self.mLink)

	def torrentIs(self):
		return self._torrentIs(self.mLink)

	def torrentIsMagnet(self):
		return self._torrentIsMagnet(self.mLink)

	def torrentIsFile(self):
		return self._torrentIsFile(self.mLink)

	def torrentHash(self):
		return self._torrentHash(self.mLink)

	def torrentHashMagnet(self):
		return self._torrentHashMagnet(self.mLink)

	def torrentHashFile(self):
		return self._torrentHashFile(self.mLink)

	##############################################################################
	# USENET
	##############################################################################

	def usenetIs(self):
		return self._usenetIs(self.mLink)

	def usenetHash(self):
		return self._usenetHash(self.mLink)
