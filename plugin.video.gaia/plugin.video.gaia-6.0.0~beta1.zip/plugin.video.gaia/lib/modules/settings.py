# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib import debrid
from lib.modules import tools
from lib.modules import interface
from lib.modules import verification
from lib.modules import vpn
from lib.modules import handler
from lib.modules import speedtest
from lib.modules import support
from lib.modules import orionoid
from lib.providers.core import manager

class Selection(object): # gaiaremove ??

	##############################################################################
	# SHOW
	##############################################################################

	@classmethod
	def show(self):
		choice = interface.Dialog.option(title = 33011, message = 33929, labelConfirm = 33893, labelDeny = 33894)
		if choice: return Wizard.show()
		else: return Advanced.show()

class Advanced(object): # gaiaremove ??

	##############################################################################
	# SHOW
	##############################################################################

	@classmethod
	def show(self, id = None):
		return tools.Settings.launch(id)

class Wizard(object):

	Property = 'GaiaWizard'

	ChoiceCancelled = interface.Dialog.ChoiceCancelled
	ChoiceRight = interface.Dialog.ChoiceCustom
	ChoiceLeft = interface.Dialog.ChoiceYes
	ChoiceMiddle = interface.Dialog.ChoiceNo

	OptionContinue = 'continue'
	OptionCancel = 'cancel'
	OptionCancelBack = 'cancelback'
	OptionCancelSkip = 'cancelskip'
	OptionCancelWizard = 'cancelwizard'

	##############################################################################
	# CONSTRUCTOR
	##############################################################################

	def __init__(self):
		self.mLevel = None

	##############################################################################
	# SHOW
	##############################################################################

	@classmethod
	def _sleep(self, seconds):
		tools.Time.sleep(seconds)

	@classmethod
	def _confirm(self, message, title = 33895):
		return interface.Dialog.confirm(title = title, message = message)

	@classmethod
	def _option(self, message, left, right, title = 33895):
		return Wizard.ChoiceLeft if interface.Dialog.option(title = title, message = message, labelConfirm = left, labelDeny = right) else Wizard.ChoiceRight

	@classmethod
	def _options(self, message, left, middle, right, title = 33895):
		return interface.Dialog.options(title = title, message = message, labelConfirm = left, labelDeny = middle, labelCustom = right)

	@classmethod
	def _input(self, default = None, title = 33895):
		return interface.Dialog.input(title = title, type = interface.Dialog.InputAlphabetic, default = default)

	@classmethod
	def _cancel(self):
		choice = self._options(33975, 35324, 33976, 33977)
		if choice == Wizard.ChoiceLeft: return Wizard.OptionCancelBack
		elif choice == Wizard.ChoiceMiddle: return Wizard.OptionCancelWizard
		elif choice == Wizard.ChoiceRight: return Wizard.OptionCancelSkip
		else: return Wizard.OptionCancelWizard

	@classmethod
	def _showWelcome(self, launch = False):
		choice = self._options(33930, 33743, 33893, 33110)
		if choice == Wizard.ChoiceCancelled:
			return Wizard.OptionCancelWizard
		elif choice == Wizard.ChoiceLeft:
			self._showFinish()
			return Wizard.OptionCancelWizard
		elif choice == Wizard.ChoiceMiddle:
			return Wizard.OptionContinue
		elif choice == Wizard.ChoiceRight:
			tools.Settings.launch(wait = True)
			self._showFinish()
			return Wizard.OptionCancelWizard

	@classmethod
	def _showFinish(self):
		'''choice = self._option(33974, 33505, 33832)
		tools.System.openLink(tools.Settings.getString('internal.link.website', raw = True), popup = False)
		if choice == Wizard.ChoiceLeft:
			# Do not use navigator().donationsNavigator().
			# This will not update Kodi's directory.
			tools.Donations.show()
		else:
			return Wizard.OptionContinue'''
		return Wizard.OptionContinue#gaiaremove

	@classmethod
	def _showLevel(self):
		self.mLevel = tools.Settings.level(default = None)
		if self.mLevel is None: # If for some reason the level cannot be read.
			self.mLevel = tools.Settings.LevelStandard
			return Wizard.OptionContinue

		choice = self._option(35321, 33743, 33821)
		if choice == Wizard.ChoiceLeft: return Wizard.OptionCancel

		enabled = interface.Format.fontColor(interface.Translation.string(32301), interface.Format.colorExcellent())
		disabled = interface.Format.fontColor(interface.Translation.string(32302), interface.Format.colorBad())
		types = [(tools.Settings.LevelBasic, 33314), (tools.Settings.LevelStandard, 33315), (tools.Settings.LevelAdvanced, 33316), (tools.Settings.LevelExpert, 33317)]

		def update(level):
			self.mLevel = level
			tools.Settings.levelSet(level)

		def items():
			items = [
				{'title' : interface.Dialog.prefixBack(33743), 'close' : True, 'return' : Wizard.OptionCancel},
				{'title' : interface.Dialog.prefixNext(33821), 'close' : True, 'return' : Wizard.OptionContinue},
				'',
			]
			for i in range(len(types)):
				items.append({'title' : '%s (%s)' % (interface.Translation.string(types[i][1]), interface.Format.iconRating(count = i + 1)), 'value' : enabled if types[i][0] == self.mLevel else disabled, 'color' : False, 'return' : True, 'action' : update, 'parameters' : {'level' : types[i][0]}})
			return items

		choice = interface.Dialog.information(title = 33895, refresh = items, reselect = 1)
		if choice is None: choice = Wizard.OptionCancel
		return choice

	@classmethod
	def _showLanguage(self):
		choice = self._option(33964, 33743, 33821)
		if choice == Wizard.ChoiceLeft: return Wizard.OptionCancel

		types = [(tools.Language.TypePrimary, 32356), (tools.Language.TypeSecondary, 32357), (tools.Language.TypeTertiary, 35036)]
		none = interface.Format.fontColor(interface.Translation.string(33112), interface.Format.colorBad())

		def items():
			languages = tools.Language.settings()
			items = [
				{'title' : interface.Dialog.prefixBack(33743), 'close' : True, 'return' : Wizard.OptionCancel},
				{'title' : interface.Dialog.prefixNext(33821), 'close' : True, 'return' : Wizard.OptionContinue},
				'',
			]
			for i in range(len(types)):
				try: language = interface.Format.fontColor(languages[i][tools.Language.Name][tools.Language.NameEnglish], interface.Format.colorExcellent())
				except: language = none
				items.append({'title' : interface.Translation.string(types[i][1]), 'value' : language, 'color' : False, 'return' : True, 'action' : tools.Language.settingsSelect, 'parameters' : {'type' : types[i][0], 'title' : 33895, 'none' : True, 'automatic' : False}})
			return items

		choice = interface.Dialog.information(title = 33895, refresh = items, reselect = 1)
		if choice is None: choice = Wizard.OptionCancel
		if not choice is True: return choice

	@classmethod
	def _showAccounts(self):
		choice = self._option(35288, 33743, 33821)
		if choice == Wizard.ChoiceLeft: return Wizard.OptionCancel

		from lib.modules.account import Orion, Trakt, Imdb, Tmdb, Fanart, Youtube, Opensubtitles, Premiumize, Offcloud, Realdebrid, Easynews

		def authenticate(account):
			if tools.Tools.isFunction(account):
				account()
			else:
				authenticated = account.authenticated()
				free = account.free()
				description = account.description()
				if description: description = interface.Translation.string(description) + ' '
				else: description = ''

				if authenticated:
					description += interface.Translation.string(33982)
					choice = self._option(description, 33743, 32512)
					if choice == Wizard.ChoiceLeft: return Wizard.OptionCancelSkip
				else:
					description += interface.Translation.string(33979 if free else 33932)
					choice = self._options(description, 33743, 32512, 33334 if free else 33335)
					if choice == Wizard.ChoiceLeft:
						return Wizard.OptionCancelSkip
					elif choice == Wizard.ChoiceRight:
						register = account.register()
						if register is None:
							choice = self._option(33981, 33342, 33341)
							if choice == Wizard.ChoiceLeft: return Wizard.OptionCancelSkip
						elif register is True:
							return Wizard.OptionCancelSkip

				account.authenticate(settings = False)
			return Wizard.OptionContinue

		def items():
			orion = orionoid.Orionoid()
			enabled = interface.Format.fontColor(interface.Translation.string(32301), interface.Format.colorExcellent())
			disabled = interface.Format.fontColor(interface.Translation.string(32302), interface.Format.colorBad())

			accounts = [
				(interface.Translation.string(32310), [
					Trakt(),
					Imdb(),
					Tmdb(),
					Fanart(),
					Youtube(),
					Opensubtitles(),
				]),
				(interface.Translation.string(33768), [
					Premiumize(),
					Offcloud(),
					Realdebrid(),
					Easynews(),
				]),
				(interface.Translation.string(33105), [
					Orion(),
				]),
			]

			items = [
				{'title' : interface.Dialog.prefixBack(33743), 'close' : True, 'return' : Wizard.OptionCancel},
				{'title' : interface.Dialog.prefixNext(33821), 'close' : True, 'return' : Wizard.OptionContinue},
			]
			for category in accounts:
				sub = []
				for account in category[1]:
					if account.settingsVisible():
						sub.append({
							'title' : '%s (%s)' % (interface.Translation.string(account.name()), interface.Format.iconRating(count = account.rank())),
							'value' : enabled if account.authenticated() else disabled,
							'color' : False,
							'action' : authenticate,
							'parameters' : {'account' : account},
						})
				if sub: items.append({'title' : category[0], 'items' : sub})

			return items

		choice = interface.Dialog.information(title = 33895, refresh = items, reselect = interface.Dialog.ReselectYes, selection = 1)
		if choice is None: choice = Wizard.OptionCancel
		return choice

	@classmethod
	def _showScrape(self):
		choice = self._option(35270, 33743, 33821)
		if choice == Wizard.ChoiceLeft: return Wizard.OptionCancel

		from lib.providers.core.manager import Manager, ProviderBase
		from lib.modules.tools import Hardware
		from lib.modules.tools import Hardware

		hardware = None
		connection = None



		def analyzeConnection(iterations = 3):
			from lib.modules.speedtest import SpeedTester, SpeedTesterGlobal
			try:
				minimum = 0
				maximum = 9999999999
				latency = maximum
				download = minimum
				latencyLabel = None
				downloadLabel = None

				for i in range(iterations):
					speedtester = SpeedTesterGlobal()
					speedtester.performance()
					if speedtester.latency() < latency: latency = speedtester.latency()
					if speedtester.download() > download: download = speedtester.download()

				if latency == maximum: latency = None
				if download == minimum: download = None
				speedtester = SpeedTesterGlobal()
				speedtester.latencySet(latency)
				speedtester.downloadSet(download)
				performance = speedtester.performance(test = False)
			except:
				tools.Logger.error()


		def optimize():
			#Manager.optimize(results = False, optimize = Manager.OptimizeAll)
			Manager.optimize(results = False, optimize = Manager.OptimizeAll, connection=False)#gaiaremove

		def items():
			items = [
				{'title' : interface.Dialog.prefixBack(33743), 'close' : True, 'return' : Wizard.OptionCancel},
				{'title' : interface.Dialog.prefixNext(33821), 'close' : True, 'return' : Wizard.OptionContinue},

				{'title' : 33183, 'items' : [
					{'title' : interface.Dialog.prefixNext(33325), 'action' : optimize},
					{'title' : interface.Dialog.prefixNext(33327), 'action' : optimize},
					{'title' : interface.Dialog.prefixNext(33326), 'action' : Manager.settings},
				]},
			]

			sub = []
			for type in ProviderBase.Types:
				count = Manager.settingsCount(label = True, type = type)
				if not count is None: sub.append({'title' : ProviderBase.TypesData[type]['label'], 'color' : False, 'value' : count, 'action' : lambda type: Manager.settings(type = type), 'parameters' : {'type' : type}})
			items.append({'title' : 32345, 'items' : sub})

			return items

		optimize()#gaiaremove
		choice = interface.Dialog.information(title = 33895, refresh = items, reselect = interface.Dialog.ReselectYes, selection = 1)
		if choice is None: choice = Wizard.OptionCancel
		return choice

	@classmethod
	def _showProviders(self):
		choice = self._option(35270, 33743, 33821)
		if choice == Wizard.ChoiceLeft: return Wizard.OptionCancel

		from lib.providers.core.manager import Manager, ProviderBase

		def optimize():
			#Manager.optimize(results = False, optimize = Manager.OptimizeAll)
			Manager.optimize(results = False, optimize = Manager.OptimizeAll, connection=False)#gaiaremove

		def items():
			items = [
				{'title' : interface.Dialog.prefixBack(33743), 'close' : True, 'return' : Wizard.OptionCancel},
				{'title' : interface.Dialog.prefixNext(33821), 'close' : True, 'return' : Wizard.OptionContinue},

				{'title' : 33183, 'items' : [
					{'title' : interface.Dialog.prefixNext(33325), 'action' : optimize},
					{'title' : interface.Dialog.prefixNext(33327), 'action' : optimize},
					{'title' : interface.Dialog.prefixNext(33326), 'action' : Manager.settings},
				]},
			]

			sub = []
			for type in ProviderBase.Types:
				count = Manager.settingsCount(label = True, type = type)
				if not count is None: sub.append({'title' : ProviderBase.TypesData[type]['label'], 'color' : False, 'value' : count, 'action' : lambda type: Manager.settings(type = type), 'parameters' : {'type' : type}})
			items.append({'title' : 32345, 'items' : sub})

			return items

		#optimize()#gaiaremove
		choice = interface.Dialog.information(title = 33895, refresh = items, reselect = interface.Dialog.ReselectYes, selection = 1)
		if choice is None: choice = Wizard.OptionCancel
		return choice

	@classmethod
	def _showProvidersX(self, first = True):#gaiaremove
		if first:
			choice = self._option(33908, 33743, 33821)
			if choice == Wizard.ChoiceLeft: return self._cancel()

		orion = orionoid.Orionoid()
		enabled = interface.Format.fontColor(interface.Translation.string(32301), interface.Format.colorExcellent())
		disabled = interface.Format.fontColor(interface.Translation.string(32302), interface.Format.colorBad())
		special = '[' + interface.Translation.string(33105) + '] '
		general = '[' + interface.Translation.string(32310) + '] '
		torrent = '[' + interface.Translation.string(33199) + '] '
		usenet = '[' + interface.Translation.string(33200) + '] '
		hoster = '[' + interface.Translation.string(33198) + '] '
		external = '[' + interface.Translation.string(35354) + '] '

		choices = [None]
		items = [interface.Format.fontBold(interface.Translation.string(33821))]

		if orion.accountValid():
			choices.append('specialorion')
			items.append(interface.Format.fontBold(special + interface.Translation.string(35414) + ': ' + (enabled if orion.accountEnabled() else disabled)))

		choices.append('generallocal')
		items.append(interface.Format.fontBold(general + interface.Translation.string(35356) + ': ' + (enabled if tools.Settings.getBoolean('provider.general.local.open.enabled') or tools.Settings.getBoolean('provider.general.local.member.enabled') else disabled)))

		if tools.Settings.getBoolean('account.debrid.premiumize.enabled') or tools.Settings.getBoolean('account.debrid.offcloud.enabled') or tools.Settings.getBoolean('account.debrid.realdebrid.enabled') or tools.Settings.getBoolean('account.debrid.easynews.enabled'):
			choices.append('generalpremium')
			items.append(interface.Format.fontBold(general + interface.Translation.string(35357) + ': ' + (enabled if tools.Settings.getBoolean('provider.general.premium.open.enabled') or tools.Settings.getBoolean('provider.general.premium.member.enabled') else disabled)))

		if handler.Handler(handler.Handler.TypeTorrent).serviceHas():
			choices.append('torrentuniversal')
			items.append(interface.Format.fontBold(torrent + interface.Translation.string(35355) + ': ' + (enabled if tools.Settings.getBoolean('provider.torrent.universal.open.enabled') or tools.Settings.getBoolean('provider.torrent.universal.distributed.enabled') or tools.Settings.getBoolean('provider.torrent.universal.member.enabled') else disabled)))
			choices.append('torrentfrench')
			items.append(interface.Format.fontBold(torrent + interface.Translation.string(35033) + ': ' + (enabled if tools.Settings.getBoolean('provider.torrent.french.open.enabled') or tools.Settings.getBoolean('provider.torrent.french.member.enabled') else disabled)))
			choices.append('torrentrussian')
			items.append(interface.Format.fontBold(torrent + interface.Translation.string(35353) + ': ' + (enabled if tools.Settings.getBoolean('provider.torrent.russian.open.enabled') or tools.Settings.getBoolean('provider.torrent.russian.member.enabled') else disabled)))
			choices.append('torrentitalian')
			items.append(interface.Format.fontBold(torrent + interface.Translation.string(35389) + ': ' + (enabled if tools.Settings.getBoolean('provider.torrent.italian.open.enabled') or tools.Settings.getBoolean('provider.torrent.italian.member.enabled') else disabled)))

		if handler.Handler(handler.Handler.TypeUsenet).serviceHas():
			choices.append('usenetuniversal')
			items.append(interface.Format.fontBold(usenet + interface.Translation.string(35355) + ': ' + (enabled if tools.Settings.getBoolean('provider.usenet.universal.open.enabled') or tools.Settings.getBoolean('provider.usenet.universal.member.enabled') else disabled)))

		if handler.Handler(handler.Handler.TypeHoster).serviceHas():
			choices.append('hosteruniversal')
			items.append(interface.Format.fontBold(hoster + interface.Translation.string(35355) + ': ' + (enabled if tools.Settings.getBoolean('provider.hoster.universal.open.enabled') or tools.Settings.getBoolean('provider.hoster.universal.member.enabled') else disabled)))

		choices.append('externalopescrapers')
		items.append(interface.Format.fontBold(external + interface.Translation.string(35549) + ': ' + (enabled if tools.Settings.getBoolean('provider.external.universal.open.opescrapersx') else disabled)))#gaiaremove - new settings for providers
		choices.append('externallamscrapers')
		items.append(interface.Format.fontBold(external + interface.Translation.string(35432) + ': ' + (enabled if tools.Settings.getBoolean('provider.external.universal.open.lamscrapersx') else disabled)))#gaiaremove
		choices.append('externalcivscrapers')
		items.append(interface.Format.fontBold(external + interface.Translation.string(35505) + ': ' + (enabled if tools.Settings.getBoolean('provider.external.universal.open.civscrapersx') else disabled)))#gaiaremove
		choices.append('externalgloscrapers')
		items.append(interface.Format.fontBold(external + interface.Translation.string(35531) + ': ' + (enabled if tools.Settings.getBoolean('provider.external.universal.open.gloscrapersx') else disabled)))#gaiaremove
		choices.append('externaluniscrapers')
		items.append(interface.Format.fontBold(external + interface.Translation.string(35360) + ': ' + (enabled if tools.Settings.getBoolean('provider.external.universal.open.uniscrapersx') else disabled)))#gaiaremove
		choices.append('externalnanscrapers')
		items.append(interface.Format.fontBold(external + interface.Translation.string(35350) + ': ' + (enabled if tools.Settings.getBoolean('provider.external.universal.open.nanscrapersx') else disabled)))#gaiaremove

		choice = interface.Dialog.select(title = 33014, items = items)
		if choice < 0: return self._cancel()
		choice = choices[choice]

		#gaiaremove
		# Takes about 3 secs. By default they are all set to true, so this can be skipped.
		'''tools.Settings.set('stream.default.torrent', 1)
		tools.Settings.set('stream.premiumize.torrent', True)
		tools.Settings.set('stream.offcloud.torrent', True)
		tools.Settings.set('stream.realdebrid.torrent', True)
		tools.Settings.set('stream.default.usenet', 1)
		tools.Settings.set('stream.premiumize.usenet', True)
		tools.Settings.set('stream.offcloud.usenet', True)
		tools.Settings.set('stream.default.hoster', 1)
		tools.Settings.set('stream.premiumize.hoster', True)
		tools.Settings.set('stream.offcloud.hoster', True)
		tools.Settings.set('stream.realdebrid.hoster', True)
		tools.Settings.set('stream.alldebrid.hoster', True)
		tools.Settings.set('stream.rapidpremium.hoster', True)
		tools.Settings.set('stream.resolveurl.hoster', True)
		tools.Settings.set('stream.urlresolver.hoster', True)'''

		#gaiaremove
		'''defaultTorrent = 0
		defaultUsenet = 0
		defaultHoster = 0
		handlerPremium = tools.Settings.getBoolean('account.debrid.premiumize.enabled')
		handlerOffcloud = tools.Settings.getBoolean('account.debrid.offcloud.enabled')
		handlerRealdebrid = tools.Settings.getBoolean('account.debrid.realdebrid.enabled')
		handlers = int(handlerPremium) + int(handlerOffcloud) + int(handlerRealdebrid)
		if handlers == 1:
			defaultTorrent = 1 if handlerPremium else 2 if handlerOffcloud else 3
			defaultUsenet = 1 if handlerPremium else 2 if handlerOffcloud else 0
			defaultHoster = 1 if handlerPremium else 2 if handlerOffcloud else 3
		tools.Settings.set('stream.torrent.default', defaultTorrent)
		tools.Settings.set('stream.usenet.default', defaultUsenet)
		tools.Settings.set('stream.hoster.default', defaultHoster)'''

		#gaiaremove
		if choice == None:
			interface.Loader.show()
			count = lmanager.Manager.providersCounts()
			interface.Loader.hide()
			if count > 200:
				if self._option(interface.Translation.string(33909) % count, 35045, 35044) == Wizard.ChoiceLeft:
					return self._showProviders(first = False)
			return Wizard.OptionContinue
		elif choice == 'specialorion':
			active = self._option(35415, 33737, 33192) == Wizard.ChoiceRight
			orion.accountEnable(active)
		elif choice == 'generallocal':
			active = self._option(33958, 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.general.local.open.enabled', active)
			tools.Settings.set('provider.general.local.member.enabled', active)
		elif choice == 'generalpremium':
			active = self._option(33906, 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.general.premium.open.enabled', active)
			tools.Settings.set('provider.general.premium.member.enabled', active)
		elif choice == 'torrentuniversal':
			active = self._option(interface.Translation.string(33956) % interface.Translation.string(35358), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.torrent.universal.open.enabled', active)
			tools.Settings.set('provider.torrent.universal.distributed.enabled', active)
			tools.Settings.set('provider.torrent.universal.member.enabled', active)
		elif choice == 'torrentfrench':
			active = self._option(interface.Translation.string(33956) % interface.Translation.string(33790), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.torrent.french.open.enabled', active)
			tools.Settings.set('provider.torrent.french.member.enabled', active)
		elif choice == 'torrentrussian':
			active = self._option(interface.Translation.string(33956) % interface.Translation.string(33992), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.torrent.russian.open.enabled', active)
			tools.Settings.set('provider.torrent.russian.member.enabled', active)
		elif choice == 'torrentitalian':
			active = self._option(interface.Translation.string(33956) % interface.Translation.string(35388), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.torrent.italian.open.enabled', active)
			tools.Settings.set('provider.torrent.italian.member.enabled', active)
		elif choice == 'usenetuniversal':
			active = self._option(interface.Translation.string(33957) % interface.Translation.string(35358), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.usenet.universal.open.enabled', active)
			tools.Settings.set('provider.usenet.universal.member.enabled', active)
		elif choice == 'hosteruniversal':
			active = self._option(interface.Translation.string(33905) % interface.Translation.string(35358), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.hoster.universal.open.enabled', active)
			tools.Settings.set('provider.hoster.universal.member.enabled', active)
		elif choice == 'externalopescrapers':
			active = self._option(interface.Translation.string(33907) % interface.Translation.string(35548), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.external.universal.open.opescrapersx', active)
		elif choice == 'externallamscrapers':
			active = self._option(interface.Translation.string(33907) % interface.Translation.string(35431), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.external.universal.open.lamscrapersx', active)
		elif choice == 'externalcivscrapers':
			active = self._option(interface.Translation.string(33907) % interface.Translation.string(35504), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.external.universal.open.civscrapersx', active)
		elif choice == 'externalgloscrapers':
			active = self._option(interface.Translation.string(33907) % interface.Translation.string(35530), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.external.universal.open.gloscrapersx', active)
		elif choice == 'externaluniscrapers':
			active = self._option(interface.Translation.string(33907) % interface.Translation.string(35359), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.external.universal.open.uniscrapersx', active)
		elif choice == 'externalnanscrapers':
			active = self._option(interface.Translation.string(33907) % interface.Translation.string(35349), 33737, 33192) == Wizard.ChoiceRight
			tools.Settings.set('provider.external.universal.open.nanscrapersx', active)

		return self._showProviders(first = False)

	@classmethod
	def _showAutomation(self):
		if self.mMode == Wizard.ModeReaper or self.mMode == Wizard.ModeQuick or self.mMode == Wizard.ModeExtensive:
			choice = self._option(35322, 33800, 33110)
			enable = choice == Wizard.ChoiceLeft
			tools.Settings.set('automatic.enabled', enable)
		return Wizard.OptionContinue

	@classmethod
	def _showScraping(self):
		if self.mMode == Wizard.ModeExtensive:
			choice = self._option(33965, 33923, 33924)
			enable = choice == Wizard.ChoiceRight
			tools.Settings.set('scrape.failure.detection', enable)

			choice = self._option(33966, 33743, 33821)
			if choice == Wizard.ChoiceLeft: return self._cancel()
			choice = self._option(33967, 33564, 33800)
			if choice == Wizard.ChoiceRight:
				manager.Manager().optimization(title = 33895, introduction = False)
		return Wizard.OptionContinue

	@classmethod
	def _showVpn(self):
		if self.mMode == Wizard.ModeExtensive:
			choice = self._option(33969, 33743, 33821)
			if choice == Wizard.ChoiceLeft: return self._cancel()
			choice = self._option(33970, 33743, 33821)
			if choice == Wizard.ChoiceLeft: return self._cancel()
			choice = self._option(33971, 33897, 33927)
			if choice == Wizard.ChoiceLeft: return Wizard.OptionCancelSkip
			vpn.Vpn().configuration(settings = False, title = 33895, finish = 33821, introduction = False)
		return Wizard.OptionContinue

	@classmethod
	def _showSpeedTest(self):
		'''if self.mMode == Wizard.ModeExtensive:
			choice = self._option(33972, 33743, 33821)
			if choice == Wizard.ChoiceLeft: return self._cancel()
			choice = self._option(33973, 33897, 33928)
			if choice == Wizard.ChoiceLeft: return Wizard.OptionCancelSkip
			speedtest.SpeedTesterGlobal().show()
		return Wizard.OptionContinue'''#gaiaremove
		choice = self._option(33972, 33743, 33821)
		if choice == Wizard.ChoiceLeft: return self._cancel()
		choice = self._option(33973, 33897, 33928)
		if choice == Wizard.ChoiceLeft: return Wizard.OptionCancelSkip
		speedtest.SpeedTesterGlobal().show()

	@classmethod
	def show(self, launch = False):
		steps = [
			#lambda: self._showWelcome(launch = launch),
			#lambda: self._showLevel(),
			#lambda: self._showLanguage(),
			#lambda: self._showAccounts(),
			lambda: self._showScrape(),
			#lambda: self._showProviders(),

			#lambda: self._showSpeedTest(),#gaiaremove
		]

		#gaiaremove - maybe ask the user if he wants to install external dependecies for hosters (urlresolver, oathscrapers, etc).
		#gaiaremove - enable subtitles if opensubititles was authenticated.

		choice = None
		step = 0
		while True:
			for i in range(step, len(steps)):
				choice = steps[i]()
				if choice == Wizard.OptionCancel:
					choice = self._cancel()

				if choice == Wizard.OptionCancelWizard:
					return False
				elif choice == Wizard.OptionCancelBack:
					step = max(0, step - 1)
					break
				elif choice == Wizard.OptionCancelSkip:
					step += 1
				else:
					step += 1

			if not choice == Wizard.OptionCancelBack: break


			'''if self._showWelcome(launch = launch) == Wizard.OptionCancelWizard: return False#gaiaremove
			if self._showLanguage() == Wizard.OptionCancelWizard: return False

			if self._showAccounts() == Wizard.OptionCancelWizard:
				return False
			if self._showProviders() == Wizard.OptionCancelWizard:
				return False

			if self._showAutomation() == Wizard.OptionCancelWizard:
				return False

			if self._showScraping() == Wizard.OptionCancelWizard:
				return False
			if self._showVpn() == Wizard.OptionCancelWizard:
				return False
			if self._showSpeedTest() == Wizard.OptionCancelWizard:
				return False'''




		# Backup the new settings.
		#tools.Backup.automaticExport(force = True)#gaiaremove

		self._showFinish()

	@classmethod
	def launchInitial(self):
		# Sometimes on first run the wizard is shown multiple times.
		# This is probably becuase the settings are adapted, and the settings read/written below is not reliable.
		# Sett a Kodi global variable and check thatt as well.
		from lib.modules import window
		if not tools.Converter.boolean(window.Window.propertyGlobal(Wizard.Property)):
			window.Window.propertyGlobalSet(Wizard.Property, True)
			if tools.Settings.getBoolean('internal.initial.wizard'):
				return False
			else:
				self.show(launch = True)
				tools.Settings.set('internal.initial.wizard', True)
				return True
		return None
