# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

try: from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database

from lib.modules.tools import System, File, Time
from lib.modules.database import Database

class Metacache(object):

	@classmethod
	def select(self, items, lang, user):
		try:
			t2 = Time.timestamp()
			dbcon = database.connect(Database.pathMetadata())
			dbcur = dbcon.cursor()
		except:
			return items

		for i in range(0, len(items)):
			try:
				imdb = '0' if items[i]['imdb'] == 'tt' else items[i]['imdb']
				tvdb = items[i]['tvdb'] if 'tvdb' in items[i] else '0'
				# NB: First lookup by TVDb and then by IMDb, since there are some incorrect shows on Trakt that have the same IMDb ID, but different TVDb IDs (eg: Gotham).
				try:
					dbcur.execute("SELECT * FROM meta WHERE (imdb = '%s' and tvdb = '%s' and lang = '%s' and user = '%s' and not imdb = '0' and not tvdb = '0')" % (imdb, tvdb, lang, user))
					match = dbcur.fetchone()
					t1 = int(match[5])
				except:
					dbcur.execute("SELECT * FROM meta WHERE (imdb = '%s' and lang = '%s' and user = '%s' and not imdb = '0') OR (tvdb = '%s' and lang = '%s' and user = '%s' and not tvdb = '0')" % (imdb, lang, user, tvdb, lang, user))
					match = dbcur.fetchone()
					t1 = int(match[5])

				update = (abs(t2 - t1) / 3600) >= 720
				if update == True: raise Exception()

				item = eval(match[4].encode('utf-8'))
				item = dict((k,v) for k, v in item.items() if not v == '0')

				items[i].update(item)
				items[i].update({'metacache': True})
			except:
				pass

		return items

	@classmethod
	def insert(self, meta):
		try:
			File.makeDirectory(System.profile())
			dbcon = database.connect(Database.pathMetadata())
			dbcur = dbcon.cursor()
			dbcur.execute("CREATE TABLE IF NOT EXISTS meta (""imdb TEXT, ""tvdb TEXT, ""lang TEXT, ""user TEXT, ""item TEXT, ""time TEXT, ""UNIQUE(imdb, tvdb, lang, user)"");")
			t = Time.timestamp()
			for m in meta:
				try:
					i = repr(m['item'])
					imdb = '0' if m['imdb'] == 'tt' else m['imdb']

					# NB: First lookup by TVDb and then by IMDb, since there are some incorrect shows on Trakt that have the same IMDb ID, but different TVDb IDs (eg: Gotham).
					try:
						dbcur.execute("SELECT * FROM meta WHERE (imdb = '%s' and tvdb = '%s' and lang = '%s' and user = '%s' and not imdb = '0' and not tvdb = '0')" % (imdb, m['tvdb'], m['lang'], m['user'])).fetchone()[0] # Try to find entry.
						dbcur.execute("DELETE FROM meta WHERE (imdb = '%s' and tvdb = '%s' and lang = '%s' and user = '%s' and not imdb = '0' and not tvdb = '0')" % (imdb, m['tvdb'], m['lang'], m['user']))
					except:
						try: dbcur.execute("DELETE FROM meta WHERE (imdb = '%s' and lang = '%s' and user = '%s' and not imdb = '0') OR (tvdb = '%s' and lang = '%s' and user = '%s' and not tvdb = '0')" % (imdb, m['lang'], m['user'], m['tvdb'], m['lang'], m['user']))
						except: pass

					dbcur.execute("INSERT INTO meta Values (?, ?, ?, ?, ?, ?)", (imdb, m['tvdb'], m['lang'], m['user'], i, t))
				except:
					pass

			dbcon.commit()
		except:
			return

	@classmethod
	def local(self, items, link, poster, fanart):
		try:
			dbcon = database.connect(Database.pathArtwork())
			dbcur = dbcon.cursor()
			args = [i['imdb'] for i in items]
			dbcur.execute('SELECT * FROM mv WHERE imdb IN (%s)'  % ', '.join(list(map(lambda arg:  "'%s'" % arg, args))))
			data = dbcur.fetchall()
		except:
			return items

		for i in range(0, len(items)):
			try:
				item = items[i]

				match = [x for x in data if x[1] == item['imdb']][0]

				try:
					if poster in item and not item[poster] == '0': raise Exception()
					if match[2] == '0': raise Exception()
					items[i].update({poster: link % ('300', '/%s.jpg' % match[2])})
				except:
					pass
				try:
					if fanart in item and not item[fanart] == '0': raise Exception()
					if match[3] == '0': raise Exception()
					items[i].update({fanart: link % ('1280', '/%s.jpg' % match[3])})
				except:
					pass
			except:
				pass

		return items

	@classmethod
	def clear(self):
		try:
			dbcon = database.connect(Database.pathMetadata())
			dbcur = dbcon.cursor()
			dbcur.execute("DELETE FROM meta;")
			dbcur.execute("vacuum") # Reduce the file size.
			dbcon.commit()
			return True
		except:
			return False
