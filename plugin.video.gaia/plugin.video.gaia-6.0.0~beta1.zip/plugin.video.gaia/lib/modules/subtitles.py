# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

class Subtitles:

	ErrorUnauthorized = 'unauthorized'

	@classmethod
	def account(self):
		from lib.modules.account import Opensubtitles
		return Opensubtitles()

	@classmethod
	def verify(self, username = None, password = None):
		if username is None:
			account = self.account()
			username = account.dataUsername()
			password = account.dataPassword()

		from xmlrpc.client import ServerProxy
		server = ServerProxy('http://api.opensubtitles.org/xml-rpc', verbose = 0)
		token = server.LogIn(username, password, 'en', 'XBMC_Subtitles_v1')
		return 'token' in token and not('status' in token and 'unauthorized' in token['status'].lower())  # If invalid credentials are provided, a token is returned which is not usable. Always check the status.

	@classmethod
	def open(self, name, imdb, season, episode, source, background = True, wait = False):
		if background:
			from threading import Thread
			thread = Thread(target = self._open, kwargs = {'name' : name, 'imdb' : imdb, 'season' : season, 'episode' : episode, 'source' : source})
			thread.start()
			if wait: thread.join()
		else:
			return self._open(name = name, imdb = imdb, season = season, episode = episode, source = source)

	@classmethod
	def _open(self, name, imdb, season, episode, source):
		import re
		import zlib
		from xmlrpc.client import ServerProxy
		from lib.modules.tools import Settings, Language, Tools, Converter, System, File, Time, Logger
		from lib.modules.interface import Player, Format, Translation, Dialog

		try:
			player = Player()

			type = Settings.getInteger('subtitle.general.type')
			if type == 0:
				player.subtitlesDisable()
				return False
			elif type == 1:
				return False
			else:
				types = ['bluray', 'brrip', 'bdrip', 'bdrmx', 'web', 'webdl', 'webrip', 'webcap', 'dvdrip', 'dvdremux', 'hdrip', 'hdtv', 'tvrip']

				selection = Settings.getInteger('subtitle.general.selection')
				notifications = Settings.getBoolean('subtitle.general.notifications')

				langs = []
				variations = Language.languagesVariation() # OpenSubtitles has variations or some languages (eg: simplified vs traditional vs bilingual Chinese).
				for mode in [Language.TypePrimary, Language.TypeSecondary, Language.TypeTertiary]:
					lang = Language.settingsCustom('subtitle.language.' + mode, default = mode, code = Language.CodeSecondary) # CodeSecondary: chi and not zho
					if lang:
						langs.append(lang)

						langCode = Language.code(lang)
						for variation in variations:
							if langCode == variation[Language.Original]:
								langs.append(variation[Language.Code][Language.CodeSecondary])

				langs = Tools.listUnique(langs)

				# Always retrieve additional subtitles.
				# Many streams have an integrated subtitle that are empty (eg: only show "Encoded by XYZ" at the start).
				#try: subLang = Player().getSubtitles()
				#except: subLang = ''
				#if subLang == langs[0]: return True
				audio = player.audioLanguage()
				if not Settings.getBoolean('subtitle.language.known'):
					if audio in langs:
						player.subtitlesDisable()
						return False
				if not Settings.getBoolean('subtitle.language.unknown'):
					if audio is None:
						player.subtitlesDisable()
						return False

				subtitleIds = []
				subtitleNames = []
				subtitleLanguages = []
				subtitleLanguageCodes = []

				internal = player.subtitlesLanguages()
				internalHas = len(internal) > 0
				for i in range(len(internal)):
					subtitleIds.append(i + 1)
					subtitleNames.append(Format.fontItalic(Translation.string(33922)))
					subtitleLanguages.append(internal[i])
					subtitleLanguageCodes.append(internal[i])

				account = self.account()
				authenticated = account.authenticated()
				username = account.dataUsername()
				password = account.dataPassword()

				server = ServerProxy('http://api.opensubtitles.org/xml-rpc', verbose = 0)

				# Sometimes the connection fails with a HTTP 503 error. Retry a few times.
				success = False
				for i in range(3):
					# Anonymous login not working anymore.
					#token = server.LogIn('', '', 'en', 'XBMC_Subtitles_v1')
					try:
						result = server.LogIn(username if username else '', password if password else '', 'en', 'XBMC_Subtitles_v1')
						success = True
						break
					except:
						Logger.log('OpenSubtitle login failure. Retrying connection.')
						Time.sleep(2)
				if not success:
					if notifications: Dialog.notification(title = 35145, message = 35862, icon = Dialog.IconError)
					return False

				if self._error(data = result, account = authenticated, token = True):
					if internalHas:
						for lang in langs:
							try:
								player.subtitlesLoad(id = subtitleIds[subtitleLanguages.index(lang)])
								return True
							except: pass
					return False
				token = result['token']

				sublanguageid = ','.join(langs)
				imdb = re.sub('[^0-9]', '', imdb)

				if season is None or episode is None:
					# Sometimes the connection fails with a HTTP 503 error. Retry a few times.
					success = False
					for i in range(3):
						try:
							result = server.SearchSubtitles(token, [{'sublanguageid': sublanguageid, 'imdbid': imdb}])
							success = True
							break
						except:
							Logger.log('OpenSubtitle search failure. Retrying connection.')
							Time.sleep(2)
					if not success:
						if notifications: Dialog.notification(title = 35145, message = 35862, icon = Dialog.IconError)
						return False

					if self._error(data = result, account = authenticated, token = False): return False
					result = result['data']
					try: vidPath = player.getPlayingFile()
					except: vidPath = ''
					format = re.split('\.|\(|\)|\[|\]|\s|\-', vidPath)
					format = [i.lower() for i in format]
					format = [i for i in format if i in types]

				else:
					# Sometimes the connection fails with a HTTP 503 error. Retry a few times.
					success = False
					for i in range(3):
						try:
							result = server.SearchSubtitles(token, [{'sublanguageid': sublanguageid, 'imdbid': imdb, 'season': season, 'episode': episode}])
							success = True
							break
						except:
							Logger.log('OpenSubtitle search failure. Retrying connection.')
							Time.sleep(2)
					if not success:
						if notifications: Dialog.notification(title = 35145, message = 35862, icon = Dialog.IconError)
						return False

					if self._error(data = result, account = authenticated, token = False): return False
					result = result['data']
					format = ['hdtv']

				try: stream = source['stream']
				except: stream = None
				try: filename = stream.fileName().lower()
				except: filename = None
				try: release = stream.releaseType().lower()
				except: release = None
				try: uploader = stream.releaseGroup().lower()
				except: uploader = None
				try:
					quality = stream.videoQuality().lower()
					if 'hd' in quality: quality = quality.replace('hd', '')
					else: quality = None
				except: quality = None
				try:
					codec = stream.videoCodec().lower()
					if codec.startswith('h2'): codec = codec.replace('h', '')
					else: codec = None
				except: codec = None

				exact = -1
				result = [i for i in result if i['SubSumCD'] == '1']

				filtersExact = []
				filters = []

				if uploader and release and codec and quality: filtersExact.append([uploader, release, codec, quality])
				if uploader and release and codec: filtersExact.append([uploader, release, codec])
				if uploader and release and quality: filtersExact.append([uploader, release, quality])

				if uploader and release: filters.append([uploader, release])
				if uploader and codec: filters.append([uploader, codec])
				if uploader and quality: filters.append([uploader, quality])
				if release and codec: filters.append([release, codec])
				if release and quality: filters.append([release, quality])

				if uploader: filters.append([uploader])
				if release: filters.append([release])
				if codec: filters.append([codec])
				if quality: filters.append([quality])
				filters.append([]) # Only manual release type

				temporary = []
				for i in range(len(filtersExact)):
					for j in types:
						f = list(filtersExact[i])
						f.append(j)
						temporary.append(f)
				filtersExact = temporary

				temporary = []
				for i in range(len(filters)):
					for j in types:
						f = list(filters[i])
						f.append(j)
						temporary.append(f)
				filters = temporary

				for lang in langs:

					if filename:
						for i in result:
							try:
								if not i['IDSubtitleFile'] in subtitleIds and not i['MovieReleaseName'] in subtitleNames and i['SubLanguageID'] == lang:
									releasename = i['MovieReleaseName'].lower()

									# Full file name
									if filename == releasename:
										if exact < 0: exact = len(subtitleIds)
										subtitleIds.append(i['IDSubtitleFile'])
										subtitleNames.append(i['MovieReleaseName'])
										subtitleLanguages.append(i['SubLanguageID'])
										subtitleLanguageCodes.append(i['ISO639'])

									# Full file name without extension
									filenameAdpated = filename
									if len(filenameAdpated) > 4 and filenameAdpated[-4] == '.': filenameAdpated = filenameAdpated[:-4]
									releasenameAdpated = releasename
									if len(releasenameAdpated) > 4 and releasenameAdpated[-4] == '.': releasenameAdpated = releasenameAdpated[:-4]
									if filenameAdpated == releasenameAdpated:
										if exact < 0: exact = len(subtitleIds)
										subtitleIds.append(i['IDSubtitleFile'])
										subtitleNames.append(i['MovieReleaseName'])
										subtitleLanguages.append(i['SubLanguageID'])
										subtitleLanguageCodes.append(i['ISO639'])

									# File name with only alphanumeric characters.
									filenameAdpated = re.sub('[^0-9a-zA-Z]+', '', filenameAdpated)
									releasenameAdpated = re.sub('[^0-9a-zA-Z]+', '', releasenameAdpated)
									if filenameAdpated == releasenameAdpated:
										if exact < 0: exact = len(subtitleIds)
										subtitleIds.append(i['IDSubtitleFile'])
										subtitleNames.append(i['MovieReleaseName'])
										subtitleLanguages.append(i['SubLanguageID'])
										subtitleLanguageCodes.append(i['ISO639'])
							except: pass

					# Only check after all full file names were tested
					for filter in filtersExact:
						for i in result:
							try:
								if not i['IDSubtitleFile'] in subtitleIds and not i['MovieReleaseName'] in subtitleNames and i['SubLanguageID'] == lang:
									releasename = i['MovieReleaseName'].lower()
									if all(x in releasename for x in filter):
										if exact < 0: exact = len(subtitleIds)
										subtitleIds.append(i['IDSubtitleFile'])
										subtitleNames.append(i['MovieReleaseName'])
										subtitleLanguages.append(i['SubLanguageID'])
										subtitleLanguageCodes.append(i['ISO639'])
							except: pass

					for filter in filters:
						for i in result:
							try:
								if not i['IDSubtitleFile'] in subtitleIds and not i['MovieReleaseName'] in subtitleNames and i['SubLanguageID'] == lang:
									releasename = i['MovieReleaseName'].lower()
									if all(x in releasename for x in filter):
										subtitleIds.append(i['IDSubtitleFile'])
										subtitleNames.append(i['MovieReleaseName'])
										subtitleLanguages.append(i['SubLanguageID'])
										subtitleLanguageCodes.append(i['ISO639'])
							except: pass

				# Pick the best one.
				filter = []
				for lang in langs:
					filter += [i for i in result if i['SubLanguageID'] == lang and any(x in i['MovieReleaseName'].lower() for x in format)]
					if quality: filter += [i for i in result if i['SubLanguageID'] == lang and quality in i['MovieReleaseName'].lower()]
					filter += [i for i in result if i['SubLanguageID'] == lang]
				for f in filter:
					if not f['IDSubtitleFile'] in subtitleIds and not f['MovieReleaseName'] in subtitleNames:
						subtitleIds.append(f['IDSubtitleFile'])
						subtitleNames.append(f['MovieReleaseName'])
						subtitleLanguages.append(f['SubLanguageID'])
						subtitleLanguageCodes.append(f['ISO639'])

				if len(subtitleIds) == 0:
					if notifications: Dialog.notification(title = 35145, message = 35146, icon = Dialog.IconInformation)
					return False

				subtitleLabels = []
				for i in range(len(subtitleIds)):
					language = Language.name(subtitleLanguageCodes[i], variation = True)
					if language is None: language = Translation.string(35040)
					name = subtitleNames[i]
					if name is None: name = Translation.string(33387)
					subtitleLabels.append(Format.bold(language + ': ') + name)

				choiceSelection = None
				choicePrevious = None
				while True:
					choice = -1
					if selection == 0:
						player.pause()
						choice = Dialog.select(title = 32353, items = subtitleLabels)
						player.pause()
					elif selection == 1:
						choice = 0
					elif selection == 2:
						if len(subtitleIds) == 1:
							choice = 0
						else:
							player.pause()
							if choiceSelection is None: choiceSelection = Dialog.option(title = 32353, message = 35144, labelConfirm = 33110, labelDeny = 33800)
							if choiceSelection: choice = Dialog.select(title = 32353, items = subtitleLabels)
							else: choice = 0
							player.pause()
					elif selection == 3:
						if exact < 0:
							player.pause()
							choice = Dialog.select(title = 32353, items = subtitleLabels)
							player.pause()
						else: choice = exact

					if choice < 0:
						player.subtitlesDisable()
						return False

					# Internal subtitles
					if internalHas and Tools.isInteger(subtitleIds[choice]):
						player.subtitlesLoad(id = subtitleIds[choice])
					else:
						try: lang = xbmc.convertLanguage(subtitleLanguages[choice], xbmc.ISO_639_1)
						except: lang = subtitleLanguages[choice]

						content = [subtitleIds[choice],]

						# Sometimes the connection fails with a HTTP 503 error. Retry a few times.
						success = False
						for i in range(3):
							try:
								content = server.DownloadSubtitles(token, content)
								success = True
								break
							except:
								Logger.log('OpenSubtitle download failure. Retrying connection.')
								Time.sleep(2)
						if not success:
							if notifications: Dialog.notification(title = 35145, message = 35862, icon = Dialog.IconError)
							return False

						content = Converter.base64From(content['data'][0]['data'])
						content = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(content)

						# Certain languages (eg: Chinese, Hebrew, etc) have to be decoded so that they can be correctly encoded with UTF-8.
						# The encoding is not known, and the data returned by OpenSubtitles does not seem to indicate the encoding.
						# Detect the encoding automatically (best guess).
						# If selected for a second time, just use them as is without decoding.
						if not choice == choicePrevious:
							encoding = Converter.encodingDetect(content)
							if encoding:
								try:
									content = content.decode(encoding)
								except:
									# Sometimes decoding fails a few Simplified Chinese subtitles). Ask user to select different ones.
									Logger.error()
									if notifications: Dialog.notification(title = 35860, message = 35861, icon = Dialog.IconWarning)
									subtitleLabels[choice] = Format.font(subtitleLabels[choice], italic = True, color = Format.colorPoor())
									choicePrevious = choice
									continue

						content = Converter.unicode(content)

						path = System.temporary(directory = 'subtitles', file = '%s.%s.srt' % (subtitleNames[choice], lang)) # Keep the file name with language between dots, because Kodi uses this format to detect the language if the SRT.
						File.writeNow(path, content)
						Time.sleep(0.5)
						player.subtitlesLoad(path = path)
						break

				if notifications: Dialog.notification(title = 35140, message = subtitleNames[choice], icon = Dialog.IconSuccess)
				return True
		except:
			Logger.error()
			return False

	@classmethod
	def _error(self, data, account = False, token = False):
		error = None
		status = data['status'].lower() if 'status' in data else None

		# If invalid credentials are provided, a token is returned which is not usable. Always check the status.
		# Always try to login first, even without an account. In case anonymous logins are enabled again.
		if (token and not 'token' in data) or (status and Subtitles.ErrorUnauthorized in status):
			error = 35685 if account else 35684

		if error:
			from lib.modules.interface import Dialog
			Dialog.notification(title = 35145, message = error, icon = Dialog.IconError)
			return True
		else:
			return False
