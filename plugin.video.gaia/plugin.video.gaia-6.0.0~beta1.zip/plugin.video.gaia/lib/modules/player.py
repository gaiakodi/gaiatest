# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import sys,time,hashlib
import xbmc,xbmcvfs

try: from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database

from lib import debrid
from lib.modules import playcount
from lib.modules import trakt
from lib.modules.clean import Title
from lib.modules import tools
from lib.modules import interface
from lib.modules import window
from lib.modules import handler
from lib.modules import subtitles
from lib.modules import library
from lib.modules import orionoid
from lib.modules.stream import Stream
from lib.modules.database import Database
from lib.modules.theme import Theme
from lib.modules.thread import Pool, Lock

# If the player automatically closes/crashes because the EOF was reached while still downloading, the player instance is never deleted.
# Now the player keeps a constant lock on the played file and the file cannot be deleted (manually, or by the downloader). The lock is only release when Kodi exits.
# Use a thread and forcefully delete the instance. Although this is still no garantuee that Kodi will release the lock on the file, but it seems to work most of the time.
def playerDelete(instance):
	time.sleep(1)
	# Do not just use "del instance", since this will only call __del__() if the reference count drops to 0. Kodi still has a reference to the instance.
	try: instance.__del__()
	except: pass
	try: del instance
	except: pass

class player(xbmc.Player):

	# Statuses
	StatusIdle = 0
	StatusPlaying = 1
	StatusPaused = 2
	StatusStopped = 3
	StatusEnded = 4

	# Download
	DownloadThresholdStart = 0.01 # If the difference between the download and the playback progress is lower than this percentage, buffering will start.
	DownloadThresholdStop = DownloadThresholdStart * 2 # If the difference between the download and the playback progress is higher than this percentage, buffering will stop.
	DownloadMinimum = 1048576 # 1 MB. The minimum number of bytes that must be available to avoid buffering. If the value is too small, the player with automatically stop/crash due to insufficient data available.
	DownloadFuture = 102400 # 100 KB. The number of bytes to read and update the progress with. Small values increase disk access, large values causes slow/jumpy progress.
	DownloadChunk = 8 # 8 B. The number of null bytes that are considered the end of file.
	DownloadNull = '\x00' * DownloadChunk

	BingeTime = 600 # Start binge scrape if 10 minutes are left on the current playback.

	def __init__ (self, type = None, kids = None):
		from lib.modules import core
		xbmc.Player.__init__(self)
		self.type = type
		self.kids = kids
		self.status = self.StatusIdle
		self.core = core.Core(type = type, kids = kids)

	def __del__(self):
		self._downloadClear(delete = False)
		self.core.progressPlaybackClose()
		try: xbmc.Player.__del__(self)
		except: pass

	def run(self, type, title, year, season, episode, imdb, tmdb, tvdb, meta, downloadType = None, downloadId = None, source = None, binge = None):
		try:
			tools.Time.sleep(0.2)

			self.navigationStreamsSpecial = tools.Settings.getInteger('interface.stream.interface') == 0

			self.typeMedia = type
			self.typeMovie = tools.Media.typeMovie(self.typeMedia)
			self.typeTelevision = tools.Media.typeTelevision(self.typeMedia)

			self.timeTotal = 0
			self.timeCurrent = 0

			self.idImdb = imdb
			self.idTmdb = tmdb
			self.idTvdb = tvdb

			self.kodi = None
			self.metadata = meta
			self.title = title
			self.year = int(year) if year else year
			try: self.name = tools.Media.titleUniversal(metadata = meta)
			except: self.name = self.title

			try:
				self.season = int(season) if self.typeTelevision else None
				self.seasonString = '%01d' % self.season if self.typeTelevision else None
			except:
				self.season = None
				self.seasonString = None
			try:
				self.episode = int(episode) if self.typeTelevision else None
				self.episodeString = '%01d' % self.episode if self.typeTelevision else None
			except:
				self.episode = None
				self.episodeString = None

			self.binge = episode and binge
			self.bingeDialogNone = tools.Binge.dialogNone()
			self.bingeDialogFull = tools.Binge.dialogFull()
			self.bingeDialogOverlay = tools.Binge.dialogOverlay()
			self.bingeDialogUpNext = tools.Binge.dialogUpNext()
			self.bingeSuppress = tools.Binge.suppress()
			self.bingeDelay = None
			self.bingeContinue = False
			self.bingePlay = False
			self.bingeFinishedScrape = False
			self.bingeFinishedCheck = False
			self.bingeFinishedShow = False
			self.bingeFinishedPlay = False
			self.bingeItems = None
			self.bingeMetadata = None

			self.progressLock = Lock()
			self.progressBusy = False
			self.progressLast = 0
			self.progress = None
			if tools.Settings.getBoolean('playback.track.enabled') and tools.Settings.getInteger('playback.track.resume') > 0:
				thread = Pool.thread(target = self._progress)
				thread.start()
			else:
				self.progress = 0

			self.source = source
			self.source['stream'] = Stream.load(data = self.source['stream'])

			self.url = self.source['stream'].linkResolved()
			self.timeTotal = 0
			self.timeCurrent = 0
			self.timeProgress = 0
			self.sizeTotal = 0
			self.sizeCurrent = 0
			self.sizeProgress = 0
			self.dialog = None

			poster, thumb, fanart, banner, meta = self.metadataExtract(meta)
			self.item = interface.Directory().item(path = self.url)
			self.item.setArt({'icon' : thumb, 'thumb' : thumb, 'poster' : poster, 'fanart' : fanart, 'banner' : banner, 'tvshow.poster' : poster, 'season.poster' : poster})
			self.item.setInfo(type = 'Video', infoLabels = tools.Media.metadataClean(meta))

			self.downloadCheck = False
			if downloadType and downloadId:
				from lib.modules import downloader
				self.download = downloader.Downloader(type = downloadType, id = downloadId)
				self.bufferCounter = 0
				self.bufferShow = True

				# Already check here, so that the player waits when the download is still queued/initialized.
				if not self._downloadCheck():
					return
			else:
				self.download = None
				self.bufferCounter = None
				self.bufferShow = None

			self.progressMessage = ''
			self.progressRemaining = 0
			self.progressTotal = 1
			self.progressDelay = 0
			if tools.Settings.getBoolean('playback.retry.enabled'):
				self.progressTotal += tools.Settings.getInteger('playback.retry.limit')
				self.progressDelay = tools.Settings.getInteger('playback.retry.delay')
			self.progressRemaining = self.progressTotal

			success = False
			xbmc.executebuiltin('Dialog.Close(notification,true)') # Hide the caching/download notification if still showing.
			while self.progressRemaining > 0:
				self._errorLog()
				self.progressRemaining -= 1
				self.error = False

				# When retrying, Kodi player might still try to play from the previous time (eg: stuck at connection timmeout).
				# Manually stop to ensure everything is cleared.
				self.stop()
				tools.Time.sleep(0.1)

				self.play(self.url, self.item)
				interface.Loader.hide()
				success = self.keepPlaybackAlive()
				if success or tools.System.aborted():
					self._closeFailure()
					break
				if self.progressRemaining > 0:
					if interface.Core.background() and not self.core.progressPlaybackEnabled():
						self.progressMessage = interface.Translation.string(35303)
					else:
						if self.progressRemaining == 1: self.progressMessage = interface.Translation.string(35294)
						elif self.progressRemaining > 1: self.progressMessage = interface.Translation.string(35293) % (self.progressRemaining + 1)

			if not success and self.progressRemaining == 0:
				self._closeFailure()
				interface.Dialog.notification(title = 33448, message = 33450, icon = interface.Dialog.IconError)

			# This should solve the issue of Gaia videos being played twice when launched from OpenMeta or widgets when using the directory structure.
			# Setting it to True will cause the video to play again after finishing playback, when launched from the local library.
			#tools.System.pluginResolvedSet(success = True, item = item)
			tools.System.pluginResolvedSet(success = False, item = self.item)

			ids = {}
			if imdb: ids['imdb'] = imdb
			if tmdb: ids['tmdb'] = tmdb
			if tvdb: ids['tvdb'] = tvdb
			tools.System.windowPropertySet('script.trakt.ids', tools.Converter.jsonTo(ids))
			tools.System.windowPropertyClear('script.trakt.ids')
			return success
		except:
			tools.Logger.error()
			return False

	def metadataExtract(self, meta):
		try:
			poster = meta['poster'] if 'poster' in meta else meta['poster2'] if 'poster2' in meta else meta['poster3'] if 'poster3' in meta else None
			thumb = meta['thumb'] if 'thumb' in meta else meta['thumb2'] if 'thumb2' in meta else meta['thumb3'] if 'thumb3' in meta else poster
			fanart = meta['fanart'] if 'fanart' in meta else meta['fanart2'] if 'fanart2' in meta else meta['fanart3'] if 'fanart3' in meta else None
			banner = meta['banner'] if 'banner' in meta else None

			if not poster or poster == '0': poster = Theme.poster()
			if not thumb or thumb == '0': thumb = Theme.thumbnail()
			if not fanart or fanart == '0': fanart = Theme.fanart()
			if not banner or banner == '0': banner = Theme.banner()

			if not 'mediatype' in meta: meta.update({'mediatype': 'episode' if 'episode' in meta and meta['episode'] else 'movie'})

			return (poster, thumb, fanart, banner, meta)
		except: pass

		try:
			meta = self.metadataRetrieve(meta)

			poster = None
			try: poster = meta['show']['art']['poster']
			except:
				try: poster = meta['show']['thumbnail']
				except:
					try: poster = meta['art']['poster']
					except:
						try: poster = meta['thumbnail']
						except: pass

			thumb = None
			try: thumb = meta['thumbnail']
			except: thumb = poster

			fanart = None
			try: fanart = meta['art']['fanart']
			except:
				try: fanart = meta['fanart']
				except: pass

			banner = None
			try: banner = meta['art']['banner']
			except: banner = fanart

			return (poster, thumb, fanart, banner, meta)
		except: pass

		return (None, None, None, None, {'title': self.name})

	def metadataRetrieve(self, meta):
		result = None
		filter = {
			'or': [
				{'field': 'year', 'operator': 'is', 'value': str(self.year)},
				{'field': 'year', 'operator': 'is', 'value': str(self.year - 1)},
				{'field': 'year', 'operator': 'is', 'value': str(self.year + 1)}
			]
		}

		if self.typeMovie:
			try:
				metas = tools.System.executeJson(method = 'VideoLibrary.GetMovies',
					parameters = {
						'filter' : filter,
						'properties' : ['title', 'originaltitle', 'genre', 'year', 'rating', 'director', 'trailer', 'tagline', 'tag', 'plot', 'plotoutline', 'playcount', 'writer', 'studio', 'mpaa', 'country', 'runtime', 'votes', 'ratings', 'art', 'fanart', 'thumbnail', 'file', 'userrating', 'premiered', 'uniqueid']
					},
				)
				if 'result' in metas and 'movies' in metas['result']:
					result = self.metadataFilter(metas['result']['movies'])
					if result and not 'mediatype' in result: result.update({'mediatype' : 'movie'})
			except:
				tools.Logger.error()

		elif self.typeTelevision:
			try:
				metas = tools.System.executeJson(method = 'VideoLibrary.GetTVShows',
					parameters = {
						'filter' : filter,
						'properties' : ['title', 'originaltitle', 'year', 'uniqueid', 'file', 'art', 'thumbnail', 'fanart']
					},
				)
				if 'result' in metas and 'tvshows' in metas['result']:
					resultShow = self.metadataFilter(metas['result']['tvshows'])
					if resultShow:
						metas = tools.System.executeJson(method = 'VideoLibrary.GetEpisodes',
							parameters = {
								'tvshowid' : resultShow['tvshowid'],
								'filter' : {
									'and': [
										{'field': 'season', 'operator': 'is', 'value': self.seasonString},
										{'field': 'episode', 'operator': 'is', 'value': self.episodeString}
									]
								},
								'properties' : ['title', 'originaltitle', 'season', 'episode', 'showtitle', 'firstaired', 'rating', 'director', 'plot', 'playcount', 'writer', 'runtime', 'votes', 'ratings', 'art', 'fanart', 'thumbnail', 'file', 'userrating', 'uniqueid']
							},
						)
						if 'result' in metas and 'episodes' in metas['result']:
							result = metas['result']['episodes'][0]
							if result:
								if not 'mediatype' in result: result.update({'mediatype' : 'episode'})
								result['show'] = resultShow
			except:
				tools.Logger.error()

		if not 'plugin' in tools.System.infoLabel('Container.PluginName'): self.kodi = result
		return result

	def metadataFilter(self, metas):
		if self.idImdb:
			for meta in metas:
				try:
					if self.idImdb == meta['uniqueid']['imdb']: return meta
				except: pass

		if self.idTmdb:
			for meta in metas:
				try:
					if self.idTmdb == meta['uniqueid']['tmdb']: return meta
				except: pass

		if self.idTvdb:
			for meta in metas:
				try:
					if self.idTvdb == meta['uniqueid']['tvdb']: return meta
				except: pass

		if self.title and self.year:
			title = Title.clean(self.title)
			year = int(self.year)
			for meta in metas:
				try:
					if year == int(meta['year']) and (title == Title.clean(meta['title']) or title == Title.clean(meta['originaltitle'])): return meta
				except: pass

		return None

	def _showStreams(self):
		if (not self.binge or (self.binge and not self.bingeFinishedCheck)):
			if self.navigationStreamsSpecial and not tools.Settings.getBoolean('automatic.enabled'):
				reload = tools.Settings.getInteger('interface.stream.interface.reload')
				if reload == 1 or (reload == 2 and self.status == self.StatusPaused):
					interface.Loader.show() # When the streams are filtered/sorted again.
					from lib.modules import core
					self.core.showStreams()

	def _debridClear(self):
		debrid.Debrid.deletePlayback(link = self.url, source = self.source)

	def _downloadStop(self):
		self._downloadClear(delete = False)
		if not self.download == None:
			from lib.modules import downloader
			self.download.stop(cacheOnly = True)

	def _downloadClear(self, delete = True):
		try: self.dialog.close()
		except: pass

		if delete:
			thread = Pool.thread(target = playerDelete, args = (self,))
			thread.start()

	def _downloadUpdateSize(self):
		try:
			from lib.modules import downloader

			# Try using the progress from the downloader, since the below code mostly returns 0.
			# Through Python, you can get the total file size (including the empty padded space).

			file = xbmcvfs.File(self.url) # The file must be opened each time this function is called, otherwise it does not refrehs with the new content/size.
			current = self.download.sizeCompleted()
			if current > 0:
				self.sizeCurrent = current
			else:
				file.seek(self.sizeCurrent, 0)
				data = file.read(self.DownloadChunk)
				try: length = len(data)
				except: length = 0
				while not data == self.DownloadNull and not length == 0:
					self.sizeCurrent += self.DownloadFuture
					file.seek(self.sizeCurrent, 0)
					data = file.read(self.DownloadChunk)
					try: length = len(data)
					except: length = 0
			self.sizeTotal = max(self.sizeTotal, file.size())
			file.close()
			if self.sizeTotal > 0: self.sizeProgress = self.sizeCurrent / float(self.sizeTotal)
		except:
			pass
		return self.sizeProgress

	def _downloadUpdateTime(self):
		try: self.timeCurrent = max(self.timeCurrent, self.getTime())
		except: pass
		try: self.timeTotal = max(self.timeTotal, self.getTotalTime())
		except: pass

		if self.timeTotal > 0:
			self.timeProgress = self.timeCurrent / float(self.timeTotal)
		return self.timeProgress

	def _downloadProgressDifference(self):
		progressSize = self._downloadUpdateSize()
		progressTime = self._downloadUpdateTime()
		return max(0, progressSize - progressTime), progressSize

	def _downloadProgress(self):
		progress = ''
		if not self.download == None:
			from lib.modules import downloader
			progress = interface.Format.fontBold(interface.Translation.string(32403) + ': ')
			self.download.refresh()
			progress += self.download.progress()
			progress += ' - ' + self.download.speed() + interface.Format.newline()
		return progress

	def _downloadCheck(self):
		if self.download == None:
			return False

		# Ensures that only one process can access this function at a time. Otherwise this function is executed multiple times at the same time.
		if self.downloadCheck:
			return False

		# If the user constantly cancels the buffering dialog, the dialog will not be shown for the rest of the playback.
		if not self.bufferShow:
			return False

		try:
			self.downloadCheck = True

			# Close all old and other dialogs.
			# Leave this for now. Seems to actually close the cache dialog below.
			#xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
			#xbmc.executebuiltin('Dialog.Close(extendedprogressdialog,true)')
			#time.sleep(0.5) # Wait for the dialogs to close.

			# NB: The progress dialog pops up when the download is at 100%. Chack for the download progress (progressSize < 1).
			progressDifference, progressSize = self._downloadProgressDifference()
			if progressSize < 1 and progressDifference < self.DownloadThresholdStart or self.sizeCurrent < self.DownloadMinimum:
				paused = False
				try:
					if self.isPlaying():
						self.pause()
						paused = True
				except: pass

				title = interface.Translation.string(33368)
				message = interface.Translation.string(33369)
				interface.Core.create(type = interface.Core.TypeDownload, title = title, message = self._downloadProgress() + message, background = False)

				progressMinimum = progressDifference
				progressRange = self.DownloadThresholdStop - progressMinimum
				while progressSize < 1 and progressDifference < self.DownloadThresholdStop or self.sizeCurrent < self.DownloadMinimum:
					progress = max(1, int(((progressDifference - progressMinimum) / float(progressRange)) * 99))
					interface.Core.update(progress = progress, message = self._downloadProgress() + message)
					if interface.Core.canceled(): break
					time.sleep(1)
					if interface.Core.canceled(): break
					progressDifference, progressSize = self._downloadProgressDifference()

				canceled = interface.Core.canceled() # Will be reset after the dialog is closed below.
				interface.Core.update(progress = 100, message = message)
				interface.Core.close()
				time.sleep(0.2)

				if canceled:
					if self.isPlayback():
						self.bufferCounter += 1
						if self.bufferCounter % 3 == 0:
							if interface.Dialog.option(title = 33368, message = 33744):
								self.bufferShow = False
					else:
						self._downloadStop()
						return False

				try:
					if paused:
						self.pause() # Unpause
				except: pass

			self.downloadCheck = False
			return True
		except:
			tools.Logger.error()
			self.downloadCheck = False
			return False

	def _bingeDelay(self):
		if self.bingeDelay is None:
			self.bingeDelay = tools.Binge.delay()
			if self.bingeDelay == 0:
				try: self.bingeDelay = self.getTotalTime()
				except:
					try: self.bingeDelay = int(self.metadata['duration'])
					except: pass
				self.bingeDelay = 30 if self.bingeDelay == 0 else int(self.bingeDelay / 60.0)
				if tools.Binge.dialogFull(): self.bingeDelay = int(self.bingeDelay / 3.0)
				self.bingeDelay = min(90, self.bingeDelay)
		return self.bingeDelay

	def _bingeCheck(self):
		try:
			if self.binge:
				remaining = self.timeTotal - self.timeCurrent
				if not self.bingeFinishedScrape and remaining < player.BingeTime:
					self.bingeFinishedScrape = True
					thread = Pool.thread(target = self._bingeScrape)
					thread.start()
				if not self.bingeFinishedCheck:
					if self.bingeDialogUpNext:
						if not self.bingeMetadata is None:
							# NB: AddonSignals cannot be called from a thread, otherwise the callback never fires.
							self.bingeFinishedCheck = True
							self._bingeUpNext()
					elif self.bingeDialogOverlay and remaining <= self._bingeDelay():
						self.bingeFinishedCheck = True
						self._bingeShow()
		except:
			tools.Logger.error()

	def _bingeScrape(self):
		try:
			from lib.modules import core
			from lib.indexers import episodes
			self.bingeMetadata = episodes.episodes().next(tvshowtitle = self.metadata['tvshowtitle'], year = self.metadata['year'], imdb = self.metadata['imdb'], tvdb = self.metadata['tvdb'], season = self.metadata['season'], episode = self.metadata['episode'])
			if self.bingeMetadata: self.bingeItems = core.Core(type = self.type, kids = self.kids, silent = True).scrape(binge = tools.Binge.ModeBackground, title = self.bingeMetadata['title'], year = self.bingeMetadata['year'], imdb = self.bingeMetadata['imdb'], tvdb = self.bingeMetadata['tvdb'], season = self.bingeMetadata['season'], episode = self.bingeMetadata['episode'], count = self.bingeMetadata['count'], tvshowtitle = self.bingeMetadata['tvshowtitle'], metadata = self.bingeMetadata)
			elif not self.bingeSuppress: interface.Dialog.notification(title = 35580, message = 35587, icon = interface.Dialog.IconInformation)
		except:
			tools.Logger.error()

	def _bingeUpNext(self):
		episodeCurrent = {
			'episodeid' : tools.Media.titleUniversal(metadata = self.metadata),
			'tvshowid' : self.metadata['imdb'] if 'imdb' in self.metadata else '',
			'title' : self.metadata['title'] if 'title' in self.metadata else '',
			'showtitle' : self.metadata['tvshowtitle'] if 'tvshowtitle' in self.metadata else '',
			'season' : int(self.metadata['season']) if 'season' in self.metadata else '',
			'episode' : int(self.metadata['episode']) if 'episode' in self.metadata else '',
			'playcount' : self.metadata['playcount'] if 'playcount' in self.metadata else 0,
			'plot' : self.metadata['plot'] if ('plot' in self.metadata and not self.metadata['plot'] == '0') else '',
			'rating' : float(self.metadata['rating']) if ('rating' in self.metadata and not self.metadata['rating'] == '0') else 0,
			'firstaired' : self.metadata['premiered'] if ('premiered' in self.metadata and not self.metadata['premiered'] == '0') else '',
			'art' : {
				'tvshow.poster' : self.metadata['poster'] if ('poster' in self.metadata and not self.metadata['poster'] == '0') else '',
				'thumb' : self.metadata['thumb'] if ('thumb' in self.metadata and not self.metadata['thumb'] == '0') else '',
				'tvshow.fanart' : self.metadata['fanart'] if ('fanart' in self.metadata and not self.metadata['fanart'] == '0') else '',
				'tvshow.landscape' : self.metadata['landscape'] if ('landscape' in self.metadata and not self.metadata['landscape'] == '0') else self.metadata['banner'] if ('banner' in self.metadata and not self.metadata['banner'] == '0') else '',
				'tvshow.clearart' : self.metadata['clearart'] if ('clearart' in self.metadata and not self.metadata['clearart'] == '0') else '',
				'tvshow.clearlogo' : self.metadata['clearlogo'] if ('clearlogo' in self.metadata and not self.metadata['clearlogo'] == '0') else '',
			},
		}

		episodeNext = {
			'episodeid' : tools.Media.titleUniversal(metadata = self.bingeMetadata),
			'tvshowid' : self.bingeMetadata['imdb'] if 'imdb' in self.bingeMetadata else '',
			'title' : self.bingeMetadata['title'] if 'title' in self.bingeMetadata else '',
			'showtitle' : self.bingeMetadata['tvshowtitle'] if 'tvshowtitle' in self.bingeMetadata else '',
			'season' : int(self.bingeMetadata['season']) if 'season' in self.bingeMetadata else '',
			'episode' : int(self.bingeMetadata['episode']) if 'episode' in self.bingeMetadata else '',
			'playcount' : self.bingeMetadata['playcount'] if 'playcount' in self.bingeMetadata else 0,
			'plot' : self.bingeMetadata['plot'] if ('plot' in self.bingeMetadata and not self.bingeMetadata['plot'] == '0') else '',
			'rating' : float(self.bingeMetadata['rating']) if ('rating' in self.bingeMetadata and not self.bingeMetadata['rating'] == '0') else 0,
			'firstaired' : self.bingeMetadata['premiered'] if ('premiered' in self.bingeMetadata and not self.bingeMetadata['premiered'] == '0') else '',
			'art' : {
				'tvshow.poster' : self.bingeMetadata['poster'] if ('poster' in self.bingeMetadata and not self.bingeMetadata['poster'] == '0') else '',
				'thumb' : self.bingeMetadata['thumb'] if ('thumb' in self.bingeMetadata and not self.bingeMetadata['thumb'] == '0') else '',
				'tvshow.fanart' : self.bingeMetadata['fanart'] if ('fanart' in self.bingeMetadata and not self.bingeMetadata['fanart'] == '0') else '',
				'tvshow.landscape' : self.bingeMetadata['landscape'] if ('landscape' in self.bingeMetadata and not self.bingeMetadata['landscape'] == '0') else self.bingeMetadata['banner'] if ('banner' in self.bingeMetadata and not self.bingeMetadata['banner'] == '0') else '',
				'tvshow.clearart' : self.bingeMetadata['clearart'] if ('clearart' in self.bingeMetadata and not self.bingeMetadata['clearart'] == '0') else '',
				'tvshow.clearlogo' : self.bingeMetadata['clearlogo'] if ('clearlogo' in self.bingeMetadata and not self.bingeMetadata['clearlogo'] == '0') else '',
			},
		}

		infoNext = {
			'current_episode': episodeCurrent,
			'next_episode': episodeNext,
			'play_info': {},
		}

		try:
			import AddonSignals
			AddonSignals.sendSignal('upnext_data', infoNext, source_id = tools.System.id())
			AddonSignals.registerSlot('upnextprovider', tools.System.id() + '_play_action', self._bingeShowUpNext)
		except: tools.Logger.error()

	def _bingeShowUpNext(self, data):
		self.bingeContinue = True
		self._bingeShow()

	def _bingeShow(self):
		try:
			if self.binge and not self.bingeFinishedShow and self.bingeItems:
				self.bingeFinishedShow = True
				if not self.bingeDialogUpNext:
					self.bingeContinue = True
					if self.bingeSuppress:
						thread = Pool.thread(target = self._bingeSuppress)
						thread.start()
					if not self.bingeDialogNone:
						try: background = self.bingeMetadata['fanart'] if 'fanart' in self.bingeMetadata else self.bingeMetadata['fanart2'] if 'fanart2' in self.bingeMetadata else self.bingeMetadata['fanart3'] if 'fanart3' in self.bingeMetadata else None
						except: background = None
						try: poster = self.bingeMetadata['poster'] if 'poster' in self.bingeMetadata else self.bingeMetadata['poster2'] if 'poster2' in self.bingeMetadata else self.bingeMetadata['poster3'] if 'poster3' in self.bingeMetadata else None
						except: poster = None
						if self.bingeDialogFull:
							delay = self._bingeDelay()
							self.bingeContinue = window.WindowBingeFull.show(title = self.bingeMetadata['tvshowtitle'], season = self.bingeMetadata['season'], episode = self.bingeMetadata['episode'], duration = self.bingeMetadata['duration'], background = background, poster = poster, delay = delay)
						elif self.bingeDialogOverlay:
							try: delay = self.getTotalTime() - self.getTime()
							except: delay = 0
							self.bingeContinue = window.WindowBingeOverlay.show(title = self.bingeMetadata['tvshowtitle'], season = self.bingeMetadata['season'], episode = self.bingeMetadata['episode'], duration = self.bingeMetadata['duration'], background = background, poster = poster, delay = delay)
				if self.bingeContinue:
					if self.status == self.StatusStopped:
						self._bingePlay()
					elif tools.Binge.actionContinue() == tools.Binge.ActionInterrupt:
						self.stop()
						self._bingePlay()
					else:
						self.bingePlay = True
				elif tools.Binge.actionCancel() == tools.Binge.ActionInterrupt:
					self.stop()
		except:
			tools.Logger.error()

	def _bingePlay(self):
		try:
			if self.binge and not self.bingeFinishedPlay and self.bingeItems:
				self.bingeFinishedPlay = True
				interface.Loader.show()
				tools.System.executePlugin(action = 'scrape', parameters = {
					'type' : self.type,
					'kids' : self.kids,
					'binge' : tools.Binge.ModeContinue,
					'title' : self.bingeMetadata['title'],
					'tvshowtitle' : self.bingeMetadata['tvshowtitle'],
					'year' : self.bingeMetadata['year'],
					'imdb' : self.bingeMetadata['imdb'],
					'tvdb' : self.bingeMetadata['tvdb'],
					'season' : self.bingeMetadata['season'],
					'episode' : self.bingeMetadata['episode'],
					'premiered' : self.bingeMetadata['premiered'],
					'metadata' : tools.Converter.jsonTo(self.bingeMetadata),
					'items' : tools.Converter.jsonTo(self.bingeItems),
				})
		except:
			tools.Logger.error()

	def _bingeSuppress(self):
		count = 0
		while count < 100:
			id = window.Window.current()
			if id > window.Window.IdMaximum and not window.Window.currentGaia():
				interface.Dialog.close(id)
				break
			count += 1
			tools.Time.sleep(0.1)

	def _closeFailure(self):
		# Close Kodi's "Playback Failed" dialog.

		# Do not check if the dialog is open first, since other dialogs (eg: Gaia stream connection dialog) might pop up on top, and then Kodi shows that dialog ID as being opened.
		#if window.Window.currentDialog(id = window.Window.IdWindowOk):
		#	window.Window.close(id = window.Window.IdWindowOk)

		window.Window.close(id = window.Window.IdWindowOk)

	def _errorLog(self):
		try:
			if self._errorSeparator: tools.Logger.log(self._errorSeparator)
		except: pass

		code = tools.Hash.random()
		start = '[PLAYBACK %s /]' % code
		end = '[/ PLAYBACK %s]' % code

		self._errorLast = None
		self._errorSeparator = end
		self._errorExpression = '%s(.*?)(?:$|%s)' % (start.replace('[', '\[').replace(']', '\]').replace(' ', '\s').replace('/', '\/'), end.replace('[', '\[').replace(']', '\]').replace(' ', '\s').replace('/', '\/'))

		tools.Logger.log(start)

	def _errorCheck(self, force = False):
		# Kodi's internal player CURL can fail (eg: HTTP timeouts, HTTP errors, Cloudflare, etc).
		# These errors are not detectable in Python. None of the player functions, or even onPlayBackError(), give any indication to these kinds of errors.
		# The only way to detect them seems to be to read/process the log file.
		#	ERROR <general>: OpenDemuxStream - Error creating demuxer
		#	INFO <general>: CVideoPlayer::OnExit()
		#	INFO <general>: CVideoPlayer::CloseFile()
		#	INFO <general>: VideoPlayer: waiting for threads to exit
		#	INFO <general>: VideoPlayer: finished waiting
		# Or:
		#	VideoPlayer::OpenFile: https://somelink.com
		#	ERROR <general>: CCurlFile::Stat - Failed: Timeout was reached(28) for https://somelink.com
		#	INFO <general>: Creating InputStream
		#	ERROR <general>: CCurlFile::FillBuffer - Failed: Timeout was reached(28)
		#	ERROR <general>: CCurlFile::Open failed with code 0 for https://somelink.com:
		#	ERROR <general>: CCurlFile::Exists - Failed: Timeout was reached(28) for https://somelink.com/VIDEO_TS.IFO
		#	ERROR <general>: CCurlFile::Exists - Failed: Timeout was reached(28) for https://somelink.com/VIDEO_TS/VIDEO_TS.IFO
		#	ERROR <general>: CCurlFile::FillBuffer - Failed: Timeout was reached(28)
		#	ERROR <general>: CCurlFile::Open failed with code 0 for https://somelink.com:
		#	ERROR <general>: CFileCache::Open - <https://somelink.com> failed to open
		#	ERROR <general>: CVideoPlayer::OpenInputStream - error opening [https://somelink.com]
		#	INFO <general>: CVideoPlayer::OnExit()
		#	WARNING <general>: CDVDMessageQueue(player)::Put MSGQ_NOT_INITIALIZED
		#	INFO <general>: CVideoPlayer::CloseFile()
		#	INFO <general>: VideoPlayer: waiting for threads to exit
		#	INFO <general>: VideoPlayer: finished waiting

		try:
			current = tools.Time.timestamp() # Only check every few seconds, otherwise there is too much disk I/O.
			if force or not self._errorLast or (current - self._errorLast) >= 5:
				self._errorLast = current

				data = tools.Logger.data()
				if data:
					data = tools.Regex.extract(data = data, expression = self._errorExpression, flags = tools.Regex.FlagAllLines)
					if data: return tools.Regex.match(data = data, expression = 'VideoPlayer::OnExit')

		except: tools.Logger.error()
		return False

	def isVisible(self):
		return window.Window.visible(window.Window.IdWindowPlayer) or window.Window.visible(window.Window.IdWindowPlayerFull)

	def isPlayback(self):
		# Kodi often starts playback where isPlaying() is true and isPlayingVideo() is false, since the video loading is still in progress, whereas the play is already started.
		try: return self.isPlaying() and self.isPlayingVideo() and self.getTime() >= 0
		except: False

	def keepPlaybackWait(self, title, message, status, substatus1, substatus2, timeout):
		from lib.modules import core
		wasPlaying = False
		delay = 0.3
		iterations = int(timeout / delay)
		for i in range(0, iterations):
			self._closeFailure()

			if self.isPlaying(): wasPlaying = True
			elif wasPlaying: break # Was playing, but not anymore. This is when the video playback fails. Kodi for some reason does not trigger the onPlayBackError signal.

			if self.isPlayback() or self.error: break

			if self._errorCheck():
				# gaiaremove - Kodi sometimes does not fire the onPlayBackStopped/onPlayBackEnded events, causing the cleanup not to execute (eg: delete debrid file).
				# Probably a Kodi bug. Seems to happen if the playback is manually stopped a few seconds after playback started.
				if not self.status == self.StatusStopped and not self.status == self.StatusEnded: self.onPlayBackStopped()

				break

			if self.download is None:
				if self.core.progressPlaybackCanceled(): break
				interface.Loader.hide() # Busy icons pops up again in Kodi 18.
				progress = 50 + int((i / float(iterations)) * 50) # Only half the progress, since the other half is from sources __init__.py.
				self.core.progressPlaybackUpdate(progress = progress, title = title, message = message, status = status, substatus1 = substatus1, substatus2 = substatus2, total = self.progressTotal, remaining = self.progressRemaining, force = True)
			else:
				self._downloadCheck()
			tools.Time.sleep(delay)

	def keepPlaybackAlive(self):
		from lib.modules import core
		self._downloadCheck()

		property = '%s.player.overlay' % tools.System.id()
		tools.System.windowPropertyClear(property)

		if self.typeMovie:
			overlay = playcount.getMovieOverlay(playcount.getMovieIndicators(), self.idImdb)
		elif self.typeTelevision:
			overlay = playcount.getEpisodeOverlay(playcount.getShowIndicators(), self.idImdb, self.idTvdb, self.seasonString, self.episodeString)
		else:
			overlay = '6'

		title = interface.Translation.string(33451)
		status = interface.Translation.string(33452)
		substatus1 = interface.Translation.string(35474)
		substatus2 = interface.Translation.string(35303)
		message = self.progressMessage
		if not message == '':
			if interface.Core.background() and not self.core.progressPlaybackEnabled():
				message += ' - '
			else:
				message += '.' + interface.Format.newline()
		message += status
		interface.Loader.hide()

		self.core.progressPlaybackInitialize(title = title, message = message, metadata = self.metadata)
		timeout = tools.Settings.getCustom('playback.general.time')
		if not timeout: timeout = 600 # Technically unlimited.

		# Use a thread for Kodi 18, since the player freezes for a few seconds before starting playback.
		thread = Pool.thread(target = self.keepPlaybackWait, args = (title, message, status, substatus1, substatus2, timeout))
		thread.start()
		thread.join()

		if self.core.progressPlaybackCanceled():
			self.core.progressPlaybackClose()
			self.stop()
			self._debridClear()
			return True

		# Only show the notification if the player is not able to load the file at all.
		if not self.isPlayback():
			self.core.progressPlaybackUpdate(progress = 100, title = title, message = message, status = status, substatus1 = substatus1, substatus2 = substatus2)
			if self.progressRemaining > 0: tools.Time.sleep(self.progressDelay)
			self.stop()
			self.core.progressPlaybackUpdate(progress = 100, message = '', status = None, force = True) # Must be set to 100 for background dialog, otherwise it shows up in a later dialog.
			tools.System.windowPropertyClear(property)
			return False

		#self.core.progressPlaybackClose()
		addLibrary = tools.Settings.getBoolean('library.general.watched')

		playbackEnd = 80
		if tools.Settings.getBoolean('playback.track.enabled'): playbackEnd = tools.Settings.getInteger('playback.track.end')
		playbackEnd = playbackEnd / 100.0

		streamsHas = False
		visibleWas = False

		while self.isPlayingVideo():
			self.timeTotal = self.getTotalTime()
			self.timeCurrent = self.getTime()

			# On some hosters (eg: VidLox), if videos are taken down, they replace it with a short 404 video clip.
			# If the video clip is below 30 seconds, assume it is not a valid one, and do not mark progress, binge watch, etc.
			if self.timeTotal and self.timeTotal > 30:
				try:
					watcher = (self.timeCurrent / self.timeTotal >= playbackEnd)
					value = tools.System.windowPropertyGet(property)

					if watcher and not value == '7':
						try: orionoid.Orionoid().streamVote(idItem = self.source['stream'].idOrionItem(), idStream = self.source['stream'].idOrionStream(), vote = orionoid.Orionoid.VoteUp)
						except: pass
						tools.System.windowPropertySet(property, '7')
						if self.typeMovie:
							playcount.markMovieDuringPlayback(imdb = self.idImdb, tmdb = self.idTmdb, watched = '7')
							if addLibrary: library.Library(type = self.typeMedia).add(title = self.title, year = self.year, imdb = self.idImdb, tmdb = self.idTmdb, metadata = self.metadata)
						else:
							playcount.markEpisodeDuringPlayback(imdb = self.idImdb, tvdb = self.idTvdb, season = self.seasonString, episode = self.episodeString, watched = '7')
							if addLibrary: library.Library(type = self.typeMedia).add(title = self.title, year = self.year, imdb = self.idImdb, tvdb = self.idTvdb, metadata = self.metadata)
					elif not watcher and not value == '6':
						tools.System.windowPropertySet(property, '6')
						# Gaia
						# Do not mark as unwatched, otherwise if the video was previously watched and later rewatched, if will mark it as unwatched when played the second time.
						# Trakt can set multiple watches so that you can track on how many times you watched something.
						#playcount.markMovieDuringPlayback(imdb = self.idImdb, tmdb = self.idTmdb, watched = '6')
						#playcount.markEpisodeDuringPlayback(imdb = self.idImdb, tvdb = self.idTvdb, season = self.seasonString, episode = self.episodeString, watched = '6')
				except:
					pass

				self._bingeCheck()

			if self.navigationStreamsSpecial:
				for i in range(4):
					visible = self.isVisible()
					playback = self.isPlayback()
					if not visibleWas and visible: visibleWas = True
					if not streamsHas and playback and visibleWas and not visible:
						streamsHas = True
						self._showStreams()
					elif streamsHas and visible:
						streamsHas = False
						interface.Dialog.closeAll()
					if not self.download == None: self._downloadCheck()
					xbmc.sleep(1000)
			else:
				if self.download == None:
					xbmc.sleep(2000)
				else:
					for i in range(4):
						self._downloadCheck()
						xbmc.sleep(500)

		tools.System.windowPropertyClear(property)
		return True

	def _progress(self):
		progress = Playback().getProgress(type = self.typeMedia, imdb = self.idImdb, tvdb = self.idTvdb, season = self.season, episode = self.episode, wait = True)
		try: self.progressLock.acquire()
		except: pass
		self.progress = progress
		try: self.progressLock.release()
		except: pass

	def getProgress(self):
		if self.timeCurrent <= 0 or self.timeTotal <= 0: return 0
		else: return (self.timeCurrent / float(self.timeTotal)) * 100.0

	def updateProgress(self, action):
		current = tools.Time.timestamp()
		allow = True
		if action == Playback.ActionPause:
			# When the player buffers, it pauses the video.
			# Only update every 5 minutes, otherwise there are too many Trakt/database calls.
			allow = (current - self.progressLast) > 300
		if allow:
			Playback().setProgress(action = action, type = self.typeMedia, imdb = self.idImdb, tvdb = self.idTvdb, season = self.season, episode = self.episode, progress = self.getProgress(), wait = False)
		self.progressLast = current

	def setProgress(self):
		try:
			if self.timeTotal == 0: self.timeTotal = self.getTotalTime()
			if self.timeCurrent == 0: self.timeCurrent = self.getTime()
		except:
			# When Kodi's player is not playing anything, it throws an exception when calling self.getTotalTime()
			return

		while True:
			try: self.progressLock.acquire()
			except: pass
			progress = self.progress
			try: self.progressLock.release()
			except: pass
			if progress == None:
				time.sleep(0.5)
			else:
				break

		if progress > 0:
			if self.timeTotal > 0:
				seconds = (progress * self.timeTotal) / 100.0
				if seconds > 0:
					if tools.Settings.getBoolean('playback.track.enabled'):
						resume = tools.Settings.getInteger('playback.track.resume')
						if resume == 2 or resume == 3:
							self.progressBusy = True
							self.pause()
							timeMinutes, timeSeconds = divmod(float(seconds), 60)
							timeHours, timeMinutes = divmod(timeMinutes, 60)
							label = '%02d:%02d:%02d' % (timeHours, timeMinutes, timeSeconds)
							label = interface.Translation.string(32502) % label
							if resume == 3: label += ' ' + interface.Translation.string(34372)
							choice = interface.Dialog.option(title = 32344, message = label, labelConfirm = 32501, labelDeny = 32503, timeout = 7000 if resume == 3 else None)
							if choice: seconds = 0

				if seconds > 0:
					self.seekTime(seconds)
				if self.progressBusy:
					self.pause()
					self.progressBusy = False

		self.updateProgress(Playback.ActionStart)

	def _updateLibrary(self):
		if self.kodi:
			try:
				try: playcount = self.kodi['playcount'] + 1
				except: playcount = 1

				if self.typeMovie: tools.System.executeJson(method = 'VideoLibrary.SetMovieDetails', parameters = {'movieid' : str(self.kodi['movieid']), 'playcount' : playcount})
				elif self.typeTelevision: tools.System.executeJson(method = 'VideoLibrary.SetEpisodeDetails', parameters = {'episodeid' : str(self.kodi['episodeid']), 'playcount' : playcount})

				interface.Directory.refresh()
			except:
				tools.Logger.error()

	def onPlayBackStarted(self):
		tools.Logger.log('Playback Started')

		self.status = self.StatusPlaying
		interface.Loader.hide()
		self.setProgress()

		for i in range(0, 600):
			if self.isPlayback(): break
			tools.Time.sleep(0.1)
		interface.Dialog.closeAll()

		subtitles.Subtitles.open(name = self.name, imdb = self.idImdb, season = self.seasonString, episode = self.episodeString, source = self.source)

	def onPlayBackPaused(self):
		tools.Logger.log('Playback Paused')

		self.status = self.StatusPaused
		if not self.progressBusy: self.updateProgress(Playback.ActionPause)

	def onPlayBackResumed(self):
		tools.Logger.log('Playback Resumed')

		self.status = self.StatusPlaying
		if not self.progressBusy: self.updateProgress(Playback.ActionStart)

	def onPlayBackStopped(self):
		tools.Logger.log('Playback Stopped')

		self.status = self.StatusStopped
		self.updateProgress(Playback.ActionStop)
		self._downloadStop()
		self._debridClear()
		self._showStreams()
		if tools.System.windowPropertyGet('%s.player.overlay' % tools.System.id()) == '7':
			trakt.rateManual(imdb = self.idImdb, tvdb = self.idTvdb, season = self.season, episode = self.episode)
		if self.binge:
			if self.bingePlay:
				self._bingePlay()
			elif self.bingeDialogNone or self.bingeDialogFull:
				self._bingeShow()

	def onPlayBackEnded(self):
		tools.Logger.log('Playback Ended')

		self.onPlayBackStopped()
		self.status = self.StatusEnded
		self._updateLibrary()
		self._downloadClear()
		self._debridClear()

	def onPlayBackError(self):
		tools.Logger.log('Playback Error')

		self.error = True

	def onAVStarted(self):
		tools.Logger.log('Playback AV Started')

	def onAVChange(self):
		tools.Logger.log('Playback AV Changed')


class Playback(object):

	# Used by Trakt scrobble
	ActionStart = 'start'
	ActionPause = 'pause'
	ActionStop = 'stop'

	def __init__(self):
		self.progress = 0

	def _trakt(self):
		if trakt.getTraktCredentialsInfo() == False: return False
		else: return tools.Settings.getBoolean('playback.track.enabled') and tools.Settings.getInteger('playback.track.progress.alternative') == 1

	def _id(self, imdb = None, tvdb = None, season = None, episode = None):
		imdbValid = not imdb == None and not imdb == '' and not imdb == '0'
		tvdbValid = not tvdb == None and not tvdb == '' and not tvdb == '0'
		id = hashlib.md5()
		if imdbValid:
			imdb = str(imdb)
			for i in imdb: id.update(i.encode('utf-8'))
		if not imdbValid and tvdbValid:
			tvdb = str(tvdb)
			for i in tvdb: id.update(i.encode('utf-8'))
		if season:
			season =  '_' + str(season)
			for i in season: id.update(i.encode('utf-8'))
		if episode:
			episode = '_' + str(episode)
			for i in episode: id.update(i.encode('utf-8'))
		return str(id.hexdigest())

	def getProgress(self, type, imdb = None, tvdb = None, season = None, episode = None, wait = True):
		thread = Pool.thread(target = self._getProgress, args = (type, imdb, tvdb, season, episode))
		thread.start()
		if wait: thread.join()

		# Ignore progress if it is very small or large.
		if self.progress < 1 or (type == tools.Media.TypeMovie and self.progress > 92) or (type == tools.Media.TypeEpisode and self.progress > 96):
			self.progress = 0

		return self.progress

	def _getProgress(self, type, imdb = None, tvdb = None, season = None, episode = None):
		self.progress = 0
		try:
			if self._trakt():
				self.progress = trakt.scrobbleProgress(type = type, imdb = imdb, tvdb = tvdb, season = season, episode = episode)
			else:
				id = self._id(imdb = imdb, tvdb = tvdb, season = season, episode = episode)
				dbcon = database.connect(Database.pathPlayback())
				dbcur = dbcon.cursor()
				dbcur.execute("SELECT * FROM playback WHERE id = '%s'" % id)
				match = dbcur.fetchone()
				self.progress = float(match[1])
		except:
			pass

	def setProgress(self, action, type, progress, imdb = None, tvdb = None, season = None, episode = None, wait = False):
		thread = Pool.thread(target = self._setProgress, args = (action, type, progress, imdb, tvdb, season, episode))
		thread.start()
		if wait: thread.join()

	def _setProgress(self, action, type, progress, imdb = None, tvdb = None, season = None, episode = None):
		try:
			if self._trakt():
				trakt.scrobbleUpdate(action = action, type = type, imdb = imdb, tvdb = tvdb, season = season, episode = episode, progress = progress)
			else:
				id = self._id(imdb = imdb, tvdb = tvdb, season = season, episode = episode)
				tools.File.makeDirectory(tools.System.profile())
				dbcon = database.connect(Database.pathPlayback())
				dbcur = dbcon.cursor()
				dbcur.execute("CREATE TABLE IF NOT EXISTS playback (""id TEXT, ""progress REAL, ""UNIQUE(id)"");")
				dbcur.execute("DELETE FROM playback WHERE id = '%s'" % id)
				dbcur.execute("INSERT INTO playback VALUES (?, ?)", (id, progress))
				dbcon.commit()
		except:
			tools.Logger.error()
