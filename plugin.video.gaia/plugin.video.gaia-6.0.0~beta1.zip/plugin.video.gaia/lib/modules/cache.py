# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from threading import Lock
from lib.modules.tools import Time, Hash, Logger
from lib.modules.database import Database
from lib.modules.serializer import Serializer

class Cache(Database):

	Name = Database.NameCache # The name of the file. Update version number of the database structure changes.
	NameTrakt = 'trakt'

	Skip = '[GAIACACHESKIP]' # If a function returns this value, it will not be cached.

	ModeSynchronous = 1		# If expired, wait until the new data has been retrieved, and return the new data.
	ModeAsynchronous = 2	# If expired, retrieve the new data in the background, and immediately return the old data.
	ModeDefault = ModeAsynchronous

	StorageAll = 1		# Cache all data to the database.
	StorageFull = 2		# Only cache non-empty data to the database.
	StorageDefault = StorageAll

	TimeoutMinute1 = 60 # 1 Minute.
	TimeoutMinute5 = 300 # 5 Minutes.
	TimeoutMinute10 = 600 # 10 Minutes.
	TimeoutMinute15 = 900 # 15 Minutes.
	TimeoutMinute20 = 1200 # 20 Minutes.
	TimeoutMinute25 = 1500 # 25 Minutes.
	TimeoutMinute30 = 1800 # 30 Minutes.
	TimeoutMinute45 = 2700 # 45 Minutes.

	TimeoutHour1 = 3600 # 1 Hour.
	TimeoutHour2 = 7200 # 2 Hours.
	TimeoutHour3 = 10800 # 3 Hours.
	TimeoutHour4 = 14400 # 4 Hours.
	TimeoutHour5 = 18000 # 5 Hours.
	TimeoutHour6 = 21600 # 6 Hours.
	TimeoutHour9 = 32400 # 9 Hours.
	TimeoutHour12 = 43200 # 12 Hours.
	TimeoutHour18 = 64800 # 18 Hours.

	TimeoutDay1 = 86400 # 1 Day.
	TimeoutDay2 = 172800 # 2 Days.
	TimeoutDay3 = 259200 # 3 Days.
	TimeoutDay4 = 345600 # 4 Days.
	TimeoutDay5 = 432000 # 5 Days.
	TimeoutDay6 = 518400 # 6 Days.

	TimeoutWeek1 = 604800 # 1 Week.
	TimeoutWeek2 = 1209600 # 2 Weeks.
	TimeoutWeek3 = 1814400 # 3 Weeks.

	TimeoutMonth1 = 2592000 # 1 Month (30 Days).
	TimeoutMonth2 = 5270400 # 2 Months (61 Days).
	TimeoutMonth3 = 7862400 # 3 Months (91 Days).
	TimeoutMonth4 = 10540800 # 4 Months (122 Days).
	TimeoutMonth5 = 13132800 # 5 Months (152 Days).
	TimeoutMonth6 = 15811200 # 6 Months (183 Days).
	TimeoutMonth9 = 23673600 # 9 Months (274 Days).

	TimeoutYear1 = 31536000 # 1 Year (365 Days).
	TimeoutYear2 = 63072000 # 2 Years (730 Days).
	TimeoutYear3 = 94608000 # 3 Years (1095 Days).

	# Keep the timeout as short as possible.
	# The idea is to always update the data in the background on each request.
	# This can cause too many requests if the same cache is access multiple times per second/minute.
	TimeoutClear = -1 # Force refresh the data, but wait until the new data comes in (ModeSynchronous).
	TimeoutRefresh = 0 # Force refresh the data, but still return the current cached data (ModeAsynchronous).
	TimeoutReset = TimeoutMonth1 # 30 Days. Maximum timeout. If values are greater than this, the timeout will be set to TimeoutClear.
	TimeoutMini = TimeoutMinute10  # 10 Minutes.
	TimeoutShort = TimeoutHour1 # 1 Hour.
	TimeoutMedium = TimeoutHour6 # 6 Hours.
	TimeoutLong = TimeoutDay3 # 3 Days.

	Instance = None
	Lock = Lock()

	def __init__(self, mode = ModeDefault, storage = StorageDefault, timeout = None, internal = False):
		if not internal:
			Logger.log('The Cache class is a singleton and should only be created through the instance() function.', type = Logger.TypeFatal)
			from lib.modules.tools import System
			System.quit(log = True)

		Database.__init__(self, Cache.Name)
		self.mMode = mode
		self.mStorage = storage
		self.mTimeout = timeout

	# NB: Always use a single instance of Cache.
	# If creating separate instance using the constructor, each instance will create its own OS file handle to the .db file and establish a seaprate database connection.
	# If too many instances of Cache are created/used (eg: when retrieving metadata, such as retrieving multiple shows and for each show retrieve all the episodes), too many threads will have open database files/connections.
	# This causes SQLite to fail with after too many accesses with the error: "OperationalError: unable to open database file".
	# This problem seems to solved when using a single Cache instance.
	@classmethod
	def instance(self):
		if Cache.Instance is None:
			Cache.Lock.acquire()
			if Cache.Instance is None: Cache.Instance = Cache(internal = True)
			Cache.Lock.release()
		return Cache.Instance

	##############################################################################
	# DATABASE
	##############################################################################

	def _initialize(self):
		self._create('''
			CREATE TABLE IF NOT EXISTS %s
			(
				id TEXT,
				time INTEGER,
				data TEXT,
				UNIQUE(id)
			);
			'''
		)
		self._create('''
			CREATE TABLE IF NOT EXISTS %s
			(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				time INTEGER,
				link TEXT,
				data TEXT
			);
			''' % Cache.NameTrakt
		)

	##############################################################################
	# ID
	##############################################################################

	def id(self, function, *args, **kwargs):
		kwargs = self._cacheArguments(function, *args, **kwargs)
		return self._id(function, kwargs)

	def _id(self, function, kwargs):
		import re
		id = re.sub('>', '', re.sub('.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', repr(function))) + '_'
		id += '_'.join([str(key) + '=' + str(value) for key, value in kwargs.items()])
		return Hash.sha512(id)

	##############################################################################
	# EXECUTE
	##############################################################################

	def execute(self, function, *args, **kwargs):
		kwargs = self._cacheArguments(function, *args, **kwargs)
		return function(**kwargs)

	##############################################################################
	# CACHE
	##############################################################################

	def _cacheRetrieve(self, id):
		return self._selectSingle('SELECT time, data FROM %s WHERE id = ?;', parameters = (id,))

	def _cacheUpdate(self, id, data):
		self._insert('INSERT OR IGNORE INTO %s (id) VALUES (?);', (id,))
		return self._update('UPDATE %s SET time = ?, data = ? WHERE id = ?;', parameters = (Time.timestamp(), data, id))

	def _cacheDelete(self, id):
		return self._update('DELETE FROM %s WHERE id = ?;', parameters = (id,))

	def _cacheDataTo(self, data):
		try:
			serial = Serializer.dataSerialize(data)
			if serial: data = serial
		except: pass
		return repr(data)

	def _cacheDataFrom(self, data):
		if data is None: return data
		import ast
		data = ast.literal_eval(data)
		try:
			serial = Serializer.dataUnserialize(data)
			if serial: data = serial
		except: pass
		return data

	def _cacheDataValid(self, data):
		if data is None or data == [] or data == {} or data == '': return False
		elif data == 'None' or data == '[]' or data == '{}': return False
		else: return True

	def _cacheArguments(self, function, *args, **kwargs):
		# Convert args to kwargs.
		try: parameters = function.__code__.co_varnames # Python 3
		except: parameters = function.func_code.co_varnames # Python 2
		parameters = (parameter for parameter in parameters if not parameter == 'self')
		kwargs.update(dict(zip(parameters, args)))
		return kwargs

	def _cache(self, result, id, function, kwargs):
		try:
			data = function(**kwargs)
			if data == Cache.Skip:
				result[0] = None
			else:
				data = self._cacheDataTo(data)
				if self.mStorage == Cache.StorageAll or self._cacheDataValid(data): self._cacheUpdate(id, data)
				result[0] = data
		except:
			Logger.error()

	def cache(self, timeout, refresh, function, *args, **kwargs):
		try:
			import threading

			kwargs = self._cacheArguments(function, *args, **kwargs)
			id = self._id(function, kwargs)

			if timeout is None: timeout = self.mTimeout

			if timeout >= Cache.TimeoutRefresh:
				cache = self._cacheRetrieve(id)
				if cache:
					try:
						difference = Time.timestamp() - cache[0]
						if difference > Cache.TimeoutReset: timeout = Cache.TimeoutClear
						elif (refresh and difference <= refresh) or difference <= timeout:
							data = self._cacheDataFrom(cache[1])
							if data is None: timeout = Cache.TimeoutClear # Sometimes the cached data is None. Refresh the request in such a case.
							elif not refresh: return data
					except: # If cache[0] is None.
						timeout = Cache.TimeoutClear
			else:
				cache = None

			result = [None]
			thread = threading.Thread(target = self._cache, args = (result, id, function, kwargs))
			thread.start()
			if timeout == Cache.TimeoutClear or self.mMode == Cache.ModeSynchronous or not cache:
				thread.join()
			else:
				result[0] = cache[1]

			return self._cacheDataFrom(result[0])
		except:
			Logger.error('Cache Failed: ' + str(function))
		return None

	def cacheRetrieve(self, function, *args, **kwargs):
		try:
			kwargs = self._cacheArguments(function, *args, **kwargs)
			id = self._id(function, kwargs)
			return self._cacheDataFrom(self._cacheRetrieve(id)[1])
		except:
			return None

	def cacheExists(self, function, *args, **kwargs):
		return bool(self.cacheRetrieve(function, *args, **kwargs))

	# Delete the entire cache entry.
	def cacheDelete(self, function, *args, **kwargs):
		kwargs = self._cacheArguments(function, *args, **kwargs)
		id = self._id(function, kwargs)
		self._cacheDelete(id)

	# Use the timeout set in the constructor.
	def cacheFixed(self, function, *args, **kwargs):
		return self.cache(None, function, *args, **kwargs)

	# Force refresh the data, but wait until the new data comes in (ModeSynchronous).
	def cacheClear(self, function, *args, **kwargs):
		return self.cache(Cache.TimeoutClear, None, function, *args, **kwargs)

	# Force refresh the data, but still return the current cached data (ModeAsynchronous).
	def cacheRefresh(self, function, *args, **kwargs):
		return self.cache(Cache.TimeoutRefresh, None, function, *args, **kwargs)

	# Force refresh the data, but still return the current cached data (ModeAsynchronous).
	# Will wait to force refresh if the cached data is older than TimeoutMini (ModeSynchronous).
	def cacheRefreshMini(self, function, *args, **kwargs):
		return self.cache(Cache.TimeoutRefresh, Cache.TimeoutMini, function, *args, **kwargs)

	# Force refresh the data, but still return the current cached data (ModeAsynchronous).
	# Will wait to force refresh if the cached data is older than TimeoutShort (ModeSynchronous).
	def cacheRefreshShort(self, function, *args, **kwargs):
		return self.cache(Cache.TimeoutRefresh, Cache.TimeoutShort, function, *args, **kwargs)

	# Force refresh the data, but still return the current cached data (ModeAsynchronous).
	# Will wait to force refresh if the cached data is older than TimeoutMedium (ModeSynchronous).
	def cacheRefreshMedium(self, function, *args, **kwargs):
		return self.cache(Cache.TimeoutRefresh, Cache.TimeoutMedium, function, *args, **kwargs)

	# Force refresh the data, but still return the current cached data (ModeAsynchronous).
	# Will wait to force refresh if the cached data is older than TimeoutLong (ModeSynchronous).
	def cacheRefreshLong(self, function, *args, **kwargs):
		return self.cache(Cache.TimeoutRefresh, Cache.TimeoutLong, function, *args, **kwargs)

	def cacheSeconds(self, timeout, function, *args, **kwargs):
		return self.cache(timeout, None, function, *args, **kwargs)

	def cacheMinutes(self, timeout, function, *args, **kwargs):
		return self.cache(timeout * 60, None, function, *args, **kwargs)

	def cacheHours(self, timeout, function, *args, **kwargs):
		return self.cache(timeout * 3600, None, function, *args, **kwargs)

	def cacheDays(self, timeout, function, *args, **kwargs):
		return self.cache(timeout * 86400, None, function, *args, **kwargs)

	def cacheMini(self, function, *args, **kwargs):
		return self.cache(Cache.TimeoutMini, None, function, *args, **kwargs)

	def cacheShort(self, function, *args, **kwargs):
		return self.cache(Cache.TimeoutShort, None, function, *args, **kwargs)

	def cacheMedium(self, function, *args, **kwargs):
		return self.cache(Cache.TimeoutMedium, None, function, *args, **kwargs)

	def cacheLong(self, function, *args, **kwargs):
		return self.cache(Cache.TimeoutLong, None, function, *args, **kwargs)

	##############################################################################
	# TRAKT
	##############################################################################

	def traktCache(self, link, data = None, timestamp = None):
		# Only cache the requests that change something on the Trakt account.
		# Trakt uses JSON post data to set things and only uses GET parameters to retrieve things.
		if data == None: return None
		if timestamp == None: timestamp = Time.timestamp()
		self._insert('INSERT INTO %s (time, link, data) VALUES (?, ?, ?);' % Cache.NameTrakt, parameters = (timestamp, link, self._cacheDataTo(data)))

	def traktRetrieve(self):
		self._lock() # Execute the select and delete as atomic operations.
		result = self._selectSingle('SELECT id, time, link, data FROM %s ORDER BY time ASC LIMIT 1;' % Cache.NameTrakt)
		if not result:
			self._unlock()
			return None
		self._delete('DELETE FROM %s WHERE id = ?;' % Cache.NameTrakt, parameters = (result[0],))
		self._unlock()
		return {'time' : result[1], 'link' : result[2], 'data' : self._cacheDataFrom(result[3])}
