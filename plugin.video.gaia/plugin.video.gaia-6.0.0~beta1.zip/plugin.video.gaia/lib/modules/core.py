# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import xbmc
import sys
import re

from lib import debrid

from lib.modules import trakt
from lib.modules import network
from lib.modules import interface
from lib.modules import window
from lib.modules import tools
from lib.modules import convert
from lib.modules import handler
from lib.modules import history
from lib.modules import video
from lib.modules import orionoid
from lib.modules import cache as cachex
from lib.modules.parser import Parser
from lib.modules.stream import Stream, Filters, Settings, Termination
from lib.modules.library import Library
from lib.modules.database import Database
from lib.modules.theme import Theme
from lib.modules.thread import Pool, Lock

from lib.providers.core import manager
from lib.providers.core.base import ProviderBase

try: from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database

class Core:

	Hosters = None
	HostersPremium = None
	HostersCaptcha = None
	HostersBlocked = None

	ServicesDebrid = None
	ServicesExternal = None

	def __init__(self, type = tools.Media.TypeNone, kids = tools.Selection.TypeUndefined, silent = False):
		self.type = type
		self.kids = kids
		self.silent = silent
		self.sources = []
		self.providers = []
		self.terminated = False
		self.downloadCanceled = False
		self.filter = None

		self.lock = Lock()

		self.autoplay = Settings.settingsModeAutomatic()

		self.propertyNotification = 'GaiaStreamsNofitifcation'
		self.propertyItems = 'GaiaItems'
		self.propertyProcess = 'GaiaProcess'
		self.propertyExtras = 'GaiaExtras'
		self.propertyMeta = 'GaiaMeta'

		self.navigationCinema = video.Trailer.cinemaEnabled()
		self.navigationCinemaProgress = self.navigationCinema and video.Trailer.cinemaProgress()
		self.navigationCinemaInerrupt = self.navigationCinema and video.Trailer.cinemaInterrupt()
		if self.navigationCinema: self.navigationCinemaTrailer = video.Trailer(type = self.type, kids = self.kids)

		self.navigationScrape = tools.Settings.getInteger('interface.scrape.interface')
		self.navigationScrapeSpecial = self.navigationScrape == 0
		self.navigationScrapeDialog = self.navigationScrape == 1
		self.navigationScrapeBar = self.navigationScrape == 2

		self.navigationStreams = tools.Settings.getInteger('interface.stream.interface')
		self.navigationStreamsSpecial = self.navigationStreams == 0
		self.navigationStreamsDirectory = self.navigationStreams == 1
		self.navigationStreamsDialogDetailed = self.navigationStreams == 2
		self.navigationStreamsDialogPlain = self.navigationStreams == 3

		self.navigationPlayback = tools.Settings.getInteger('interface.playback.interface')
		self.navigationPlaybackSpecial = self.navigationPlayback == 0 # Accessed from RealDebrid interface.py.
		self.navigationPlaybackDialog = self.navigationPlayback == 1
		self.navigationPlaybackBar = self.navigationPlayback == 2

	def parameterize(self, action, type = None):
		if type == None: type = self.type
		if not type == None: action += '&type=%s' % type
		if not self.kids == None: action += '&kids=%d' % self.kids
		return action

	def kidsOnly(self):
		return self.kids == tools.Selection.TypeInclude

	def loaderShow(self):
		if not self.silent: interface.Loader.show()

	def loaderHide(self):
		if not self.silent: interface.Loader.hide()

	def progressFailure(self, single = False):
		if not self.silent:
			self.loaderHide()
			interface.Dialog.notification(title = 33448, message = 32401 if single else 32402, icon = interface.Dialog.IconError)

	def progressNotification(self, loader = False, force = False):
		# Check if the dialog was already shown.
		# Otherwise the notification might be shown twice if:
		#    1. Streams are shown in the directory structure.
		#    2. Playback fails or cache download starts.
		# If playback doesn't start, the directory structure is reloaded and showStreams() is called again.
		if not self.silent:
			if not tools.Converter.boolean(window.Window.propertyGlobal(self.propertyNotification)) or force:
				self.progressClose(force = True, loader = loader)
				if not self.filter or self.filter['initial'] == 0:
					interface.Dialog.notification(title = 33448, message = 35372, icon = interface.Dialog.IconError)
				else:
					counts = []
					counts.append((33497, self.filter['initial']))
					#counts.append((35453, self.filter['exclusion']))
					counts.append((35455, self.filter['limit'])) # Include the limited count, in case the number of streams are limited.
					counts = interface.Format.iconJoin(['%s: %d' % (interface.Translation.string(i[0]), i[1]) for i in counts])
					interface.Dialog.notification(title = 35373, message = counts, icon = interface.Dialog.IconWarning if self.filter['filter'] == 0 else interface.Dialog.IconSuccess, time = 5000)
			if self.filter and self.filter['final'] == 0 and self.filter['initial'] > 0:
				self.loaderHide()
				result = interface.Dialog.option(title = 33448, message = 35380)
				if result: self.loaderShow()
				return result
			else:
				window.Window.propertyGlobalSet(self.propertyNotification, True)
		return False

	def progressClose(self, loader = True, force = False):
		if self.navigationCinema:
			self.navigationCinemaTrailer.cinemaStop() # Eg if no streams were found.
		if not self.silent:
			if self.navigationScrapeSpecial:
				if force or not self.navigationStreamsSpecial or self.autoplay:
					window.WindowScrape.update(finished = True)
					window.WindowScrape.close()
			else:
				interface.Core.close()
				if force: interface.Dialog.closeAllProgress() # If called from another process, the interface.Core instance might be lost. Close all progress dialogs.
			if loader: self.loaderHide()

	def progressCanceled(self):
		if not self.silent:
			if self.navigationCinema:
				return self.navigationCinemaTrailer.cinemaCanceled()
			elif self.navigationScrapeSpecial:
				try:
					if tools.System.aborted():
						tools.System.exit()
						return True
				except: pass
				return not window.WindowScrape.visible()
			else:
				if interface.Core.background():
					return False
				else:
					try:
						if tools.System.aborted():
							tools.System.exit()
							return True
					except: pass
					return interface.Core.canceled()
		return False

	def progressPlaybackEnabled(self):
		return self.navigationPlaybackSpecial

	def progressPlaybackInitialize(self, title = None, message = None, metadata = None, force = False, loader = True):
		if not self.silent:
			if not force and (self.navigationCinema and self.autoplay):
				self.mLastTitle = title
				interface.Dialog.notification(title = title, message = message, icon = interface.Dialog.IconInformation)
			else:
				if self.navigationPlaybackSpecial:
					self.progressClose(loader = loader) # For autoplay.
					try: background = metadata['fanart']
					except:
						try: background = metadata['fanart2']
						except:
							try: background = metadata['fanart3']
							except: background = None
					window.WindowPlayback.show(background = background, status = message)
				else:
					if message == None: message = ''
					else: message = interface.Format.fontBold(message) + '%s'
					interface.Core.create(type = interface.Core.TypePlayback, background = self.navigationPlaybackBar, title = title, message = message, progress = 0)
					if interface.Core.background() and loader: self.loaderHide()

	def progressPlaybackUpdate(self, progress = None, title = None, message = None, status = None, substatus1 = None, substatus2 = None, total = None, remaining = None, force = False):
		if not self.silent:
			if force or not self.navigationCinema or not self.autoplay:
				if self.navigationPlaybackSpecial:
					if status == None: status = message
					window.WindowPlayback.update(progress = progress, status = status, substatus1 = substatus1, substatus2 = substatus2, total = total, remaining = remaining)
				else:
					if message == None: message = ''
					else: message = interface.Format.fontBold(message) + '%s'
					interface.Core.update(progress = progress, title = title, message = message)

	def progressPlaybackClose(self, loader = True, force = False):
		if not self.silent:
			if self.navigationPlaybackSpecial:
				window.WindowPlayback.update(finished = True)
				window.WindowPlayback.close()
			else:
				interface.Core.close()
				if force: interface.Dialog.closeAllProgress() # If called from another process, the interface.Core instance might be lost. Close all progress dialogs.
			if loader: self.loaderHide()

	def progressPlaybackCanceled(self):
		if not self.silent:
			if self.downloadCanceled:
				return True
			elif self.navigationPlaybackSpecial:
				try:
					if tools.System.aborted():
						tools.System.exit()
						return True
				except: pass
				return not window.WindowPlayback.visible()
			else:
				if interface.Core.background():
					return False
				else:
					try:
						if tools.System.aborted():
							tools.System.exit()
							return True
					except: pass
					return interface.Core.canceled()
		return False

	def scrape(self, title = None, year = None, imdb = None, tmdb = None, tvdb = None, season = None, episode = None, tvshowtitle = None, premiered = None, metadata = None, autoplay = None, preset = None, count = None, library = False, exact = False, items = None, process = True, binge = None, cache = True):
		try:
			# External addons (eg OpenMeta) does not call functions correctly, and the type might not be set.
			if self.type is None: self.type = tools.Media.TypeShow if season or episode else tools.Media.TypeMovie

			# Loader still showing after continuing with binge watching.
			# The loader is shown in _bingePlay in the player.
			if self.navigationStreamsSpecial and binge == tools.Binge.ModeContinue: interface.Loader.hide()

			# When the play action is called from the skin's widgets.
			# Otherwise the directory with streams is not shown.
			# Only has to be done if accessed from the home screen. Not necessary if the user is already in a directory structure.
			# Check for tools.Binge.ModeBackground. Seems to be an issue on Mac devices causing the episode direcotry list to be loaded if binge scraping happens in the background.
			if not binge == tools.Binge.ModeBackground and self.navigationStreamsDirectory and not 'plugin' in tools.System.infoLabel('Container.PluginName') and not tools.System.infoLabel('Container.FolderPath'):
				tools.System.launchAddon()

			new = items == None
			if not self.navigationCinema: self.loaderShow()
			window.Window.propertyGlobalClear(self.propertyNotification)
			if binge is None or binge == tools.Binge.ModeBackground: binge = tools.Binge.ModeFirst if tools.Binge.enabled() else tools.Binge.ModeNone
			if cache is None: cache = True

			if autoplay == None:
				if tools.Converter.boolean(window.Window.propertyGlobal('PseudoTVRunning')): autoplay = True
				else: autoplay = self.autoplay

			# Show here for autoplay. Manual is shown after the streams are listed.
			if autoplay and not self.silent: tools.Donations.popup()

			if tools.Tools.isString(metadata): metadata = tools.Converter.jsonFrom(metadata)

			# Retrieve metadata if not available.
			# Applies to links from Kodi's local library. The metadata cannot be saved in the link, since Kodi cuts off the link if too long. Retrieve it here afterwards.
			if not metadata:
				if tvshowtitle:
					from lib.indexers import shows
					# TODO: The episode metadata should be retrieved, not the show metadata.
					# Currently the metadata is always passed as a parameter, but if that changes, this has to be fixed.
					metadata = shows.shows().metadata(tvshowtitle = tvshowtitle, title = title, year = year, imdb = imdb, tvdb = tvdb, season = season, episode = episode)
				else:
					from lib.indexers import movies
					metadata = movies.movies().metadata(imdb = imdb)

			if new:
				if not self.silent and self.navigationCinema:
					try: background = metadata['fanart']
					except:
						try: background = metadata['fanart2']
						except:
							try: background = metadata['fanart3']
							except: background = None
					self.navigationCinemaTrailer.cinemaStart(type = self.type, background = background)
				if exact: self.scrapeLabel = title if title else tvshowtitle
				else: self.scrapeLabel = tools.Media.titleUniversal(metadata = metadata, title = title if tvshowtitle is None else tvshowtitle, year = year, season = season, episode = episode)
				tools.Logger.log('Scraping Initialized', name = 'CORE', type = tools.Logger.TypeInfo)

				self.timerGlobal = tools.Time(start = True)
				result = self.scrapeItem(title = title, year = year, imdb = imdb, tmdb = tmdb, tvdb = tvdb, season = season, episode = episode, tvshowtitle = tvshowtitle, premiered = premiered, metadata = metadata, preset = preset, count = count, exact = exact, autoplay = autoplay, cache = cache)

				if result == None or (self.progressCanceled() and not self.navigationCinema): # Avoid the no-streams notification right after the unavailable notification
					self.progressClose(force = True)
					return None
				try:
					if not exact:
						api = orionoid.Orionoid(silent = True)
						if api.accountAllow():
							from lib.modules.stream import Manager
							sourcesOrion = Manager.excludeDuplicate(items = self.sources, orion = True)
							api.streamUpdate(metadata, sourcesOrion)
				except: pass
			else:
				if tools.Tools.isString(items): items = tools.Converter.jsonFrom(items)
				self.sources = items

			self.sources = self.sourcesPrepare(items = self.sources)

			window.Window.propertyGlobalClear(self.propertyExtras)
			window.Window.propertyGlobalSet(self.propertyItems, tools.Converter.jsonTo(self.sources))
			window.Window.propertyGlobalSet(self.propertyMeta, tools.Converter.jsonTo(metadata))
			window.Window.propertyGlobalSet(self.propertyProcess, process)

			if new and Termination.settingsEnabled() and Termination.settingsMode() == Termination.ModeOverwrite:
				autoplay = self.terminated or self.timerGlobal.elapsed() < ProviderBase.settingsGlobalLimitTime()

			if not self.silent:
				self._showClear()
				self.showStreams(items = self.sources, metadata = metadata, autoplay = autoplay, initial = True, library = library, direct = exact, new = new, process = process, binge = binge)

			tools.Logger.log('Scraping Finished', name = 'CORE', type = tools.Logger.TypeInfo)
			self.scrapeStatistics()

			return self.sources
		except:
			tools.Logger.error()
			self.progressClose(force = True)

	def scrapeExact(self, terms = None):
		if not tools.Settings.getBoolean('internal.initial.exact'):
			interface.Dialog.confirm(title = 32010, message = 35159)
			tools.Settings.set('internal.initial.exact', True)
		if terms is None:
			terms = interface.Dialog.input(title = 35158, type = interface.Dialog.InputAlphabetic)
		if terms:
			if tools.Media.typeTelevision(self.type): return self.scrape(title = terms, exact = True)
			else: return self.scrape(title = terms, exact = True)

	def scrapePreset(self, link, autoplay):
		if not self.navigationCinema: self.loaderShow()
		preset = manager.Manager.presetsSelection()
		if preset: tools.System.execute('RunPlugin(%s&autoplay=%d&preset=%s)' % (link, autoplay, preset))
		self.loaderHide()

	def scrapePresetManual(self, link):
		self.scrapePreset(link = link, autoplay = False)

	def scrapePresetAutomatic(self, link):
		self.scrapePreset(link = link, autoplay = True)

	def scrapeAgain(self, link):
		tools.System.execute('RunPlugin(%s&cache=%d)' % (link, False))

	def scrapeManual(self, link):
		tools.System.execute('RunPlugin(%s&autoplay=%d)' % (link, False))

	def scrapeAutomatic(self, link):
		tools.System.execute('RunPlugin(%s&autoplay=%d)' % (link, True))

	def scrapeSingle(self, link):
		tools.System.execute('RunPlugin(%s&binge=%d)' % (link, tools.Binge.ModeNone))

	def scrapeBinge(self, link):
		tools.System.execute('RunPlugin(%s&binge=%d)' % (link, tools.Binge.ModeFirst))

	def scrapeAlternative(self, link):
		tools.System.execute('RunPlugin(%s&autoplay=%d)' % (link, False if self.autoplay else True))

	def scrapeItem(self, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered, metadata = None, preset = None, count = None, exact = False, autoplay = False, cache = True):
		try:
			def titleClean(value):
				values = []
				if value == None: return values

				# Remove years in brackets from titles.
				# Do not remove years that are not between brackets, since it might be part of the title. Eg: 2001 A Space Oddesy
				# Eg: Heartland (CA) (2007) -> Heartland (CA)
				value = re.sub('[\(\{\[][0-9]{4}[\)\}\]]', '', value)

				# Replace country codes. Otherwise "U.S." will end up as "U S".
				value = re.sub('u\.s\.', 'us', value, flags = re.IGNORECASE)
				value = re.sub('u\.k\.', 'uk', value, flags = re.IGNORECASE)

				# Remove apostrophes.
				# Create two different versions of apostrophes (one with "'s" -> "s", and the other one "'s" -> ""), since some sites can only use one of them.

				valueNew = re.sub('([\'\`])([a-zA-Z](?:$|[\s\-\!\$\%%\^\&\*\(\)\_\+\|\~\=\`\{\}\\\[\]\:\"\;\'\`\<\>\?\,\.\\\/]))', '\g<2>', value) # Replace apostrophes at the end of the word with an empty string (eg: Peter's -> Peters).
				if value == valueNew: values1 = [valueNew]
				else: values1 = [valueNew, re.sub('([\'\`][a-zA-Z])($|[\s\-\!\$\%%\^\&\*\(\)\_\+\|\~\=\`\{\}\\\[\]\:\"\;\'\`\<\>\?\,\.\\\/])', '\g<2>', value)]

				values2 = []
				for val in values1:
					# Replace apostrophes at the start of the word with a space (eg: "L'Ascension de Skywalker" -> "L Ascension de Skywalker" and "LAscension de Skywalker").
					values2.append(re.sub('([\'\`])', ' ', val)) # Place this before the one below, since the one below might exceed the maximum number of search titles. YggTorrent can only find with the "'" or " ", but not with "".
					values2.append(re.sub('([\'\`])', '', val))

				seen = set()
				values2 = [i for i in values2 if not (i in seen or seen.add(i))]

				for val in values2:
					# Remove symbols.
					# Eg: Heartland (CA) -> Heartland CA
					# Replace with space: Brooklyn Nine-Nine -> Brooklyn Nine Nine
					val = re.sub('[\-\!\$\%%\^\&\*\(\)\_\+\|\~\=\`\{\}\\\[\]\:\"\;\'\`\<\>\?\,\.\\\/]', ' ', val)

					# Replace extra spaces.
					val = re.sub('\s+', ' ', val).strip()

					values.append(val)

				seen = set()
				values = [i for i in values if not (i in seen or seen.add(i))]
				return values

			def titleProcess(title, titleShow):
				if titleShow:
					self.titles['main'] = titleShow
					self.titles['episode'] = title
				else:
					self.titles['main'] = title

				# Make all titles unicode types (if they are not already unicode).
				try: self.titles['main'] = self.titles['main'].decode('utf-8')
				except: pass
				try: self.titles['native'] = {key : [v.decode('utf-8') for v in val] for key, val in self.titles['native'].items()}
				except: pass
				try: self.titles['local'] = self.titles['local'].decode('utf-8')
				except: pass
				try: self.titles['original'] = self.titles['original'].decode('utf-8')
				except: pass
				try: self.titles['collection'] = self.titles['collection'].decode('utf-8')
				except: pass
				try: self.titles['episode'] = self.titles['episode'].decode('utf-8')
				except: pass
				try:
					for key, value in self.titles['alias']:
						for i in range(len(value)):
							try: self.titles['alias'][key][i] = self.titles['alias'][key][i].decode('utf-8')
							except: pass
				except: pass

				# Also search titles that contain abbreviations (consecutive capital letters).
				# Eg: "K.C. Undercover" is retrieved as "KC Undercover" by informants. Most providers have it as "K C Undercover".
				titleAbbreviation = self.titles['main']
				if 'original' in self.titles and self.titles['original']: titleAbbreviation = self.titles['original']
				if titleAbbreviation:
					abbreviations = re.findall('[A-Z]{2,}', titleAbbreviation)
					for abbreviation in abbreviations:
						titleAbbreviation = titleAbbreviation.replace(abbreviation, ' '.join(list(abbreviation)))
				if titleAbbreviation:
					try: self.titles['abbreviation'] = titleAbbreviation.decode('utf-8')
					except: self.titles['abbreviation'] = titleAbbreviation

				character = ProviderBase.settingsGlobalTitleCharacter()
				limit = ProviderBase.settingsGlobalTitleLimit()
				titles = []
				processedMain = []
				processedCollection = []
				processedEpisode = []

				if 'main' in self.titles and self.titles['main']:
					titles.append(self.titles['main'])
					processedMain.append(self.titles['main'])
				if 'original' in self.titles and self.titles['original']:
					titles.append(self.titles['original'])
					processedMain.append(self.titles['original'])
				if 'native' in self.titles and self.titles['native']:
					#titles.extend(self.titles['native'].values()) # Do not add to the main titles, since we do not want to search these like the other alterntive titles.
					processedMain.extend(tools.Tools.listFlatten(self.titles['native'].values()))
				if 'local' in self.titles and self.titles['local']:
					titles.append(self.titles['local'])
					processedMain.append(self.titles['local'])
				if 'abbreviation' in self.titles and self.titles['abbreviation']:
					titles.append(self.titles['abbreviation'])
					processedMain.append(self.titles['abbreviation'])
				if 'alias' in self.titles and self.titles['alias']:
					country = tools.Language.country(ProviderBase.settingsGlobalTitleLanguage()).lower()
					if country in self.titles['alias']: titles.extend(self.titles['alias'][country])
					if 'us' in self.titles['alias']: titles.extend(self.titles['alias']['us'])
					if None in self.titles['alias']: titles.extend(self.titles['alias'][None])
					for value in self.titles['alias'].values(): processedMain.extend(value)

				# Add title without the collection name.
				# Eg: "The Lord of the Rings: The Two Towers" -> "The Two Towers"
				if 'collection' in self.titles and self.titles['collection']:
					if 'main' in self.titles and self.titles['main']:
						titleReduced = re.sub(self.titles['collection'], '', self.titles['main'], re.IGNORECASE)
						if not titleReduced == self.titles['main']:
							titleReduced = titleReduced.strip(' :-()[]')
							if titleReduced:
								titles.append(titleReduced)
								processedMain.append(titleReduced)

				main = []
				for title in titles:
					titlesCleaned = titleClean(title)
					for titleCleaned in titlesCleaned:
						main.append(titleCleaned)
						main.append(tools.Converter.unicodeNormalize(string = titleCleaned, umlaut = False))
						if character: main.append(tools.Converter.unicodeNormalize(string = titleCleaned, umlaut = True))
						main.append(tools.Converter.unicodeStrip(string = titleCleaned)) # Some sites do not deal with encoding unicode at all. Instead, they just strip any unicode characters.
				for i in range(len(main)):
					try: main[i] = main[i].decode('utf-8')
					except: pass
				seen = set()
				main = [i.strip() for i in main]
				main = [i for i in main if i and not(i.lower() in seen or seen.add(i.lower()))]
				processedMain.extend(main)

				native = {}
				if 'native' in self.titles and self.titles['native']:
					for key, val in self.titles['native'].items():
						nativeTitles = []
						for title in val:
							titlesCleaned = titleClean(title)
							for titleCleaned in titlesCleaned:
								nativeTitles.append(titleCleaned)
								nativeTitles.append(tools.Converter.unicodeNormalize(string = titleCleaned, umlaut = False))
								if character: nativeTitles.append(tools.Converter.unicodeNormalize(string = titleCleaned, umlaut = True))
								nativeTitles.append(tools.Converter.unicodeStrip(string = titleCleaned)) # Some sites do not deal with encoding unicode at all. Instead, they just strip any unicode characters.
							native[key] = nativeTitles
					for key, val in native.items():
						for i in range(len(val)):
							try: val[i] = val[i].decode('utf-8')
							except: pass
						seen = set()
						val = [i.strip() for i in val]
						val = [i for i in val if i and not(i.lower() in seen or seen.add(i.lower()))]
						native[key] = val
					for val in native.values():
						processedMain.extend(val)

				collection = []
				if 'collection' in self.titles and self.titles['collection']:
					collection.extend(titleClean(self.titles['collection']))
					processedCollection.append(self.titles['collection'])
				for i in range(len(collection)):
					try: collection[i] = collection[i].decode('utf-8')
					except: pass
				seen = set()
				collection = [i.strip() for i in collection]
				collection = [i for i in collection if i and not(i.lower() in seen or seen.add(i.lower()))]

				episode = []
				if 'episode' in self.titles and self.titles['episode']:
					episode.extend(titleClean(self.titles['episode']))
					processedEpisode.append(self.titles['episode'])
				for i in range(len(episode)):
					try: episode[i] = episode[i].decode('utf-8')
					except: pass
				seen = set()
				episode = [i.strip() for i in episode]
				episode = [i for i in episode if i and not(i.lower() in seen or seen.add(i.lower()))]

				self.titles['search'] = {}
				self.titles['search']['main'] = main
				self.titles['search']['native'] = native
				self.titles['search']['collection'] = collection
				self.titles['search']['episode'] = episode

				if limit > 0:
					if len(self.titles['search']['main']) > limit:
						self.titles['search']['main'] = self.titles['search']['main'][:limit]

					count = limit - len(self.titles['search']['main'])
					if count <= 0: count = 1
					self.titles['search']['native'] = {key : val[:count] for key, val in self.titles['search']['native'].items()}

					count = limit - len(self.titles['search']['main'])
					if count <= 0: count = 1
					self.titles['search']['collection'] = self.titles['search']['collection'][:count]

					count = limit - len(self.titles['search']['main'])
					if count <= 0: count = 1
					self.titles['search']['episode'] = self.titles['search']['episode'][:count]

				# This is important for matching titles in stream.py.
				# Eg: The title "Amélie", but most file names contain "Amelie".
				processedExtra = []
				expression = re.compile('^\s*[\s\d\-\!\$\%%\^\&\*\(\)\_\+\|\~\=\`\{\}\\\[\]\:\"\;\'\`\<\>\?\,\.\\\/]*\s*$') # Ignore titles with single symbol (when unicode fails leaving only spaces/symbols/digits behind).
				seen = set()
				processedMain = [i for i in processedMain if i and not(i.lower() in seen or seen.add(i.lower()))] # Reduce computation.
				for title in processedMain:
					titleNew = tools.Converter.unicodeNormalize(string = title, umlaut = False).strip()
					if titleNew and (titleNew == title or not expression.match(titleNew)): processedExtra.append(titleNew)
					if character:
						titleNew = tools.Converter.unicodeNormalize(string = title, umlaut = True).strip()
						if titleNew and (titleNew == title or not expression.match(titleNew)): processedExtra.append(titleNew)
				for i in range(len(processedExtra)):
					try: processedExtra[i] = processedExtra[i].decode('utf-8')
					except: pass
				processedMain.extend(processedExtra)

				seen = set()
				processedMain = [i for i in processedMain if i and not(i.lower() in seen or seen.add(i.lower()))]
				seen = set()
				processedCollection = [i for i in processedCollection if i and not(i.lower() in seen or seen.add(i.lower()))]
				seen = set()
				processedEpisode = [i for i in processedEpisode if i and not(i.lower() in seen or seen.add(i.lower()))]
				seen = set()
				processedAll = processedMain + processedCollection + processedEpisode
				processedAll = [i for i in processedAll if i and not(i.lower() in seen or seen.add(i.lower()))]

				self.titles['processed'] = {}
				self.titles['processed']['all'] = processedAll
				self.titles['processed']['main'] = processedMain
				self.titles['processed']['collection'] = processedCollection
				self.titles['processed']['episode'] = processedEpisode

				# Convert all titles to unicode, otherwise there are encode/decode errors down the line during scraping and in stream.py.
				titleDecode(self.titles)

			def titleDecode(titles):
				for key, value in titles.items():
					if value:
						if tools.Tools.isDictionary(value):
							titleDecode(value)
						else:
							if tools.Tools.isArray(value):
								for i in range(len(value)):
									try: value[i] = value[i].decode('utf-8')
									except: pass
							else:
								try: value = value.decode('utf-8')
								except: pass
							titles[key] = value

			def _progressShow(title, message, metadata = None):
				if not self.silent:
					self.mLastMessage1 = message
					if self.navigationCinemaProgress:
						self.mLastTitle = title
						interface.Dialog.notification(title = title, message = message, icon = interface.Dialog.IconInformation)
					elif not self.navigationCinema:
						if self.navigationScrapeSpecial:
							try: background = metadata['fanart']
							except:
								try: background = metadata['fanart2']
								except:
									try: background = metadata['fanart3']
									except: background = None
							window.WindowScrape.show(background = background, status = message)
						else:
							interface.Core.create(type = interface.Core.TypeScrape, background = self.navigationScrapeBar, title = title, message = message)

			def _progressUpdate(percentage, message1, message2 = None, message2Alternative = None, showElapsed = True):
				if not self.silent:
					if percentage == None: percentage = self.progressPercentage
					else: self.progressPercentage = max(percentage, self.progressPercentage) # Do not let the progress bar go back if more streams are added while precheck is running.

					if self.navigationCinemaProgress:
						percentageChange = (self.progressPercentage - self.progressPercentageLast) > 20
						messageChange = not self.mLastMessage1 == message1
						self.mLastMessage1 = message1
						if percentageChange or messageChange or self.progressPercentage == 100:
							self.progressPercentageLast = self.progressPercentage
							interface.Dialog.notification(title = self.mLastTitle, message = interface.Format.iconSeparator(color = True, pad = True).join([self.mLastMessage1, str(int(self.progressPercentage)) + '%']), icon = interface.Dialog.IconInformation)
					elif not self.navigationCinema:
						if self.navigationScrapeSpecial:
							self.mLastMessage1 = message1
							window.WindowScrape.update(
								status = message1, progress = self.progressPercentage, time = _progressElapsed(),
								streamsTotal = self.streamsTotal, streamsHdUltra = self.streamsHdUltra, streamsHd1080 = self.streamsHd1080, streamsHd720 = self.streamsHd720, streamsSd = self.streamsSd, streamsLd = self.streamsLd,
								streamsTorrent = self.streamsTorrent, streamsUsenet = self.streamsUsenet, streamsHoster = self.streamsHoster,
								streamsCached = self.streamsCached, streamsDebrid = self.streamsDebrid, streamsDirect = self.streamsDirect, streamsPremium = self.streamsPremium, streamsLocal = self.streamsLocal,
								streamsFinished = self.streamsFinished, streamsBusy = self.streamsBusy,
								providersFinished = self.providersFinished, providersBusy = self.providersBusy, providersLabels = self.providersLabels,
								skip = self.skip
							)
						else:
							if not message2: message2 = ''
							if interface.Core.background():
								messageNew = self.mLastName + message1
								if message2Alternative: message2 = message2Alternative
								# Do last, because of message2Alternative. Must be done BEFORE dialog update, otherwise stream count sometimes jumps back.
								self.mLastMessage1 = message1
								self.mLastMessage2 = message2
								elapsedTime = _progressElapsed(mini = True) + Format.iconSeparator(color = True, pad = True) if showElapsed and message2 else ''
								interface.Core.update(progress = self.progressPercentage, title = messageNew, message = elapsedTime + message2)
							else:
								messageNew = interface.Format.fontBold(message1) + '%s'
								# Do last, because of message2Alternative. Must be done BEFORE dialog update, otherwise stream count sometimes jumps back.
								self.mLastMessage1 = message1
								self.mLastMessage2 = message2
								elapsedTime = _progressElapsed(full = True) if showElapsed else ' '
								interface.Core.update(progress = self.progressPercentage, message = interface.Format.newline().join([messageNew, elapsedTime, message2]))

			def _progressTime():
				while not self.stopThreads:
					_progressUpdate(self.progressPercentage, self.mLastMessage1, self.mLastMessage2)
					tools.Time.sleep(0.2)

			def _progressElapsed(raw = True, mini = False, full = False):
				seconds = max(0, timer.elapsed())
				if full: return timeStringDescription % seconds
				elif mini: return timeString % seconds
				else: return seconds

			def additionalTitle(title, titleShow, imdb, tvdb):
				threads = []

				original = self.enabledTitle and ProviderBase.settingsGlobalTitleOriginal()
				threads.append(Pool.thread(target = additionalTitleOriginal, args = (original, title, titleShow, imdb, tvdb)))

				if self.enabledTitle:
					native = ProviderBase.settingsGlobalTitleNative()
					local = ProviderBase.settingsGlobalTitleLocal()
					if native or local: threads.append(Pool.thread(target = additionalTitleTranslation, args = (title, titleShow, imdb, tvdb, native, local)))
					if ProviderBase.settingsGlobalTitleAlias(): threads.append(Pool.thread(target = additionalTitleAlias, args = (title, titleShow, imdb, tvdb)))

				if self.enabledCollection:
					threads.append(Pool.thread(target = additionalTitleCollection, args = (title, titleShow, imdb, tvdb)))

				[thread.start() for thread in threads]
				[thread.join() for thread in threads]

				titleProcess(title, titleShow)

			def additionalTitleOriginal(update, title, titleShow, imdb, tvdb):
				from lib.modules.account import Tmdb

				self.progressTitleOriginal = 0
				try:
					titleOriginal = None
					languageOriginal = None

					key = Tmdb().key()
					if key:
						result = cachex.Cache.instance().cacheLong(network.Networker().requestText, 'http://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % (imdb, key))
						self.progressTitleOriginal = 25
						result = tools.Converter.jsonFrom(result)
						if not tools.Tools.isArray(result): result = [result]
						for i in result:
							for j in i:
								for key, value in i.items():
									if not tools.Tools.isArray(value): value = [value]
									for k in value:
										if 'original_title' in k: # Movies
											titleOriginal = k['original_title']
											try: languageOriginal = k['original_language']
											except: pass
											break
										elif 'original_name' in k: # Shows
											titleOriginal = k['original_name']
											try: languageOriginal = k['original_language']
											except: pass
											break
									if titleOriginal: break
								if titleOriginal: break
							if titleOriginal: break

					if not titleOriginal:
						self.progressTitleOriginal = 50
						result = cachex.Cache.instance().cacheLong(network.Networker().requestText, 'http://www.imdb.com/title/%s' % imdb)
						self.progressTitleOriginal = 75
						result = Parser(result)
						for lookup in ['originalTitle', re.compile('originalTitle__*', flags = re.IGNORECASE)]:
							resultTitle = result.find_all('div', class_ = lookup)
							if len(resultTitle) > 0:
								titleOriginal = resultTitle[0].getText()
								titleOriginal = titleOriginal[:titleOriginal.rfind('(')]
								if titleOriginal: break
						if not titleOriginal:
							resultTitle = result.find_all('h1', {'itemprop' : 'name'})
							if len(resultTitle) > 0:
								titleOriginal = resultTitle[0].getText()
								titleOriginal = titleOriginal[:titleOriginal.rfind('(')]
						if titleOriginal: titleOriginal = tools.Regex.remove(data = titleOriginal, expression = 'original\s*title\s*:\s*')

						try:
							resultLanguage = result.find_all('li', {'data-testid' : 'title-details-languages'})
							if resultLanguage:
								languageOriginal = resultLanguage[0].find_all('a')[0].text
						except: pass

					if update and titleOriginal: self.titles['original'] = titleOriginal.strip() or titleShow or title # Sometimes foreign titles have a space at the end.
					if languageOriginal: self.languageOriginal = tools.Language.code(languageOriginal)

				except: tools.Logger.error()
				self.progressTitleOriginal = 100

			def additionalTitleTranslation(title, titleShow, imdb, tvdb, native = True, local = True):
				try:
					self.progressTitleTranslation = 0
					languages = []
					if local:
						languagesLocal = ProviderBase.settingsGlobalTitleLanguage()
						if languagesLocal: languages.append(languagesLocal)
					if native:
						languagesProviders = [i.languages() for i in self.providers]
						languagesProviders = tools.Tools.listFlatten(languagesProviders)
						languagesProviders = tools.Tools.listUnique(languagesProviders)
						try: del languages[tools.Language.UniversalCode]
						except: pass
						try: del languages[tools.Language.EnglishCode]
						except: pass
						if languagesProviders: languages.extend(languagesProviders)

					translations = {language : [] for language in languages}

					self.progressTitleTranslation = 25
					if titleShow and (imdb or tvdb):
						from lib.metadata.manager import Manager
						from lib.metadata.metadata import Metadata
						items = Manager(Manager.ProviderTvdb).translationTitle(media = Metadata.MediaShow, idImdb = imdb, idTvdb = tvdb, language = languages)
						if items:
							for key, val in items.items():
								translations[key].extend(val)

					self.progressTitleTranslation = 50
					found = True
					for language in languages:
						if not translations[language]:
							found = False
							break

					if not found and imdb:
						items = trakt.getTVShowTranslation if titleShow else trakt.getMovieTranslation
						items = items(imdb, languages, full = True)
						if items:
							for item in items:
								translations[item['language']].append(item['title'])

					self.progressTitleTranslation = 75
					titleLower = titleShow.lower() if titleShow else title.lower()
					for key, val in translations.items():
						translations[key] = [i for i in val if not i.lower() == titleLower]

					try: titlesLocal = translations[languagesLocal][0]
					except: titlesLocal = None
					self.titles['local'] = titlesLocal or titleShow or title

					# Allow multiple native titles.
					# Eg: Portuguese might have multiple translations, one for Portugal and a different one for Brazil.
					self.titles['native'] = {key : val for key, val in translations.items() if key in languagesProviders}

					self.progressTitleTranslation = 100
				except: tools.Logger.error()

			def additionalTitleAlias(title, titleShow, imdb, tvdb):
				self.progressTitleAlias = 25
				try:
					aliases = trakt.getTVShowAliases(imdb) if titleShow else trakt.getMovieAliases(imdb)
					if not aliases: aliases = []

					titleAliases = {}
					for alias in aliases:
						country = alias['country']
						if country: country = country.lower()
						else: country = None
						if not country in titleAliases: titleAliases[country] = []
						titleAliases[country].append(alias['title'])

					for key, value in titleAliases.items():
						seen = set()
						titleAliases[key] = [i for i in value if i and not(i.lower() in seen or seen.add(i.lower()))]

					self.titles['alias'] = titleAliases
				except: tools.Logger.error()
				self.progressTitleAlias = 100

			def additionalTitleCollection(title, titleShow, imdb, tvdb):
				from lib.modules.account import Tmdb

				self.progressTitleCollection = 0
				try:
					key = Tmdb().key()
					if key:
						result = cachex.Cache.instance().cacheLong(network.Networker().requestJson, 'https://api.themoviedb.org/3/movie/%s?api_key=%s' % (imdb, key))
						self.progressTitleCollection = 50
						try: self.titles['collection'] = re.sub('collection$', '', result['belongs_to_collection']['name'], flags = re.IGNORECASE).strip()
						except: self.titles['collection'] = None
						try: id = result['belongs_to_collection']['id']
						except: id = None
						if id:
							result = cachex.Cache.instance().cacheLong(network.Networker().requestJson, 'https://api.themoviedb.org/3/collection/%d?api_key=%s' % (id, key))
							self.progressTitleCollection = 75
							try: self.count = len(result['parts'])
							except: pass
				except: tools.Logger.error()
				self.progressTitleCollection = 100

			def initializeProviders(media, preset, imdb, tvdb, exclude = None):
				self.providers = manager.Manager.providers(enabled = True, exclude = exclude, preset = preset)
				self.providersBusy = len(self.providers)

			tools.Logger.log('Scraping Started', name = 'CORE', type = tools.Logger.TypeInfo)

			threads = []
			movie = tvshowtitle == None if self.type == None else (self.type == tools.Media.TypeMovie or self.type == tools.Media.TypeDocumentary or self.type == tools.Media.TypeShort)
			media = tools.Media.TypeMovie if movie else tools.Media.TypeShow

			try: duration = metadata['duration']
			except: duration = None

			self.count = count
			self.languageOriginal = None
			self.titles = {}
			if exact:
				if not movie and not title: title = tvshowtitle
				self.titles['processed'] = {'all' : [title], 'main' : [title]}
				self.titles['search'] = {'exact' : [title]}
			else:
				titleProcess(title, tvshowtitle)

			try: year = int(year)
			except: pass
			try: season = int(season)
			except: pass
			try: episode = int(episode)
			except: pass

			self.streamsTotal = 0
			self.streamsHdUltra = 0
			self.streamsHd1080 = 0
			self.streamsHd720 = 0
			self.streamsSd = 0
			self.streamsLd = 0
			self.streamsTorrent = 0
			self.streamsUsenet = 0
			self.streamsHoster = 0
			self.streamsCached = 0
			self.streamsDebrid = 0
			self.streamsDirect = 0
			self.streamsPremium = 0
			self.streamsLocal = 0

			self.skip = False
			self.providersLabels = None
			self.providersFinished = 0
			self.providersBusy = 0
			self.providersWait = -1
			self.streamsFinished = 0
			self.streamsBusy = 0
			self.streamsRunning = False

			self.startedThreads = False
			self.stopThreads = False
			self.finishedThreads = False
			self.threadsAdjusted = []
			self.sourcesAdjusted = []
			self.statusAdjusted = []
			self.priortityAdjusted = []

			labels = []

			self.threadsLock = Lock()
			self.dataLock = Lock()

			# Termination
			self.terminated = False
			self.termination = Termination()
			self.terminationLock = Lock()
			self.terminationEnabled = self.termination.enabled()
			if self.terminationEnabled:
				mode = self.termination.mode()
				self.terminationEnabled = (mode == Termination.ModeAny) or (mode == Termination.ModeOverwrite) or (mode == Termination.ModeManual and not autoplay) or (mode == Termination.ModeAutomatic and autoplay)

			self.unresponsiveEnabled = tools.Settings.getBoolean('scrape.termination.unresponsive')
			self.unresponsiveTime = tools.Settings.getCustom('scrape.termination.unresponsive.time')
			self.unresponsiveTimeLabel = tools.Settings.customLabel(id = 'scrape.termination.unresponsive.time', value = self.unresponsiveTime)
			self.unresponsiveLimit = tools.Settings.getCustom('scrape.termination.unresponsive.limit')
			self.unresponsiveLimitLabel = tools.Settings.customLabel(id = 'scrape.termination.unresponsive.limit', value = self.unresponsiveLimit)

			self.enabledDeveloper = tools.System.developer(version = False)
			self.enabledProviders = tools.Settings.getBoolean('interface.scrape.interface.providers')
			self.enabledTitle = ProviderBase.settingsGlobalTitleEnabled()
			self.enabledPack = ProviderBase.settingsGlobalPackEnabled()
			self.enabledCollection = ProviderBase.settingsGlobalPackMovie()
			self.enabledFailures = manager.Manager.failureEnabled()

			self.preloadEnabled = self.enabledDeveloper and tools.Settings.getBoolean('developer.preload.container')
			self.preloadEnabledTorrent = self.preloadEnabled and tools.Settings.getBoolean('developer.preload.container.torrent')
			self.preloadEnabledUsenet = self.preloadEnabled and tools.Settings.getBoolean('developer.preload.container.usenet')

			self.precheckLink = self.enabledDeveloper and tools.Settings.getBoolean('developer.precheck.link')
			self.precheckLinkTime = tools.Settings.getCustom('developer.precheck.link.time')
			if not self.precheckLinkTime: self.precheckLinkTime = 30
			self.precheckMetadata = self.enabledDeveloper and tools.Settings.getBoolean('developer.precheck.metadata')
			self.precheckMetadataTime = tools.Settings.getCustom('developer.precheck.metadata.time')
			if not self.precheckMetadataTime: self.precheckMetadataTime = 30

			self.cacheCount = 0
			self.cacheBusy = 0

			self.cacheEnabled = tools.Settings.getBoolean('scrape.cache.inspection')
			self.cacheEnabledPremiumize = self.cacheEnabled and tools.Settings.getBoolean('scrape.cache.inspection.premiumize')
			self.cacheEnabledOffcloud = self.cacheEnabled and tools.Settings.getBoolean('scrape.cache.inspection.offcloud')
			self.cacheEnabledRealdebrid = self.cacheEnabled and tools.Settings.getBoolean('scrape.cache.inspection.realdebrid')
			self.cacheTime = tools.Settings.getCustom('scrape.cache.inspection.time')
			self.cacheTimeLabel = tools.Settings.customLabel(id = 'scrape.cache.inspection.time', value = self.cacheTime)

			self.enabledExtra = self.cacheEnabled or self.precheckLink or self.precheckMetadata

			if self.cacheEnabled:
				try:
					self.cacheOrion = orionoid.Orionoid()
					if not self.cacheOrion.accountValid(): self.cacheOrion = None
				except:
					self.cacheOrion = None

				self.cacheTypes = []
				self.cacheObjects = []
				self.cacheThreads = []
				if self.cacheEnabledPremiumize:
					premiumizeCore = debrid.premiumize.Core()
					if premiumizeCore.accountValid():
						if tools.Settings.getBoolean('stream.premiumize.torrent'):
							self.cacheTypes.append(handler.Handler.TypeTorrent)
							self.cacheObjects.append(premiumizeCore)
						if tools.Settings.getBoolean('stream.premiumize.usenet') and (self.cacheOrion or self.preloadEnabledUsenet):
							self.cacheTypes.append(handler.Handler.TypeUsenet)
							self.cacheObjects.append(premiumizeCore)
						if tools.Settings.getBoolean('stream.premiumize.hoster'):
							self.cacheTypes.append(handler.Handler.TypeHoster)
							self.cacheObjects.append(premiumizeCore)
					else:
						self.cacheEnabledPremiumize = False
				if self.cacheEnabledOffcloud:
					offcloudCore = debrid.offcloud.Core()
					if offcloudCore.accountValid():
						if tools.Settings.getBoolean('stream.offcloud.torrent'):
							self.cacheTypes.append(handler.Handler.TypeTorrent)
							self.cacheObjects.append(offcloudCore)
						if tools.Settings.getBoolean('stream.offcloud.usenet') and (self.cacheOrion or self.preloadEnabledUsenet):
							self.cacheTypes.append(handler.Handler.TypeUsenet)
							self.cacheObjects.append(offcloudCore)
					else:
						self.cacheEnabledOffcloud = False
				if self.cacheEnabledRealdebrid:
					realdebridCore = debrid.realdebrid.Core()
					if realdebridCore.accountValid() and tools.Settings.getBoolean('stream.realdebrid.torrent'):
						self.cacheTypes.append(handler.Handler.TypeTorrent)
						self.cacheObjects.append(realdebridCore)
					else:
						self.cacheEnabledRealdebrid = False
				self.cacheEnabled = len(self.cacheTypes) > 0

			# Limit the number of running threads.
			# Can be more than actual core count, since threads in python are run on a single core.
			# Do not use too many, otherwise Kodi begins lagging (eg: the dialog is not updated very often, and the elapsed seconds are stuck).
			# NB: Do not use None (aka unlimited). If 500+ links are found, too many threads are started, causing a major delay by having to switch between threads. Use a limited number of threads.
			self.threadsLimit = tools.Hardware.processorCountCore() * 2 #gaiaremove - should this be increased?

			tools.File.makeDirectory(tools.System.profile())
			self.sourceFile = Database.pathProviders()

			self.progressTitleOriginal = 0
			self.progressTitleTranslation = 0
			self.progressTitleAlias = 0
			self.progressTitleCollection = 0

			self.progressPercentage = 0
			self.progressPercentageLast = 0

			percentageDone = 0
			percentageInitialize = 0.05
			percentageTitle = 0.05 if (self.enabledTitle or self.enabledCollection) else 0
			percentagePrecheck = 0.15 if self.precheckLink else 0
			percentageMetadata = 0.15 if self.precheckMetadata else 0
			percentageCache = 0.05 if self.cacheEnabled else 0
			percentageFinalizingStreams = 0.03
			percentageSaveStreams = 0.02
			percentageProviders = 1 - percentageInitialize - percentageTitle - percentagePrecheck - percentageMetadata - percentageCache - percentageFinalizingStreams - percentageSaveStreams - 0.01 # Subtract 0.01 to keep the progress bar always a bit empty in case provided sources something like 123 of 123, even with threads still running.

			self.mLastName = interface.Dialog.title(extension = '', bold = False)
			self.mLastMessage1 = ''
			self.mLastMessage2 = ''

			self.timeInitialize = 0
			self.timeTitle = 0
			self.timeScrape = 0
			self.timePrecheck = 0
			self.timeMetadata = 0
			self.timeFinalize = 0
			self.timeCache = 0
			self.timeSave = 0
			self.usage = None

			timer = tools.Time()
			timerSingle = tools.Time()
			timeStep = 0.5
			timeString = '%s ' + interface.Translation.string(32405)
			timeStringDescription = interface.Translation.string(32404) + ': ' + timeString

			heading = 'Stream Search'
			message = 'Initializing Providers'
			_progressShow(title = heading, message = message, metadata = metadata)
			self.loaderHide()
			timer.start()

			# Ensures that the elapsed time in the dialog is updated more frequently.
			# Otherwise the update is laggy if many threads run.
			timeThread = Pool.thread(target = _progressTime)
			timeThread.start()

			# Clear old sources from database.
			# Due to long links and metadata, the database entries can grow very large, not only wasting disk space, but also reducing search/insert times.
			# Delete old entries that will be ignored in any case.
			manager.Manager.databaseInitialize()

			message = 'Initializing Providers'
			_progressUpdate(0, message)

			self.skip = False
			specialAllow = False

			if (specialAllow or not self.progressCanceled()):
				timeout = 30 # Do not make this too low, since native titles retrival depends on this.
				message = 'Initializing Providers'
				thread = Pool.thread(target = initializeProviders, args = (media, preset, imdb, tvdb))

				thread.start()
				timerSingle.start()
				while True:
					try:
						if self.progressCanceled():
							specialAllow = False
							break
						if not thread.is_alive(): break
						_progressUpdate(int((min(1, timerSingle.elapsed() / float(timeout))) * percentageInitialize * 100), message)
						tools.Time.sleep(timeStep)
					except:
						tools.Logger.error()

				self.timeInitialize = timerSingle.elapsed()

			if len(self.providers) == 0 and (specialAllow or not self.progressCanceled()):
				if not self.silent: interface.Dialog.notification(message = 'No Providers Available', icon = interface.Dialog.IconError)
				self.stopProviders()
				tools.Time.sleep(0.3) # Ensure the time thread (0.2 interval) is stopped.
				if len(self.sourcesAdjusted) == 0: return None # Orion found a few links, but not enough, causing other providers to be searched.
			elif (not specialAllow and self.progressCanceled()):
				self.stopProviders()
				tools.Time.sleep(0.3) # Ensure the time thread (0.2 interval) is stopped.
				return None

			if not exact and (specialAllow or not self.progressCanceled()):
				percentageDone = percentageInitialize
				message = 'Retrieving Additional Titles'
				timeout = ProviderBase.settingsGlobalTitleTime()

				thread = Pool.thread(target = additionalTitle, args = (title, tvshowtitle, imdb, tvdb))
				thread.start()

				timerSingle.start()
				while True:
					try:
						if self.progressCanceled():
							specialAllow = False
							break
						if (not thread or not thread.is_alive()): break
						_progressUpdate(int((((self.progressTitleOriginal + self.progressTitleTranslation + self.progressTitleAlias + self.progressTitleCollection) / 3.0) * percentageTitle) + percentageDone), message)
						tools.Time.sleep(timeStep)
						if timerSingle.elapsed() >= timeout: break
					except:
						tools.Logger.error()

				self.timeTitle = timerSingle.elapsed()

				if not specialAllow and self.progressCanceled():
					self.stopProviders()
					tools.Time.sleep(0.3) # Ensure the time thread (0.2 interval) is stopped.
					return None

			# Finding Sources
			self.skip = True
			tools.Hardware.usageStart()

			threadProvider = Pool.thread(target = self.scrapeProviders, args = (threads, labels, self.providers, media, self.titles, year, premiered, imdb, tmdb, tvdb, season, episode, self.languageOriginal, self.count, duration, exact, cache))
			threadProvider.start()

			if (specialAllow or not self.progressCanceled()):
				percentageDone = percentageTitle + percentageInitialize
				message = 'Finding Stream Sources'
				stringInput1 = 'Processed Providers: %d of %d'
				stringInput2 = 'Providers: %d of %d'
				stringInput3 = interface.Format.newline() + 'Streams Found: %d'
				timeout = ProviderBase.settingsGlobalLimitTime()
				timerSingle.start()

				# Wait until providers were started, so that we can correctly calculate self.providersFinished.
				while not self.startedThreads and not self.stopThreads:
					if self.progressCanceled(): break
					if self.finishedThreads: break
					tools.Time.sleep(0.1)

				totalProviders = len(self.providers)

				unresponsiveTime = 0
				self.unresponsiveEnabled = self.unresponsiveEnabled and totalProviders > self.unresponsiveLimit # Ignore if only a few providers are enabled.

				while True:
					try:
						if self.progressCanceled():
							interface.Loader.show()
							specialAllow = True
							self.stopProviders()
							break
						if timerSingle.elapsed() >= timeout:
							tools.Logger.log('Scraping Timeout Reached', name = 'CORE', type = tools.Logger.TypeInfo)
							self.stopProviders()
							break
						if self.terminated:
							self.stopProviders()
							break

						totalThreads = len(threads)
						providersLabels = []
						if self.startedThreads and totalThreads > 0:
							self.providersLabels = []
							for x in range(totalThreads):
								if threads[x].is_alive():
									self.providersLabels.append(labels[x])
							providersLabels = self.providersLabels
						else:
							self.providersLabels = None

						busy = len(providersLabels)
						if self.stopThreads: self.providersBusy = 0
						else: self.providersBusy = busy + self.providersWait
						self.providersFinished = totalProviders - self.providersBusy

						if self.providersBusy == 0 and ((threadProvider and not threadProvider.is_alive()) or self.stopThreads):
							break

						if self.unresponsiveEnabled:
							if self.providersBusy <= self.unresponsiveLimit:
								unresponsiveTime += timeStep
								if unresponsiveTime >= self.unresponsiveTime:
									tools.Logger.log('Unresponsive Termination Triggered', name = 'CORE', type = tools.Logger.TypeInfo)
									break

						foundStreams = []
						if len(foundStreams) < 2 and self.streamsHdUltra > 0: foundStreams.append('%sx HDULTRA' % self.streamsHdUltra)
						if len(foundStreams) < 2 and self.streamsHd1080 > 0: foundStreams.append('%sx HD1080' % self.streamsHd1080)
						if len(foundStreams) < 2 and self.streamsHd720 > 0: foundStreams.append('%sx HD720' % self.streamsHd720)
						if len(foundStreams) < 2 and self.streamsSd > 0: foundStreams.append('%sx SD' % self.streamsSd)
						if len(foundStreams) < 2 and self.streamsLd > 0: foundStreams.append('%sx LD' % self.streamsLd)
						if len(foundStreams) > 0: foundStreams = ' [%s]' % (', '.join(foundStreams))
						else: foundStreams = ''

						percentage = int((((self.providersFinished / float(totalProviders)) * percentageProviders) + percentageDone) * 100)
						stringProvidersValue1 = stringInput1 % (self.providersFinished, totalProviders)
						stringProvidersValue2 = stringInput2 % (self.providersFinished, totalProviders)
						if self.enabledProviders and busy > 0: stringProvidersValue1 += ' [%s]' % (', '.join(providersLabels[:3]))
						stringProvidersValue1 += (stringInput3 % len(self.sourcesAdjusted)) + foundStreams
						_progressUpdate(percentage, message, stringProvidersValue1, stringProvidersValue2)

						tools.Time.sleep(timeStep)
					except:
						tools.Logger.error()
						break

				self.timeScrape = timerSingle.elapsed()
				self.usage = tools.Hardware.usageSop()

				# NB: Check in the end. In case the movie/episode is accessed on a subsequent run, it will be retrieved from the local cache database.
				# In such a case the early termination is not triggered.
				self.adjustTermination()

			self.skip = False
			self.providersLabels = []

			# Special handle for cancel on scraping. Allows to still inspect debrid cache after cancellation.
			if (specialAllow or not self.progressCanceled()):
				specialAllow = True
				if self.progressCanceled(): self.progressClose()
				tools.Time.sleep(0.2) # Important, otherwise close and open can clash.
				percentageDone = percentageTitle + percentageProviders + percentageInitialize
				message = 'Stopping Stream Collection'
				_progressShow(title = heading, message = message, metadata = metadata)
				_progressUpdate(percentageDone, message, ' ', ' ')
				interface.Loader.hide()

			# Failures
			# Do not detect failures if the scraping was canceled.
			if (specialAllow or not self.progressCanceled()) and self.enabledFailures:
				_progressUpdate(None, 'Detecting Provider Failures', ' ', ' ')
				threadsFinished = []
				threadsUnfinished = []
				for i in range(len(threads)):
					id = self.providers[i]['id']
					if threads[i].is_alive():
						threadsUnfinished.append(id)
					else:
						threadsFinished.append(id)
				manager.Manager.failureUpdate(finished = threadsFinished, unfinished = threadsUnfinished)

			del threads[:] # Make sure all providers are stopped.

			# Prechecks
			if (specialAllow or not self.progressCanceled()) and self.precheckLink:
				percentageDone = percentageTitle + percentageProviders + percentageInitialize
				message = 'Checking Stream Availability'
				stringInput1 = 'Processed Streams: %d of %d'
				stringInput2 = 'Streams: %d of %d'
				timeout = self.precheckLinkTime
				timerSingle.start()

				while True:
					try:
						if self.progressCanceled():
							specialAllow = False
							break
						if timerSingle.elapsed() >= timeout:
							break

						totalThreads = self.cacheCount + len(self.threadsAdjusted)
						aliveCount = len([x for x in self.threadsAdjusted if x.is_alive()])
						self.streamsFinished = self.cacheCount + len([x for x in self.statusAdjusted if x == 'done'])
						self.streamsBusy = totalThreads - self.streamsFinished

						if aliveCount == 0: break

						percentage = int((((self.streamsFinished / float(totalThreads)) * percentagePrecheck) + percentageDone) * 100)
						stringSourcesValue1 = stringInput1 % (self.streamsFinished, totalThreads)
						stringSourcesValue2 = stringInput2 % (self.streamsFinished, totalThreads)
						_progressUpdate(percentage, message, stringSourcesValue1, stringSourcesValue2)

						tools.Time.sleep(timeStep)
					except:
						tools.Logger.error()
						break

				self.timePrecheck = timerSingle.elapsed()

			# Metadata
			if (specialAllow or not self.progressCanceled()) and self.precheckMetadata:
				percentageDone = percentagePrecheck + percentageTitle + percentageProviders + percentageInitialize
				message = 'Checking Additional Metadata'
				stringInput1 = 'Processed Streams: %d of %d'
				stringInput2 = 'Streams: %d of %d'
				timeout = self.precheckMetadataTime
				timerSingle.start()

				while True:
					try:
						if self.progressCanceled():
							specialAllow = False
							break
						if timerSingle.elapsed() >= timeout:
							break

						totalThreads = self.cacheCount + len(self.threadsAdjusted)
						aliveCount = len([x for x in self.threadsAdjusted if x.is_alive()])
						self.streamsFinished = self.cacheCount + len([x for x in self.statusAdjusted if x == 'done'])
						self.streamsBusy = totalThreads - self.streamsFinished

						if aliveCount == 0: break

						percentage = int((((self.streamsFinished / float(totalThreads)) * percentageMetadata) + percentageDone) * 100)
						stringSourcesValue1 = stringInput1 % (self.streamsFinished, totalThreads)
						stringSourcesValue2 = stringInput2 % (self.streamsFinished, totalThreads)
						_progressUpdate(percentage, message, stringSourcesValue1, stringSourcesValue2)

						tools.Time.sleep(timeStep)
					except:
						tools.Logger.error()
						break

				self.timeMetadata = timerSingle.elapsed()

			# Finalizing Providers
			# Wait for all the source threads to complete.
			# This is especially important if there are not prechecks, metadata, or debrid cache inspection, and a provider finishes with a lot of streams just before the timeout.
			if specialAllow or not self.progressCanceled():
				percentageDone = percentageMetadata + percentagePrecheck + percentageTitle + percentageProviders + percentageInitialize
				message = 'Finalizing Stream Collection'
				stringInput1 = 'Processed Streams: %d of %d'
				stringInput2 = 'Streams: %d of %d'
				timeout = 60 # Can take some while for a lot of streams.
				unfinishedCounter = 0
				timerSingle.start()

				while True:
					try:
						elapsedTime = timerSingle.elapsed()
						if self.progressCanceled() or elapsedTime >= timeout:
							break

						totalThreads = self.cacheCount + len(self.threadsAdjusted)
						self.streamsFinished = self.cacheCount + len([x for x in self.statusAdjusted if x == 'done'])
						self.streamsBusy = totalThreads - self.streamsFinished

						if self.streamsBusy == 0: break

						# Sometimes adjusting is stuck on processing a few remaining links (eg: 2 links).
						# If less than 1% of links are busy, do not wait for the full timeout.
						if self.streamsBusy <= 3 or (self.streamsBusy / float(totalThreads)) < 0.01:
							unfinishedCounter += 1
							if unfinishedCounter >= (15 / timeStep): break # 15 secs.
						self.adjustSourceStart() # Sometimes there is just 1 unfinished stream adjustment (not sure why). Maybe this helps.

						percentage = int((((elapsedTime / float(timeout)) * percentageFinalizingStreams) + percentageDone) * 100)
						stringSourcesValue1 = stringInput1 % (self.streamsFinished, totalThreads)
						stringSourcesValue2 = stringInput2 % (self.streamsFinished, totalThreads)
						_progressUpdate(percentage, message, stringSourcesValue1, stringSourcesValue2)

						tools.Time.sleep(timeStep)
					except:
						tools.Logger.error()
						break

				self.timeFinalize = timerSingle.elapsed()

			# Debrid Cache
			if (specialAllow or not self.progressCanceled()) and self.cacheEnabled:
				percentageDone = percentageFinalizingStreams + percentageMetadata + percentagePrecheck + percentageTitle + percentageProviders + percentageInitialize
				message = 'Inspecting Debrid Cache'
				stringInput1 = ' ' # Must have space to remove line.
				stringInput2 = 'Inspecting Debrid Cache'
				timeout = self.cacheTime
				timerSingle.start()

				thread = Pool.thread(target = self.adjustSourceCache, args = (timeout, False))
				thread.start()
				while True:
					try:
						elapsedTime = timerSingle.elapsed()
						if self.progressCanceled():
							specialAllow = False
							break
						if elapsedTime >= timeout:
							break
						if not thread.is_alive():
							if not self.cacheBusy: break

						percentage = int((((elapsedTime / float(timeout)) * percentageCache) + percentageDone) * 100)
						_progressUpdate(percentage, message, stringInput1, stringInput2)

						tools.Time.sleep(timeStep)
					except:
						tools.Logger.error()
						break

				self.timeCache = timerSingle.elapsed()

			# Finalizing Streams

			percentageDone = percentageFinalizingStreams + percentageMetadata + percentagePrecheck + percentageTitle + percentageProviders + percentageCache + percentageInitialize
			message = 'Saving Streams'
			stringInput1 = ' ' # Must have space to remove line.
			stringInput2 = 'Saving Streams'
			timeout = 15
			timerSingle.start()
			thread = Pool.thread(target = self.adjustSourceDatabase) # Update Database
			thread.start()

			if not self.progressCanceled(): # The thread is still running in the background, even if the dialog was canceled previously.
				while True:
					try:
						elapsedTime = timerSingle.elapsed()
						if not thread.is_alive():
							break
						if self.progressCanceled() or elapsedTime >= timeout:
							break

						percentage = int((((elapsedTime / float(timeout)) * percentageSaveStreams) + percentageDone) * 100)
						_progressUpdate(percentage, message, stringInput1, stringInput2)

						tools.Time.sleep(timeStep)
					except:
						tools.Logger.error()
						break

				self.timeSave = timerSingle.elapsed()

			# Sources
			self.sources = self.sourcesAdjusted
			for i in range(len(self.sources)):
				self.sources[i]['kids'] = self.kids
				self.sources[i]['type'] = self.type
				# Required by handler for selecting the correct episode from a season pack.
				# Do not use the name 'metadata', since that is checked in sourceResolve().
				self.sources[i]['information'] = metadata

			self.stopThreads = True
			tools.Time.sleep(0.3) # Ensure the time thread (0.2 interval) is stopped.

			_progressUpdate(100, 'Preparing Streams', ' ', ' ', showElapsed = False)

			# Clear because member variable.
			self.threadsAdjusted = []
			self.sourcesAdjusted = []
			self.statusAdjusted = []
			self.priortityAdjusted = []

			return self.sources
		except:
			tools.Logger.error()
			return None

	def scrapeStatistics(self):
		try:
			from lib.modules.convert import ConverterDuration
			items = []

			# Summary

			duration = ConverterDuration(self.timerGlobal.elapsed(), unit = ConverterDuration.UnitSecond).string(format = ConverterDuration.FormatInitialShort).lower()
			items1 = [
				{'label' : 'Scrape Title', 'value' : self.scrapeLabel},
				{'label' : 'Scrape Duration', 'value' : duration},
				{'label' : 'Provider Count', 'value' : len(self.providers)},
				{'label' : 'Stream Count', 'value' : self.filter['final'] if self.filter and 'final' in self.filter else 0},
			]
			items.append({'section' : 'Summary', 'items' : items1, 'align' : True, 'empty' : True})

			# Duration

			items2 = [
				{'label' : 'Provider Initialize Duration', 'value' : ConverterDuration(self.timeInitialize, unit = ConverterDuration.UnitSecond).string(format = ConverterDuration.FormatInitialShort).lower()},
				{'label' : 'Title Retrieve Duration', 'value' : ConverterDuration(self.timeTitle, unit = ConverterDuration.UnitSecond).string(format = ConverterDuration.FormatInitialShort).lower()},
				{'label' : 'Provider Scrape Duration', 'value' : ConverterDuration(self.timeScrape, unit = ConverterDuration.UnitSecond).string(format = ConverterDuration.FormatInitialShort).lower()},
				{'label' : 'Stream Precheck Duration', 'value' : ConverterDuration(self.timePrecheck, unit = ConverterDuration.UnitSecond).string(format = ConverterDuration.FormatInitialShort).lower()},
				{'label' : 'Stream Metadata Duration', 'value' : ConverterDuration(self.timeMetadata, unit = ConverterDuration.UnitSecond).string(format = ConverterDuration.FormatInitialShort).lower()},
				{'label' : 'Stream Finalize Duration', 'value' : ConverterDuration(self.timeFinalize, unit = ConverterDuration.UnitSecond).string(format = ConverterDuration.FormatInitialShort).lower()},
				{'label' : 'Debrid Cache Duration', 'value' : ConverterDuration(self.timeCache, unit = ConverterDuration.UnitSecond).string(format = ConverterDuration.FormatInitialShort).lower()},
				{'label' : 'Stream Save Duration', 'value' : ConverterDuration(self.timeSave, unit = ConverterDuration.UnitSecond).string(format = ConverterDuration.FormatInitialShort).lower()},
			]
			items1 = [{'label' : 'Total Duration', 'value' : duration, 'items' : items2}]
			items.append({'section' : 'Duration', 'items' : items1, 'align' : True, 'empty' : True})

			# Hardware

			items1 = [
				{'label' : 'Processor Utilized', 'value' : self.usage['processor']['label'] if self.usage else 'Unknown'},
				{'label' : 'Memory Utilized', 'value' : self.usage['memory']['label'] if self.usage else 'Unknown'},
			]
			items.append({'section' : 'Hardware', 'items' : items1, 'align' : True, 'empty' : True})

			# Providers

			labelLength = 0
			queryHas = False
			for provider in self.providers:
				length = len(provider.name())
				if length > labelLength: labelLength = length
				for query in provider.statistics()['search'].keys():
					if query:
						queryHas = True
						length = len(query)
						if length > labelLength: labelLength = length
			if queryHas and labelLength: labelLength += 3 # Quotes + colon

			items1 = []
			for provider in tools.Tools.listSort(self.providers, key = lambda i : i.name().lower()):
				statistics = provider.statistics()

				items2 = []
				for query, data in statistics['search'].items():
					if data['cache']: label = 'Cached'
					elif query: label = '"%s"' % query
					else: label = 'Default' # For providers other than web.py.
					duration = ConverterDuration(data['duration'], unit = ConverterDuration.UnitMillisecond).string(format = ConverterDuration.FormatInitialFixed, unit = ConverterDuration.UnitSecond).lower().ljust(3)
					value = 'Duration: %s | Streams: %s | Queries: %s | Pages: %s | Requests: %s' % (duration, str(data['stream']).ljust(4), str(data['query']).ljust(2), str(data['page']).ljust(2), str(data['request']).ljust(3))
					items2.append({'label' : label, 'value' : value, 'level' : tools.Logger.LevelExtended})

				duration = ConverterDuration(statistics['duration'], unit = ConverterDuration.UnitMillisecond).string(format = ConverterDuration.FormatInitialFixed, unit = ConverterDuration.UnitSecond).lower().ljust(3)
				value = 'Duration: %s | Streams: %s | Queries: %s | Pages: %s | Requests: %s' % (duration, str(statistics['stream']).ljust(4), str(statistics['query']).ljust(2), str(statistics['page']).ljust(2), str(statistics['request']).ljust(3))
				if items2: items1.append({'label' : provider.name(), 'value' : value, 'items' : items2}) # Check if there are items2, to remove providers that did not search (eg: searched movie, but the provider can only search shows).

			items.append({'section' : 'Providers', 'items' : items1, 'align' : True, 'empty' : True})

			# Metadata

			statistics = Stream.statisticsSummary()
			items1 = []
			labelLength = 0
			for type in [Stream.StatisticGlobal, Stream.StatisticExtracted, Stream.StatisticCached, Stream.StatisticFailed]:
				length = len(type)
				if length > labelLength: labelLength = length
			labelLength += 1
			for type in [Stream.StatisticGlobal, Stream.StatisticExtracted, Stream.StatisticCached, Stream.StatisticFailed]:
				total = ConverterDuration(statistics[type]['total'], unit = ConverterDuration.UnitMillisecond).string(format = ConverterDuration.FormatInitialShort).lower().ljust(6)
				average = ConverterDuration(statistics[type]['average'], unit = ConverterDuration.UnitMillisecond).string(format = ConverterDuration.FormatInitialFixed, unit = ConverterDuration.UnitMillisecond).lower().ljust(5)
				minimum = ConverterDuration(statistics[type]['minimum'], unit = ConverterDuration.UnitMillisecond).string(format = ConverterDuration.FormatInitialFixed, unit = ConverterDuration.UnitMillisecond).lower()
				maximum = ConverterDuration(statistics[type]['maximum'], unit = ConverterDuration.UnitMillisecond).string(format = ConverterDuration.FormatInitialFixed, unit = ConverterDuration.UnitMillisecond).lower()
				value = 'Streams: %s | Total Duration: %s | Average Duration: %s (%s - %s)' % (str(statistics[type]['count']).ljust(4), total, average, minimum, maximum)
				items1.append({'label' : type.capitalize(), 'value' : value})
			items.append({'section' : 'Metadata', 'items' : items1, 'align' : True, 'empty' : True})

			# Filter

			count = 0
			filters = [
				['initial', 'Count Initial Before Filtering'],
				['duplicate', 'Count After Duplicates Removal'],
				['support', 'Count After Unsupported Removal'],
				['blocked', 'Count After Blocked Removal'],
				['captcha', 'Count After Captcha Removal'],
				['precheck', 'Count After Precheck Removal'],
				['filter', 'Count After Stream Filtering'],
				['limit', 'Count After Stream Limiting'],
				['final', 'Count Final After Filtering'],
			]
			items2 = []
			if self.filter:
				for i in filters:
					if not self.filter[i[0]] is None: count = self.filter[i[0]]
					items2.append({'label' : i[1], 'value' : count})
			items1 = [{'label' : 'Stream Count', 'value' : count, 'items' : items2}]
			items.append({'section' : 'Filters', 'items' : items1, 'align' : True, 'empty' : True})

			# Settings

			enabled = 'Enabled'
			disabled = 'Disabled'
			unlimited = 'Unlimited'
			full = 'Full'
			quick = 'Quick'
			items1 = []

			items2 = [
				{'label' : 'Time Limit', 'value' : ProviderBase.settingsGlobalLimitTimeLabel()},
				{'label' : 'Page Limit', 'value' : ProviderBase.settingsGlobalLimitPagesLabel()},
				{'label' : 'Request Limit', 'value' : ProviderBase.settingsGlobalLimitRequestsLabel()},
			]
			items1.append({'label' : 'Limits', 'items' : [i for i in items2 if not i is None]})

			items2 = [
				{'label' : 'Concurrency Mode', 'value' : ProviderBase.settingsGlobalConcurrencyModeLabel()},
				{'label' : 'Concurrency Limit', 'value' : ProviderBase.settingsGlobalConcurrencyLimitLabel()},
			]
			items1.append({'label' : 'Concurrency', 'items' : [i for i in items2 if not i is None]})

			packEnabled = ProviderBase.settingsGlobalPackEnabled()
			items2 = [
				{'label' : 'Pack Scraping', 'value' : enabled if packEnabled else disabled},
				{'label' : 'Movie Packs', 'value' : enabled if ProviderBase.settingsGlobalPackMovie() else disabled} if packEnabled else None,
				{'label' : 'Show Packs', 'value' : enabled if ProviderBase.settingsGlobalPackShow() else disabled} if packEnabled else None,
				{'label' : 'Season Packs', 'value' : enabled if ProviderBase.settingsGlobalPackSeason() else disabled} if packEnabled else None,
			]
			items1.append({'label' : 'Packs', 'items' : [i for i in items2 if not i is None]})

			titleEnabled = ProviderBase.settingsGlobalTitleEnabled()
			items2 = [
				{'label' : 'Alternative Titles', 'value' : enabled if titleEnabled else disabled},
				{'label' : 'Time Limit', 'value' : ProviderBase.settingsGlobalTitleTimeLabel()} if titleEnabled else None,
				{'label' : 'Title Limit', 'value' : ProviderBase.settingsGlobalTitleLimit()} if titleEnabled else None,
				{'label' : 'Special Characters', 'value' : enabled if ProviderBase.settingsGlobalTitleCharacter() else disabled} if titleEnabled else None,
				{'label' : 'Original Title', 'value' : enabled if ProviderBase.settingsGlobalTitleOriginal() else disabled} if titleEnabled else None,
				{'label' : 'Native Title', 'value' : enabled if ProviderBase.settingsGlobalTitleNative() else disabled} if titleEnabled else None,
				{'label' : 'Local Title', 'value' : enabled if ProviderBase.settingsGlobalTitleLocal() else disabled} if titleEnabled else None,
				{'label' : 'Alias Titles', 'value' : enabled if ProviderBase.settingsGlobalTitleAlias() else disabled} if titleEnabled else None,
				{'label' : 'Title Language', 'value' : tools.Language.name(ProviderBase.settingsGlobalTitleLanguage())} if titleEnabled and (ProviderBase.settingsGlobalTitleLocal() or ProviderBase.settingsGlobalTitleAlias()) else None,
			]
			items1.append({'label' : 'Titles', 'items' : [i for i in items2 if not i is None]})

			keywordEnabled = ProviderBase.settingsGlobalKeywordEnabled()
			items2 = [
				{'label' : 'Alternative Keywords', 'value' : enabled if keywordEnabled else disabled},
				{'label' : 'English Keywords', 'value' : quick if ProviderBase.settingsGlobalKeywordEnglish() == 1 else full if ProviderBase.settingsGlobalKeywordEnglish() == 2 else disabled} if keywordEnabled else None,
				{'label' : 'Native Keywords', 'value' : quick if ProviderBase.settingsGlobalKeywordNative() == 1 else full if ProviderBase.settingsGlobalKeywordNative() == 2 else disabled} if keywordEnabled else None,
				{'label' : 'Custom Keywords', 'value' : quick if ProviderBase.settingsGlobalKeywordCustom() == 1 else full if ProviderBase.settingsGlobalKeywordCustom() == 2 else disabled} if keywordEnabled else None,
				{'label' : 'Keyword Language', 'value' : tools.Language.name(ProviderBase.settingsGlobalKeywordLanguage())} if keywordEnabled and ProviderBase.settingsGlobalKeywordCustom() > 0 else None,
			]
			items1.append({'label' : 'Keywords', 'items' : [i for i in items2 if not i is None]})

			mirrorEnabled = ProviderBase.settingsGlobalMirrorEnabled()
			unblockEnabled = ProviderBase.settingsGlobalUnblockEnabled()
			items2 = [
				{'label' : 'Mirror Domains', 'value' : enabled if mirrorEnabled else disabled},
				{'label' : 'Mirror Limit', 'value' : ProviderBase.settingsGlobalMirrorLimit()} if mirrorEnabled else None,
				{'label' : 'Mirror Unlock', 'value' : enabled if unblockEnabled else disabled},
				{'label' : 'Mirror Service', 'value' : ProviderBase.settingsGlobalUnblockType()} if unblockEnabled else None,
			]
			items1.append({'label' : 'Mirrors', 'items' : [i for i in items2 if not i is None]})

			preemptionEnabled = Termination.settingsEnabled()
			items2 = [
				{'label' : 'Preemptive Termination', 'value' : enabled if preemptionEnabled else disabled},
				{'label' : 'Termination Mode', 'value' : Termination.settingsMode().capitalize()} if preemptionEnabled else None,
				{'label' : 'Unresponsive Termination', 'value' : enabled if self.unresponsiveEnabled else disabled},
				{'label' : 'Time Limit', 'value' : self.unresponsiveTimeLabel} if self.unresponsiveEnabled else None,
				{'label' : 'Provider Limit', 'value' : self.unresponsiveLimitLabel} if self.unresponsiveEnabled else None,
			]
			items1.append({'label' : 'Termination', 'items' : [i for i in items2 if not i is None]})

			failureEnabled = manager.Manager.failureEnabled()
			items2 = [
				{'label' : 'Failure Detection', 'value' : enabled if failureEnabled else disabled},
				{'label' : 'Failure Limit', 'value' : manager.Manager.failureLimit()} if failureEnabled else None,
				{'label' : 'Retry Delay', 'value' : manager.Manager.failureTimeLabel()} if failureEnabled else None,
			]
			items1.append({'label' : 'Failures', 'items' : [i for i in items2 if not i is None]})

			items2 = [
				{'label' : 'Cache Inspection', 'value' : enabled if self.cacheEnabled else disabled},
				{'label' : 'Time Limit', 'value' : self.cacheTimeLabel} if self.cacheEnabled else None,
				{'label' : 'Premiumize Inspection', 'value' : enabled if self.cacheEnabledPremiumize else disabled} if self.cacheEnabled else None,
				{'label' : 'Offcloud Inspection', 'value' : enabled if self.cacheEnabledOffcloud else disabled} if self.cacheEnabled else None,
				{'label' : 'Realdebrid Inspection', 'value' : enabled if self.cacheEnabledRealdebrid else disabled} if self.cacheEnabled else None,
			]
			items1.append({'label' : 'Cache', 'items' : [i for i in items2 if not i is None]})

			items2 = [
				{'label' : 'Developer Options', 'value' : enabled if tools.System.developer(version = False) else disabled},
			]
			items1.append({'label' : 'Developer', 'items' : [i for i in items2 if not i is None]})

			items.append({'section' : 'Settings', 'items' : items1, 'align' : True, 'empty' : True})

			tools.Logger.details(title = 'Scrape Statistics', items = items)
		except: tools.Logger.error()

	def scrapeProviders(self, threads, labels, providers, media, titles, year, premiered, imdb, tmdb, tvdb, season, episode, language, count, duration, exact, cache):
		#cache = False#gaiaremove - gaiaremove - gaiaremove

		ProviderBase.concurrencyInitialize()

		# gaiaremove - sort first by priority and then secondary/internal by provider rank. This will allow better proivders tro execute first if the "concurrency limit" was set."
		# gaiaremove - maybe a combination of prioerity + rank + performance.
		# gaiaremove - change the provider performance to a float. Maybe rename it to soemthing better (inverse of performance).

		# Randomize the provider order.
		# In case a concurrency limit is used (not all providers are started at the same time), some providers that take longer than others might always start last and then just unnecessarily increase the scraping time.
		# If shuffeled, these slow providers will not always be last, but sometimes are executed first.
		providers = tools.Tools.listShuffle(providers)

		priorityMaximum = 0
		for provider in providers:
			priority = provider.scrapePriority()
			if priority: priorityMaximum = max(priorityMaximum, priority)

		providersPriority = [[] for i in range(priorityMaximum + 1)]
		providersNone = []
		for provider in providers:
			priority = provider.scrapePriority()
			if priority is None: providersNone.append(provider)
			else: providersPriority[priority].append(provider)
		providersPriority = [provider for provider in providersPriority if provider]
		providersPriority.append(providersNone)
		self.providersWait = sum([len(sub) for sub in providersPriority])

		self.finishedThreads = False
		for sub in providersPriority:
			if not self.stopThreads:
				threadsSub = []
				for provider in sub:
					thread = Pool.thread(target = self.scrapeProvider, args = (provider, media, titles, year, premiered, imdb, tmdb, tvdb, season, episode, language, count, duration, exact, cache))
					threadsSub.append(thread)
					threads.append(thread)
					labels.append(provider.label())

				totalSub = len(threadsSub)
				[thread.start() for thread in threadsSub]
				self.providersWait -= totalSub
				self.startedThreads = True
				[thread.join() for thread in threadsSub]
				self.startedThreads = False

		# If a single provider is scraped a second time, just retrieving thyew results from cache, "startedThreads" is set to True and then immediately  to False.
		# The GUI can then get stuck on "Providers Started", because the value of the variable is set to False again.
		# Use a second variable to indicate everything is done.
		self.finishedThreads = True

	def scrapeProvider(self, provider, media, titles, year, premiered, imdb, tmdb, tvdb, season, episode, language, count, duration, exact, cache):
		try:
			streams = provider.execute(
				media = media,
				titles = titles,
				year = year,
				date = premiered,

				idImdb = imdb,
				idTmdb = tmdb,
				idTvdb = tvdb,

				numberSeason = season,
				numberEpisode = episode,

				language = language,
				count = count,
				duration = duration,

				exact = exact,
				silent = self.silent,
				cacheLoad = cache,

				hostersAll = self.hosters(),
				hostersPremium = self.hostersPremium(),
			)

			streamsCache = []
			streamsScrape = []
			if streams:
				for stream in streams:
					if stream['stream'].infoCache(): streamsCache.append(stream)
					else: streamsScrape.append(stream)

				self.addSources(streamsCache, False)
				self.addSources(streamsScrape, True)

			termination = provider.scrapeTermination()
			if termination and len(streams) > termination:
				self.stopThreads = True
				tools.Logger.log('Enough links found. Provider termination triggered (%s).' % provider.label(), name = 'CORE', type = tools.Logger.TypeInfo)
		except:
			tools.Logger.error()

	def stopProviders(self):
		self.stopThreads = True
		for provider in self.providers:
			provider.stop()

	def addLink(self, link = None, extras = None, metadata = None):
		if not link:
			interface.Loader.hide()
			link = interface.Dialog.input(title = 35434)

		interface.Loader.show()
		item = None
		if link:
			if metadata == None:
				metadata = window.Window.propertyGlobal(self.propertyMeta)
				metadata = tools.Converter.jsonFrom(metadata)
			elif tools.Tools.isString(metadata):
				metadata = tools.Converter.jsonFrom(network.Networker.linkUnquote(metadata))

			try: title = metadata['tvshowtitle']
			except:
				try: title = metadata['title']
				except: title = None
			try: year = metadata['year']
			except: year = None
			try: season = metadata['season']
			except: season = None
			try: episode = metadata['episode']
			except: episode = None

			container = network.Container(link)
			if container.torrentIs(): sourceType = Stream.SourceTypeTorrent
			elif container.usenetIs(): sourceType = Stream.SourceTypeUsenet
			elif network.Networker.linkIsLocal(link) or re.search('^(\/|file|[a-z]:)', link, re.IGNORECASE) or tools.File.samba(link) or tools.File.exists(link): sourceType = Stream.SourceTypeLocal
			else: sourceType = Stream.SourceTypeHoster

			stream = Stream(
				validate = False,
				metaTitle = title, metaYear = year, metaSeason = season, metaEpisode = episode,
				link = link,
				sourceType = sourceType, sourceOrigin = tools.System.name(), sourceProvider = 'Custom',
				accessDirect = sourceType == Stream.SourceTypeLocal,
				infoCustom = True,
			)
			stream.videoQualitySet(value = Stream.VideoQualityHdUltra, extract = False)
			item = {'stream' : stream}

		if extras == None:
			extras = window.Window.propertyGlobal(self.propertyExtras)
			extras = tools.Converter.jsonFrom(extras)
		elif tools.Tools.isString(extras):
			extras = tools.Converter.jsonFrom(network.Networker.linkUnquote(extras))
		if not extras: extras = []
		if item: extras.append(item)
		extras = self.sourcesPrepare(items = extras)

		jsonExtras = tools.Tools.copy(extras)
		window.Window.propertyGlobalSet(self.propertyExtras, tools.Converter.jsonTo(jsonExtras))

		interface.Loader.show()
		self.showStreams(extras = extras, metadata = metadata, autoplay = False, add = True)

	def filterStreams(self):
		filters = Filters()
		data = tools.Tools.copy(filters.data()) # Make a copy, otherwise this dictionary is changed as well.
		filters.show()
		if not filters.data() == data: # Only reload if the filters have changed.
			interface.Loader.show()
			self.showStreams()

	def showStreams(self, items = None, extras = None, metadata = None, direct = False, filter = True, autoplay = False, clear = False, library = False, initial = False, new = True, add = False, process = True, binge = None):
		try:
			if clear: self._showClear()

			if items == None:
				items = window.Window.propertyGlobal(self.propertyItems)
				items = tools.Converter.jsonFrom(items)

				# Important for History Streams window.
				# Otherwise the items are processed id the window is reloaded.
				process = tools.Converter.boolean(window.Window.propertyGlobal(self.propertyProcess))
			elif tools.Tools.isString(items):
				items = tools.Converter.jsonFrom(network.Networker.linkUnquote(items))

			if not process: autoplay = False

			if self.navigationScrapeDialog and self.navigationStreamsDirectory:
				# Important to close here and not later.
				self.progressClose(loader = self.navigationStreamsSpecial and new and not autoplay)

			if not direct and self.navigationStreamsDirectory and not(self.navigationCinema and autoplay):
				return self._showStreamsDirectory(filter = filter and (new or binge), autoplay = autoplay, library = library, initial = initial, new = new, add = add, process = process, binge = binge)

			if extras == None:
				extras = window.Window.propertyGlobal(self.propertyExtras)
				extras = tools.Converter.jsonFrom(extras)
			elif tools.Tools.isString(extras):
				extras = tools.Converter.jsonFrom(network.Networker.linkUnquote(extras))

			if (items == None or len(items) == 0) and (extras == None or len(extras) == 0):
				if new: self.progressNotification(loader = True)
				return False

			if metadata == None:
				metadata = window.Window.propertyGlobal(self.propertyMeta)
				metadata = tools.Converter.jsonFrom(metadata)
			elif tools.Tools.isString(metadata):
				metadata = tools.Converter.jsonFrom(network.Networker.linkUnquote(metadata))

			itemsFiltered = []
			if items:
				for i in range(len(items)):
					items[i]['stream'] = Stream.load(data = items[i]['stream'])
				if filter:
					if process: itemsFiltered = self.sourcesFilter(items = items, metadata = metadata, autoplay = autoplay)
					else: itemsFiltered = items
					if len(itemsFiltered) == 0:
						if not new or self.progressNotification():
							return self.showStreams(items = items, extras = extras, metadata = metadata, direct = False if autoplay else True, library = library, filter = False, autoplay = False, clear = True, new = new, add = add, binge = binge)
						else:
							self.progressClose(force = True, loader = self.navigationStreamsSpecial and new and not autoplay)
							return False
				else:
					if process: itemsFiltered = self.sourcesFilter(items = items, metadata = metadata, apply = False, autoplay = False)
					else: itemsFiltered = items
				itemsFiltered = self.sourcesLabel(items = itemsFiltered, metadata = metadata)

			if extras:
				for i in range(len(extras)):
					extras[i]['stream'] = Stream.load(data = extras[i]['stream'])
				itemsFiltered = extras + itemsFiltered

			if autoplay:
				result = self._showAutoplay(items = itemsFiltered, metadata = metadata, binge = binge)
				if result:
					self.progressClose(force = True)
					return result
				else:
					return self.showStreams(items = items, extras = extras, metadata = metadata, direct = True, library = library, filter = False, autoplay = False, clear = True, new = new, add = add, binge = binge)

			if self.navigationStreamsDialogDetailed or self.navigationStreamsDialogPlain:
				self.loaderShow()
				if new: self.progressNotification()
			result = self._showStreams(items = itemsFiltered, metadata = metadata, initial = initial, library = library, add = add, binge = binge)
			if not(self.navigationStreamsDialogDetailed or self.navigationStreamsDialogPlain):
				if new: self.progressNotification()

			self.progressClose(force = True, loader = self.navigationStreamsSpecial and new)
			return result
		except:
			tools.Logger.error()
			self.progressClose(force = True)
			return None

	def _showClear(self, filter = False, autoplay = False):
		Filters.clear()

	def _showStreamsDirectory(self, filter = False, autoplay = False, library = False, initial = False, new = True, add = False, process = True, binge = None):
		try:
			if not self.navigationCinema: self.loaderShow()
			tools.Time.sleep(0.2)
			# NB: Use "filterx" and not "filter" as parameters.
			# Otherwise for some weird reason the back button in the directory does not work.
			# Maybe Kodi uses that parameter name internally (eg: left side menu "Filter" option).
			command = '%s?action=streamsShow&direct=%d&filterx=%d&autoplay=%d&library=%d&initial=%d&new=%d&add=%d&process=%d&binge=%d' % (sys.argv[0], True, filter, autoplay, library, initial, new, add, process, int(binge))
			command = self.parameterize(command)
			self.progressClose(force = True, loader = False) # Important to close to free up window memory, since Container.Update is in a separate process which does not know the window anymore.
			if not self.navigationCinema: self.loaderShow()
			if self.navigationCinema and not autoplay: self.navigationCinemaTrailer.cinemaStop() # Must happen here, otherwise the player won't stop.
			if autoplay: result = tools.System.execute('RunPlugin(%s)' % command)
			else: result = tools.System.execute('Container.Update(%s)' % command)
			return result
		except:
			tools.Logger.error()
			return None

	def _showStreams(self, items = None, metadata = None, library = False, initial = False, add = False, binge = None):
		# Exclude attributes to save some space in the interface.
		# Also exclude the title, otherwise Kodi 19 shows the tittle attribute from the metadaata, instead of the custom label.
		metadataKodi = tools.Media.metadataClean(metadata, exclude = True)

		sysaddon = sys.argv[0]
		syshandle = int(sys.argv[1])
		sysmeta = tools.Converter.quoteTo(tools.Converter.jsonTo(metadata))

		hasFanart = tools.Settings.getBoolean('interface.theme.artwork')
		addonPoster = Theme.poster()
		addonBanner = Theme.banner()
		addonFanart = Theme.fanart()

		total = len(items)
		try: multi = 'meta' in items[0]
		except: multi = False

		try: title = metadata['tvshowtitle']
		except:
			try: title = metadata['originaltitle']
			except:
				try: title = metadata['title']
				except: title = ''

		try: year = metadata['year']
		except: year = None
		try: season = metadata['season']
		except: season = None
		try: episode = metadata['episode']
		except: episode = None

		try: imdb = metadata['imdb']
		except: imdb = None
		try: tmdb = metadata['tmdb']
		except: tmdb = None
		try: tvdb = metadata['tvdb']
		except: tvdb = None
		id = '' if multi else tools.Hash.sha1((imdb if imdb else tmdb if tmdb else tvdb if tvdb else sysmeta) + '_' + str(season) + '_' + str(episode) + '_' + str(total))

		try: poster = metadata['poster'] if 'poster' in metadata else metadata['poster2'] if 'poster2' in metadata else metadata['poster3'] if 'poster3' in metadata else None
		except: poster = None
		try: fanart = metadata['fanart'] if 'fanart' in metadata else metadata['fanart2'] if 'fanart2' in metadata else metadata['fanart3'] if 'fanart3' in metadata else None
		except: fanart = None
		try: banner = metadata['banner'] if 'banner' in metadata else None
		except: banner = None
		try: thumb = metadata['thumb'] if 'thumb' in metadata else poster
		except: thumb = None

		poster1 = metadata['poster'] if 'poster' in metadata else None
		poster2 = metadata['poster2'] if 'poster2' in metadata else None
		poster3 = metadata['poster3'] if 'poster3' in metadata else None

		if poster == '0' or poster == None: poster = addonPoster
		if banner == '0' or banner == None: banner = addonBanner if poster == '0' or poster == None else poster
		if thumb == '0' or thumb == None: thumb = addonFanart if fanart == '0' or fanart == None else fanart
		if not hasFanart or (fanart == '0' or fanart == None): fanart = addonFanart

		if self.navigationStreamsSpecial:
			if self.navigationCinema and not self.navigationCinemaInerrupt:
				self.navigationCinemaTrailer.cinemaStop()
			window.WindowStreams.show(background = fanart, status = 'Loading Streams', close = not initial)

			window.Window.propertyGlobalSet('GaiaIndexId', id) # Used in WindowStreams.
			window.Window.propertyGlobalSet('GaiaPosterStatic', tools.Settings.getInteger('interface.stream.interface.poster') == 0)

			window.Window.propertyGlobalSet('GaiaColorPrimary', interface.Format.colorPrimary())
			window.Window.propertyGlobalSet('GaiaColorSecondary', interface.Format.colorSecondary())
			window.Window.propertyGlobalSet('GaiaColorTertiary', interface.Format.colorTertiary())
			window.Window.propertyGlobalSet('GaiaColorMain', interface.Format.colorMain())
			window.Window.propertyGlobalSet('GaiaColorDisabled', interface.Format.colorDisabled())
			window.Window.propertyGlobalSet('GaiaColorAlternative', interface.Format.colorAlternative())
			window.Window.propertyGlobalSet('GaiaColorSpecial', interface.Format.colorSpecial())
			window.Window.propertyGlobalSet('GaiaColorUltra', interface.Format.colorUltra())
			window.Window.propertyGlobalSet('GaiaColorExcellent', interface.Format.colorExcellent())
			window.Window.propertyGlobalSet('GaiaColorGood', interface.Format.colorGood())
			window.Window.propertyGlobalSet('GaiaColorMedium', interface.Format.colorMedium())
			window.Window.propertyGlobalSet('GaiaColorPoor', interface.Format.colorPoor())
			window.Window.propertyGlobalSet('GaiaColorBad', interface.Format.colorBad())

			for quality in Stream.KodiVideoQuality.keys():
				if quality: window.Window.propertyGlobalSet('GaiaColor' + quality.capitalize(), interface.Format.colorQuality(quality))

			colorHighlightBase = interface.Format.colorSpecial()
			colorHighlightLocal = interface.Format.colorAlpha(color = colorHighlightBase, alpha = 'FF')
			colorHighlightCached = interface.Format.colorAlpha(color = colorHighlightBase, alpha = 'DD')
			colorHighlightDirect = interface.Format.colorAlpha(color = colorHighlightBase, alpha = '77')
			colorHighlightDebrid = interface.Format.colorAlpha(color = colorHighlightBase, alpha = '55')
			colorHighlightDefault = 'FF000000'
		else:
			icons = tools.Settings.getInteger('interface.stream.interface.icons')

		# NB: Using GUI locking might seem to be faster when there only a handlful of streams. However, if there are many streams (eg: 500), not using locking is a lot faster, especially for the directory and special window.
		directoryUpdate = not initial or binge == tools.Binge.ModeContinue
		directory = interface.Directory(content = interface.Directory.ContentFiles, cache = True, update = directoryUpdate, lock = False)

		format = Stream.settingsFormat()
		labelFill = Stream._labelFill()
		enabledCache = tools.Settings.getBoolean('download.cache.enabled')
		controls = []
		contexts = []

		for i in range(total):
			try:
				extra = ''
				itemJson = items[i]
				stream = itemJson['stream']

				syssource = tools.Converter.quoteTo(tools.Converter.jsonTo(itemJson))

				orionItem = stream.idOrionItem()
				orionStream = stream.idOrionStream()
				if orionItem and orionStream: orion = {'item' : orionItem, 'stream' : orionStream}
				else: orion = None

				# Set from history where each item is from a differnt movie/show.
				try:
					if multi:
						metadata = itemJson['meta']
						metadataKodi = tools.Media.metadataClean(metadata, exclude = True) # Exclude attributes to save some space in the interface.
						sysmeta = network.Networker.linkQuote(tools.Converter.jsonTo(metadata), plus = True)

						try: title = metadata['tvshowtitle']
						except:
							try: title = metadata['originaltitle']
							except:
								try: title = metadata['title']
								except: title = ''

						try: year = metadata['year']
						except: year = None
						try: season = metadata['season']
						except: season = None
						try: episode = metadata['episode']
						except: episode = None

						try: imdb = metadata['imdb']
						except: imdb = None
						try: tmdb = metadata['tmdb']
						except: tmdb = None
						try: tvdb = metadata['tvdb']
						except: tvdb = None

						extra = interface.Format.font(title + ' ' + tools.Media.title(metadata = None, title = '', year = year, season = season, episode = episode, skin = False).strip(), bold = True)
						if not self.navigationStreamsSpecial: extra += Stream.labelSeparator()

						try: poster = metadata['poster'] if 'poster' in metadata else metadata['poster2'] if 'poster2' in metadata else metadata['poster3'] if 'poster3' in metadata else None
						except: poster = None
						try: fanart = metadata['fanart'] if 'fanart' in metadata else metadata['fanart2'] if 'fanart2' in metadata else metadata['fanart3'] if 'fanart3' in metadata else None
						except: fanart = None
						try: banner = metadata['banner'] if 'banner' in metadata else None
						except: banner = None
						try: thumb = metadata['thumb'] if 'thumb' in metadata else poster
						except: thumb = None

						poster1 = metadata['poster'] if 'poster' in metadata else None
						poster2 = metadata['poster2'] if 'poster2' in metadata else None
						poster3 = metadata['poster3'] if 'poster3' in metadata else None

						if poster == '0' or poster == None: poster = addonPoster
						if banner == '0' or banner == None: banner = addonBanner if poster == '0' or poster == None else poster
						if thumb == '0' or thumb == None: thumb = addonFanart if fanart == '0' or fanart == None else fanart
						if not hasFanart or (fanart == '0' or fanart == None): fanart = addonFanart
				except:
					tools.Logger.error()

				# ACTION URL.
				if not stream.sourceTypeLocal() and enabledCache: url = '%s?action=playCache&handleMode=%s&source=%s&metadata=%s&binge=%d' % (sysaddon, handler.Handler.ModeDefault, syssource, sysmeta, bool(binge))
				else: url = '%s?action=play&handleMode=%s&source=%s&metadata=%s&binge=%d' % (sysaddon, handler.Handler.ModeDefault, syssource, sysmeta, bool(binge))
				url = self.parameterize(url)
				sysurl = tools.Converter.quoteTo(url)

				# ITEM
				if self.navigationStreamsSpecial:
					label = ''
					label2 = ''
					icon = thumb
				else:
					if self.navigationStreamsDialogDetailed:
						label = itemJson['label'][0]
						try: label2 = itemJson['label'][1]
						except: label2 = ''
					else:
						label = interface.Format.fontNewline().join(itemJson['label'])
						label2 = ''

					try: label = label.replace('[GAIANUMBER]', Stream.labelNumber(0 if 'custom' in itemJson and itemJson['custom'] else (i + 1), separator = True, format = format))
					except: pass
					try: label = label.replace('[GAIAEXTRA]', extra)
					except: pass

					if multi:
						icon = thumb
					else:
						# NB: If icons == 0, the list is a directory, and the icon/poster/etc are set to '' or None, then Kodi throws this error:
						# Kodi ERROR: InputStream: Error opening
						# Set to a non-existing value(eg 'x') to get rid of the errors.
						if icons == 0: icon = thumb = poster = banner = 'x'
						elif icons == 1: icon = thumb
						else: icon = thumb = interface.Icon.path(icon = stream.videoQuality().lower(), quality = interface.Icon.QualityLarge, special = interface.Icon.SpecialQuality if icons == 3 else interface.Icon.SpecialNone)
						poster = icon

				item = directory.item(label = label, label2 = label2)

				# Kodi uses a GUI lock everytime a function is called on a ListItem, like setArt() or setProperty().
				# If there are many streams, all this locking drastically increases loading times. 25-30 sec for 500 streams.
				# Instead set all the properties in one function call.
				# This should not be neccessary in Kodi 18 anymore, if we create the ListItem without locking (offscreen).
				# Still leaves this here for older Kodi versions, where locking cannot be disabled in ListItem. And in case something in the future changes with the GUI lock.
				properties = {}

				art = {'icon': icon, 'thumb': thumb, 'poster': poster, 'banner': banner}
				item.setArt(art)
				if not fanart == None: properties['Fanart_Image'] = fanart

				# NB: Needed to transfer the addon handle ID to play
				# https://forum.kodi.tv/showthread.php?tid=328080
				properties['IsPlayable'] = 'false'
				#properties['IsPlayable'] = 'true' # Causes popup dialog from Kodi if playback was unsuccesful.

				item.setInfo(type = 'video', infoLabels = metadataKodi)
				width, height = stream.videoResolution(format = Stream.FormatKodi)
				item.addStreamInfo('video', {'codec': stream.videoCodec(format = Stream.FormatKodi), 'width' : width, 'height': height})
				item.addStreamInfo('audio', {'codec': stream.audioCodec(format = Stream.FormatKodi), 'channels': stream.audioChannels(format = Stream.FormatKodi)})

				# SPECIAL WINDOW
				if self.navigationStreamsSpecial:
					name = stream.fileName()

					if not name: name = stream.linkPrimary()
					prefix = int(bool(stream.sourceOrigin(label = Stream.LabelSettings, orion = True)))
					highlight = colorHighlightLocal if stream.sourceTypeLocal() else colorHighlightCached if stream.accessCacheAny() else colorHighlightDirect if stream.accessTypeDirect() else colorHighlightDebrid if stream.accessDebridAny() else colorHighlightDefault

					audio = audioLanguage = stream.labelAudio(format = format)
					audioHas = not labelFill in audio
					languages = stream.audioLanguage()

					countries = []
					if languages:
						if len(languages) > 0:
							if audioHas: audioLanguage += Stream.labelSeparator(format = format)
							else: audioLanguage = None
						for j in range(len(languages)):
							country = tools.Language.country(languages[j])
							if not country in countries:
								countries.append(country)
								properties['GaiaAudioFlag' + str(j + 1)] = country

					subtitle = subtitleLanguage = stream.labelSubtitle(format = format)
					subtitleHas = not labelFill in subtitle
					languages = stream.subtitleLanguage()
					countries = []
					if languages:
						if len(languages) > 0:
							if subtitleHas: subtitleLanguage += Stream.labelSeparator(format = format)
							else: subtitleLanguage = None
						for j in range(len(languages)):
							country = tools.Language.country(languages[j])
							if not country in countries:
								countries.append(country)
								properties['GaiaSubtitleFlag' + str(j + 1)] = country

					properties['GaiaPoster1'] = poster1 if poster1 else ''
					properties['GaiaPoster2'] = poster2 if poster2 else ''
					properties['GaiaPoster3'] = poster3 if poster3 else ''
					properties['GaiaAction'] = url
					properties['GaiaHighlight'] = highlight
					properties['GaiaNumber'] = Stream.labelNumber(i + 1, format = format)
					properties['GaiaExtra'] = extra
					properties['GaiaIcon'] = stream.sourceOriginIcon() if prefix else None
					properties['GaiaPrefix'] = tools.Converter.unicode(prefix)
					properties['GaiaType'] = stream.sourceType()
					properties['GaiaSource'] = stream.labelSource(format = format)
					properties['GaiaSourceExtra'] = stream.labelSource(format = format, extra = extra)
					properties['GaiaPopularity'] = stream.labelPopularity(format = format)
					properties['GaiaTime'] = stream.labelTime(format = format)
					properties['GaiaPeers'] = stream.labelPeers(format = format)
					properties['GaiaSeeds'] = stream.labelSeeds(format = format)
					properties['GaiaLeeches'] = stream.labelLeeches(format = format)
					properties['GaiaRelease'] = stream.labelRelease(format = format, uploader = False)
					properties['GaiaName'] = name
					properties['GaiaSize'] = stream.labelSize(format = format)
					properties['GaiaBandwidth'] = stream.labelBandwidth(format = format)
					properties['GaiaAccess'] = stream.labelAccess(format = format)
					properties['GaiaInfo'] = stream.labelType(format = format)
					properties['GaiaVideo'] = stream.labelVideo(format = format)
					properties['GaiaQuality'] = stream.videoQuality()
					properties['GaiaAudio'] = audio
					properties['GaiaAudioLanguage'] = audioLanguage
					properties['GaiaSubtitle'] = subtitle
					properties['GaiaSubtitleLanguage'] = subtitleLanguage

				item.setProperties(properties)

				# ADD ITEM
				if self.navigationStreamsDialogDetailed or self.navigationStreamsDialogPlain:
					controls.append(item)
				else:
					context = interface.Context(mode = interface.Context.ModeStream, type = self.type, kids = self.kids, create = True, queue = True, source = syssource, metadata = sysmeta, art = art, orion = orion, link = url, label = label, title = title, year = year, season = season, episode = episode, imdb = imdb, tmdb = tmdb, tvdb = tvdb)
					if self.navigationStreamsSpecial:
						contexts.append(context)
						controls.append(item)
						window.WindowStreams.update(progress = i / float(total))
					else:
						item.addContextMenuItems([context.menu()])
						controls.append([url, item, False])
			except:
				tools.Logger.error()

		if self.navigationStreamsSpecial:
			window.WindowStreams.itemAdd(item = controls, context = contexts)
			window.WindowStreams.update(finished = True)
			window.WindowStreams.focus()
			if not multi: window.WindowStreams.itemReselect() # Go to previously selected position if window is reopened.
			if not self.silent: tools.Donations.popup()
		elif self.navigationStreamsDialogDetailed or self.navigationStreamsDialogPlain:
			self.loaderHide()
			if not self.silent: tools.Donations.popup(wait = True)
			if self.navigationStreamsDialogDetailed: choice = interface.Dialog.select(items = controls, details = True)
			else: choice = interface.Dialog.select(items = [i.getLabel() for i in controls])
			if choice >= 0: self.play(items[choice], metadata = metadata, binge = binge)
		else:
			directory.addItems(items = controls)
			directory.finish()
			self.progressClose(force = True, loader = False)
			def closeLoader():
				tools.Time.sleep(2)
				self.loaderHide()
				if not self.silent: tools.Donations.popup()
			threadLoader = Pool.thread(target = closeLoader)
			threadLoader.start()

		if self.navigationCinema:
			self.navigationCinemaTrailer.cinemaStop()

		# When launching from the local library, Kodi shows an OK dialog and/or a notification stating that the item couldn't be played, or that it coudln't find the next item in the playlist.
		# These popups happen random and sometimes not at all. It probably depends on the time it takes to scrape/launch Gaia.
		# There seems to be nothing that can be done about these popups, except closing them automatically.
		if library:
			def closePopups():
				for i in range(30): # Don't make this too large, otherwise the Gaia stream notification takes too long to show. 20 is too low.
					interface.Dialog.closeOk()
					interface.Dialog.closeNotification()
					tools.Time.sleep(0.05)
				self.progressNotification(force = True) # Reopen.
			threadLibrary = Pool.thread(target = closePopups)
			threadLibrary.start()

	def _showAutoplay(self, items, metadata, binge = None):
		self.loaderShow()

		items = [i for i in items if ('autoplay' in i and i['autoplay'] == True) or not 'autoplay' in i]

		imdb = metadata['imdb'] if 'imdb' in metadata else None
		tmdb = metadata['tmdb'] if 'tmdb' in metadata else None
		tvdb = metadata['tvdb'] if 'tvdb' in metadata else None

		title = metadata['title'] if 'title' in metadata else None
		year = metadata['year'] if 'year' in metadata else None
		season = metadata['season'] if 'season' in metadata else None
		episode = metadata['episode'] if 'episode' in metadata else None

		autoHandler = handler.Handler()
		heading = interface.Translation.string(33451)
		message = interface.Translation.string(33452)
		for i in range(len(items)):
			self.progressPlaybackInitialize(title = heading, message = message, metadata = metadata, loader = False)
			if not self.navigationCinema and self.progressPlaybackCanceled(): break
			percentage = int(((i / float(len(items))) * 30) + 20)
			self.progressPlaybackUpdate(progress = percentage, title = heading, message = message)
			try:
				handle = autoHandler.serviceDetermine(mode = handler.Handler.ModeDefault, item = items[i], popups = False)
				if not handle == handler.Handler.ReturnUnavailable:
					result = self.sourceResolve(items[i], handle = handle, info = False)
					items[i]['stream'].streamSet(result)
					if result['success']:
						history.History().insert(type = self.type, kids = self.kids, link = items[i]['stream'].linkPrimary(), metadata = metadata, source = items[i])
						if not self.navigationCinema and self.progressPlaybackCanceled(): break
						if self.navigationCinema:
							self.navigationCinemaTrailer.cinemaStop()
							self.loaderShow()
							self.progressPlaybackInitialize(title = heading, message = message, metadata = metadata, force = True) # Make sure it is shown after the trailer playback stops.
							self.progressPlaybackUpdate(progress = percentage, title = heading, message = message, force = True)
						from lib.modules.player import player
						success = player(type = self.type, kids = self.kids).run(type = self.type, title = title, year = year, season = season, episode = episode, imdb = imdb, tmdb = tmdb, tvdb = tvdb, meta = metadata, source = items[i], binge = binge)
						if success: return items[i]
						else: continue
			except:
				tools.Logger.error()

		if self.navigationCinema: self.navigationCinemaTrailer.cinemaStop()
		self.progressPlaybackClose()
		interface.Dialog.notification(title = 33448, message = 33574, sound = False, icon = interface.Dialog.IconInformation)
		return None

	def play(self, source, metadata = None, downloadType = None, downloadId = None, handle = None, handleMode = None, index = None, binge = None):
		try:
			self.downloadCanceled = False
			sequential = tools.Settings.getBoolean('playback.general.sequential')
			if sequential:
				items = tools.Converter.jsonFrom(tools.System.windowPropertyGet(self.propertyItems))
				if index == None:
					for i in range(len(items)):
						if items[i]['stream'].linkPrimary() == source['stream'].linkPrimary():
							index = i
							break
				if not index == None: # Ignore for locally downloaded files (files played from the download manager while the sequential playback option is enabled).
					try:
						source = items[index]
					except:
						tools.Logger.error()
						self.progressClose(force = True)
						return

			labelInitiate = interface.Translation.string(33674)
			labelResolve = interface.Translation.string(35282)
			labelContainer = interface.Translation.string(35283)
			labelEstablish = interface.Translation.string(33452)
			labelRemote = interface.Translation.string(35537)

			heading = interface.Translation.string(33451)
			message = labelInitiate

			self.progressPlaybackInitialize(title = heading, message = labelInitiate, metadata = metadata)
			self.progressPlaybackUpdate(progress = 1, title = heading, message = message)

			try:
				if metadata == None:
					metadata = tools.System.windowPropertyGet(self.propertyMeta)
					metadata = tools.Converter.jsonFrom(metadata)

				title = metadata['tvshowtitle'] if 'tvshowtitle' in metadata else metadata['title']
				year = metadata['year'] if 'year' in metadata else None
				season = metadata['season'] if 'season' in metadata else None
				episode = metadata['episode'] if 'episode' in metadata else None

				imdb = metadata['imdb'] if 'imdb' in metadata else None
				tmdb = metadata['tmdb'] if 'tmdb' in metadata else None
				tvdb = metadata['tvdb'] if 'tvdb' in metadata else None
			except:
				if not metadata == None: metadata = None
				title = None
				year = None
				season = None
				episode = None
				imdb = None
				tmdb = None
				tvdb = None

			try:
				item = tools.Tools.copy(source)
				if tools.Tools.isArray(item): item = item[0]
				item['stream'] = Stream.load(data = item['stream'])
				self.progressPlaybackUpdate(progress = 2, title = heading, message = message)

				if handle == None and not item['stream'].sourceTypeLocal():
					try: handle = handler.Handler().serviceDetermine(mode = handleMode, item = item, popups = True)
					except: handle = handler.Handler.ReturnUnavailable

					# Important for Incursion and Placenta providers that must be resolved first.
					if handle == handler.Handler.ReturnUnavailable:
						message = labelResolve
						self.progressPlaybackUpdate(progress = 3, title = heading, message = message)
						self.sourceResolveProvider(item = item)
						self.progressPlaybackUpdate(progress = 4, title = heading, message = message)
						handle = handler.Handler().serviceDetermine(mode = handleMode, item = item, popups = True)

					if handle == handler.Handler.ReturnUnavailable:
						interface.Dialog.notification(title = 33448, message = 33203, icon = interface.Dialog.IconError)

					if handle == handler.Handler.ReturnUnavailable or handle == handler.Handler.ReturnExternal or handle == handler.Handler.ReturnCancel:
						self.progressPlaybackClose()
						self.loaderHide()
						return None

				image = None
				if not metadata == None:
					keys = ['poster', 'poster1', 'poster2', 'poster3', 'thumb', 'thumb1', 'thumb2', 'thumb3', 'icon', 'icon1', 'icon2', 'icon3']
					for key in keys:
						if key in metadata:
							value = metadata[key]
							if not value == None and not value == '':
								image = value
								break

				try:
					if self.progressPlaybackCanceled():
						self.loaderHide()
						return None
				except: pass

				self.progressPlaybackUpdate(progress = 5, title = heading, message = message)
				self.tProcessed = False
				self.tResolved = None

				stream = item['stream']
				typeLocal = stream.sourceTypeLocal()
				typePremium = stream.sourceTypePremium()
				typeTorrent = stream.sourceTypeTorrent()
				typeUsenet = stream.sourceTypeUsenet()
				typeHoster = stream.sourceTypeHoster()

				# OffCloud cloud downloads require a download, even if it is a hoster. Only instant downloads on OffCloud do not need this.
				try: cloud = not typePremium and not typeTorrent and not typeUsenet and not debrid.offcloud.Core().instant() and handler.Handler(handler.Handler.TypeHoster).service(handle).id() == debrid.offcloud.Core().id()
				except: cloud = False

				# Torrents and usenet have a download dialog with their own thread. Do not start a thread for them here.
				if not typeLocal and (cloud or typeTorrent or typeUsenet):
					# Do not close the dialog, otherwise there is a period where no dialog is showing.
					# The progress dialog in the debrid downloader (through sourceResolve), will overwrite this.
					#progressDialog.close()

					self.tMessage = message
					def _resolve(item, handle):
						try:
							stream = item['stream']
							notify = False
							if typeHoster and stream.linkProvider():
								self.tProcessed = True
							else:
								# Download the container. This is also done by sourceResolve(), but download it here to show it to the user in the dialog, because it takes some time.
								download = typeTorrent or typeUsenet
								sourceObject = self.sourceProviderObject(stream = stream)
								if sourceObject:
									resolved = None
									for link in stream.link():
										self.tMessage = labelResolve
										resolved = sourceObject.resolve(link = link)
										if resolved:
											if download:
												container = network.Container(link = resolved, download = True)

												# First try the original link when calling resolve() for the first time.
												# This will use the original link (or the redirection link if applicbale).
												# If the download fails (eg: due to an old non-exisiting domain - eg: old links from Orion), try replacing the domain with the domain in the provider code and try again.
												if not container.isFile():
													resolved = sourceObject.resolve(link = link, renew = True)
													container = network.Container(link = resolved, download = True)

												if (typeTorrent and not container.torrentIsMagnet()) or typeUsenet: self.tMessage = labelContainer
												if not container.isFile(): notify = True
												hash = container.hash(type = stream.sourceType()) # Pass in the type, otherwise the container will load/construct the providers to check to which provider the container belongs to.
												if hash: self.tProcessed = True
											else:
												self.tProcessed = True
											if self.tProcessed:
												stream.linkProviderSet(resolved, hoster = True)
												break
								elif stream.infoCustom():
									self.tProcessed = True
									stream.linkProviderSet(stream.linkPrimary())
							if not self.tProcessed and notify: interface.Dialog.notification(title = 35600, message = 35601, icon = interface.Dialog.IconError)
						except:
							tools.Logger.error()

					thread = Pool.thread(target = _resolve, args = (item, handle))
					thread.start()

					progress = 0
					while thread.is_alive():
						try:
							if tools.System.aborted():
								tools.System.exit()
								self.loaderHide()
								return None
							if self.progressPlaybackCanceled():
								self.progressPlaybackClose()
								return None
						except:
							self.loaderHide()

						progress += 0.25
						progressCurrent = 5 + min(int(progress), 25)
						self.progressPlaybackUpdate(progress = progressCurrent, title = heading, message = self.tMessage)
						tools.Time.sleep(0.5)

					if not self.tProcessed:
						self.progressPlaybackClose()
						return None

					message = labelRemote
					self.progressPlaybackUpdate(progress = 30, title = heading, message = message)
					self.tResolved = self.sourceResolve(item, info = True, handle = handle, handleMode = handleMode, handleClose = False)

					if handler.Handler.serviceExternal(handle) and self.tResolved['error'] == handler.Handler.ReturnExternal: # Do not return if there is a different error.
						self.progressPlaybackUpdate(progress = 50, title = heading, message = message)
						return self.tResolved['link']
					if self.tResolved['link']:
						if not self.progressPlaybackCanceled():
							message = labelEstablish
							self.progressPlaybackUpdate(progress = 45, title = heading, message = message)
				else:
					def _resolve(item, handle):
						self.tResolved = self.sourceResolve(item, info = True, handle = handle, handleMode = handleMode, handleClose = False)

					thread = Pool.thread(target = _resolve, args = (item, handle))
					thread.start()

					end = 3600
					for x in range(end):
						try:
							if tools.System.aborted():
								tools.System.exit()
								self.loaderHide()
								return None
							if self.progressPlaybackCanceled():
								self.progressPlaybackClose()
								return None
						except:
							self.loaderHide()

						if not interface.Dialog.dialogId() in [interface.Dialog.IdDialogKeyboard, interface.Dialog.IdDialogYesNo]:
							break

						progress = 5 + int((x / float(end)) * 20)
						self.progressPlaybackUpdate(progress = progress, title = heading, message = message)

						tools.Time.sleep(0.5)

					if not self.progressPlaybackCanceled():
						end = 30
						for x in range(end):
							try:
								if tools.System.aborted():
									tools.System.exit()
									self.loaderHide()
									return None
								if self.progressPlaybackCanceled():
									self.progressPlaybackClose()
									return None
							except:
								self.loaderHide()

							if not thread.is_alive(): break

							progress = 25 + int((x / float(end)) * 25)
							self.progressPlaybackUpdate(progress = progress, title = heading, message = message)

							tools.Time.sleep(0.5)

						# For pairing dialogs to remain open.
						# Have it in two steps to have a smoother progress, instead of a very long single timeout.
						if not self.progressPlaybackCanceled() and thread.is_alive():
							end = 3600
							for x in range(end):
								try:
									if tools.System.aborted():
										tools.System.exit()
										self.loaderHide()
										return None
									if self.progressPlaybackCanceled():
										self.progressPlaybackClose()
										return None
								except:
									self.loaderHide()

								if not thread.is_alive(): break

								progress = 50
								self.progressPlaybackUpdate(progress = progress, title = heading, message = message)

								tools.Time.sleep(0.5)

				loader = True
				if 'loader' in self.tResolved and self.tResolved['loader']:
					loader = False
					interface.Loader.show()

				# Close download dialog if opened.
				if self.navigationPlaybackSpecial:
					interface.Core.close()

				if self.progressPlaybackCanceled():
					tools.Logger.error()
					self.progressPlaybackClose(loader = loader)
					return None
				elif handler.Handler.serviceExternal(handle) and self.tResolved['error'] == handler.Handler.ReturnExternal: # Do not return if there is a different error.
					self.progressPlaybackUpdate(progress = 50, title = heading, message = message)
					return self.tResolved['link']
				else:
					self.progressPlaybackUpdate(progress = 50, title = heading, message = message)

				if not self.tResolved['success']:
					if sequential:
						return self.play(source = source, metadata = metadata, downloadType = downloadType, downloadId = downloadId, handle = handle, handleMode = handleMode, index = index + 1, binge = binge)
					else:
						self.progressPlaybackClose(loader = loader)
						return None

				stream.streamSet(self.tResolved)
				history.History().insert(type = self.type, kids = self.kids, link = stream.linkPrimary(), metadata = metadata, source = source)

				tools.Time.sleep(0.2)
				interface.Dialog.close(id = interface.Dialog.IdDialogKeyboard)
				interface.Dialog.close(id = interface.Dialog.IdDialogYesNo)

				# If the background dialog is not closed, when another background dialog is launched, it will contain the old information from the previous dialog.
				# Manually close it. Do not close the foreground dialog, since it does not have the issue and keeping the dialog shown is smoother transition.
				# NB: This seems to not be neccessary with the new interface.Core. However, enable again if the problems are observed.
				#if interface.Core.background():
				#	interface.Core.close()
				#	self.loaderShow() # Since there is no dialog anymore.

				from lib.modules.player import player
				player(type = self.type, kids = self.kids).run(type = self.type, title = title, year = year, season = season, episode = episode, imdb = imdb, tmdb = tmdb, tvdb = tvdb, meta = metadata, downloadType = downloadType, downloadId = downloadId, source = item, binge = binge)

				return self.tResolved['link']
			except:
				tools.Logger.error()
				self.loaderHide()

			self.progressPlaybackClose()
			self.progressFailure(single = True)
			return True
		except:
			tools.Logger.error()
			self.progressPlaybackClose()
			return False

	def playCache(self, source, metadata = None, handleMode = None, binge = None):
		try:
			if tools.Settings.getBoolean('download.cache.enabled'):
				self.loaderShow()

				if metadata == None:
					metadata = tools.System.windowPropertyGet(self.propertyMeta)
					metadata = tools.Converter.jsonFrom(metadata)

				item = source
				if tools.Tools.isArray(item): item = item[0]

				handle = handler.Handler().serviceDetermine(mode = handleMode, item = item, popups = True)
				if handle == handler.Handler.ReturnUnavailable or handle == handler.Handler.ReturnExternal or handle == handler.Handler.ReturnCancel:
					self.loaderHide()
					return None

				result = self.sourceResolve(item, handle = handle, handleMode = handleMode, handleClose = False) # Do not use item['urlresolved'], because it has the | HTTP header part removed, which is needed by the downloader.

				# If the Premiumize download is still running and the user clicks cancel in the dialog.
				if not result['success']: return

				link = result['link']
				source['stream'].streamSet(result)

				if item['stream'].sourceTypeLocal(): # Must be after self.sourceResolve.
					self.play(source = source, metadata = metadata, handle = handle, binge = binge)
					return

				downloadType = None
				downloadId = None
				if not link == None and not link == '':
					from lib.modules import downloader
					downer = downloader.Downloader(downloader.Downloader.TypeCache)
					path = downer.download(media = self.type, link = link, metadata = metadata, source = source, automatic = True)
					if path and not path == '':
						downloadType = downer.type()
						downloadId = downer.id()

						tools.Time.sleep(3) # Allow a few seconds for the download to start. Otherwise the download was queued but not started and the file was not created yet.
						downer.refresh()

				self.loaderHide()
				self.playLocal(path = path, source = source, metadata = metadata, downloadType = downloadType, downloadId = downloadId, binge = binge)
			else:
				self.play(source = source, metadata = metadata, binge = binge)
		except:
			self.loaderHide()
			tools.Logger.error()

	# Used by downloader.
	def playLocal(self, path, source, metadata, downloadType = None, downloadId = None, binge = None):
		source['stream'] = Stream.load(data = source['stream'])
		source['stream'].linkSet(path)
		source['stream'].sourceTypeSet(Stream.SourceTypeLocal)
		self.play(source = source, metadata = metadata, downloadType = downloadType, downloadId = downloadId, binge = binge)

	def addSources(self, sources, check):
		if self.stopThreads: return
		try:
			if len(sources) > 0:
				self.sources.extend(sources)

				hostersCaptcha = self.hostersCaptcha()
				hostersBlocked = self.hostersBlocked()
				services = self.servicesDebrid()

				for source in sources:
					try:
						source['stream'] = Stream.load(data = source['stream'])

						lookups = [source['stream'].sourceHoster(), source['stream'].sourceProvider(), source['stream'].sourcePublisher()]
						lookups = [lookup.lower() for lookup in lookups if lookup]

						# External providers do not always set the full hoster domain (eg: vidoza instead of vidoza.net).
						# Do not just check if the domain contains the hoster, since this would match eg: "cloud" and "icloud".
						# Instead check if the domain starts with the hoster and followed by a ".".
						lookups2 = [lookup + '.' for lookup in lookups if not '.' in lookup]

						lookups.append(source['stream'].sourceType())

						# Add debrid.
						debrid = False
						for key, value in services.items():
							if value: # In case the service list request failed, returning None.
								for val in value:
									if any(k == val for k in lookups) or ('.' in val and any(val.startswith(k) for k in lookups2)):
										source['stream'].accessDebridSet(id = key)
										debrid = True
										break

						# Add captcha
						source['stream'].infoCaptchaSet(hostersCaptcha)

						# Add blocked
						source['stream'].infoBlockedSet(hostersBlocked)

						source['stream'].infoTerminationClear() # Clear the termination status, since it could change after various parameters were set after the scraperer rreeturnedit (debrid, provider, etc).
						self.adjustSourceAppend(source)

						if not source['stream'].infoDuplicate():
							if debrid: self.streamsDebrid += 1

							# When loading from cache.
							if source['stream'].accessCacheAny(): self.streamsCached += 1

							quality = source['stream'].videoQualityCategory()
							priority = False
							if quality == Stream.VideoQualityHdUltra:
								priority = True
								self.streamsHdUltra += 1 # 4K or higher
							elif quality == Stream.VideoQualitySd:
								self.streamsSd += 1
							elif quality == Stream.VideoQualityScr or quality == Stream.VideoQualityCam:
								self.streamsLd += 1
							else:
								quality = source['stream'].videoQuality()
								if quality == Stream.VideoQualityHd1080:
									priority = True
									self.streamsHd1080 += 1
								elif quality == Stream.VideoQualityHd720:
									priority = True
									self.streamsHd720 += 1

							if source['stream'].sourceTypeTorrent(): self.streamsTorrent += 1
							elif source['stream'].sourceTypeUsenet(): self.streamsUsenet += 1
							elif source['stream'].sourceTypeHoster(): self.streamsHoster += 1
							elif source['stream'].sourceTypePremium(): self.streamsPremium += 1
							elif source['stream'].sourceTypeLocal(): self.streamsLocal += 1

							if source['stream'].accessTypeDirect(): self.streamsDirect += 1

							self.streamsTotal += 1
							if check and self.enabledExtra:
								index = len(self.threadsAdjusted)
								thread = Pool.thread(target = self.adjustSource, args = (source, index))
								self.priortityAdjusted.append(priority) # Give priority to HD links
								self.statusAdjusted.append('queued')
								self.threadsAdjusted.append(thread)
							else:
								self.cacheCount += 1
					except:
						tools.Logger.error()

				self.adjustSourceStart()
				self.adjustTermination()
				thread = Pool.thread(target = self.adjustSourceCache, args = (None, True))
				thread.start()
		except:
			tools.Logger.error()

	def adjustLock(self):
		# NB: For some reason Python somtimes throws an exception saying that a unlocked/locked lock (tried) to aquire/release. Always keep these statements in a try-catch.
		try: self.threadsLock.acquire()
		except: pass

	def adjustUnlock(self):
		# NB: For some reason Python somtimes throws an exception saying that a unlocked/locked lock (tried) to aquire/release. Always keep these statements in a try-catch.
		try: self.threadsLock.release()
		except: pass

	def adjustTerminationLock(self):
		try: self.terminationLock.acquire()
		except: pass

	def adjustTerminationUnlock(self):
		try: self.terminationLock.release()
		except: pass

	def adjustTermination(self):
		try:
			self.adjustTerminationLock()
			if self.terminationEnabled and not self.terminated:
				if self.termination.process(items = self.sourcesAdjusted):
					self.terminated = True
					if self.termination.notification(): interface.Dialog.notification(title = 33882, message = 35638, icon = interface.Dialog.IconInformation)
					tools.Logger.log('Preemptive Termination Triggered', name = 'CORE', type = tools.Logger.TypeInfo)
		except:
			tools.Logger.error()
		finally:
			try: self.adjustTerminationUnlock()
			except: pass
		return self.terminated

	def adjustSourceCache(self, timeout = None, partial = False):
		# Premiumize seems to take long to verify usenet hashes.
		# Split torrents and usenet up, with the hope that torrents will complete, even when usenet takes very long.
		# Can also be due to expensive local hash calculation for NZBs.
		if self.cacheEnabled:
			if partial and self.cacheBusy: return # If it is the final full inspection, always execute, even if another partial inspection is still busy.

			self.adjustLock()
			self.cacheBusy += 1

			if timeout is None:
				timeout = self.cacheTime
				if not timeout: timeout = 45

			if self.cacheOrion:
				links = []
				for source in self.sourcesAdjusted:
					if not source['stream'].hashContainer() and (source['stream'].sourceTypeTorrent() or source['stream'].sourceTypeUsenet()):
						links.append(source['stream'].linkPrimary())
				if links:
					identifiers = self.cacheOrion.identifiers(links = links, chunked = partial)
					for link, identifier in identifiers.items():
						for i in range(len(self.sourcesAdjusted)):
							if self.sourcesAdjusted[i]['stream'].linkPrimary() == link:
								if not identifier is None:
									self.sourcesAdjusted[i]['stream'].hashContainerSet(identifier['hash'])
									self.sourcesAdjusted[i]['stream'].segmentSet(identifier['segment'])
								break

			threads = []
			for i in range(len(self.cacheTypes)):
				threads.append(Pool.thread(target = self._adjustSourceCache, args = (self.cacheObjects[i], self.cacheTypes[i], timeout, partial)))

			self.adjustUnlock()

			[thread.start() for thread in threads]
			[thread.join() for thread in threads]

			self.adjustLock()
			self.cacheBusy -= 1
			self.adjustUnlock()
			self.adjustTermination()

	def _adjustSourceCache(self, object, type, timeout, partial = False):
		try:
			debridId = object.id()
			self.adjustLock()
			hashes = []
			sources = []

			modes = object.cachedModes()
			modeHash = handler.Handler.TypeTorrent in modes or handler.Handler.TypeUsenet in modes
			modeLink = handler.Handler.TypeHoster in modes
			for source in self.sourcesAdjusted:
				if not source['stream'].infoDuplicate():
					if (source['stream'].sourceType() == type or (modeLink and type == handler.Handler.TypeHoster)) and (not 'premium' in source or not source['premium']):
						# Only check those that were not previously inspected.
						if not source['stream'].accessCacheHas(debridId, exact = Stream.ExactYes):
							# NB: Do not calculate the hash if it is not available.
							# The hash is not available because the NZB could not be downloaded, or is still busy in the thread.
							# Calling container.hash() will cause the NZB to download again, which causes long delays.
							# Since the hashes are accumlated here sequentially, it might cause the download to take so long that the actual debrid cache query has never time to execute.
							# If the NZBs' hashes are not available at this stage, ignore it.
							'''if not source['stream'].hashContainer():
								container = network.Container(link = source['stream'].linkPrimary())
								source['stream'].hashContainerSet(container.hash(type = source['stream'].sourceType())) # Pass in the type, otherwise the container will load/construct the providers to check to which provider the container belongs to.
							'''

							torrentOrUsenet = source['stream'].sourceTypeTorrent() or source['stream'].sourceTypeUsenet()
							hash = source['stream'].hashContainer()
							if torrentOrUsenet and modeHash and hash:
								hashes.append(hash)
								sources.append(source)
							elif not torrentOrUsenet and modeLink:
								link = source['stream'].linkPrimary()
								if link:
									hashes.append(link)
									sources.append(source)

			self.adjustUnlock()

			# Partial will inspect the cache will the scraping is still busy.
			# Only check if there are a bunch of them, otherwise there are too many API calls (heavy load on both server and local machine).
			if len(hashes) == 0 or (partial and len(hashes) < 40): return

			# NB: Set all statuses to false, otherwise the same links will be send multiple times for inspection, if multiple hosters finish in a short period of time before the previous inspection is done.
			# This will exclude all currently-being-looked-up links from the next iteration in the for-loop above.
			for i in range(len(self.sourcesAdjusted)):
				hash = self.sourcesAdjusted[i]['stream'].hashContainer()
				if (modeHash and hash and hash in hashes) or (modeLink and self.sourcesAdjusted[i]['stream'].linkPrimary() in hashes):
					self.sourcesAdjusted[i]['stream'].accessCacheSet(id = debridId, value = False, exact = Stream.ExactYes)
					self.sourcesAdjusted[i]['stream'].infoTerminationClear() # Clear the termination status, since it could change after the cache changed.
			self.adjustUnlock()

			def _updateIndividually(id, hash, cached):
				try:
					hash = tools.Converter.unicode(hash)
					hashLower = hash.lower()
					self.adjustLock()
					for i in range(len(self.sourcesAdjusted)):
						try:
							if self.sourcesAdjusted[i]['stream'].hashContainer() == hashLower or self.sourcesAdjusted[i]['stream'].linkPrimary() == hash:
								if cached and not self.sourcesAdjusted[i]['stream'].accessCache(id, exact = Stream.ExactYes):
									self.sourcesAdjusted[i]['stream'].accessCacheSet(id = id, value = cached, exact = Stream.ExactYes)
									self.sourcesAdjusted[i]['stream'].infoTerminationClear() # Clear the termination status, since it could change after the cache changed.
									if cached and self.sourcesAdjusted[i]['stream'].accessCacheCount() == 1: # Only count one of the debird service caches.
										self.streamsCached += 1
								break
						except:
							tools.Logger.error()
					self.adjustUnlock()
				except:
					tools.Logger.error()

			object.cached(id = hashes, timeout = timeout, callback = _updateIndividually, sources = sources)
		except: tools.Logger.error()
		finally: self.adjustUnlock()

	# priority starts stream checks HD720 and greater first.
	def adjustSourceStart(self, priority = True):
		if self.stopThreads: return
		try:
			self.adjustLock()

			# HD links
			running = [i for i in self.threadsAdjusted if i.is_alive()]
			openSlots = None if self.threadsLimit is None else max(0, self.threadsLimit - len(running))
			counter = 0
			for j in range(len(self.threadsAdjusted)):
				if self.priortityAdjusted is True and self.statusAdjusted[j] == 'queued':
					self.statusAdjusted[j] = 'busy'
					self.threadsAdjusted[j].start()
					counter += 1
					if not openSlots is None and counter > openSlots: return

			# Non-HD links
			running = [i for i in self.threadsAdjusted if i.is_alive()]
			openSlots = None if self.threadsLimit is None else max(0, self.threadsLimit - len(running))
			counter = 0
			for j in range(len(self.threadsAdjusted)):
				if self.statusAdjusted[j] == 'queued':
					self.statusAdjusted[j] = 'busy'
					self.threadsAdjusted[j].start()
					counter += 1
					if not openSlots is None and counter > openSlots: return
		except: tools.Logger.error()
		finally: self.adjustUnlock()

	def adjustSourceAppend(self, source):
		if self.stopThreads: return
		try:
			self.adjustLock()
			self.adjustSourceContains(source)
			self.sourcesAdjusted.append(source)
		except: tools.Loggere.error()
		finally: self.adjustUnlock()

	def adjustSourceContains(self, source): # Filter out duplicate URLs early on, to reduce the prechecks & metadata on them.
		if self.stopThreads: return
		contains = False
		try:
			debrids = [debrid.premiumize.Core().id(), debrid.offcloud.Core().id(), debrid.realdebrid.Core().id()]
			for i in range(len(self.sourcesAdjusted)):
				sourceAdjusted = self.sourcesAdjusted[i]
				sourceLink = sourceAdjusted['stream'].link()
				sourceHash = sourceAdjusted['stream'].hash()
				if any(link in sourceLink for link in source['stream'].link()) or (sourceHash and sourceHash == source['stream'].hash()):
					source['stream'].infoDuplicateSet()

					# NB: Compare both debrid caches.
					# If there are different providers and/or different variations of the provider (for different foreign languages or umlauts), the same item might be detected by multiple providers.
					# This is especially important for debrid cached links. One provider might have it flagged as cache, the other one not. Then on the second run of the scraping procees, the values are read from database, and which ever one was written first to the DB will be returned.
					# Later pick the longest dict, since that one is expected to contains most metadata/info.

					# If any one is cached, make both cached.
					for exact in [Stream.ExactYes, Stream.ExactNo]:
						for id in debrids:
							cache = sourceAdjusted['stream'].accessCache(id = id, exact = exact)
							cacheNew = source['stream'].accessCache(id = id, exact = exact)
							if cache is None: cache = cacheNew
							elif not cacheNew is None: cache = cache or cacheNew
							if not cache is None:
								sourceAdjusted['stream'].accessCacheSet(id = id, value = cache, exact = exact)
								source['stream'].accessCacheSet(id = id, value = cache, exact = exact)
								source['stream'].infoTerminationClear() # Clear the termination status, since it could change after the cache changed.

					contains = True
					break
		except:
			tools.Logger.error()
		return contains

	def adjustSourceUpdate(self, index, stream = None, precheck = None, resolved = None, hash = None, mutex = True):
		if self.stopThreads:
			return
		try:
			if index >= 0:
				if mutex: self.adjustLock()
				if not stream is None:
					self.sourcesAdjusted[index]['stream'] = stream
				if not precheck is None:
					self.sourcesAdjusted[index]['stream'].infoPrecheckSet(precheck)
				if not resolved is None:
					self.sourcesAdjusted[index]['stream'].linkProviderSet(resolved)
				if not hash is None:
					self.sourcesAdjusted[index]['stream'].hashContainerSet(hash)

				if mutex: self.adjustUnlock()
		except: pass
		finally:
			if mutex: self.adjustUnlock()

	# Write changes to database.
	def adjustSourceDatabase(self, timeout = 30):
		try:
			self.adjustLock()

			sources = {}
			for i in range(len(self.sourcesAdjusted)):
				try:
					result = self.sourcesAdjusted[i]
					stream = result['stream']
					if stream.infoCache(): continue

					provider = stream.provider()
					imdb = stream.idImdb()
					tmdb = stream.idTmdb()
					tvdb = stream.idTvdb()
					query = stream.infoQuery()

					id = [provider.id(), imdb, tmdb, tvdb, query]
					id = [x if x else ' ' for x in id]
					id = '_'.join(id)

					if not id in sources:
						sources[id] = {
							'provider' : provider,
							'query' : query,
							'imdb' : imdb,
							'tmdb' : tmdb,
							'tvdb' : tvdb,
							'season' : stream.metaSeason(),
							'episode' : stream.metaEpisode(),
							'streams' : [],
						}

					sources[id]['streams'].append(stream)
				except: tools.Logger.error()

			try:
				for source in sources.values():
					manager.Manager.streamsInsert(data = source['streams'], provider = source['provider'], query = source['query'], idImdb = source['imdb'], idTmdb = source['tmdb'], idTvdb = source['tvdb'], numberSeason = source['season'], numberEpisode = source['episode'])
			except: tools.Logger.error()
		except: tools.Logger.error()
		finally: self.adjustUnlock()

	def adjustSourceDone(self, index):
		try:
			self.adjustLock()
			if index >= 0 and index < len(self.statusAdjusted):
				self.statusAdjusted[index] = 'done'
		except: tools.Logger.error()
		finally: self.adjustUnlock()

	def adjustSource(self, source, index):
		if self.stopThreads:
			self.adjustSourceDone(index)
			return None
		try:
			if not source['stream'].infoDuplicate():
				link = source['stream'].linkPrimary()
				local = source['stream'].sourceTypeLocal()
				special = source['stream'].sourceTypeTorrent() or source['stream'].sourceTypeUsenet()
				status = network.Networker.StatusUnknown

				# Resolve Link
				if not special and (self.precheckLink or self.precheckMetadata):
					if not source['stream'].linkProvider():
						resolved = network.Resolver.resolve(source = source, clean = True)
						if resolved:
							self.adjustSourceUpdate(index, resolved = link)
							link = resolved

				# Debrid Cache
				# Do before precheck and metadata, because it is a lot faster and more important. So execute first.
				if special and self.cacheEnabled and not source['stream'].hashContainer():
					# Do not automatically get the hash, since this will have to download the torrent/NZB files.
					# Sometimes more than 150 MB of torrents/NZBs can be downloaded on one go, wasting bandwidth and slowing down the addon/Kodi.
					download = False
					if source['stream'].sourceTypeTorrent(): download = self.preloadEnabledTorrent
					elif source['stream'].sourceTypeUsenet(): download = self.preloadEnabledUsenet

					container = network.Container(link = link, download = download)

					# Pass in the type, otherwise the container will load the providers to check to which provider the container belongs to.
					# This in turn calls the provider constructor for each of the lookups.
					# So Usenet links, or torrent tiles (without a hash) will instantiate the corresponding provider for each link found, which uses unnecessary processing power.
					hash = container.hash(type = source['stream'].sourceType())

					if not hash == None: self.adjustSourceUpdate(index, hash = hash)

				# Precheck
				if not special and self.precheckLink:
					if local: status = network.Networker.StatusOnline
					else: status = network.Networker().requestStatus(timeout = self.precheckLinkTime)
					self.adjustSourceUpdate(index, precheck = status)

				# Metadata
				if not special and self.precheckMetadata:
					if index < 0: return None # Already in list.
					if 'stream' in source: stream = source['stream']
					else: stream = Stream()
					if not local: stream.loadHeaders(link = link, timeout = self.precheckMetadataTime, force = False)
					self.adjustSourceUpdate(index, stream = stream)
		except:
			tools.Logger.error()

		self.adjustSourceDone(index)
		if not self.threadsLimit is None: self.adjustSourceStart()
		return source

	def sourcesFilter(self, items, metadata, autoplay = False, apply = True):
		try:
			filters = Filters(mode = Filters.ModeNone if autoplay else Filters.ModeManual)
			self.filter, items = filters.process(items = items, filter = apply)
		except: tools.Logger.error()
		return items

	def sourcesPrepare(self, items):
		try:
			# Create Metadata
			# Important update = true, because otherwise the debrid cache status is not always shown in the history window (shows as debrid instead of cached)
			for i in range(len(items)):
				items[i]['stream'] = Stream.load(data = items[i]['stream'])
		except:
			tools.Logger.error()
		return items

	def sourcesLabel(self, items, metadata):
		try:
			if not self.navigationStreamsSpecial:
				prefix = '[GAIANUMBER][GAIAEXTRA]'
				unknown = interface.Format.fontItalic(35248)
				separator = Stream.labelSeparator()
				format = Stream.settingsFormat()
				padding = tools.Settings.getInteger('interface.stream.interface.padding') # Try with Confluence. 3 and 3.5 is not enough. 4 by default.

				layout = tools.Settings.getInteger('interface.stream.interface.layout')
				layoutSingle = layout == 0
				layoutMultiple = layout == 1

				layoutName = tools.Settings.getInteger('interface.stream.interface.name')
				layoutNameExclusiveFront = layoutName == 1
				layoutNameExclusiveBack = layoutName == 2
				layoutNamePrependFront = layoutName == 3
				layoutNameAppendFront = layoutName == 4
				layoutNamePrependBack = layoutName == 5
				layoutNameAppendBack = layoutName == 6

				for i in range(len(items)):
					stream = items[i]['stream']

					labelTop = ''
					labelBottom = ''
					spaceTop = ''
					spaceBottom = ''

					if layoutSingle:
						if layoutNameExclusiveFront:
							name = stream.fileName()
							if not name: name = unknown
							labelTop = [name, stream.labelSingle(format = format)]
						elif layoutNameExclusiveBack:
							name = stream.fileName()
							if not name: name = unknown
							labelTop = [stream.labelSingle(format = format), name]
						elif layoutNamePrependFront:
							labelTop = [stream.fileName(), stream.labelTop(format = format), stream.labelBottom(format = format)]
						elif layoutNameAppendFront:
							labelTop = [stream.labelTop(format = format), stream.fileName(), stream.labelBottom(format = format)]
						elif layoutNamePrependBack:
							labelTop = [stream.labelTop(format = format), stream.fileName(), stream.labelBottom(format = format)]
						elif layoutNameAppendBack:
							labelTop = [stream.labelTop(format = format), stream.labelBottom(format = format), stream.fileName()]
						else:
							labelTop = stream.labelSingle(format = format)

						if tools.Tools.isArray(labelTop): labelTop = separator.join([x for x in labelTop if x])
					elif layoutMultiple:
						if layoutNameExclusiveFront:
							labelBottom = stream.labelSingle(format = format)
							labelTop = stream.fileName()
							if not labelTop: labelTop = unknown
						elif layoutNameExclusiveBack:
							labelTop = stream.labelSingle(format = format)
							labelBottom = stream.fileName()
							if not labelBottom: labelBottom = unknown
						elif layoutNamePrependFront:
							labelTop = [stream.fileName(), stream.labelTop(format = format)]
						elif layoutNameAppendFront:
							labelTop = [stream.labelTop(format = format), stream.fileName()]
						elif layoutNamePrependBack:
							labelBottom = [stream.fileName(), stream.labelBottom(format = format)]
						elif layoutNameAppendBack:
							labelBottom = [stream.labelBottom(format = format), stream.fileName()]
						else:
							labelBottom = stream.labelTop(format = format)
							labelTop = stream.labelBottom(format = format)

						if tools.Tools.isArray(labelTop): labelTop = separator.join([x for x in labelTop if x])
						if tools.Tools.isArray(labelBottom): labelBottom = separator.join([x for x in labelBottom if x])

						if padding > 0:
							# Spaces needed, otherwise the second line is cut off when shorter than the first line
							spaceTop = 0
							spaceBottom = 0
							if not labelTop: labelTop = ''
							if not labelBottom: labelBottom = ''
							lengthTop = len(re.sub('\\[(.*?)\\]', '', labelTop))
							lengthBottom = len(re.sub('\\[(.*?)\\]', '', labelBottom))
							if lengthBottom > lengthTop: spaceTop = int((lengthBottom - lengthTop) * padding)
							else: spaceBottom = int((lengthBottom - lengthTop) * padding)
							spaceTop = ' ' * max(8, spaceTop)
							spaceBottom = ' ' * max(8, spaceBottom)

					labels = []
					if labelTop:
						labelTop = prefix + labelTop + spaceTop
						labels.append(labelTop)
					if labelBottom:
						labelBottom += spaceBottom
						labels.append(labelBottom)

					items[i]['label'] = labels
		except:
			tools.Logger.error()
		return items

	def sourceCloud(self, item):
		result = self.sourceResolve(item = item, info = True, handleMode = handler.Handler.ModeSelection, cloud = True)
		if result['success']: interface.Dialog.notification(title = 33229, message = 33230, icon = interface.Dialog.IconSuccess)

	def sourceResult(self, error = None, id = None, link = None, local = False, loader = False):
		if error == None and not local:
			if not network.Networker.linkIs(link):
				error = 'unknown'
		return {
			'success' : (error == None),
			'error' : error,
			'id' : id,
			'link' : link,
			'loader' : loader,
		}

	def sourceExternal(self, stream):
		lookups = [stream.sourceHoster(), stream.sourcePublisher(), stream.sourceProvider()]
		if not stream.idOrionHas(): lookups.extend([stream.providerId(), stream.providerName()])
		lookups = [lookup.lower() for lookup in lookups if lookup]
		services = self.servicesExternal()
		for lookup in lookups:
			try: return services[lookup]
			except: pass
		return None

	def sourceProviderObject(self, stream):
		object = stream.providerObject()
		if not object or stream.idOrionHas(): object = self.sourceExternal(stream = stream) # If the stream comes from Orion, lookup the actual external provider.
		return object

	def sourceResolveProvider(self, item, force = False):
		if not force and item['stream'].linkProvider():
			return item['stream'].linkProvider()
		else:
			sourceObject = self.sourceProviderObject(stream = item['stream'])
			if sourceObject:
				resolved = None
				for link in item['stream'].link():
					resolved = sourceObject.resolve(link)
					if resolved:
						item['stream'].linkProviderSet(resolved, hoster = True)
						return resolved
			elif item['stream'].infoCustom():
				resolved = item['stream'].linkPrimary()
				item['stream'].linkProviderSet(resolved)
				return resolved
		return None

	def sourceResolve(self, item, info = False, internal = False, download = False, handle = None, handleMode = None, handleClose = True, resolve = network.Resolver.ModeService, cloud = False):
		try:
			error = None
			loader = False
			self.downloadCanceled = False
			log = True

			item['stream'] = Stream.load(data = item['stream'])
			url = self.sourceResolveProvider(item = item)

			if resolve == network.Resolver.ModeProvider: return self.sourceResult(link = url, loader = loader)

			# Do not retrieve the original link.
			# If externaal providers cannot resolve the link, they return None.
			# In such a case, resolving should stop immediately, instead of passing the original link to the handlere/resolver.
			# If the resolve() function is not implemented by the provider, the original link is returned as the resolved link, and will be set as linkProvider in the stream.
			url = item['stream'].linkResolved(original = False, provider = True, stream = False)
			if url is None: # Provider (especially external providers) could not internally resolve the link via the resolve() function.
				interface.Dialog.notification(title = 33448, message = 33691, icon = interface.Dialog.IconError)
				return self.sourceResult(error = 'resolve', loader = loader)

			url = url.replace('filefactory.com/stream/', 'filefactory.com/file/')
			if resolve == network.Resolver.ModeNone: return self.sourceResult(link = url, loader = loader)

			# Allow magnet links and local files.
			#if url == None or not '://' in str(url): raise Exception()
			isLocalFile = item['stream'].sourceTypeLocal() or tools.File.exists(url)
			if isLocalFile:
				# STRM files containing a plugin link.
				# Eg: The .strm files that are added by Gaia to the library.
				if Library.pathStrm(url):
					url = Library().resolveStrm(url)
					if url.startswith('plugin'):
						tools.System.executePlugin(command = url)
						return self.sourceResult(loader = loader)
					elif tools.File.exists(url):
						return self.sourceResult(link = url, local = True, loader = loader)
					else:
						# In case the STRM file contains a HTTP link, continue like normal.
						pass
				else:
					return self.sourceResult(link = url, local = True, loader = loader)

			if url == None or (not isLocalFile and not '://' in str(url) and not 'magnet:' in str(url)):
				error = 'Resolve Error'

			if not error:
				if not internal: item['stream'] = Stream.load(data = item['stream'])

				popups = (not internal)
				sourceHandler = handler.Handler()
				if handle == None:
					handle = sourceHandler.serviceDetermine(mode = handleMode, item = item, popups = popups, cloud = cloud)
					if handle == handler.Handler.ReturnUnavailable or handle == handler.Handler.ReturnExternal or handle == handler.Handler.ReturnCancel:
						info = False
						url = None
						self.downloadCanceled = (handle == handler.Handler.ReturnCancel)
						error = 'Handler Error'

				if not error:
					result = sourceHandler.handle(link = url, item = item, name = handle, download = download, popups = popups, close = handleClose, mode = handleMode, cloud = cloud)

					if 'loader' in result and result['loader']:
						loader = True
						interface.Loader.show()

					if not result['success']:
						if result['error'] == handler.Handler.ReturnUnavailable or result['error'] == handler.Handler.ReturnExternal or result['error'] == handler.Handler.ReturnCancel:
							info = False
							url = None
							self.downloadCanceled = (result['error'] == handler.Handler.ReturnCancel)
							if result['error'] == handler.Handler.ReturnExternal: log = False
							error = 'Handler Error: ' + result['error']
						else:
							error = 'Url Error: ' + result['error']

					if not error:
						# Kodi Player fails if there are spaces in the URL.
						# OffCloud sometimes returns links with spaces (eg: season packs).
						result['link'] = network.Networker.linkClean(result['link'], strip = False)

						extension = network.Networker().linkExtension(link = result['link'])
						extensions = ['rar', 'zip', '7zip', '7z', 's7z', 'tar', 'gz', 'gzip', 'iso', 'bz2', 'lz', 'lzma', 'dmg']
						if extension in extensions:
							if info:
								message = interface.Translation.string(33757) % extension.upper()
								interface.Dialog.notification(title = 33448, message = message, icon = interface.Dialog.IconError)
							try: orionoid.Orionoid().streamVote(idItem = item['stream'].idOrionItem(), idStream = item['stream'].idOrionStream(), vote = orionoid.Orionoid.VoteDown)
							except: pass
							return self.sourceResult(error = 'filetype', loader = loader)

						# Do not do prechecks at the moment.
						# If every re-enabled, do not do checks for Emby/Jellyfin, since those servers return an empty reply on HEEAD requests.
						'''if result['link'].startswith('http') and '.m3u8' in result['link']:
							if not network.Networker().requestSuccess(link = result['link']):
								error = 'M3U8 Error'
						elif result['link'].startswith('http'):
							# Some Premiumize hoster links, eg Vidto, return a 403 error when doing this precheck, even though the link works.
							# Do not conduct these prechecks for debrid services. If there is a problem with the link, the Kodi player will just fail.
							if not 'handle' in result or not result['handle'] in [i['id'] for i in handler.Handler.handles()]:
								if not network.Networker().requestSuccess(link = result['link']):
									error = 'Server Error'
						'''

						if not error: return result
		except:
			if log: tools.Logger.error()
			error = True

		if error:
			if log and not error is True: tools.Logger.log(error)
			if info: interface.Dialog.notification(title = 33448, message = 33449, icon = interface.Dialog.IconError)
			try: orionoid.Orionoid().streamVote(idItem = item['stream'].idOrionItem(), idStream = item['stream'].idOrionStream(), vote = orionoid.Orionoid.VoteDown)
			except: pass
			return self.sourceResult(link = url, error = 'unknown', loader = loader)

	def hosters(self):
		if Core.Hosters is None:
			self.lock.acquire() # Is accessed from multiple provider threads. Make sure it is only done once.
			if Core.Hosters is None:
				Core.Hosters = []
				try: Core.Hosters.extend(handler.HandleUrlResolver().services())
				except: pass
				try: Core.Hosters.extend(handler.HandleResolveUrl().services())
				except: pass
			self.lock.release()
		return Core.Hosters

	def hostersPremium(self):
		if Core.HostersPremium is None:
			self.lock.acquire() # Is accessed from multiple provider threads. Make sure it is only done once.
			if Core.HostersPremium is None:
				Core.HostersPremium = ['1fichier.com', 'oboom.com', 'rapidgator.net', 'rg.to', 'uploaded.net', 'uploaded.to', 'ul.to', 'filefactory.com', 'nitroflare.com', 'turbobit.net', 'uploadrocket.net']
			self.lock.release()
		return Core.HostersPremium

	def hostersCaptcha(self):
		if Core.HostersCaptcha is None:
			self.lock.acquire() # Is accessed from multiple provider threads. Make sure it is only done once.
			if Core.HostersCaptcha is None:
				Core.HostersCaptcha = ['hugefiles.net', 'kingfiles.net', 'openload.io', 'openload.co', 'oload.tv', 'thevideo.me', 'vidup.me', 'streamin.to', 'torba.se']
			self.lock.release()
		return Core.HostersCaptcha

	def hostersBlocked(self):
		if Core.HostersBlocked is None:
			self.lock.acquire() # Is accessed from multiple provider threads. Make sure it is only done once.
			if Core.HostersBlocked is None:
				Core.HostersBlocked = []
			self.lock.release()
		return Core.HostersBlocked

	def servicesDebrid(self):
		if Core.ServicesDebrid is None:
			self.lock.acquire() # Is accessed from multiple provider threads. Make sure it is only done once.
			if Core.ServicesDebrid is None:
				Core.ServicesDebrid = debrid.Debrid.services()
			self.lock.release()
		return Core.ServicesDebrid

	def servicesExternal(self):
		try:
			if Core.ServicesExternal is None:
				self.lock.acquire() # Is accessed from multiple provider threads. Make sure it is only done once.
				if Core.ServicesExternal is None:
					Core.ServicesExternal = {}
					symbols = ['.', '-', '_']

					# Do not retrieve only the enabled providers.
					# The user might have disabled external providers, but might still want to use hosters links from Orion that require these disabled providers.
					providers = manager.Manager.providers(enabled = None, local = False)

					for provider in providers:
						keys = []

						keys.append(provider.id())
						keys.append(provider.name())
						keys.append(provider.name().lower())
						try: keys.append(provider.instanceId())
						except: pass

						links = provider.links()
						if links:
							for link in links:
								keys.append(link)
								link = link.lower()
								keys.append(link)

								domain1 = network.Networker.linkDomain(link = link, subdomain = False, topdomain = True, ip = True)
								keys.append(domain1)
								keys.append(tools.Tools.replaceNotAlphaNumeric(domain1)) # Legacy Orion has hosters without TLD dot (eg: "nitrodownload" instead of "nitro.download").

								domain2 = network.Networker.linkDomain(link = link, subdomain = False, topdomain = False, ip = True)
								keys.append(domain2)
								keys.append(tools.Tools.replaceNotAlphaNumeric(domain2))

								for symbol in symbols:
									domain1 = domain1.replace(symbol, '')
									domain2 = domain2.replace(symbol, '')
								keys.append(domain1)
								keys.append(domain2)

						keys = [key for key in keys if key]
						keys = tools.Tools.listUnique(keys)

						for key in keys:
							Core.ServicesExternal[key] = provider

				self.lock.release()
		except:
			tools.Logger.error()
			try: self.lock.release()
			except: pass
		return Core.ServicesExternal
