# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs
import xbmcgui

import sys
import os
import re
import threading

class Time(object):

	# Use time.clock() instead of time.time() for processing time.
	# NB: Do not use time.clock(). Gives the wrong answer in timestamp() AND runs very fast in Linux. Hence, in the stream finding dialog, for every real second, Linux progresses 5-6 seconds.
	# http://stackoverflow.com/questions/85451/python-time-clock-vs-time-time-accuracy
	# https://www.tutorialspoint.com/python/time_clock.htm

	ZoneUtc = 'utc'
	ZoneLocal = 'local'

	FormatTimestamp = None
	FormatDateTime = '%Y-%m-%d %H:%M:%S'
	FormatDate = '%Y-%m-%d'
	FormatTime = '%H:%M:%S'
	FormatTimeShort = '%H:%M'

	def __init__(self, start = False):
		self.mStart = None
		if start: self.start()

	def start(self):
		import time
		self.mStart = time.time()
		return self.mStart

	def restart(self):
		return self.start()

	def elapsed(self, milliseconds = False):
		import time
		if self.mStart == None:
			self.mStart = time.time()
		if milliseconds: return (time.time() - self.mStart) * 1000
		else: return int(time.time() - self.mStart)

	def expired(self, expiration):
		return self.elapsed() >= expiration

	@classmethod
	def sleep(self, seconds):
		import time
		time.sleep(seconds)

	@classmethod
	def integer(self, date):
		return int(Regex.remove(data = date, expression = '[^0-9]'))

	# UTC timestamp
	# iso: Convert ISO to UTC timestamp.
	@classmethod
	def timestamp(self, fixedTime = None, format = None, iso = False):
		import time
		if iso:
			if not fixedTime: return 0

			import datetime

			delimiter = -1
			if not fixedTime.endswith('Z'):
				delimiter = fixedTime.rfind('+')
				if delimiter == -1: delimiter = fixedTime.rfind('-')

			if delimiter >= 0:
				stamp = fixedTime[:delimiter]
				sign = fixedTime[delimiter]
				zone = fixedTime[delimiter + 1:]
			else:
				stamp = fixedTime
				zone = None

			if stamp.find('.') > -1: stamp = stamp[:stamp.find('.')]
			try: date = datetime.datetime.strptime(stamp, '%Y-%m-%dT%H:%M:%S')
			except TypeError: date = datetime.datetime(*(time.strptime(stamp, '%Y-%m-%dT%H:%M:%S')[0:6]))

			difference = datetime.timedelta()
			if zone:
				hours, minutes = zone.split(':')
				hours = int(hours)
				minutes = int(minutes)
				if sign == '-':
					hours = -hours
					minutes = -minutes
				difference = datetime.timedelta(hours = hours, minutes = minutes)

			delta = date - difference - datetime.datetime.utcfromtimestamp(0)
			try: seconds = delta.total_seconds() # Works only on 2.7.
			except: seconds = delta.seconds + (delta.days * 86400) # Close enough.
			return seconds
		else:
			if fixedTime is None:
				# Do not use time.clock(), gives incorrect result for search.py
				return int(time.time())
			else:
				if format:
					fixedTime = self.datetime(fixedTime, format)
					if not fixedTime: return 0
				try: return int(time.mktime(fixedTime.timetuple()))
				except:
					# Somtimes mktime fails (mktime argument out of range), which seems to be an issue with very large dates (eg 2120-02-03) on Android.
					try: return int(time.strftime('%s', fixedTime))
					except: return 0

	@classmethod
	def format(self, timestamp = None, format = FormatDateTime, local = None):
		import time
		import datetime
		if timestamp is None: timestamp = self.timestamp()
		date = datetime.datetime.utcfromtimestamp(timestamp)
		if local:
			from lib.externals import pytz
			date = pytz.utc.localize(date).astimezone(pytz.timezone(self.zone()))
		return date.strftime(format)

	# datetime object from string
	@classmethod
	def datetime(self, string, format = FormatDateTime):
		import time
		import datetime
		try:
			return datetime.datetime.strptime(string, format)
		except:
			# Older Kodi Python versions do not have the strptime function.
			# http://forum.kodi.tv/showthread.php?tid=112916
			return datetime.datetime.fromtimestamp(time.mktime(time.strptime(string, format)))

	@classmethod
	def year(self, timestamp = None):
		import datetime
		if timestamp is None: return datetime.datetime.now().year
		else: return datetime.datetime.utcfromtimestamp(timestamp).year

	@classmethod
	def past(self, seconds = 0, minutes = 0, days = 0, format = FormatTimestamp, local = None):
		result = self.timestamp() - seconds - (minutes * 60) - (days * 86400)
		if not format == self.FormatTimestamp: result = self.format(timestamp = result, format = format, local = local)
		return result

	@classmethod
	def future(self, seconds = 0, minutes = 0, days = 0, format = FormatTimestamp, local = None):
		result = self.timestamp() + seconds + (minutes * 60) + (days * 86400)
		if not format == self.FormatTimestamp: result = self.format(timestamp = result, format = format, local = local)
		return result

	@classmethod
	def zone(self, country = None, all = False):
		if country:
			from lib.externals import pytz
			zones = pytz.country_timezones(country)
			if zones:
				if not all: return zones[0]
				else: return zones
			return None
		else:
			import time
			if time.daylight: offsetHour = time.altzone / 3600
			else: offsetHour = time.timezone / 3600
			return 'Etc/GMT%+d' % offsetHour

	@classmethod
	def offset(self, zone = None, country = None, all = False):
		import datetime
		from lib.externals import pytz
		if not zone: zone = self.zone(country = country, all = False)
		if Tools.isArray(zone): return [datetime.datetime.now(pytz.timezone(i)).strftime('%z') for i in zone]
		else: return datetime.datetime.now(pytz.timezone(zone)).strftime('%z')

	@classmethod
	def convert(self, stringTime, stringDay = None, abbreviate = False, formatInput = FormatTimeShort, formatOutput = None, zoneFrom = ZoneUtc, zoneTo = ZoneLocal):
		import datetime
		from lib.externals import pytz
		result = ''
		try:
			# If only time is given, the date will be set to 1900-01-01 and there are conversion problems if this goes down to 1899.
			if formatInput == '%H:%M':
				# Use current datetime (now) in order to accomodate for daylight saving time.
				stringTime = '%s %s' % (datetime.datetime.now().strftime('%Y-%m-%d'), stringTime)
				formatNew = '%Y-%m-%d %H:%M'
			else:
				formatNew = formatInput

			if zoneFrom == Time.ZoneUtc: zoneFrom = pytz.timezone('UTC')
			elif zoneFrom == Time.ZoneLocal: zoneFrom = pytz.timezone(self.zone())
			else: zoneFrom = pytz.timezone(zoneFrom)

			if zoneTo == Time.ZoneUtc: zoneTo = pytz.timezone('UTC')
			elif zoneTo == Time.ZoneLocal: zoneTo = pytz.timezone(self.zone())
			else: zoneTo = pytz.timezone(zoneTo)

			timeobject = self.datetime(string = stringTime, format = formatNew)

			if stringDay:
				stringDay = stringDay.lower()
				if stringDay.startswith('mon'): weekday = 0
				elif stringDay.startswith('tue'): weekday = 1
				elif stringDay.startswith('wed'): weekday = 2
				elif stringDay.startswith('thu'): weekday = 3
				elif stringDay.startswith('fri'): weekday = 4
				elif stringDay.startswith('sat'): weekday = 5
				else: weekday = 6
				weekdayCurrent = datetime.datetime.now().weekday()
				timeobject += datetime.timedelta(days = weekday) - datetime.timedelta(days = weekdayCurrent)

			timeobject = zoneFrom.localize(timeobject)
			timeobject = timeobject.astimezone(zoneTo)

			if not formatOutput: formatOutput = formatInput

			stringTime = timeobject.strftime(formatOutput)
			if stringDay:
				import calendar
				if abbreviate: stringDay = calendar.day_abbr[timeobject.weekday()]
				else: stringDay = calendar.day_name[timeobject.weekday()]
				return (stringTime, stringDay)
			else:
				return stringTime
		except:
			Logger.error()
			return stringTime


class Tools(object):

	@classmethod
	def copy(self, instance, deep = True):
		import copy
		return copy.deepcopy(instance) if deep else copy.copy(instance)

	@classmethod
	def update(self, structure1, structure2, none = True, lists = False, unique = True):
		attribute = unique if Tools.isString(unique) or Tools.isArray(unique) else None
		if not structure1 is None and not structure2 is None:
			for key, value in structure2.items():
				if not none and key in structure1 and value is None: pass
				elif not key in structure1 or structure1[key] is None: structure1[key] = value
				elif Tools.isDictionary(value): structure1[key] = self.update(structure1 = structure1.get(key, {}), structure2 = value, lists = lists, unique = unique)
				elif lists and Tools.isArray(value):
					structure1[key] = (structure1.get(key, []) + value)
					if unique: structure1[key] = self.listUnique(structure1[key], attribute = attribute, update = True, none = none, lists = lists, unique = unique)
				else: structure1[key] = value
		return structure1

	# Wether or not the instance object has a given attribute (either a variable or function).
	@classmethod
	def hasAttribute(self, instance, name):
		return hasattr(instance, name)

	# Wether or not the instance object has a given variable.
	@classmethod
	def hasVariable(self, instance, name):
		attribute = getattr(instance, name, None)
		return not attribute is None and not callable(attribute)

	# Wether or not the instance object has a given function.
	@classmethod
	def hasFunction(self, instance, name):
		attribute = getattr(instance, name, None)
		return not attribute is None and callable(attribute)

	@classmethod
	def getVariable(self, instance, name):
		return getattr(instance, name, None)

	# Returns the function pointer of an object.
	@classmethod
	def getFunction(self, instance, name):
		return getattr(instance, name, None)

	# Returns the pointer to a class.
	@classmethod
	def getClass(self, instance, name):
		return getattr(instance, name, None)

	# Either provide an instance
	@classmethod
	def getInstance(self, instance, name):
		try:
			if Tools.isString(instance):
				import importlib
				instance = importlib.import_module(instance)
			return self.getClass(instance = instance, name = name)()
		except: return None

	# Returns the module import string from a class or instance.
	@classmethod
	def getModule(self, instance):
		return instance.__module__

	@classmethod
	def getParameters(self, function, internal = False):
		result = list(function.__code__.co_varnames[:function.__code__.co_argcount])
		if not internal: result.remove('self')
		return result

	@classmethod
	def isFunction(self, function):
		return callable(function)

	# Executes a function of an object.
	@classmethod
	def executeFunction(self, instance, name, *args, **kwargs):
		return self.getFunction(instance = instance, name = name)(*args, **kwargs)

	# Remove special characters (non-alpha-numeric).
	# Do not use [^\w\d], since it removes unicode alpha characters.
	# \p is not supported in Python's re module.
	# Use Python's builtin function instead.
	@classmethod
	def replaceNotAlphaNumeric(self, data, replace = ''):
		try:
			for char in data:
				if not char.isalnum() and not char == replace:
					data = data.replace(char, replace)
		except: pass
		return data

	# Remove special characters (non-alpha).
	@classmethod
	def replaceNotAlpha(self, data, replace = ''):
		try:
			for char in data:
				if not char.isalpha() and not char == replace:
					data = data.replace(char, replace)
		except: pass
		return data

	@classmethod
	def dictionaryGet(self, dictionary, keys, merge = False):
		try:
			result = dictionary
			if Tools.isArray(keys):
				if merge:
					for key in keys:
						if Tools.isArray(result):
							items = []
							for item in result:
								if Tools.isArray(item[key]): items.extend(item[key])
								else: items.append(item[key])
							result = items
						else:
							result = result[key]
				else:
					for key in keys: result = result[key]
			else:
				if merge and Tools.isArray(result):
					items = []
					for item in result:
						if Tools.isArray(item[keys]): items.extend(item[keys])
						else: items.append(item[keys])
					result = items
				else:
					result = result[keys]
			return result
		except:
			return None

	@classmethod
	def dictionarySet(self, dictionary, keys, value):
		for key in keys[:-1]:
			 dictionary = dictionary.setdefault(key, {})
		dictionary[keys[-1]] = value

	@classmethod
	def dictionaryMerge(self, dictionary1, dictionary2):
		result = self.copy(dictionary1)
		result.update(dictionary2)
		return result

	@classmethod
	def listUnique(self, data, attribute = None, update = False, none = True, lists = False, unique = True):
		if attribute:
			result = []
			if update:
				seen = {}
				for i in range(len(data)):
					item = data[i]
					key = self.dictionaryGet(dictionary = item, keys = attribute)
					if key in seen:
						if self.isStructure(item):
							Tools.update(result[seen[key]], item, none = none, lists = lists, unique = unique)
						else:
							result[seen[key]] = item
					else:
						seen[key] = i
						result.append(item)
			else:
				seen = set()
				add = seen.add
				result = []
				for i in data:
					key = self.dictionaryGet(dictionary = i, keys = attribute)
					if not key in seen:
						result.append(i)
						add(key)
			return result
		elif len(data) > 0 and self.isDictionary(data[0]):
			result = []
			for i in data:
				if not i in result: result.append(i)
			return result
		else:
			seen = set()
			add = seen.add
			return [i for i in data if not (i in seen or add(i))]

	@classmethod
	def listFlatten(self, data, recursive = True):
		result = []
		for i in data:
			if self.isArray(i):
				if recursive: i = self.listFlatten(data = i, recursive = recursive)
				result.extend(i)
			else: result.append(i)
		return result

	@classmethod
	def listSort(self, data, key = None, reverse = False):
		return sorted(data, key = key, reverse = reverse)

	@classmethod
	def listShuffle(self, data):
		import random
		random.shuffle(data)
		return data

	@classmethod
	def isInstance(self, value, type):
		return isinstance(value, type)

	@classmethod
	def isBoolean(self, value):
		return isinstance(value, bool)

	@classmethod
	def isString(self, value):
		try: return isinstance(value, (str, bytes))
		except:
			try: return isinstance(value, (basestring, unicode))
			except: pass
		return False

	@classmethod
	def isInteger(self, value, bool = False):
		if not bool and self.isBoolean(value): return False
		return isinstance(value, int)

	@classmethod
	def isFloat(self, value):
		return isinstance(value, float)

	@classmethod
	def isNumber(self, value, bool = False):
		if not bool and self.isBoolean(value): return False
		return isinstance(value, (int, float))

	@classmethod
	def isList(self, value):
		return isinstance(value, list)

	@classmethod
	def isTuple(self, value):
		return isinstance(value, tuple)

	@classmethod
	def isArray(self, value):
		return isinstance(value, (list, tuple))

	@classmethod
	def isDictionary(self, value):
		return isinstance(value, dict)

	@classmethod
	def isStructure(self, value):
		return isinstance(value, (dict, list, tuple))

class Regex(object):

	FlagCaseInsensitive	= re.IGNORECASE
	FlagAllLines		= re.DOTALL

	FlagsDefault 		= FlagCaseInsensitive

	Symbol				= '[\-\!\$\%%\^\&\*\(\)\_\+\|\~\=\`\{\}\\\[\]\:\"\;\'\<\>\?\,\.\\\/]'

	@classmethod
	def expression(self, expression, flags = FlagsDefault):
		return re.compile(expression, flags = flags)

	@classmethod
	def match(self, data, expression, flags = FlagsDefault):
		return bool(re.search(expression, data, flags = flags))

	@classmethod
	def search(self, data, expression, all = False, flags = FlagsDefault):
		try:
			if all: return re.findall(expression, data, flags = flags)
			else: return re.search(expression, data, flags = flags)
		except: return None

	@classmethod
	def extract(self, data, expression, group = 1, all = False, flags = FlagsDefault):
		try:
			if all:
				match = re.findall(expression, data, flags = flags)
				if group is None: return match
				else: return match[group]
			else:
				match = re.search(expression, data, flags = flags)
				if group is None: return match.groups()
				else: return match.group(group)
		except: return None

	@classmethod
	def replace(self, data, expression, replacement, group = None, flags = FlagsDefault):
		if group:
			match = self.search(data = data, expression = expression, flags = flags)
			if match: data = data[:match.start(group)] + replacement + data[match.end(group):]
			return data
		else:
			return re.sub(expression, replacement, data, flags = flags)

	@classmethod
	def remove(self, data, expression, group = None, flags = FlagsDefault):
		return self.replace(data = data, expression = expression, replacement = '', group = group, flags = flags)


class JavaScript(object):

	Lock = threading.Lock()

	# variable: return the value of a specific variable. Otherwise return whatever the script returns.
	@classmethod
	def execute(self, code, variable = None):
		# When executing/parsing multiple code snippets from multiple threads at the same time using EvalJs, only one execution will succeed.
		# EvalJs probably uses an interal cache which gets overwritten but the code from multiple threads.
		# eval_js does not have this problem and can be executed in parallel. However, when using a lock, it is still about 50% faster than without a lock.
		try:
			JavaScript.Lock.acquire()
			if variable is None:
				from lib.externals.js2py import eval_js
				return eval_js(code)
			else:
				from lib.externals.js2py import EvalJs
				context = EvalJs()
				context.execute(code)
				return Tools.getVariable(context, variable)
		except:
			Logger.error()
			return None
		finally:
			JavaScript.Lock.release()


class Math(object):

	@classmethod
	def scale(self, value, fromMinimum = 0, fromMaximum = 1, toMinimum = 0, toMaximum = 1):
		return toMinimum + (value - fromMinimum) * ((toMaximum - toMinimum) / float(fromMaximum - fromMinimum))

	# Returns the closest value from the list.
	@classmethod
	def closest(self, list, value):
		return list[min(range(len(list)), key = lambda i : abs(list[i] - value))]

	@classmethod
	def random(self, start = 0.0, end = 1.0):
		import random
		if Tools.isFloat(start) or Tools.isFloat(end): return random.uniform(start, end)
		else: return random.randint(start, end)

	@classmethod
	def randomProbability(self, probability):
		return self.random() <= probability

	@classmethod
	def round(self, value, places = 0):
		return round(value, places)

	# Round to closests eg 10.
	@classmethod
	def roundClosest(self, value, base = 10):
		return int(base * round(float(value) / base))

	@classmethod
	def roundUp(self, value):
		import math
		return math.ceil(value)

	@classmethod
	def roundDown(self, value):
		import math
		return math.floor(value)

class Matcher(object):

	# Native Python
	AlgorithmDifferenceSequence = 'differencesequence' # Python's difflib.SequenceMatcher

	# Edit Distance (how many characters have to be added/removed/modified to get from string 1 to string 2).
	AlgorithmLongestSequence = 'longestsequence' # Longest Common Subsequence Distance
	AlgorithmLevenshtein = 'levenshtein' # Levenshtein Distance
	AlgorithmDamerauLevenshtein = 'dameraulevenshtein' # Damerau-Levenshtein Distance
	AlgorithmHamming = 'hamming' # Hamming Distance
	AlgorithmJaro = 'jaro' # Jaro Distance
	AlgorithmJaroWinkler = 'jarowinkler' # Jaro-Winkler Distance

	# Vector Similarity (measure of similarity between two non-zero vectors of an inner product space).
	AlgorithmCosine = 'cosine' # Cosine Similarity
	AlgorithmJaccard = 'jaccard' # Jaccard Similarity
	AlgorithmSorensen = 'sorensen' # Sorensen Dice Similarity
	AlgorithmQgram = 'qgram' # Q-Gram Similarity

	@classmethod
	def _encode(self, string):
		try: return string.decode('utf-8')
		except: return string

	@classmethod
	def match(self, algorithm, string1, string2, ignoreCase = True, ignoreSpace = False, ignoreNumeric = False, ignoreSymbol = False):
		string1 = self._encode(string1)
		string2 = self._encode(string2)

		if algorithm == Matcher.AlgorithmDifferenceSequence: return self.differenceSequence(string1 = string1, string2 = string2, ignoreCase = ignoreCase)
		if algorithm == Matcher.AlgorithmLongestSequence: return self.longestSequence(string1 = string1, string2 = string2, ignoreCase = ignoreCase, ignoreSpace = ignoreSpace, ignoreNumeric = ignoreNumeric, ignoreSymbol = ignoreSymbol)
		elif algorithm == Matcher.AlgorithmLevenshtein: return self.levenshtein(string1 = string1, string2 = string2, ignoreCase = ignoreCase, ignoreSpace = ignoreSpace, ignoreNumeric = ignoreNumeric, ignoreSymbol = ignoreSymbol)
		elif algorithm == Matcher.AlgorithmDamerauLevenshtein: return self.damerauLevenshtein(string1 = string1, string2 = string2, ignoreCase = ignoreCase, ignoreSpace = ignoreSpace, ignoreNumeric = ignoreNumeric, ignoreSymbol = ignoreSymbol)
		elif algorithm == Matcher.AlgorithmHamming: return self.hamming(string1 = string1, string2 = string2, ignoreCase = ignoreCase, ignoreSpace = ignoreSpace, ignoreNumeric = ignoreNumeric, ignoreSymbol = ignoreSymbol)
		elif algorithm == Matcher.AlgorithmJaro: return self.jaro(string1 = string1, string2 = string2, ignoreCase = ignoreCase, ignoreSpace = ignoreSpace, ignoreNumeric = ignoreNumeric, ignoreSymbol = ignoreSymbol)
		elif algorithm == Matcher.AlgorithmJaroWinkler: return self.jaroWinkler(string1 = string1, string2 = string2, ignoreCase = ignoreCase, ignoreSpace = ignoreSpace, ignoreNumeric = ignoreNumeric, ignoreSymbol = ignoreSymbol)
		elif algorithm == Matcher.AlgorithmCosine: return self.cosine(string1 = string1, string2 = string2, ignoreCase = ignoreCase, ignoreSpace = ignoreSpace, ignoreNumeric = ignoreNumeric, ignoreSymbol = ignoreSymbol)
		elif algorithm == Matcher.AlgorithmJaccard: return self.jaccard(string1 = string1, string2 = string2, ignoreCase = ignoreCase, ignoreSpace = ignoreSpace, ignoreNumeric = ignoreNumeric, ignoreSymbol = ignoreSymbol)
		elif algorithm == Matcher.AlgorithmSorensen: return self.sorensen(string1 = string1, string2 = string2, ignoreCase = ignoreCase, ignoreSpace = ignoreSpace, ignoreNumeric = ignoreNumeric, ignoreSymbol = ignoreSymbol)
		elif algorithm == Matcher.AlgorithmQgram: return self.qgram(string1 = string1, string2 = string2, ignoreCase = ignoreCase, ignoreSpace = ignoreSpace, ignoreNumeric = ignoreNumeric, ignoreSymbol = ignoreSymbol)
		else: return 0

	@classmethod
	def differenceSequence(self, string1, string2, ignoreCase = False):
		from difflib import SequenceMatcher
		string1 = self._encode(string1)
		string2 = self._encode(string2)
		if ignoreCase:
			string1 = string1.lower()
			string2 = string2.lower()
		return SequenceMatcher(None, string1, string2).ratio()

	@classmethod
	def longestSequence(self, string1, string2, ignoreCase = True, ignoreSpace = False, ignoreNumeric = False, ignoreSymbol = False):
		from lib.externals.pytextdist.edit_distance import lcs_similarity
		return lcs_similarity(self._encode(string1), self._encode(string2), ignore_non_alnumspc = ignoreSymbol, ignore_space = ignoreSpace, ignore_numeric = ignoreNumeric, ignore_case = ignoreCase)

	@classmethod
	def levenshtein(self, string1, string2, ignoreCase = True, ignoreSpace = False, ignoreNumeric = False, ignoreSymbol = False):
		from lib.externals.pytextdist.edit_distance import levenshtein_similarity
		return levenshtein_similarity(self._encode(string1), self._encode(string2), ignore_non_alnumspc = ignoreSymbol, ignore_space = ignoreSpace, ignore_numeric = ignoreNumeric, ignore_case = ignoreCase)

	@classmethod
	def damerauLevenshtein(self, string1, string2, ignoreCase = True, ignoreSpace = False, ignoreNumeric = False, ignoreSymbol = False):
		from lib.externals.pytextdist.edit_distance import damerau_levenshtein_similarity
		return damerau_levenshtein_similarity(self._encode(string1), self._encode(string2), ignore_non_alnumspc = ignoreSymbol, ignore_space = ignoreSpace, ignore_numeric = ignoreNumeric, ignore_case = ignoreCase)

	@classmethod
	def hamming(self, string1, string2, ignoreCase = True, ignoreSpace = False, ignoreNumeric = False, ignoreSymbol = False):
		from lib.externals.pytextdist.edit_distance import hamming_similarity
		# Hamming distance requires both strings to be the same length.
		string1 = self._encode(string1)
		string2 = self._encode(string2)
		length1 = len(string1)
		length2 = len(string2)
		if length1 > length2: string2 = string2.ljust(length1, 'x')
		elif length2 > length1: string1 = string1.ljust(length2, 'x')
		return hamming_similarity(string1, string2, ignore_non_alnumspc = ignoreSymbol, ignore_space = ignoreSpace, ignore_numeric = ignoreNumeric, ignore_case = ignoreCase)

	@classmethod
	def jaro(self, string1, string2, ignoreCase = True, ignoreSpace = False, ignoreNumeric = False, ignoreSymbol = False):
		from lib.externals.pytextdist.edit_distance import jaro_similarity
		return jaro_similarity(self._encode(string1), self._encode(string2), ignore_non_alnumspc = ignoreSymbol, ignore_space = ignoreSpace, ignore_numeric = ignoreNumeric, ignore_case = ignoreCase)

	@classmethod
	def jaroWinkler(self, string1, string2, ignoreCase = True, ignoreSpace = False, ignoreNumeric = False, ignoreSymbol = False):
		from lib.externals.pytextdist.edit_distance import jaro_winkler_similarity
		return jaro_winkler_similarity(self._encode(string1), self._encode(string2), ignore_non_alnumspc = ignoreSymbol, ignore_space = ignoreSpace, ignore_numeric = ignoreNumeric, ignore_case = ignoreCase)

	@classmethod
	def cosine(self, string1, string2, ignoreCase = True, ignoreSpace = False, ignoreNumeric = False, ignoreSymbol = False):
		from lib.externals.pytextdist.vector_similarity import cosine_similarity
		try: return cosine_similarity(self._encode(string1), self._encode(string2), ignore_non_alnumspc = ignoreSymbol, ignore_space = ignoreSpace, ignore_numeric = ignoreNumeric, ignore_case = ignoreCase)
		except: return 0 # Empty string throws exception.

	@classmethod
	def jaccard(self, string1, string2, ignoreCase = True, ignoreSpace = False, ignoreNumeric = False, ignoreSymbol = False):
		from lib.externals.pytextdist.vector_similarity import jaccard_similarity
		try: return jaccard_similarity(self._encode(string1), self._encode(string2), ignore_non_alnumspc = ignoreSymbol, ignore_space = ignoreSpace, ignore_numeric = ignoreNumeric, ignore_case = ignoreCase)
		except: return 0 # Empty string throws exception.

	@classmethod
	def sorensen(self, string1, string2, ignoreCase = True, ignoreSpace = False, ignoreNumeric = False, ignoreSymbol = False):
		from lib.externals.pytextdist.vector_similarity import sorensen_dice_similarity
		try: return sorensen_dice_similarity(self._encode(string1), self._encode(string2), ignore_non_alnumspc = ignoreSymbol, ignore_space = ignoreSpace, ignore_numeric = ignoreNumeric, ignore_case = ignoreCase)
		except: return 0 # Empty string throws exception.

	@classmethod
	def qgram(self, string1, string2, ignoreCase = True, ignoreSpace = False, ignoreNumeric = False, ignoreSymbol = False):
		from lib.externals.pytextdist.vector_similarity import qgram_similarity
		try: return qgram_similarity(self._encode(string1), self._encode(string2), ignore_non_alnumspc = ignoreSymbol, ignore_space = ignoreSpace, ignore_numeric = ignoreNumeric, ignore_case = ignoreCase)
		except: return 0 # Empty string throws exception.

class Language(object):

	Code = 'code'
	Name = 'name'
	Original = 'original'
	Country = 'country'
	Frequency = 'frequency'

	# Types
	TypePrimary = 'primary'
	TypeSecondary = 'secondary'
	TypeTertiary = 'tertiary'
	TypeDefault = TypePrimary

	# Settings
	SettingBase = 'general.language.'
	SettingPrimary = SettingBase + TypePrimary
	SettingSecondary = SettingBase + TypeSecondary
	SettingTertiary = SettingBase + TypeTertiary

	# Api
	ApiTrakt = 'trakt'
	ApiTvdb = 'tvdb'

	# Cases
	CaseCapital = 0
	CaseUpper = 1
	CaseLower = 2

	# Names
	NameEnglish = 0
	NameNative = 1
	NameDefault = NameEnglish

	# Codes
	CodePrimary = 0
	CodeSecondary = 1
	CodeTertiary = 2
	CodeDefault = CodePrimary

	# Common
	FrequencyCommon = 3			# Very common language, spoken by 10s of millions.
	FrequencyOccasional = 2		# Less common language, spoken by a few millions or a major national language.
	FrequencyUncommon = 1		# Uncommon language, spoke by a few millions or less.
	FrequencyNone = 0			# Not an official language.

	Disabled = 'none'			# Do not use a language at all.
	Automatic = 'automatic'		# Use the language according to the settings specified by the user in the language settings under the General tab.
	Alternative = 'alternative'	# Use the first language, besides English, according to the settings sepcified by the user in the language settings under the General tab. Just like Automatic, but excludes English.

	UniversalName = 'Universal'
	UniversalCode = 'un'
	UniversalCountry = 'un'

	EnglishName = 'English'
	EnglishCode = 'en'
	EnglishCountry = 'gb'

	# Other
	FrenchCode = 'fr'
	DutchCode = 'nl'
	GermanCode = 'de'
	ItalianCode = 'it'
	SpanishCode = 'es'
	PortugueseCode = 'pt'
	RussianCode = 'ru'

	# Sets
	Sets = {
		'providers' : [FrenchCode, DutchCode, GermanCode, ItalianCode, SpanishCode, PortugueseCode, RussianCode],	# The set of languages supported by providers. Used in scrape.query.keyword.language.
	}

	Replacements = {'gr' : 'el'}
	Detection = None
	Settings = None

	Languages = (
		{Name : [UniversalName, UniversalName],			Code : [UniversalCode, UniversalCode, UniversalCode],	Country : UniversalCountry,	Frequency : FrequencyNone},
		{Name : ['Abkhaz', 'Aҧсуа бызшәа'],				Code : ['ab', 'abk', 'abk'],	Country : 'ge',	Frequency : FrequencyUncommon},
		{Name : ['Afar', 'Qafár af'],					Code : ['aa', 'aar', 'aar'],	Country : 'dj',	Frequency : FrequencyUncommon},
		{Name : ['Afrikaans', 'Afrikaans'],				Code : ['af', 'afr', 'afr'],	Country : 'za',	Frequency : FrequencyOccasional},
		{Name : ['Akan', 'Akan'],						Code : ['ak', 'aka', 'aka'],	Country : 'gh',	Frequency : FrequencyUncommon},
		{Name : ['Albanian', 'Shqip'],					Code : ['sq', 'alb', 'sqi'],	Country : 'al',	Frequency : FrequencyOccasional},
		{Name : ['Amharic', 'ኣማርኛ'],					Code : ['am', 'amh', 'amh'],	Country : 'et',	Frequency : FrequencyUncommon},
		{Name : ['Arabic', 'العربية'],					Code : ['ar', 'ara', 'ara'],	Country : 'sa',	Frequency : FrequencyCommon},
		{Name : ['Aragonese', 'l\'Aragonés'],			Code : ['an', 'arg', 'arg'],	Country : 'es',	Frequency : FrequencyUncommon},
		{Name : ['Armenian', 'Հայերեն'],				Code : ['hy', 'arm', 'hye'],	Country : 'am',	Frequency : FrequencyOccasional},
		{Name : ['Assamese', 'অসমীয়া'],					Code : ['as', 'asm', 'asm'],	Country : 'in',	Frequency : FrequencyUncommon},
		{Name : ['Avar', 'МагIарул МацI'],				Code : ['av', 'ava', 'ava'],	Country : 'ru',	Frequency : FrequencyUncommon},
		{Name : ['Avestan', 'Avestan'],					Code : ['ae', 'ave', 'ave'],	Country : 'ir',	Frequency : FrequencyUncommon},
		{Name : ['Aymara', 'Aymar Aru'],				Code : ['ay', 'aym', 'aym'],	Country : 'bo',	Frequency : FrequencyUncommon},
		{Name : ['Azerbaijani', 'Azərbaycanca'],		Code : ['az', 'aze', 'aze'],	Country : 'az',	Frequency : FrequencyOccasional},
		{Name : ['Bambara', 'Bamanankan'],				Code : ['bm', 'bam', 'bam'],	Country : 'ml',	Frequency : FrequencyOccasional},
		{Name : ['Bashkir', 'башҡорт Теле'],			Code : ['ba', 'bak', 'bak'],	Country : 'ru',	Frequency : FrequencyUncommon},
		{Name : ['Basque', 'Euskara'],					Code : ['eu', 'baq', 'eus'],	Country : 'es',	Frequency : FrequencyUncommon},
		{Name : ['Belarusian', 'Беларуская'],			Code : ['be', 'bel', 'bel'],	Country : 'by',	Frequency : FrequencyOccasional},
		{Name : ['Bengali', 'বাংলা'],					Code : ['bn', 'ben', 'ben'],	Country : 'bd',	Frequency : FrequencyCommon},
		{Name : ['Bihari', 'Bihari'],					Code : ['bh', 'bih', 'bih'],	Country : 'in',	Frequency : FrequencyUncommon},
		{Name : ['Bislama', 'Bislama'],					Code : ['bi', 'bis', 'bis'],	Country : 'vu',	Frequency : FrequencyUncommon},
		{Name : ['Bosnian', 'Босански'],				Code : ['bs', 'bos', 'bos'],	Country : 'ba',	Frequency : FrequencyOccasional},
		{Name : ['Bokmal', 'Bokmål'],					Code : ['nb', 'nob', 'nob'],	Country : 'no',	Frequency : FrequencyUncommon},
		{Name : ['Breton', 'Brezhoneg'],				Code : ['br', 'bre', 'bre'],	Country : 'fr',	Frequency : FrequencyUncommon},
		{Name : ['Bulgarian', 'български'],				Code : ['bg', 'bul', 'bul'],	Country : 'bg',	Frequency : FrequencyUncommon},
		{Name : ['Burmese', 'မြန်မာစာ'],					Code : ['my', 'bur', 'mya'],	Country : 'mm',	Frequency : FrequencyOccasional},
		{Name : ['Catalan', 'Català'],					Code : ['ca', 'cat', 'cat'],	Country : 'es',	Frequency : FrequencyOccasional},
		{Name : ['Chamorro', 'Chamoru'],				Code : ['ch', 'cha', 'cha'],	Country : 'gu',	Frequency : FrequencyUncommon},
		{Name : ['Chechen', 'Нохчийн Mотт'],			Code : ['ce', 'che', 'che'],	Country : 'ru',	Frequency : FrequencyUncommon},
		{Name : ['Chichewa', 'Chicheŵa'],				Code : ['ny', 'nya', 'nya'],	Country : 'mw',	Frequency : FrequencyUncommon},
		{Name : ['Chinese', '中文'],						Code : ['zh', 'chi', 'zho'],	Country : 'cn',	Frequency : FrequencyCommon},
		{Name : ['Chuvash', 'Чӑвашла'],					Code : ['cv', 'chv', 'chv'],	Country : 'ru',	Frequency : FrequencyUncommon},
		{Name : ['Cornish', 'Kernewek'],				Code : ['kw', 'cor', 'cor'],	Country : 'gb',	Frequency : FrequencyUncommon},
		{Name : ['Corsican', 'v'],						Code : ['co', 'cos', 'cos'],	Country : 'fr',	Frequency : FrequencyUncommon},
		{Name : ['Cree', 'ᓀᐦᐃᔭᐍᐏᐣ'],					Code : ['cr', 'cre', 'cre'],	Country : 'ca',	Frequency : FrequencyUncommon},
		{Name : ['Croatian', 'Hrvatski'],				Code : ['hr', 'hrv', 'hrv'],	Country : 'hr',	Frequency : FrequencyUncommon},
		{Name : ['Czech', 'Čeština'],					Code : ['cs', 'cze', 'ces'],	Country : 'cz',	Frequency : FrequencyOccasional},
		{Name : ['Danish', 'Dansk'],					Code : ['da', 'dan', 'dan'],	Country : 'dk',	Frequency : FrequencyOccasional},
		{Name : ['Dutch', 'Nederlands'],				Code : ['nl', 'dut', 'nld'],	Country : 'nl',	Frequency : FrequencyCommon},
		{Name : ['Dzongkha', 'རྫོང་ཁ་'],					Code : ['dz', 'dzo', 'dzo'],	Country : 'bt',	Frequency : FrequencyUncommon},
		{Name : ['English', 'English'],					Code : ['en', 'eng', 'eng'],	Country : 'gb',	Frequency : FrequencyCommon},
		{Name : ['Esperanto', 'Esperantaj'],			Code : ['eo', 'epo', 'epo'],	Country : None,	Frequency : FrequencyNone},
		{Name : ['Estonian', 'Eesti'],					Code : ['et', 'est', 'est'],	Country : 'ee',	Frequency : FrequencyUncommon},
		{Name : ['Ewe', 'Èʋegbe'],						Code : ['ee', 'ewe', 'ewe'],	Country : 'gh',	Frequency : FrequencyUncommon},
		{Name : ['Faroese', 'Føroyskt'],				Code : ['fo', 'fao', 'fao'],	Country : 'fo',	Frequency : FrequencyUncommon},
		{Name : ['Fijian', 'Vakaviti'],					Code : ['fj', 'fij', 'fij'],	Country : 'fj',	Frequency : FrequencyUncommon},
		{Name : ['Finnish', 'Suomi'],					Code : ['fi', 'fin', 'fin'],	Country : 'fi',	Frequency : FrequencyOccasional},
		{Name : ['French', 'Français'],					Code : ['fr', 'fre', 'fra'],	Country : 'fr',	Frequency : FrequencyCommon},
		{Name : ['Frisian', 'Frysk'],					Code : ['fy', 'fry', 'fry'],	Country : 'nl',	Frequency : FrequencyUncommon},
		{Name : ['Fula', 'Fulfulde'],					Code : ['ff', 'ful', 'ful'],	Country : 'bf',	Frequency : FrequencyOccasional},
		{Name : ['Galician', 'Galego'],					Code : ['gl', 'glg', 'glg'],	Country : 'es',	Frequency : FrequencyUncommon},
		{Name : ['Ganda', 'Oluganda'],					Code : ['lg', 'lug', 'lug'],	Country : 'ug',	Frequency : FrequencyUncommon},
		{Name : ['Georgian', 'ქართული'],				Code : ['ka', 'geo', 'kat'],	Country : 'ge',	Frequency : FrequencyOccasional},
		{Name : ['German', 'Deutsch'],					Code : ['de', 'ger', 'deu'],	Country : 'de',	Frequency : FrequencyCommon},
		{Name : ['Greek', 'Ελληνικά'],					Code : ['el', 'gre', 'ell'],	Country : 'gr',	Frequency : FrequencyCommon},
		{Name : ['Greenlandic', 'Kalaallisut'],			Code : ['kl', 'kal', 'kal'],	Country : 'gl',	Frequency : FrequencyUncommon},
		{Name : ['Guarani', 'Avañe\'ẽ'],				Code : ['gn', 'grn', 'grn'],	Country : 'py',	Frequency : FrequencyUncommon},
		{Name : ['Gujarati', 'ગુજરાતી'],					Code : ['gu', 'guj', 'guj'],	Country : 'in',	Frequency : FrequencyOccasional},
		{Name : ['Haitian', 'Kreyòl Ayisyen'],			Code : ['ht', 'hat', 'hat'],	Country : 'ht',	Frequency : FrequencyOccasional},
		{Name : ['Hausa', 'حَوْسَ'],						Code : ['ha', 'hau', 'hau'],	Country : 'ng',	Frequency : FrequencyOccasional},
		{Name : ['Hebrew', 'עברית'],					Code : ['he', 'heb', 'heb'],	Country : 'il',	Frequency : FrequencyOccasional},
		{Name : ['Herero', 'Otjiherero'],				Code : ['hz', 'her', 'her'],	Country : 'na',	Frequency : FrequencyUncommon},
		{Name : ['Hindi', 'हिन्दी'],						Code : ['hi', 'hin', 'hin'],	Country : 'in',	Frequency : FrequencyCommon},
		{Name : ['Hiri Motu', 'Hiri Motu'],				Code : ['ho', 'hmo', 'hmo'],	Country : 'pg',	Frequency : FrequencyUncommon},
		{Name : ['Hungarian', 'Magyar'],				Code : ['hu', 'hun', 'hun'],	Country : 'hu',	Frequency : FrequencyOccasional},
		{Name : ['Interlingua', 'Interlingua'],			Code : ['ia', 'ina', 'ina'],	Country : None,	Frequency : FrequencyNone},
		{Name : ['Indonesian', 'Bahasa Indonesia'],		Code : ['id', 'ind', 'ind'],	Country : 'id',	Frequency : FrequencyOccasional},
		{Name : ['Interlingue', 'Interlingue'],			Code : ['ie', 'ile', 'ile'],	Country : None,	Frequency : FrequencyNone},
		{Name : ['Irish', 'Gaeilge'],					Code : ['ga', 'gle', 'gle'],	Country : 'ie',	Frequency : FrequencyUncommon},
		{Name : ['Igbo', 'Asụsụ Igbo'],					Code : ['ig', 'ibo', 'ibo'],	Country : 'ng',	Frequency : FrequencyOccasional},
		{Name : ['Inupiaq', 'Inupiatun'],				Code : ['ik', 'ipk', 'ipk'],	Country : 'us',	Frequency : FrequencyUncommon},
		{Name : ['Ido', 'Ido'],							Code : ['io', 'ido', 'ido'],	Country : None,	Frequency : FrequencyNone},
		{Name : ['Icelandic', 'Íslenska'],				Code : ['is', 'ice', 'isl'],	Country : 'is',	Frequency : FrequencyOccasional},
		{Name : ['Italian', 'Italiano'],				Code : ['it', 'ita', 'ita'],	Country : 'it',	Frequency : FrequencyCommon},
		{Name : ['Inuktitut', 'ᐃᓄᒃᑎᑐᑦ'],				Code : ['iu', 'iku', 'iku'],	Country : 'ca',	Frequency : FrequencyUncommon},
		{Name : ['Japanese', '日本語'],					Code : ['ja', 'jpn', 'jpn'],	Country : 'jp',	Frequency : FrequencyCommon},
		{Name : ['Javanese', 'Baṣa Jawa'],				Code : ['jv', 'jav', 'jav'],	Country : 'id',	Frequency : FrequencyOccasional},
		{Name : ['Kannada', 'ಕನ್ನಡ'],						Code : ['kn', 'kan', 'kan'],	Country : 'in',	Frequency : FrequencyOccasional},
		{Name : ['Kanuri', 'Kanuri'],					Code : ['kr', 'kau', 'kau'],	Country : 'ng',	Frequency : FrequencyUncommon},
		{Name : ['Kashmiri', 'कॉशुर'],					Code : ['ks', 'kas', 'kas'],	Country : 'in',	Frequency : FrequencyUncommon},
		{Name : ['Kazakh', 'Қазақ Tілі'],				Code : ['kk', 'kaz', 'kaz'],	Country : 'kz',	Frequency : FrequencyOccasional},
		{Name : ['Khmer', 'ភាសាខ្មែរ'],					Code : ['km', 'khm', 'khm'],	Country : 'kh',	Frequency : FrequencyOccasional},
		{Name : ['Kikuyu', 'Gĩkũyũ'],					Code : ['ki', 'kik', 'kik'],	Country : 'ke',	Frequency : FrequencyUncommon},
		{Name : ['Kinyarwanda', 'Ikinyarwanda'],		Code : ['rw', 'kin', 'kin'],	Country : 'rw',	Frequency : FrequencyUncommon},
		{Name : ['Kirundi', 'íkiRǔndi'],				Code : ['rn', 'run', 'run'],	Country : 'bi',	Frequency : FrequencyUncommon},
		{Name : ['Kyrgyz', 'Кыргызча'],					Code : ['ky', 'kir', 'kir'],	Country : 'kg',	Frequency : FrequencyOccasional},
		{Name : ['Komi', 'Коми кыв'],					Code : ['kv', 'kom', 'kom'],	Country : 'ru',	Frequency : FrequencyUncommon},
		{Name : ['Kongo', 'Kikongo'],					Code : ['kg', 'kon', 'kon'],	Country : 'cd',	Frequency : FrequencyUncommon},
		{Name : ['Korean', '한국어'],					Code : ['ko', 'kor', 'kor'],	Country : 'kr',	Frequency : FrequencyCommon},
		{Name : ['Kurdish', 'Kurdí'],					Code : ['ku', 'kur', 'kur'],	Country : 'iq',	Frequency : FrequencyOccasional},
		{Name : ['Kwanyama', 'Oshikwanyama'],			Code : ['kj', 'kua', 'kua'],	Country : 'ao',	Frequency : FrequencyUncommon},
		{Name : ['Latin', 'Lingua Latina'],				Code : ['la', 'lat', 'lat'],	Country : 'it',	Frequency : FrequencyUncommon},
		{Name : ['Luxembourgish', 'Lëtzebuergesch'],	Code : ['lb', 'ltz', 'ltz'],	Country : 'lu',	Frequency : FrequencyUncommon},
		{Name : ['Limburgish', 'Lèmburgs'],				Code : ['li', 'lim', 'lim'],	Country : 'nl',	Frequency : FrequencyUncommon},
		{Name : ['Lingala', 'Lingála'],					Code : ['ln', 'lin', 'lin'],	Country : 'cd',	Frequency : FrequencyOccasional},
		{Name : ['Lao', 'ພາສາລາວ'],					Code : ['lo', 'lao', 'lao'],	Country : 'la',	Frequency : FrequencyOccasional},
		{Name : ['Lithuanian', 'Lietuvių'],				Code : ['lt', 'lit', 'lit'],	Country : 'lt',	Frequency : FrequencyUncommon},
		{Name : ['Luba-Kasai', 'Tshiluba'],				Code : ['lu', 'lub', 'lub'],	Country : 'cd',	Frequency : FrequencyUncommon},
		{Name : ['Latvian', 'Latviešu'],				Code : ['lv', 'lav', 'lav'],	Country : 'lv',	Frequency : FrequencyUncommon},
		{Name : ['Manx', 'Gaelg'],						Code : ['gv', 'glv', 'glv'],	Country : 'im',	Frequency : FrequencyUncommon},
		{Name : ['Macedonian', 'Mакедонски'],			Code : ['mk', 'mac', 'mkd'],	Country : 'mk',	Frequency : FrequencyOccasional},
		{Name : ['Malagasy', 'Malagasy'],				Code : ['mg', 'mlg', 'mlg'],	Country : 'mg',	Frequency : FrequencyUncommon},
		{Name : ['Malay', 'Bahasa Melayu'],				Code : ['ms', 'may', 'msa'],	Country : 'my',	Frequency : FrequencyOccasional},
		{Name : ['Malayalam', 'മലയാളം'],				Code : ['ml', 'mal', 'mal'],	Country : 'in',	Frequency : FrequencyOccasional},
		{Name : ['Maldivian', 'ދިވެހި'],					Code : ['dv', 'div', 'div'],	Country : 'mv',	Frequency : FrequencyUncommon},
		{Name : ['Maltese', 'Malti'],					Code : ['mt', 'mlt', 'mlt'],	Country : 'mt',	Frequency : FrequencyUncommon},
		{Name : ['Maori', 'Te Reo Māori'],				Code : ['mi', 'mao', 'mri'],	Country : 'nz',	Frequency : FrequencyUncommon},
		{Name : ['Marathi', 'मराठी'],					Code : ['mr', 'mar', 'mar'],	Country : 'in',	Frequency : FrequencyUncommon},
		{Name : ['Marshallese', 'Kajin M̧ajeļ'],			Code : ['mh', 'mah', 'mah'],	Country : 'mh',	Frequency : FrequencyUncommon},
		{Name : ['Mongolian', 'монгол'],				Code : ['mn', 'mon', 'mon'],	Country : 'mn',	Frequency : FrequencyOccasional},
		{Name : ['Nauru', 'Ekakairũ Naoero'],			Code : ['na', 'nau', 'nau'],	Country : 'nr',	Frequency : FrequencyUncommon},
		{Name : ['Navajo', '	Diné Bizaad'],			Code : ['nv', 'nav', 'nav'],	Country : 'us',	Frequency : FrequencyUncommon},
		{Name : ['North Ndebele', 'Sindebele'],			Code : ['nd', 'nde', 'nde'],	Country : 'zw',	Frequency : FrequencyUncommon},
		{Name : ['Nepali', 'नेपाली'],						Code : ['ne', 'nep', 'nep'],	Country : 'np',	Frequency : FrequencyOccasional},
		{Name : ['Ndonga', 'Oshindonga'],				Code : ['ng', 'ndo', 'ndo'],	Country : 'na',	Frequency : FrequencyUncommon},
		{Name : ['Norwegian', 'Norsk'],					Code : ['no', 'nor', 'nor'],	Country : 'no',	Frequency : FrequencyOccasional},
		{Name : ['Nuosu', 'Nuosuhxop'],					Code : ['ii', 'iii', 'iii'],	Country : 'cn',	Frequency : FrequencyUncommon},
		{Name : ['Nynorsk', 'Nynorsk'],					Code : ['nn', 'nno', 'nno'],	Country : 'no',	Frequency : FrequencyUncommon},
		{Name : ['Occitan', 'Occitan'],					Code : ['oc', 'oci', 'oci'],	Country : 'fr',	Frequency : FrequencyUncommon},
		{Name : ['Ojibwe', 'ᐊᓂᔑᓈᐯᒧᐎᓐ'],				Code : ['oj', 'oji', 'oji'],	Country : 'ca',	Frequency : FrequencyUncommon},
		{Name : ['Old Slavonic', 'словѣньскъ'],			Code : ['cu', 'chu', 'chu'],	Country : 'sk',	Frequency : FrequencyUncommon},
		{Name : ['Oromo', 'Afaan Oromoo'],				Code : ['om', 'orm', 'orm'],	Country : 'et',	Frequency : FrequencyUncommon},
		{Name : ['Oriya', 'ଓଡ଼ିଆ'],						Code : ['or', 'ori', 'ori'],	Country : 'in',	Frequency : FrequencyUncommon}, # Uncommon, otherwise the word "or" is matched in stream.py.
		{Name : ['Ossetian', 'ирон æвзаг'],				Code : ['os', 'oss', 'oss'],	Country : 'ru',	Frequency : FrequencyUncommon},
		{Name : ['Punjabi', 'ਪੰਜਾਬੀ'],					Code : ['pa', 'pan', 'pan'],	Country : 'in',	Frequency : FrequencyCommon},
		{Name : ['Pali', 'पालि'],						Code : ['pi', 'pli', 'pli'],	Country : 'in',	Frequency : FrequencyUncommon},
		{Name : ['Persian', 'فارسی'],					Code : ['fa', 'per', 'fas'],	Country : 'ir',	Frequency : FrequencyCommon},
		{Name : ['Polish', 'Polski'],					Code : ['pl', 'pol', 'pol'],	Country : 'pl',	Frequency : FrequencyCommon},
		{Name : ['Pashto', 'پښتو'],						Code : ['ps', 'pus', 'pus'],	Country : 'af',	Frequency : FrequencyUncommon},
		{Name : ['Portuguese', 'Português'],			Code : ['pt', 'por', 'por'],	Country : 'pt',	Frequency : FrequencyCommon},
		{Name : ['Quechua', 'Qhichwa'],					Code : ['qu', 'que', 'que'],	Country : 'pe',	Frequency : FrequencyUncommon},
		{Name : ['Romansh', 'Rumantsch'],				Code : ['rm', 'roh', 'roh'],	Country : 'ch',	Frequency : FrequencyUncommon},
		{Name : ['Romanian', 'Română'],					Code : ['ro', 'rum', 'ron'],	Country : 'ro',	Frequency : FrequencyOccasional},
		{Name : ['Russian', 'Русский'],					Code : ['ru', 'rus', 'rus'],	Country : 'ru',	Frequency : FrequencyCommon},
		{Name : ['Sanskrit', 'संस्कृतम्'],					Code : ['sa', 'san', 'san'],	Country : 'in',	Frequency : FrequencyUncommon},
		{Name : ['Sardinian', 'Sardu'],					Code : ['sc', 'srd', 'srd'],	Country : 'it',	Frequency : FrequencyUncommon},
		{Name : ['Sindhi', 'سنڌي'],						Code : ['sd', 'snd', 'snd'],	Country : 'in',	Frequency : FrequencyUncommon},
		{Name : ['Sami', 'Sámi'],						Code : ['se', 'sme', 'sme'],	Country : 'se',	Frequency : FrequencyUncommon},
		{Name : ['Samoan', 'Gagana Sāmoa'],				Code : ['sm', 'smo', 'smo'],	Country : 'ws',	Frequency : FrequencyUncommon},
		{Name : ['Sango', 'Yângâ tî Sängö'],			Code : ['sg', 'sag', 'sag'],	Country : 'cf',	Frequency : FrequencyUncommon},
		{Name : ['Serbian', 'Српски'],					Code : ['sr', 'srp', 'srp'],	Country : 'rs',	Frequency : FrequencyOccasional},
		{Name : ['Gaelic', 'Gàidhlig'],					Code : ['gd', 'gla', 'gla'],	Country : 'gb',	Frequency : FrequencyUncommon},
		{Name : ['Shona', 'Shona'],						Code : ['sn', 'sna', 'sna'],	Country : 'zw',	Frequency : FrequencyOccasional},
		{Name : ['Sinhala', 'සිංහල'],					Code : ['si', 'sin', 'sin'],	Country : 'lk',	Frequency : FrequencyOccasional},
		{Name : ['Slovak', 'Slovenčina'],				Code : ['sk', 'slo', 'slk'],	Country : 'sk',	Frequency : FrequencyOccasional},
		{Name : ['Slovene', 'Slovenščina'],				Code : ['sl', 'slv', 'slv'],	Country : 'si',	Frequency : FrequencyOccasional},
		{Name : ['Somali', '	af Soomaali'],			Code : ['so', 'som', 'som'],	Country : 'so',	Frequency : FrequencyOccasional},
		{Name : ['Sotho', 'Sesotho'],					Code : ['st', 'sot', 'sot'],	Country : 'za',	Frequency : FrequencyOccasional},
		{Name : ['South Ndebele', 'isiNdebele'],		Code : ['nr', 'nbl', 'nbl'],	Country : 'za',	Frequency : FrequencyUncommon},
		{Name : ['Spanish', 'Español'],					Code : ['es', 'spa', 'spa'],	Country : 'es',	Frequency : FrequencyCommon},
		{Name : ['Sundanese', 'Basa Sunda'],			Code : ['su', 'sun', 'sun'],	Country : 'id',	Frequency : FrequencyOccasional},
		{Name : ['Swahili', 'Kiswahili'],				Code : ['sw', 'swa', 'swa'],	Country : 'tz',	Frequency : FrequencyUncommon},
		{Name : ['Swati', 'siSwati'],					Code : ['ss', 'ssw', 'ssw'],	Country : 'sz',	Frequency : FrequencyUncommon},
		{Name : ['Swedish', 'Svenska'],					Code : ['sv', 'swe', 'swe'],	Country : 'se',	Frequency : FrequencyOccasional},
		{Name : ['Tamil', 'தமிழ்'],						Code : ['ta', 'tam', 'tam'],	Country : 'in',	Frequency : FrequencyCommon},
		{Name : ['Telugu', 'తెలుగు'],						Code : ['te', 'tel', 'tel'],	Country : 'in',	Frequency : FrequencyCommon},
		{Name : ['Tajik', 'тоҷики'],					Code : ['tg', 'tgk', 'tgk'],	Country : 'tj',	Frequency : FrequencyUncommon},
		{Name : ['Thai', 'ภาษาไทย'],					Code : ['th', 'tha', 'tha'],	Country : 'th',	Frequency : FrequencyCommon},
		{Name : ['Tigrinya', 'ትግርኛ'],					Code : ['ti', 'tir', 'tir'],	Country : 'er',	Frequency : FrequencyUncommon},
		{Name : ['Tibetan', 'དབུས་སྐད'],					Code : ['bo', 'tib', 'bod'],	Country : 'cn',	Frequency : FrequencyUncommon},
		{Name : ['Turkmen', 'Türkmençe'],				Code : ['tk', 'tuk', 'tuk'],	Country : 'tm',	Frequency : FrequencyOccasional},
		{Name : ['Tagalog', 'Tagalog'],					Code : ['tl', 'tgl', 'tgl'],	Country : 'ph',	Frequency : FrequencyOccasional},
		{Name : ['Tswana', 'Setswana'],					Code : ['tn', 'tsn', 'tsn'],	Country : 'za',	Frequency : FrequencyUncommon},
		{Name : ['Tongan', 'Faka-Tonga'],				Code : ['to', 'ton', 'ton'],	Country : 'to',	Frequency : FrequencyUncommon},
		{Name : ['Turkish', 'Türkçe'],					Code : ['tr', 'tur', 'tur'],	Country : 'tr',	Frequency : FrequencyOccasional},
		{Name : ['Tsonga', 'Xitsonga'],					Code : ['ts', 'tso', 'tso'],	Country : 'za',	Frequency : FrequencyUncommon},
		{Name : ['Tatar', 'татарча'],					Code : ['tt', 'tat', 'tat'],	Country : 'ru',	Frequency : FrequencyUncommon},
		{Name : ['Twi', 'Twi'],							Code : ['tw', 'twi', 'twi'],	Country : 'gh',	Frequency : FrequencyUncommon},
		{Name : ['Tahitian', 'Reo Tahiti'],				Code : ['ty', 'tah', 'tah'],	Country : 'pf',	Frequency : FrequencyUncommon},
		{Name : ['Ukrainian', 'Українська'],			Code : ['uk', 'ukr', 'ukr'],	Country : 'ua',	Frequency : FrequencyCommon},
		{Name : ['Urdu', 'اُردُو'],						Code : ['ur', 'urd', 'urd'],	Country : 'pk',	Frequency : FrequencyCommon},
		{Name : ['Uyghur', 'ئۇيغۇر'],						Code : ['ug', 'uig', 'uig'],	Country : 'cn',	Frequency : FrequencyUncommon},
		{Name : ['Uzbek', 'اوزبیک'],						Code : ['uz', 'uzb', 'uzb'],	Country : 'uz',	Frequency : FrequencyOccasional},
		{Name : ['Venda', 'Tshivenḓa'],					Code : ['ve', 'ven', 'ven'],	Country : 'za',	Frequency : FrequencyUncommon},
		{Name : ['Vietnamese', 'Tiếng Việt'],			Code : ['vi', 'vie', 'vie'],	Country : 'vn',	Frequency : FrequencyCommon},
		{Name : ['Volapuk', 'Volapük'],					Code : ['vo', 'vol', 'vol'],	Country : None,	Frequency : FrequencyNone},
		{Name : ['Walloon', 'Walloon'],					Code : ['wa', 'wln', 'wln'],	Country : 'be',	Frequency : FrequencyUncommon},
		{Name : ['Welsh', 'Cymraeg'],					Code : ['cy', 'wel', 'cym'],	Country : 'gb',	Frequency : FrequencyUncommon},
		{Name : ['Wolof', 'Wolof'],						Code : ['wo', 'wol', 'wol'],	Country : 'sn',	Frequency : FrequencyUncommon},
		{Name : ['Xhosa', 'isiXhosa'],					Code : ['xh', 'xho', 'xho'],	Country : 'za',	Frequency : FrequencyOccasional},
		{Name : ['Yiddish', 'ייִדיש ייִדיש'],				Code : ['yi', 'yid', 'yid'],	Country : 'il',	Frequency : FrequencyUncommon},
		{Name : ['Yoruba', 'Èdè Yorùbá'],				Code : ['yo', 'yor', 'yor'],	Country : 'ng',	Frequency : FrequencyOccasional},
		{Name : ['Zhuang', '話僮'],						Code : ['za', 'zha', 'zha'],	Country : 'cn',	Frequency : FrequencyUncommon},
		{Name : ['Zulu', 'isiZulu'],					Code : ['zu', 'zul', 'zul'],	Country : 'za',	Frequency : FrequencyOccasional},
	)

	# Language variations used by OpenSubtitles.
	LanguagesVariation = (
		{Original : 'zh',	Name : ['Chinese (Simplified)', '简体中文'],					Code : ['zh', 'chi', 'zho'],	Country : 'cn',	Frequency : FrequencyCommon},
		{Original : 'zh',	Name : ['Chinese (Traditional)', '繁体中文'],					Code : ['zt', 'zht', 'zht'],	Country : 'tw',	Frequency : FrequencyCommon},
		{Original : 'zh',	Name : ['Chinese (Bilingual)', '双语中文'],						Code : ['ze', 'zhe', 'zhe'],	Country : 'cn',	Frequency : FrequencyCommon},

		{Original : 'pt',	Name : ['Portuguese (Brazil)', 'Português (Brasil)'],			Code : ['pb', 'pob', 'pob'],	Country : 'br',	Frequency : FrequencyCommon},
		{Original : 'pt',	Name : ['Portuguese (Mozambique)', 'Português (Moçambique)'],	Code : ['pm', 'pom', 'pom'],	Country : 'mz',	Frequency : FrequencyCommon},

		{Original : 'es',	Name : ['Spanish (Europe)', 'Español (Europa)'],				Code : ['sp', 'spn', 'spn'],	Country : 'es',	Frequency : FrequencyCommon},
		{Original : 'es',	Name : ['Spanish (Latin)', 'Español (Latina)'],					Code : ['ea', 'spl', 'spl'],	Country : None,	Frequency : FrequencyCommon},
	)

	@classmethod
	def _process(self, language):
		if type(language) is tuple: language = language[0]
		elif type(language) is dict: language = language['code'][Language.CodeDefault]
		language = language.lower().strip()
		try: language = Language.Replacements[language]
		except: pass
		try: language = Converter.unicode(language)
		except: pass
		return language

	@classmethod
	def isAutomatic(self, language):
		return language.lower() == Language.Automatic

	@classmethod
	def isAlternative(self, language):
		return language.lower() == Language.Alternative

	@classmethod
	def isUniversal(self, language):
		language = language.lower()
		return language == Language.UniversalCode or language == Language.UniversalName.lower()

	@classmethod
	def settings(self, single = False):
		if Language.Settings is None:
			languages = []

			language = Settings.getString(Language.SettingPrimary)
			if not language.lower() == Language.Disabled:
				language = self.language(language)
				if language and not language in languages: languages.append(language)

			language = Settings.getString(Language.SettingSecondary)
			if not language.lower() == Language.Disabled:
				language = self.language(language)
				if language and not language in languages: languages.append(language)

			language = Settings.getString(Language.SettingTertiary)
			if not language.lower() == Language.Disabled:
				language = self.language(language)
				if language and not language in languages: languages.append(language)

			if len(languages) == 0: languages.append(self.language(Language.EnglishCode))
			Language.Settings = languages

		if single: return Language.Settings[0]
		else: return Language.Settings

	@classmethod
	def settingsCode(self, code = CodeDefault, single = False):
		languages = self.settings(single = single)
		return [language[Language.Code][code] for language in languages]

	@classmethod
	def settingsName(self, name = NameDefault, single = False):
		languages = self.settings(single = single)
		return [language[Language.Name][name] for language in languages]

	# default can be set to Alternative. This allows to return another language besides English.
	# Eg: We are working with the English title. If we want titles besides the English one, and the user specified Automatic in the settings, then Automatic is converted to Alternative.
	@classmethod
	def settingsCustom(self, id = None, type = None, default = Automatic, code = CodeDefault):
		if id is None: id = Language.SettingBase + type
		setting = Settings.getString(id)

		if self.isAutomatic(setting):
			if default == Language.TypePrimary:
				setting = Settings.getString(Language.SettingPrimary)
				if setting.lower() == Language.Disabled: return None
			elif default == Language.TypeSecondary:
				setting = Settings.getString(Language.SettingSecondary)
				if setting.lower() == Language.Disabled: return None
			elif default == Language.TypeTertiary:
				setting = Settings.getString(Language.SettingTertiary)
				if setting.lower() == Language.Disabled: return None
			else:
				setting = default

		if code is None or code is False: return self.language(language = setting)
		else: return self.code(language = setting, code = code)

	@classmethod
	def settingsSelect(self, id = None, type = None, title = None, automatic = None, none = None, set = None):
		from lib.modules.interface import Dialog

		if id is None: id = Language.SettingBase + type
		current = Settings.getString(id)
		languages = self.languages(universal = False)

		if set:
			if Tools.isString(set): set = Language.Sets[set]
			languages = [i for i in languages if any(j in set for j in i[Language.Code])]

		languages = [i[Language.Name][Language.NameDefault] for i in languages]
		if automatic: languages.insert(0, Language.Automatic.capitalize())
		if none: languages.insert(0, Language.Disabled.capitalize())

		choice = Dialog.select(title = title if title else 33787, items = languages, selection = current)
		if choice < 0: return None

		choice = languages[choice]
		Settings.set(id, choice)
		Language.Settings = None # Reset so that new settings are read.
		return choice

	@classmethod
	def isUniversal(self, language):
		if language == None: return False
		language = self._process(language)
		return language == Language.UniversalCode.lower() or language == Language.UniversalName.lower()

	@classmethod
	def isEnglish(self, language):
		if language == None: return False
		language = self._process(language)
		return language == Language.EnglishCode.lower() or language == Language.EnglishName.lower()

	@classmethod
	def languages(self, universal = True, frequency = None):
		if universal: result = Language.Languages
		else: result = Language.Languages[1:]
		if not frequency is None: result = [i for i in result if i[Language.Frequency] >= frequency]
		return result

	@classmethod
	def languagesVariation(self):
		return Language.LanguagesVariation

	@classmethod
	def names(self, case = CaseCapital, universal = True, name = NameDefault, frequency = None):
		names = Language.Languages
		if not frequency is None: result = [i for i in names if i[Language.Frequency] >= frequency]
		names = [i[Language.Name][name] for i in names]
		if not universal: names = names[1:]
		if case == Language.CaseUpper: names = [i.upper() for i in names]
		elif case == Language.CaseLower: names = [i.lower() for i in names]
		return names

	@classmethod
	def codes(self, case = CaseLower, universal = True, code = CodeDefault, frequency = None):
		codes = Language.Languages
		if not frequency is None: codes = [i for i in codes if i[Language.Frequency] >= frequency]
		codes = [i[Language.Code][code] for i in codes]
		if not universal: codes = codes[1:]
		if case == Language.CaseCapital: codes = [i.capitalize() for i in codes]
		elif case == Language.CaseUpper: codes = [i.upper() for i in codes]
		return codes

	@classmethod
	def detection(self):
		if Language.Detection == None:
			Language.Detection = self.names(case = Language.CaseLower, universal = False)
			Language.Detection += self.codes(case = Language.CaseLower, universal = False, code = Language.CodeSecondary)
			Language.Detection += self.codes(case = Language.CaseLower, universal = False, code = Language.CodeTertiary)
			Language.Detection = list(set(Language.Detection))
		return Language.Detection

	@classmethod
	def index(self, language):
		if language is None: return None
		language = self._process(language)

		for i in range(len(Language.Languages)):
			if language in Language.Languages[i][Language.Code]:
				return i

		for i in range(len(Language.Languages)):
			if language in [Language.Languages[i][Language.Name][Language.NameEnglish].lower(), Language.Languages[i][Language.Name][Language.NameNative].lower()]:
				return i

		return None

	@classmethod
	def language(self, language, variation = False):
		if language is None: return None
		language = self._process(language)

		if Language.Automatic in language:
			return self.settings(single = True)
		elif Language.Alternative in language:
			languages = self.settings()
			for i in languages:
				if not i[Language.Code][Language.CodePrimary] == Language.EnglishCode:
					return i
			return languages[0]

		if variation:
			for i in Language.LanguagesVariation:
				if language in i[Language.Code]:
					return i

			for i in Language.LanguagesVariation:
				if language in [i[Language.Name][Language.NameEnglish].lower(), i[Language.Name][Language.NameNative].lower()]:
					return i

		for i in Language.Languages:
			if language in i[Language.Code]:
				return i

		for i in Language.Languages:
			if language in [i[Language.Name][Language.NameEnglish].lower(), i[Language.Name][Language.NameNative].lower()]:
				return i

		return None

	@classmethod
	def name(self, language, name = NameDefault, variation = False):
		if language is None: return None
		language = self._process(language)

		if Language.Automatic in language:
			return self.settings(single = True)[Language.Name][name]
		elif Language.Alternative in language:
			languages = self.settings()
			for i in languages:
				if not i[Language.Code][Language.CodePrimary] == Language.EnglishCode:
					return i[Language.Name][name]
			return languages[0][Language.Name][name]

		if variation:
			for i in Language.LanguagesVariation:
				if language in i[Language.Code]:
					return i[Language.Name][name]

			for i in Language.LanguagesVariation:
				if language in [i[Language.Name][Language.NameEnglish].lower(), i[Language.Name][Language.NameNative].lower()]:
					return i[Language.Name][name]

		for i in Language.Languages:
			if language in i[Language.Code]:
				return i[Language.Name][name]

		for i in Language.Languages:
			if language in [i[Language.Name][Language.NameEnglish].lower(), i[Language.Name][Language.NameNative].lower()]:
				return i[Language.Name][name]

		return None

	@classmethod
	def code(self, language, code = CodeDefault, variation = False):
		if language is None: return None
		language = self._process(language)

		if Language.Automatic in language:
			return self.settings(single = True)[Language.Code][code]
		elif Language.Alternative in language:
			languages = self.settings()
			for i in languages:
				if not i[Language.Code][Language.CodePrimary] == Language.EnglishCode:
					return i[Language.Code][code]
			return languages[0][Language.Code][code]

		if variation:
			for i in Language.LanguagesVariation:
				if language in i[Language.Code]:
					return i[Language.Code][code]

			for i in Language.LanguagesVariation:
				if language in [i[Language.Name][Language.NameEnglish].lower(), i[Language.Name][Language.NameNative].lower()]:
					return i[Language.Code][code]

		for i in Language.Languages:
			if language in i[Language.Code]:
				return i[Language.Code][code]

		for i in Language.Languages:
			if language in [i[Language.Name][Language.NameEnglish].lower(), i[Language.Name][Language.NameNative].lower()]:
				return i[Language.Code][code]

		return None

	@classmethod
	def ununiversalize(self, languages, english = True):
		for i in range(len(languages)):
			if self.isUniversal(languages[i]):
				del languages[i]
				if english:
					has = False
					for j in range(len(languages)):
						if self.isEnglish(languages[j]):
							has = True
							break
					if not has: languages.append(self.language(Language.EnglishCode))
				break
		return languages

	@classmethod
	def clean(self, languages):
		current = []
		result = []
		for i in languages:
			if i and not i[Language.Name][Language.NameEnglish] in current:
				current.append(i[Language.Name][Language.NameEnglish])
				result.append(i)
		return result

	@classmethod
	def country(self, language):
		if language == None: return None
		try: return self.language(language)[Language.Country]
		except: return Language.UniversalCountry

	@classmethod
	def api(self, type):
		supported = []
		if type == Language.ApiTrakt: supported = ['bg', 'cs', 'da', 'de', 'el', 'en', 'es', 'fi', 'fr', 'he', 'hr', 'hu', 'it', 'ja', 'ko', 'nl', 'no', 'pl', 'pt', 'ro', 'ru', 'sk', 'sl', 'sr', 'sv', 'th', 'tr', 'uk', 'zh']
		elif type == Language.ApiTvdb: supported = ['en', 'sv', 'no', 'da', 'fi', 'nl', 'de', 'it', 'es', 'fr', 'pl', 'hu', 'el', 'tr', 'ru', 'he', 'ja', 'pt', 'zh', 'cs', 'sl', 'hr', 'ko']

		language = Language.settingsCustom('metadata.metadata.language')
		return language if language in supported else Language.EnglishCode


class Country(object):

	Code				= 'code'
	Name				= 'name'
	Language			= 'language'

	Disabled			= 'none'
	Automatic			= 'automatic'

	NamePrimary			= 0
	#NameSecondary		= 1
	NameDefault			= NamePrimary

	CodePrimary			= 0 # ISO Alpha-2
	CodeSecondary		= 1 # ISO Alpha-3
	CodeTertiary		= 2 # FIPS 10-4
	CodeQuaternary		= 3 # ISO Numeric
	CodeDefault			= CodePrimary

	LanguagePrimary		= 0
	LanguageSecondary	= 1
	LanguageTertiary	= 2
	LanguageQuaternary	= 3
	LanguageDefault		= LanguagePrimary
	LanguageAll			= None

	UniversalName		= 'Universal'
	UniversalCode		= 'un'
	UniversalLanguage	= 'un'
	UniversalNumber		= -1

	Countries			= (
		{ Name : [UniversalName],									Code : [UniversalCode, UniversalCode, UniversalCode, UniversalNumber],	Language : [UniversalLanguage] },
		{ Name : ['Andorra'],										Code : ['ad', 'and', 'an', 20],		Language : ['ca'] },
		{ Name : ['United Arab Emirates'],							Code : ['ae', 'are', 'ae', 784],	Language : ['ar', 'fa', 'en', 'hi', 'ur'] },
		{ Name : ['Afghanistan'],									Code : ['af', 'afg', 'af', 4],		Language : ['fa', 'ps', 'uz', 'tk'] },
		{ Name : ['Antigua and Barbuda'],							Code : ['ag', 'atg', 'ac', 28],		Language : ['en'] },
		{ Name : ['Anguilla'],										Code : ['ai', 'aia', 'av', 660],	Language : ['en'] },
		{ Name : ['Albania'],										Code : ['al', 'alb', 'al', 8],		Language : ['sq', 'el'] },
		{ Name : ['Armenia'],										Code : ['am', 'arm', 'am', 51],		Language : ['hy'] },
		{ Name : ['Angola'],										Code : ['ao', 'ago', 'ao', 24],		Language : ['pt'] },
		{ Name : ['Antarctica'],									Code : ['aq', 'ata', 'ay', 10],		Language : [] },
		{ Name : ['Argentina'],										Code : ['ar', 'arg', 'ar', 32],		Language : ['es', 'en', 'it', 'de', 'fr', 'gn'] },
		{ Name : ['American Samoa'],								Code : ['as', 'asm', 'aq', 16],		Language : ['en', 'sm', 'to'] },
		{ Name : ['Austria'],										Code : ['at', 'aut', 'au', 40],		Language : ['de', 'hr', 'hu', 'sl'] },
		{ Name : ['Australia'],										Code : ['au', 'aus', 'as', 36],		Language : ['en'] },
		{ Name : ['Aruba'],											Code : ['aw', 'abw', 'aa', 533],	Language : ['nl', 'es', 'en'] },
		{ Name : ['Aland Islands'],									Code : ['ax', 'ala', None, 248],	Language : ['sv'] },
		{ Name : ['Azerbaijan'],									Code : ['az', 'aze', 'aj', 31],		Language : ['az', 'ru', 'hy'] },
		{ Name : ['Bosnia and Herzegovina'],						Code : ['ba', 'bih', 'bk', 70],		Language : ['bs', 'hr', 'sr'] },
		{ Name : ['Barbados'],										Code : ['bb', 'brb', 'bb', 52],		Language : ['en'] },
		{ Name : ['Bangladesh'],									Code : ['bd', 'bgd', 'bg', 50],		Language : ['bn', 'en'] },
		{ Name : ['Belgium'],										Code : ['be', 'bel', 'be', 56],		Language : ['nl', 'fr', 'de'] },
		{ Name : ['Burkina Faso'],									Code : ['bf', 'bfa', 'uv', 854],	Language : ['fr'] },
		{ Name : ['Bulgaria'],										Code : ['bg', 'bgr', 'bu', 100],	Language : ['bg', 'tr'] },
		{ Name : ['Bahrain'],										Code : ['bh', 'bhr', 'ba', 48],		Language : ['ar', 'en', 'fa', 'ur'] },
		{ Name : ['Burundi'],										Code : ['bi', 'bdi', 'by', 108],	Language : ['fr', 'rn'] },
		{ Name : ['Benin'],											Code : ['bj', 'ben', 'bn', 204],	Language : ['fr'] },
		{ Name : ['Saint Barthelemy'],								Code : ['bl', 'blm', 'tb', 652],	Language : ['fr'] },
		{ Name : ['Bermuda'],										Code : ['bm', 'bmu', 'bd', 60],		Language : ['en', 'pt'] },
		{ Name : ['Brunei'],										Code : ['bn', 'brn', 'bx', 96],		Language : ['ms', 'en'] },
		{ Name : ['Bolivia'],										Code : ['bo', 'bol', 'bl', 68],		Language : ['es', 'qu', 'ay'] },
		{ Name : ['Bonaire, Saint Eustatius and Saba'],				Code : ['bq', 'bes', None, 535],	Language : ['nl', 'en'] },
		{ Name : ['Brazil'],										Code : ['br', 'bra', 'br', 76],		Language : ['pt', 'es', 'en', 'fr'] },
		{ Name : ['Bahamas'],										Code : ['bs', 'bhs', 'bf', 44],		Language : ['en'] },
		{ Name : ['Bhutan'],										Code : ['bt', 'btn', 'bt', 64],		Language : ['dz'] },
		{ Name : ['Bouvet Island'],									Code : ['bv', 'bvt', 'bv', 74],		Language : [] },
		{ Name : ['Botswana'],										Code : ['bw', 'bwa', 'bc', 72],		Language : ['en', 'tn'] },
		{ Name : ['Belarus'],										Code : ['by', 'blr', 'bo', 112],	Language : ['be', 'ru'] },
		{ Name : ['Belize'],										Code : ['bz', 'blz', 'bh', 84],		Language : ['en', 'es'] },
		{ Name : ['Canada'],										Code : ['ca', 'can', 'ca', 124],	Language : ['en', 'fr', 'iu'] },
		{ Name : ['Cocos Islands'],									Code : ['cc', 'cck', 'ck', 166],	Language : ['ms', 'en'] },
		{ Name : ['Democratic Republic of the Congo'],				Code : ['cd', 'cod', 'cg', 180],	Language : ['fr', 'ln', 'kg'] },
		{ Name : ['Central African Republic'],						Code : ['cf', 'caf', 'ct', 140],	Language : ['fr', 'sg', 'ln', 'kg'] },
		{ Name : ['Republic of the Congo'],							Code : ['cg', 'cog', 'cf', 178],	Language : ['fr', 'kg', 'ln'] },
		{ Name : ['Switzerland'],									Code : ['ch', 'che', 'sz', 756],	Language : ['de', 'fr', 'it', 'rm'] },
		{ Name : ['Ivory Coast'],									Code : ['ci', 'civ', 'iv', 384],	Language : ['fr'] },
		{ Name : ['Cook Islands'],									Code : ['ck', 'cok', 'cw', 184],	Language : ['en', 'mi'] },
		{ Name : ['Chile'],											Code : ['cl', 'chl', 'ci', 152],	Language : ['es'] },
		{ Name : ['Cameroon'],										Code : ['cm', 'cmr', 'cm', 120],	Language : ['en', 'fr'] },
		{ Name : ['China'],											Code : ['cn', 'chn', 'ch', 156],	Language : ['zh', 'ug', 'za'] },
		{ Name : ['Colombia'],										Code : ['co', 'col', 'co', 170],	Language : ['es'] },
		{ Name : ['Costa Rica'],									Code : ['cr', 'cri', 'cs', 188],	Language : ['es', 'en'] },
		{ Name : ['Cuba'],											Code : ['cu', 'cub', 'cu', 192],	Language : ['es'] },
		{ Name : ['Cape Verde'],									Code : ['cv', 'cpv', 'cv', 132],	Language : ['pt'] },
		{ Name : ['Curacao'],										Code : ['cw', 'cuw', 'uc', 531],	Language : ['nl'] },
		{ Name : ['Christmas Island'],								Code : ['cx', 'cxr', 'kt', 162],	Language : ['en', 'zh', 'ms'] },
		{ Name : ['Cyprus'],										Code : ['cy', 'cyp', 'cy', 196],	Language : ['el', 'tr', 'en'] },
		{ Name : ['Czech Republic'],								Code : ['cz', 'cze', 'ez', 203],	Language : ['cs', 'sk'] },
		{ Name : ['Germany'],										Code : ['de', 'deu', 'gm', 276],	Language : ['de'] },
		{ Name : ['Djibouti'],										Code : ['dj', 'dji', 'dj', 262],	Language : ['fr', 'ar', 'so', 'aa'] },
		{ Name : ['Denmark'],										Code : ['dk', 'dnk', 'da', 208],	Language : ['da', 'en', 'fo', 'de'] },
		{ Name : ['Dominica'],										Code : ['dm', 'dma', 'do', 212],	Language : ['en'] },
		{ Name : ['Dominican Republic'],							Code : ['do', 'dom', 'dr', 214],	Language : ['es'] },
		{ Name : ['Algeria'],										Code : ['dz', 'dza', 'ag', 12],		Language : ['ar'] },
		{ Name : ['Ecuador'],										Code : ['ec', 'ecu', 'ec', 218],	Language : ['es'] },
		{ Name : ['Estonia'],										Code : ['ee', 'est', 'en', 233],	Language : ['et', 'ru'] },
		{ Name : ['Egypt'],											Code : ['eg', 'egy', 'eg', 818],	Language : ['ar', 'en', 'fr'] },
		{ Name : ['Western Sahara'],								Code : ['eh', 'esh', 'wi', 732],	Language : ['ar'] },
		{ Name : ['Eritrea'],										Code : ['er', 'eri', 'er', 232],	Language : ['aa', 'ar', 'ti'] },
		{ Name : ['Spain'],											Code : ['es', 'esp', 'sp', 724],	Language : ['es', 'ca', 'gl', 'eu', 'oc'] },
		{ Name : ['Ethiopia'],										Code : ['et', 'eth', 'et', 231],	Language : ['am', 'en', 'om', 'ti', 'so'] },
		{ Name : ['Finland'],										Code : ['fi', 'fin', 'fi', 246],	Language : ['fi', 'sv'] },
		{ Name : ['Fiji'],											Code : ['fj', 'fji', 'fj', 242],	Language : ['en', 'fj'] },
		{ Name : ['Falkland Islands'],								Code : ['fk', 'flk', 'fk', 238],	Language : ['en'] },
		{ Name : ['Micronesia'],									Code : ['fm', 'fsm', 'fm', 583],	Language : ['en'] },
		{ Name : ['Faroe Islands'],									Code : ['fo', 'fro', 'fo', 234],	Language : ['fo', 'da'] },
		{ Name : ['France'],										Code : ['fr', 'fra', 'fr', 250],	Language : ['fr', 'br', 'co', 'ca', 'eu', 'oc'] },
		{ Name : ['Gabon'],											Code : ['ga', 'gab', 'gb', 266],	Language : ['fr'] },
		{ Name : ['United Kingdom'],								Code : ['gb', 'gbr', 'uk', 826],	Language : ['en', 'cy', 'gd'] },
		{ Name : ['Grenada'],										Code : ['gd', 'grd', 'gj', 308],	Language : ['en'] },
		{ Name : ['Georgia'],										Code : ['ge', 'geo', 'gg', 268],	Language : ['ka', 'ru', 'hy', 'az'] },
		{ Name : ['French Guiana'],									Code : ['gf', 'guf', 'fg', 254],	Language : ['fr'] },
		{ Name : ['Guernsey'],										Code : ['gg', 'ggy', 'gk', 831],	Language : ['en', 'fr'] },
		{ Name : ['Ghana'],											Code : ['gh', 'gha', 'gh', 288],	Language : ['en', 'ak', 'ee', 'tw'] },
		{ Name : ['Gibraltar'],										Code : ['gi', 'gib', 'gi', 292],	Language : ['en', 'es', 'it', 'pt'] },
		{ Name : ['Greenland'],										Code : ['gl', 'grl', 'gl', 304],	Language : ['kl', 'da', 'en'] },
		{ Name : ['Gambia'],										Code : ['gm', 'gmb', 'ga', 270],	Language : ['en', 'wo', 'ff'] },
		{ Name : ['Guinea'],										Code : ['gn', 'gin', 'gv', 324],	Language : ['fr'] },
		{ Name : ['Guadeloupe'],									Code : ['gp', 'glp', 'gp', 312],	Language : ['fr'] },
		{ Name : ['Equatorial Guinea'],								Code : ['gq', 'gnq', 'ek', 226],	Language : ['es', 'fr'] },
		{ Name : ['Greece'],										Code : ['gr', 'grc', 'gr', 300],	Language : ['el', 'en', 'fr'] },
		{ Name : ['South Georgia and the South Sandwich Islands'],	Code : ['gs', 'sgs', 'sx', 239],	Language : ['en'] },
		{ Name : ['Guatemala'],										Code : ['gt', 'gtm', 'gt', 320],	Language : ['es'] },
		{ Name : ['Guam'],											Code : ['gu', 'gum', 'gq', 316],	Language : ['en', 'ch'] },
		{ Name : ['Guinea-Bissau'],									Code : ['gw', 'gnb', 'pu', 624],	Language : ['pt'] },
		{ Name : ['Guyana'],										Code : ['gy', 'guy', 'gy', 328],	Language : ['en'] },
		{ Name : ['Hong Kong'],										Code : ['hk', 'hkg', 'hk', 344],	Language : ['zh', 'zh', 'en'] },
		{ Name : ['Heard Island and McDonald Islands'],				Code : ['hm', 'hmd', 'hm', 334],	Language : [] },
		{ Name : ['Honduras'],										Code : ['hn', 'hnd', 'ho', 340],	Language : ['es'] },
		{ Name : ['Croatia'],										Code : ['hr', 'hrv', 'hr', 191],	Language : ['hr', 'sr'] },
		{ Name : ['Haiti'],											Code : ['ht', 'hti', 'ha', 332],	Language : ['ht', 'fr'] },
		{ Name : ['Hungary'],										Code : ['hu', 'hun', 'hu', 348],	Language : ['hu'] },
		{ Name : ['Indonesia'],										Code : ['id', 'idn', 'id', 360],	Language : ['id', 'en', 'nl', 'jv'] },
		{ Name : ['Ireland'],										Code : ['ie', 'irl', 'ei', 372],	Language : ['en', 'ga'] },
		{ Name : ['Israel'],										Code : ['il', 'isr', 'is', 376],	Language : ['he', 'ar', 'en'] },
		{ Name : ['Isle of Man'],									Code : ['im', 'imn', 'im', 833],	Language : ['en', 'gv'] },
		{ Name : ['India'],											Code : ['in', 'ind', 'in', 356],	Language : ['en', 'hi', 'bn', 'te', 'mr', 'ta', 'ur', 'gu', 'kn', 'ml', 'or', 'pa', 'as', 'bh', 'ks', 'ne', 'sd', 'sa', 'fr'] },
		{ Name : ['British Indian Ocean Territory'],				Code : ['io', 'iot', 'io', 86],		Language : ['en'] },
		{ Name : ['Iraq'],											Code : ['iq', 'irq', 'iz', 368],	Language : ['ar', 'ku', 'hy'] },
		{ Name : ['Iran'],											Code : ['ir', 'irn', 'ir', 364],	Language : ['fa', 'ku'] },
		{ Name : ['Iceland'],										Code : ['is', 'isl', 'ic', 352],	Language : ['is', 'en', 'de', 'da', 'sv', 'no'] },
		{ Name : ['Italy'],											Code : ['it', 'ita', 'it', 380],	Language : ['it', 'de', 'fr', 'sc', 'ca', 'co', 'sl'] },
		{ Name : ['Jersey'],										Code : ['je', 'jey', 'je', 832],	Language : ['en', 'pt'] },
		{ Name : ['Jamaica'],										Code : ['jm', 'jam', 'jm', 388],	Language : ['en'] },
		{ Name : ['Jordan'],										Code : ['jo', 'jor', 'jo', 400],	Language : ['ar', 'en'] },
		{ Name : ['Japan'],											Code : ['jp', 'jpn', 'ja', 392],	Language : ['ja'] },
		{ Name : ['Kenya'],											Code : ['ke', 'ken', 'ke', 404],	Language : ['en', 'sw'] },
		{ Name : ['Kyrgyzstan'],									Code : ['kg', 'kgz', 'kg', 417],	Language : ['ky', 'uz', 'ru'] },
		{ Name : ['Cambodia'],										Code : ['kh', 'khm', 'cb', 116],	Language : ['km', 'fr', 'en'] },
		{ Name : ['Kiribati'],										Code : ['ki', 'kir', 'kr', 296],	Language : ['en'] },
		{ Name : ['Comoros'],										Code : ['km', 'com', 'cn', 174],	Language : ['ar', 'fr'] },
		{ Name : ['Saint Kitts and Nevis'],							Code : ['kn', 'kna', 'sc', 659],	Language : ['en'] },
		{ Name : ['North Korea'],									Code : ['kp', 'prk', 'kn', 408],	Language : ['ko'] },
		{ Name : ['South Korea'],									Code : ['kr', 'kor', 'ks', 410],	Language : ['ko', 'en'] },
		{ Name : ['Kosovo'],										Code : ['xk', 'xkx', 'kv', 0],		Language : ['sq', 'sr'] },
		{ Name : ['Kuwait'],										Code : ['kw', 'kwt', 'ku', 414],	Language : ['ar', 'en'] },
		{ Name : ['Cayman Islands'],								Code : ['ky', 'cym', 'cj', 136],	Language : ['en'] },
		{ Name : ['Kazakhstan'],									Code : ['kz', 'kaz', 'kz', 398],	Language : ['kk', 'ru'] },
		{ Name : ['Laos'],											Code : ['la', 'lao', 'la', 418],	Language : ['lo', 'fr', 'en'] },
		{ Name : ['Lebanon'],										Code : ['lb', 'lbn', 'le', 422],	Language : ['ar', 'fr', 'en', 'hy'] },
		{ Name : ['Saint Lucia'],									Code : ['lc', 'lca', 'st', 662],	Language : ['en'] },
		{ Name : ['Liechtenstein'],									Code : ['li', 'lie', 'ls', 438],	Language : ['de'] },
		{ Name : ['Sri Lanka'],										Code : ['lk', 'lka', 'ce', 144],	Language : ['si', 'ta', 'en'] },
		{ Name : ['Liberia'],										Code : ['lr', 'lbr', 'li', 430],	Language : ['en'] },
		{ Name : ['Lesotho'],										Code : ['ls', 'lso', 'lt', 426],	Language : ['en', 'st', 'zu', 'xh'] },
		{ Name : ['Lithuania'],										Code : ['lt', 'ltu', 'lh', 440],	Language : ['lt', 'ru', 'pl'] },
		{ Name : ['Luxembourg'],									Code : ['lu', 'lux', 'lu', 442],	Language : ['lb', 'de', 'fr'] },
		{ Name : ['Latvia'],										Code : ['lv', 'lva', 'lg', 428],	Language : ['lv', 'ru', 'lt'] },
		{ Name : ['Libya'],											Code : ['ly', 'lby', 'ly', 434],	Language : ['ar', 'it', 'en'] },
		{ Name : ['Morocco'],										Code : ['ma', 'mar', 'mo', 504],	Language : ['ar', 'fr'] },
		{ Name : ['Monaco'],										Code : ['mc', 'mco', 'mn', 492],	Language : ['fr', 'en', 'it'] },
		{ Name : ['Moldova'],										Code : ['md', 'mda', 'md', 498],	Language : ['ro', 'ru', 'tr'] },
		{ Name : ['Montenegro'],									Code : ['me', 'mne', 'mj', 499],	Language : ['sr', 'hu', 'bs', 'sq', 'hr'] },
		{ Name : ['Saint Martin'],									Code : ['mf', 'maf', 'rn', 663],	Language : ['fr'] },
		{ Name : ['Madagascar'],									Code : ['mg', 'mdg', 'ma', 450],	Language : ['fr', 'mg'] },
		{ Name : ['Marshall Islands'],								Code : ['mh', 'mhl', 'rm', 584],	Language : ['mh', 'en'] },
		{ Name : ['Macedonia'],										Code : ['mk', 'mkd', 'mk', 807],	Language : ['mk', 'sq', 'tr', 'sr'] },
		{ Name : ['Mali'],											Code : ['ml', 'mli', 'ml', 466],	Language : ['fr', 'bm'] },
		{ Name : ['Myanmar'],										Code : ['mm', 'mmr', 'bm', 104],	Language : ['my'] },
		{ Name : ['Mongolia'],										Code : ['mn', 'mng', 'mg', 496],	Language : ['mn', 'ru'] },
		{ Name : ['Macao'],											Code : ['mo', 'mac', 'mc', 446],	Language : ['zh', 'zh', 'pt'] },
		{ Name : ['Northern Mariana Islands'],						Code : ['mp', 'mnp', 'cq', 580],	Language : ['tl', 'zh', 'ch', 'en'] },
		{ Name : ['Martinique'],									Code : ['mq', 'mtq', 'mb', 474],	Language : ['fr'] },
		{ Name : ['Mauritania'],									Code : ['mr', 'mrt', 'mr', 478],	Language : ['ar', 'fr', 'wo'] },
		{ Name : ['Montserrat'],									Code : ['ms', 'msr', 'mh', 500],	Language : ['en'] },
		{ Name : ['Malta'],											Code : ['mt', 'mlt', 'mt', 470],	Language : ['mt', 'en'] },
		{ Name : ['Mauritius'],										Code : ['mu', 'mus', 'mp', 480],	Language : ['en', 'fr'] },
		{ Name : ['Maldives'],										Code : ['mv', 'mdv', 'mv', 462],	Language : ['dv', 'en'] },
		{ Name : ['Malawi'],										Code : ['mw', 'mwi', 'mi', 454],	Language : ['ny'] },
		{ Name : ['Mexico'],										Code : ['mx', 'mex', 'mx', 484],	Language : ['es'] },
		{ Name : ['Malaysia'],										Code : ['my', 'mys', 'my', 458],	Language : ['ms', 'en', 'zh', 'ta', 'te', 'ml', 'pa', 'th'] },
		{ Name : ['Mozambique'],									Code : ['mz', 'moz', 'mz', 508],	Language : ['pt'] },
		{ Name : ['Namibia'],										Code : ['na', 'nam', 'wa', 516],	Language : ['en', 'af', 'de', 'hz'] },
		{ Name : ['New Caledonia'],									Code : ['nc', 'ncl', 'nc', 540],	Language : ['fr'] },
		{ Name : ['Niger'],											Code : ['ne', 'ner', 'ng', 562],	Language : ['fr', 'ha', 'kr'] },
		{ Name : ['Norfolk Island'],								Code : ['nf', 'nfk', 'nf', 574],	Language : ['en'] },
		{ Name : ['Nigeria'],										Code : ['ng', 'nga', 'ni', 566],	Language : ['en', 'ha', 'yo', 'ig', 'ff'] },
		{ Name : ['Nicaragua'],										Code : ['ni', 'nic', 'nu', 558],	Language : ['es', 'en'] },
		{ Name : ['Netherlands'],									Code : ['nl', 'nld', 'nl', 528],	Language : ['nl', 'fy'] },
		{ Name : ['Norway'],										Code : ['no', 'nor', 'no', 578],	Language : ['no', 'nb', 'nn', 'se', 'fi'] },
		{ Name : ['Nepal'],											Code : ['np', 'npl', 'np', 524],	Language : ['ne', 'en'] },
		{ Name : ['Nauru'],											Code : ['nr', 'nru', 'nr', 520],	Language : ['na', 'en'] },
		{ Name : ['Niue'],											Code : ['nu', 'niu', 'ne', 570],	Language : ['en'] },
		{ Name : ['New Zealand'],									Code : ['nz', 'nzl', 'nz', 554],	Language : ['en', 'mi'] },
		{ Name : ['Oman'],											Code : ['om', 'omn', 'mu', 512],	Language : ['ar', 'en', 'ur'] },
		{ Name : ['Panama'],										Code : ['pa', 'pan', 'pm', 591],	Language : ['es', 'en'] },
		{ Name : ['Peru'],											Code : ['pe', 'per', 'pe', 604],	Language : ['es', 'qu', 'ay'] },
		{ Name : ['French Polynesia'],								Code : ['pf', 'pyf', 'fp', 258],	Language : ['fr', 'ty'] },
		{ Name : ['Papua New Guinea'],								Code : ['pg', 'png', 'pp', 598],	Language : ['en', 'ho'] },
		{ Name : ['Philippines'],									Code : ['ph', 'phl', 'rp', 608],	Language : ['tl', 'en'] },
		{ Name : ['Pakistan'],										Code : ['pk', 'pak', 'pk', 586],	Language : ['ur', 'en', 'pa', 'sd', 'ps'] },
		{ Name : ['Poland'],										Code : ['pl', 'pol', 'pl', 616],	Language : ['pl'] },
		{ Name : ['Saint Pierre and Miquelon'],						Code : ['pm', 'spm', 'sb', 666],	Language : ['fr'] },
		{ Name : ['Pitcairn'],										Code : ['pn', 'pcn', 'pc', 612],	Language : ['en'] },
		{ Name : ['Puerto Rico'],									Code : ['pr', 'pri', 'rq', 630],	Language : ['en', 'es'] },
		{ Name : ['Palestinian Territory'],							Code : ['ps', 'pse', 'we', 275],	Language : ['ar'] },
		{ Name : ['Portugal'],										Code : ['pt', 'prt', 'po', 620],	Language : ['pt'] },
		{ Name : ['Palau'],											Code : ['pw', 'plw', 'ps', 585],	Language : ['en', 'ja', 'zh'] },
		{ Name : ['Paraguay'],										Code : ['py', 'pry', 'pa', 600],	Language : ['es', 'gn'] },
		{ Name : ['Qatar'],											Code : ['qa', 'qat', 'qa', 634],	Language : ['ar', 'es'] },
		{ Name : ['Reunion'],										Code : ['re', 'reu', 're', 638],	Language : ['fr'] },
		{ Name : ['Romania'],										Code : ['ro', 'rou', 'ro', 642],	Language : ['ro', 'hu'] },
		{ Name : ['Serbia'],										Code : ['rs', 'srb', 'ri', 688],	Language : ['sr', 'hu', 'bs'] },
		{ Name : ['Russia'],										Code : ['ru', 'rus', 'rs', 643],	Language : ['ru', 'tt', 'kv', 'ce', 'cv', 'ba'] },
		{ Name : ['Rwanda'],										Code : ['rw', 'rwa', 'rw', 646],	Language : ['rw', 'en', 'fr', 'sw'] },
		{ Name : ['Saudi Arabia'],									Code : ['sa', 'sau', 'sa', 682],	Language : ['ar'] },
		{ Name : ['Solomon Islands'],								Code : ['sb', 'slb', 'bp', 90],		Language : ['en'] },
		{ Name : ['Seychelles'],									Code : ['sc', 'syc', 'se', 690],	Language : ['en', 'fr'] },
		{ Name : ['Sudan'],											Code : ['sd', 'sdn', 'su', 729],	Language : ['ar', 'en'] },
		{ Name : ['South Sudan'],									Code : ['ss', 'ssd', 'od', 728],	Language : ['en'] },
		{ Name : ['Sweden'],										Code : ['se', 'swe', 'sw', 752],	Language : ['sv', 'se', 'fi'] },
		{ Name : ['Singapore'],										Code : ['sg', 'sgp', 'sn', 702],	Language : ['en', 'ms', 'ta', 'zh'] },
		{ Name : ['Saint Helena'],									Code : ['sh', 'shn', 'sh', 654],	Language : ['en'] },
		{ Name : ['Slovenia'],										Code : ['si', 'svn', 'si', 705],	Language : ['sl', 'sh'] },
		{ Name : ['Svalbard and Jan Mayen'],						Code : ['sj', 'sjm', 'sv', 744],	Language : ['no', 'ru'] },
		{ Name : ['Slovakia'],										Code : ['sk', 'svk', 'lo', 703],	Language : ['sk', 'hu'] },
		{ Name : ['Sierra Leone'],									Code : ['sl', 'sle', 'sl', 694],	Language : ['en'] },
		{ Name : ['San Marino'],									Code : ['sm', 'smr', 'sm', 674],	Language : ['it'] },
		{ Name : ['Senegal'],										Code : ['sn', 'sen', 'sg', 686],	Language : ['fr', 'wo'] },
		{ Name : ['Somalia'],										Code : ['so', 'som', 'so', 706],	Language : ['so', 'ar', 'it', 'en'] },
		{ Name : ['Suriname'],										Code : ['sr', 'sur', 'ns', 740],	Language : ['nl', 'en', 'jv'] },
		{ Name : ['Sao Tome and Principe'],							Code : ['st', 'stp', 'tp', 678],	Language : ['pt'] },
		{ Name : ['El Salvador'],									Code : ['sv', 'slv', 'es', 222],	Language : ['es'] },
		{ Name : ['Sint Maarten'],									Code : ['sx', 'sxm', 'nn', 534],	Language : ['nl', 'en'] },
		{ Name : ['Syria'],											Code : ['sy', 'syr', 'sy', 760],	Language : ['ar', 'ku', 'hy', 'fr', 'en'] },
		{ Name : ['Swaziland'],										Code : ['sz', 'swz', 'wz', 748],	Language : ['en', 'ss'] },
		{ Name : ['Turks and Caicos Islands'],						Code : ['tc', 'tca', 'tk', 796],	Language : ['en'] },
		{ Name : ['Chad'],											Code : ['td', 'tcd', 'cd', 148],	Language : ['fr', 'ar'] },
		{ Name : ['French Southern Territories'],					Code : ['tf', 'atf', 'fs', 260],	Language : ['fr'] },
		{ Name : ['Togo'],											Code : ['tg', 'tgo', 'to', 768],	Language : ['fr', 'ee', 'ha'] },
		{ Name : ['Thailand'],										Code : ['th', 'tha', 'th', 764],	Language : ['th', 'en'] },
		{ Name : ['Tajikistan'],									Code : ['tj', 'tjk', 'ti', 762],	Language : ['tg', 'ru'] },
		{ Name : ['Tokelau'],										Code : ['tk', 'tkl', 'tl', 772],	Language : ['en'] },
		{ Name : ['East Timor'],									Code : ['tl', 'tls', 'tt', 626],	Language : ['pt', 'id', 'en'] },
		{ Name : ['Turkmenistan'],									Code : ['tm', 'tkm', 'tx', 795],	Language : ['tk', 'ru', 'uz'] },
		{ Name : ['Tunisia'],										Code : ['tn', 'tun', 'ts', 788],	Language : ['ar', 'fr'] },
		{ Name : ['Tonga'],											Code : ['to', 'ton', 'tn', 776],	Language : ['to', 'en'] },
		{ Name : ['Turkey'],										Code : ['tr', 'tur', 'tu', 792],	Language : ['tr', 'ku', 'az', 'av'] },
		{ Name : ['Trinidad and Tobago'],							Code : ['tt', 'tto', 'td', 780],	Language : ['en', 'fr', 'es', 'zh'] },
		{ Name : ['Tuvalu'],										Code : ['tv', 'tuv', 'tv', 798],	Language : ['en', 'sm'] },
		{ Name : ['Taiwan'],										Code : ['tw', 'twn', 'tw', 158],	Language : ['zh', 'zh'] },
		{ Name : ['Tanzania'],										Code : ['tz', 'tza', 'tz', 834],	Language : ['sw', 'en', 'ar'] },
		{ Name : ['Ukraine'],										Code : ['ua', 'ukr', 'up', 804],	Language : ['uk', 'ru', 'pl', 'hu'] },
		{ Name : ['Uganda'],										Code : ['ug', 'uga', 'ug', 800],	Language : ['en', 'lg', 'sw', 'ar'] },
		{ Name : ['United States Minor Outlying Islands'],			Code : ['um', 'umi', None, 581],	Language : ['en'] },
		{ Name : ['United States'],									Code : ['us', 'usa', 'us', 840],	Language : ['en', 'es', 'fr'] },
		{ Name : ['Uruguay'],										Code : ['uy', 'ury', 'uy', 858],	Language : ['es'] },
		{ Name : ['Uzbekistan'],									Code : ['uz', 'uzb', 'uz', 860],	Language : ['uz', 'ru', 'tg'] },
		{ Name : ['Vatican'],										Code : ['va', 'vat', 'vt', 336],	Language : ['la', 'it', 'fr'] },
		{ Name : ['Saint Vincent and the Grenadines'],				Code : ['vc', 'vct', 'vc', 670],	Language : ['en', 'fr'] },
		{ Name : ['Venezuela'],										Code : ['ve', 'ven', 've', 862],	Language : ['es'] },
		{ Name : ['British Virgin Islands'],						Code : ['vg', 'vgb', 'vi', 92],		Language : ['en'] },
		{ Name : ['US Virgin Islands'],								Code : ['vi', 'vir', 'vq', 850],	Language : ['en'] },
		{ Name : ['Vietnam'],										Code : ['vn', 'vnm', 'vm', 704],	Language : ['vi', 'en', 'fr', 'zh', 'km'] },
		{ Name : ['Vanuatu'],										Code : ['vu', 'vut', 'nh', 548],	Language : ['bi', 'en', 'fr'] },
		{ Name : ['Wallis and Futuna'],								Code : ['wf', 'wlf', 'wf', 876],	Language : ['fr'] },
		{ Name : ['Samoa'],											Code : ['ws', 'wsm', 'ws', 882],	Language : ['sm', 'en'] },
		{ Name : ['Yemen'],											Code : ['ye', 'yem', 'ym', 887],	Language : ['ar'] },
		{ Name : ['Mayotte'],										Code : ['yt', 'myt', 'mf', 175],	Language : ['fr'] },
		{ Name : ['South Africa'],									Code : ['za', 'zaf', 'sf', 710],	Language : ['zu', 'xh', 'af', 'en', 'tn', 'st', 'ts', 'ss', 've', 'nr'] },
		{ Name : ['Zambia'],										Code : ['zm', 'zmb', 'za', 894],	Language : ['en', 'ny'] },
		{ Name : ['Zimbabwe'],										Code : ['zw', 'zwe', 'zi', 716],	Language : ['en', 'sn', 'nr', 'nd'] },
		{ Name : ['Serbia and Montenegro'],							Code : ['cs', 'scg', 'yi', 891],	Language : ['cu', 'hu', 'sq', 'sr'] },
		{ Name : ['Netherlands Antilles'],							Code : ['an', 'ant', 'nt', 530],	Language : ['nl', 'en', 'es'] },
	)

	@classmethod
	def countries(self, universal = True, sort = None):
		if universal: result = Country.Countries
		else: result = Country.Countries[1:]

		if sort:
			if sort is True: sort = Country.Name
			result = sorted(result, key = lambda i : i[sort][0])

		return result

	@classmethod
	def country(self, data):
		if not data is None:

			compare = None
			compareString = None
			if Tools.isNumber(data):
				compare = (Country.Code, (Country.CodeQuaternary,))
			else:
				data = data.lower().replace(' ', '')
				length = len(data)
				if length == 2: compare = (Country.Code, (Country.CodePrimary, Country.CodeTertiary))
				elif length == 3: compare = (Country.Code, (Country.CodeSecondary,))
				elif length > 3: compareString = (Country.Name, (Country.NamePrimary,))

			if compare:
				for i in Country.Countries:
					value = i[compare[0]]
					for j in compare[1]:
						if data == value[j]:
							return i
			elif compareString:
				for i in Country.Countries:
					value = i[compareString[0]]
					for j in compareString[1]:
						if data == value[j].lower().replace(' ', ''):
							return i

		return None

	@classmethod
	def name(self, data, name = NameDefault):
		country = self.country(data = data)
		if country: return country[Country.Name][name]
		return None

	@classmethod
	def code(self, data, code = CodeDefault):
		country = self.country(data = data)
		if country: return country[Country.Code][code]
		return None

	@classmethod
	def language(self, data, language = LanguageAll):
		country = self.country(data = data)
		if country:
			result = country[Country.Language]
			if not language is Country.LanguageAll: result = result[language]
			return result
		return None

	@classmethod
	def zone(self, data, all = False):
		code = self.code(data = data, code = Country.CodePrimary)
		if code: return Time.zone(country = code, all = all)
		return None

	@classmethod
	def offset(self, data, all = False):
		code = self.code(data = data, code = Country.CodePrimary)
		if code: return Time.offset(country = code, all = all)
		return None

	@classmethod
	def settings(self, id = None, type = None, code = CodeDefault):
		setting = Settings.getString(id)
		if code is None or code is False: return self.country(data = setting)
		else: return self.code(data = setting, code = code)

	@classmethod
	def settingsSelect(self, id = None, type = None, title = None, automatic = None, none = None):
		from lib.modules.interface import Dialog

		current = Settings.getString(id)
		countries = self.countries(universal = False, sort = Country.Name)

		countries = [i[Country.Name][Country.NameDefault] for i in countries]
		if automatic: countries.insert(0, Country.Automatic.capitalize())
		if none: countries.insert(0, Country.Disabled.capitalize())

		choice = Dialog.select(title = title if title else 33855, items = countries, selection = current)
		if choice < 0: return None

		choice = countries[choice]
		Settings.set(id, choice)
		return choice


class Identifier(object):

	Base = 32
	Alphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'

	@classmethod
	def generate(self, *parts):
		import hashlib
		parts = list(parts)
		for i in range(len(parts)):
			try: parts[i] = Converter.unicode(parts[i])
			except: pass
		parts = '_'.join(parts)
		try: hash = hashlib.sha256(parts.encode('utf-8')).hexdigest()
		except: hash = hashlib.sha256(parts).hexdigest()
		hash = int(hash, 16) % (10 ** 48)
		return self.base(hash)

	@classmethod
	def base(self, value, base = Base):
		if value == 0: return Identifier.Alphabet[0]
		digits = []
		while value:
			digits.append(Identifier.Alphabet[int(value % base)])
			value = int(value / base)
		digits.reverse()
		return ''.join(digits)


class Hash(object):

	# Fast hashing algorithm used by Python's dictionary.
	# Returns integer.
	@classmethod
	def hash(self, data):
		# To get hex hash: hash(data).to_bytes(8, 'big').hex().upper()
		return hash(data)

	@classmethod
	def random(self):
		import uuid
		return str(uuid.uuid4().hex).upper()

	@classmethod
	def sha1(self, data):
		import hashlib
		try: return hashlib.sha1(data.encode('utf-8')).hexdigest().upper()
		except: return hashlib.sha1(data).hexdigest().upper() # If data contains non-encodable characters, like YggTorrent containers.

	@classmethod
	def sha256(self, data):
		import hashlib
		try: return hashlib.sha256(data.encode('utf-8')).hexdigest().upper()
		except: return hashlib.sha256(data).hexdigest().upper() # If data contains non-encodable characters, like YggTorrent containers.

	@classmethod
	def sha512(self, data):
		import hashlib
		try: return hashlib.sha512(data.encode('utf-8')).hexdigest().upper()
		except: return hashlib.sha512(data).hexdigest().upper() # If data contains non-encodable characters, like YggTorrent containers.

	@classmethod
	def md5(self, data):
		import hashlib
		try: return hashlib.md5(data.encode('utf-8')).hexdigest().upper()
		except: return hashlib.md5(data).hexdigest().upper() # If data contains non-encodable characters, like YggTorrent containers.

	@classmethod
	def file(self, path):
		return self.fileSha256(path)

	@classmethod
	def fileSha1(self, path):
		return self.sha1(File.readNow(path))

	@classmethod
	def fileSha256(self, path):
		return self.sha256(File.readNow(path))

	@classmethod
	def fileSha512(self, path):
		return self.sha512(File.readNow(path))

	@classmethod
	def fileMd5(self, path):
		return self.md5(File.readNow(path))

	@classmethod
	def valid(self, hash, length = 40):
		return hash and len(hash) == length and bool(re.match('^[a-fA-F0-9]+', hash))

class Video(object):

	# https://en.wikipedia.org/wiki/Video_file_format
	# https://dotwhat.net/type/video-movie-files

	Extensions = {
		'mp2' : True,
		'mp4' : True,
		'mpg' : True,
		'mpg2' : True,
		'mpg4' : True,
		'mpeg' : True,
		'mpeg2' : True,
		'mpeg4' : True,
		'mpe' : True,
		'mpv' : True,
		'm4v' : True,
		'm4p' : True,
		'm2v' : True,
		'm2p' : True,
		'ps' : True,
		'mkv' : True,
		'mk3d' : True,
		'webm' : True,
		'avi' : True,
		'avp' : True,
		'avs' : True,
		'amv' : True,
		'flv' : True,
		'f4v' : True,
		'swf' : True,
		'aaf' : True,
		'asf' : True,
		'asx' : True,
		'3gp' : True,
		'3gpp' : True,
		'3gp2' : True,
		'3g2' : True,
		'3mm' : True,
		'ogg' : True,
		'ogv' : True,
		'wmv' : True,
		'mov' : True,
		'hdmov' : True,
		'qt' : True,
		'vob' : True,
		'rm' : True,
		'rmvb' : True,
		'svi' : True,
		'avchd' : True,
		'divx' : True,
		'xvid' : True,
		'mxf' : True,
		'viv' : True,
		'ts' : True,
		'mts' : True,
		'm2t' : True,
		'm2ts' : True,
		'bup' : True,
		'edl' : True,
		'enc' : True,
		'nsv' : True,
		'264' : True,
		'265' : True,
		'266' : True,
		'vp6' : True,
		'vp7' : True,
		'vp8' : True,
		'vp9' : True,
		'vp10' : True,
	}

	@classmethod
	def extensions(self):
		return Video.Extensions

	@classmethod
	def extensionValid(self, extension = None, path = None, unknown = False):
		if extension == None: extension = os.path.splitext(path)[1][1:]
		if not extension and unknown: return True
		return extension.lower() in Video.Extensions

class Audio(object):

	# Values must correspond to settings.
	StartupNone = 0
	Startup1 = 1
	Startup2 = 2
	Startup3 = 3
	Startup4 = 4
	Startup5 = 5

	@classmethod
	def startup(self, type = None):
		if type is None:
			type = Settings.getInteger('general.launch.sound')
		if type == 0 or type is None:
			return False
		else:
			path = os.path.join(System.pathResources(), 'resources', 'media', 'audio', 'startup', 'startup%d' % type, 'Gaia')
			return self.play(path = path, notPlaying = True)

	@classmethod
	def play(self, path, notPlaying = True):
		player = xbmc.Player()
		if not notPlaying or not player.isPlaying():
			player.play(path, windowed = True)
			return True
		else:
			return False

# Kodi's thumbnail cache
class Thumbnail(object):

	Directory = 'special://thumbnails'

	@classmethod
	def hash(self, path):
		try:
			path = path.lower()
			bs = bytearray(path.encode())
			crc = 0xffffffff
			for b in bs:
				crc = crc ^ (b << 24)
				for i in range(8):
					if crc & 0x80000000:
						crc = (crc << 1) ^ 0x04C11DB7
					else:
						crc = crc << 1
				crc = crc & 0xFFFFFFFF
			return '%08x' % crc
		except:
			return None

	@classmethod
	def delete(self, path):
		name = self.hash(path)
		if name == None:
			return None
		name += '.jpg'
		file = None
		directories, files = File.listDirectory(Thumbnail.Directory)
		for f in files:
			if f == name:
				file = os.path.join(Thumbnail.Directory, f)
				break
		for d in directories:
			dir = os.path.join(Thumbnail.Directory, d)
			directories2, files2 = File.listDirectory(dir)
			for f in files2:
				if f == name:
					file = os.path.join(dir, f)
					break
			if not file == None:
				break
		if not file == None:
			File.delete(file, force = True)

class Selection(object):

	# Must be integers
	TypeExclude = -1
	TypeUndefined = 0
	TypeInclude = 1

class Kids(object):

	Restriction7 = 0
	Restriction13 = 1
	Restriction16 = 2
	Restriction18 = 3

	@classmethod
	def enabled(self):
		return Settings.getBoolean('general.kids.enabled')

	@classmethod
	def restriction(self):
		return Settings.getInteger('general.kids.restriction')

	@classmethod
	def password(self, hash = True):
		password = Settings.getString('general.kids.password')
		if hash and not(password == None or password == ''): password = Hash.md5(password).lower()
		return password

	@classmethod
	def passwordEmpty(self):
		password = self.password()
		return password == None or password == ''

	@classmethod
	def verify(self, password):
		return not self.enabled() or self.passwordEmpty() or password.lower() == self.password().lower()

	@classmethod
	def locked(self):
		return Settings.getBoolean('general.kids.locked', cached = False) # Do not use the cached setting.

	@classmethod
	def lockable(self):
		return not self.passwordEmpty() and not self.locked()

	@classmethod
	def unlockable(self):
		return not self.passwordEmpty() and self.locked()

	@classmethod
	def lock(self):
		if self.locked():
			return True
		else:
			from lib.modules.interface import Dialog
			Settings.set('general.kids.locked', True)
			Dialog.confirm(title = 33438, message = 33445)
			System.restart() # Kodi still keeps the old menus in cache (when going BACK). Clear them by restarting the addon. Must be AFTER showing the dialog.
			return True

	@classmethod
	def unlock(self, internal = False):
		if self.locked():
			from lib.modules.interface import Dialog
			password = self.password()
			if password and not password == '':
				match = Dialog.inputPassword(title = 33440, verify = password)
				if not match:
					Dialog.confirm(title = 33440, message = 33441)
					return False
			Settings.set('general.kids.locked', False)
			if not internal: Dialog.confirm(title = 33438, message = 33444)
			System.restart() # Kodi still keeps the old menus in cache (when going BACK). Clear them by restarting the addon. Must be AFTER showing the dialog.
			return True
		else:
			return True

	@classmethod
	def allowed(self, certificate):
		if certificate == None or certificate == '':
			return False

		certificate = certificate.lower().replace(' ', '').replace('-', '').replace('_', '').strip()
		restriction = self.restriction()

		if (certificate  == 'g' or certificate  == 'tvy'):
			return True
		elif (certificate == 'pg' or certificate == 'tvy7') and restriction >= 1:
			return True
		elif (certificate == 'pg13' or certificate == 'tvpg') and restriction >= 2:
			return True
		elif (certificate == 'r' or certificate == 'tv14') and restriction >= 3:
			return True
		return False

class Converter(object):

	@classmethod
	def roman(self, number):
		number = number.lower().replace(' ', '')
		numerals = {'i' : 1, 'v' : 5, 'x' : 10, 'l' : 50, 'c' : 100, 'd' : 500, 'm' : 1000}
		result = 0
		for i, c in enumerate(number):
			if not c in numerals:
				return None
			elif (i + 1) == len(number) or numerals[c] > numerals[number[i + 1]]:
				result += numerals[c]
			else:
				result -= numerals[c]
		return result

	# Converts a string into a number representation.
	@classmethod
	def number(self, string, pad = True, inverse = False):
		numbers = [ord(char) for char in string]
		if inverse: numbers = [65536 - number for number in numbers]
		if pad: numbers = ['%05d' % number for number in numbers] # Unicode can go up to 65535.
		else: numbers = [str(number) for number in numbers]
		return ''.join(numbers)

	@classmethod
	def boolean(self, value, string = False, none = False):
		if none and value is None:
			return value
		elif string:
			return 'true' if value else 'false'
		else:
			if value is True or value is False:
				return value
			elif Tools.isInteger(value):
				return value > 0
			elif Tools.isString(value):
				value = value.lower()
				return value == 'true' or value == 'yes' or value == 't' or value == 'y' or value == '1'
			else:
				return False

	@classmethod
	def dictionary(self, jsonData):
		try:
			import json

			if jsonData == None: return None
			jsonData = json.loads(jsonData)

			# In case the quotes in the string were escaped, causing the first json.loads to return a unicode string.
			try: jsonData = json.loads(jsonData)
			except: pass

			return jsonData
		except:
			return jsonData

	# Detect encoding from string.
	@classmethod
	def encodingDetect(self, value, best = True):
		try:
			from lib.externals import chardet
			return chardet.detect(value)['encoding']
		except:
			Logger.error()
			return None

	# Replaces all unicode characters with an ASCII-normalized characters closest to the uunicode characterself.
	# Always returns an ASCII string.
	# Eg: Amélie -> Amelie
	# Eg (Non-umlaut): Über -> Uber
	# Eg (Umlaut): Über -> Ueber
	@classmethod
	def unicodeNormalize(self, string, umlaut = False):
		try:
			if not string: return string
			try: string = string.decode('utf-8')
			except: pass
			if umlaut:
				try: string = string.replace(unichr(196), 'Ae').replace(unichr(203), 'Ee').replace(unichr(207), 'Ie').replace(unichr(214), 'Oe').replace(unichr(220), 'Ue').replace(unichr(228), 'ae').replace(unichr(235), 'ee').replace(unichr(239), 'ie').replace(unichr(246), 'oe').replace(unichr(252), 'ue')
				except: pass
			# It seems unidecode does not work in Python 2, only in Python 3.
			# In Python 2 the letter is removed instead of being reeplaced with a non-accent ASCII letter.
			#from lib.externals.unidecode import unidecode
			#return unidecode(string.decode('utf-8'))
			import unicodedata
			return unicodedata.normalize('NFKD', string).encode('ascii', 'ignore').decode('ascii')
		except:
			return self.unicodeStrip(string = string)

	# Removes all unicode characters.
	# Always returns an ASCII string.
	# Eg: Amélie -> Amlie
	@classmethod
	def unicodeStrip(self, string):
		try: string = string.decode('utf-8')
		except: pass
		try: return string.encode('ascii', 'ignore').decode('ascii')
		except: return string

	@classmethod
	def unicode(self, value, encoding = 'utf-8'):
		if Tools.isString(value):
			try: value = str(value, encoding)
			except: pass
		else:
			# Non-strings (None, boolean, etc) fail to convert to string if the encoding is set.
			return str(value)
		return value

	@classmethod
	def bytes(self, value, encoding = 'utf-8'):
		try: value = bytes(value, encoding)
		except: pass
		return value

	@classmethod
	def base16From(self, data):
		import base64
		return self.unicode(base64.b16decode(data))

	@classmethod
	def base16To(self, data):
		import base64
		return self.unicode(base64.b16encode(self.bytes(data)))

	@classmethod
	def base32From(self, data):
		import base64
		return self.unicode(base64.b32decode(data))

	@classmethod
	def base32To(self, data):
		import base64
		return self.unicode(base64.b32encode(self.bytes(data)))

	@classmethod
	def base64From(self, data, url = False):
		import base64
		if url: data = base64.urlsafe_b64decode(data)
		else: data = base64.b64decode(data)
		return self.unicode(data)

	@classmethod
	def base64To(self, data):
		import base64
		return self.unicode(base64.b64encode(self.bytes(data)))

	@classmethod
	def jsonFrom(self, data, default = None):
		import json
		try: return json.loads(data)
		except: return default

	@classmethod
	def jsonTo(self, data, default = None):
		def _jsonTo(object):
			try: return object.__json__()
			except: return object.__dict__
		import json
		try: return json.dumps(data, default = _jsonTo, separators = (',', ':')) # separators: otherwise unnecessary spaces are added between the key and the value, increasing the JSON string size.
		except: return default

	@classmethod
	def quoteFrom(self, data, default = None):
		try:
			from lib.modules.network import Networker
			return Networker.linkUnquote(data, plus = True)
		except: return default

	@classmethod
	def quoteTo(self, data, default = None):
		try:
			from lib.modules.network import Networker
			return Networker.linkQuote(data, plus = True)
		except: return default

	@classmethod
	def serialize(self, data):
		try:
			import pickle
			return pickle.dumps(data)
		except:
			return None

	@classmethod
	def unserialize(self, data):
		try:
			import pickle
			return pickle.loads(data)
		except:
			return None

	# Convert HTML entities to ASCII.
	@classmethod
	def htmlFrom(self, data):
		try:
			try: from HTMLParser import HTMLParser
			except: from html.parser import HTMLParser
			return str(HTMLParser().unescape(data))
		except:
			return data


class Logger(object):

	try: TypeInfo = xbmc.LOGINFO
	except: TypeInfo = xbmc.LOGNOTICE
	TypeDebug = xbmc.LOGDEBUG
	TypeError = xbmc.LOGERROR
	TypeFatal = xbmc.LOGFATAL
	TypeDefault = TypeInfo

	@classmethod
	def log(self, message, message2 = None, message3 = None, message4 = None, message5 = None, name = True, parameters = None, type = TypeDefault):
		divider = ' '
		message = str(message)
		if message2: message += divider + str(message2)
		if message3: message += divider + str(message3)
		if message4: message += divider + str(message4)
		if message5: message += divider + str(message5)
		if name:
			nameValue = System.name().upper() + ' ' + System.version()
			if not name is True: nameValue += ' (' + name + ')'
			if parameters:
				nameValue += ' ['
				if Tools.isString(parameters):
					nameValue += parameters
				else:
					nameValue += ', '.join([str(parameter) for parameter in parameters])
				nameValue += ']'
			nameValue += ': '
			message = nameValue + message
		xbmc.log(message, type)

	@classmethod
	def error(self, message = None, exception = True):
		if exception:
			type, value, trace = sys.exc_info()
			try: filename = trace.tb_frame.f_code.co_filename
			except: filename = None
			try: linenumber = trace.tb_lineno
			except: linenumber = None
			try: name = trace.tb_frame.f_code.co_name
			except: name = None
			try: errortype = type.__name__
			except: errortype = None
			try: errormessage = value.message
			except:
				try:
					import traceback
					errormessage = traceback.format_exception(type, value, trace)
				except: pass
			if message: message += ' -> '
			else: message = ''
			message += str(errortype) + ' -> ' + str(errormessage)
			parameters = [filename, linenumber, name]
		else:
			parameters = None
		self.log(message, name = 'ERROR', parameters = parameters, type = Logger.TypeError)

	@classmethod
	def errorCustom(self, message):
		self.log(message, name = 'ERROR', type = Logger.TypeError)

	@classmethod
	def path(self):
		path = File.translatePath('special://logpath')
		if not path.endswith('.log'): path = File.joinPath(path, 'kodi.log')
		return path

	@classmethod
	def data(self):
		return File.readNow(self.path())

	@classmethod
	def details(self, title, items):
		try:
			def _string(value):
				if value is None: return ''
				return Converter.unicode(value)

			empty = ''
			indent = '   '
			line = '#' * 59
			text = [line, ' ' + title.upper(), line]

			for item in items:
				text.append(empty)
				text.append(indent + item['title'].upper())
				for i in item['items']:
					if Tools.isArray(i): i = '%s: %s' % (i[0], _string(i[1]))
					text.append(indent + indent + _string(i))

			text.extend([empty, line])
			self.log('', name = False)
			[self.log('#' + i, name = False) for i in text]
			self.log('', name = False)
		except:
			self.error(message = 'Could not generate detailed information')

	@classmethod
	def system(self):
		try:
			items = []

			# System
			informationSystem = System.informationSystem()
			items.append({
				'title' : 'System',
				'items' : [
					['Family', informationSystem['family']],
					['Name', informationSystem['name']],
					['Codename', informationSystem['codename']],
					['Version', informationSystem['version']],
					['Bits', informationSystem['bits']],
					['Architecture', informationSystem['architecture']],
				],
			})

			# Python
			informationPython = System.informationPython()
			items.append({
				'title' : 'Python',
				'items' : [
					['Build', informationPython['build']],
					['Version', informationPython['version']],
					['Implementation', informationPython['implementation']],
				],
			})

			# Kodi
			informationKodi = System.informationKodi()
			items.append({
				'title' : 'Kodi',
				'items' : [
					['Name', informationKodi['name']],
					['Build', informationKodi['build']],
					['Version', informationKodi['version']],
					['Date', informationKodi['date']],
					['Uptime', informationKodi['uptime']],
				],
			})

			# Gaia
			informationAddon = System.informationAddon()
			items.append({
				'title' : 'Gaia',
				'items' : [
					['Name', informationAddon['name']],
					['Version', informationAddon['version']],
					['Author', informationAddon['author']],
				],
			})

			# Usage
			informationUsage = System.informationUsage()
			items.append({
				'title' : 'Usage',
				'items' : [
					['Processor', informationUsage['processor']['label']['description']],
					['Memory', informationUsage['memory']['label']['description']],
					['Storage', informationUsage['storage']['label']['description']],
				],
			})

			return self.details(title = 'Gaia System Details', items = items)
		except:
			self.error(message = 'Could not generate system information')

class File(object):

	PrefixSpecial = 'special://'
	PrefixSamba = 'smb://'

	DirectoryHome = PrefixSpecial + 'home'
	DirectoryTemporary = PrefixSpecial + 'temp'

	@classmethod
	def freeSpace(self, path = '/'):
		free = 0
		directory = os.path.realpath(path)
		try:
			if not free:
				import shutil
				total, used, free = shutil.disk_usage(directory)
		except: pass
		try:
			if not free:
				import psutil
				free = psutil.disk_usage(directory).free
		except: pass
		try:
			if not free:
				windows = Platform.familyType() == Platform.FamilyWindows
				if windows:
					try:
						if not free:
							import ctypes
							bytes = ctypes.c_ulonglong(0)
							ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(directory), None, None, ctypes.pointer(bytes))
							free = bytes.value
					except: pass
					try:
						if not free:
							import win32file
							sectorsPerCluster, bytesPerSector, freeClusters, totalClusters = win32file.GetDiskFreeSpace(directory)
							free = sectorsPerCluster * bytesPerSector * freeClusters
					except: pass
				else:
					try:
						if not free:
							stats = os.statvfs(dirname)
							free = stats.f_bavail * stats.f_frsize
					except: pass
					try:
						if free == 0:
							import subprocess
							stats = subprocess.Popen(['df', '-Pk', directory], stdout = subprocess.PIPE).communicate()[0]
							free = int(stats.splitlines()[1].split()[3]) * 1024
					except: pass
		except: pass
		return free

	@classmethod
	def translate(self, path):
		if path.startswith(File.PrefixSpecial): path = xbmcvfs.translatePath(path)
		return path

	@classmethod
	def name(self, path, extension = False):
		name = os.path.basename(path if extension else os.path.splitext(path)[0])
		if not name: name = None
		return name

	@classmethod
	def makeDirectory(self, path):
		return xbmcvfs.mkdirs(path)

	@classmethod
	def translatePath(self, path):
		return xbmcvfs.translatePath(path)

	@classmethod
	def legalPath(self, path):
		return xbmcvfs.makeLegalFilename(path)

	@classmethod
	def joinPath(self, path, *paths):
		parts = []
		for p in paths:
			if Tools.isArray(p): parts.extend(p)
			else: parts.append(p)
		return os.path.join(path, *parts)

	@classmethod
	def exists(self, path): # Directory must end with slash
		# Do not use xbmcvfs.exists, since it returns true for http links.
		if path.startswith('http:') or path.startswith('https:') or path.startswith('ftp:') or path.startswith('ftps:'):
			return os.path.exists(path)
		else:
			return xbmcvfs.exists(path)

	@classmethod
	def existsDirectory(self, path):
		if not path.endswith('/') and not path.endswith('\\'): path += '/'
		return xbmcvfs.exists(path)

	# If samba file or directory.
	@classmethod
	def samba(self, path):
		return path.startswith(File.PrefixSamba)

	# If network (samba or any other non-local supported Kodi path) file or directory.
	# Path must point to a valid file or directory.
	@classmethod
	def network(self, path):
		return self.samba(path) or (self.exists(path) and not os.path.exists(path))

	@classmethod
	def delete(self, path, force = True):
		try:
			# For samba paths
			try:
				if self.exists(path):
					xbmcvfs.delete(path)
			except:
				pass

			# All with force
			try:
				if self.exists(path):
					if force:
						import stat
						os.chmod(path, stat.S_IWRITE) # Remove read only.
					return os.remove(path) # xbmcvfs often has problems deleting files
			except:
				pass

			return not self.exists(path)
		except:
			return False

	@classmethod
	def directory(self, path):
		return os.path.dirname(path)

	@classmethod
	def directoryName(self, path):
		return os.path.basename(self.directory(path))

	@classmethod
	def deleteDirectory(self, path, force = True):
		try:
			# For samba paths
			try:
				if self.existsDirectory(path):
					xbmcvfs.rmdir(path)
					if not self.existsDirectory(path):
						return True
			except:
				pass

			try:
				if self.existsDirectory(path):
					import shutil
					shutil.rmtree(path)
					if not self.existsDirectory(path):
						return True
			except:
				pass

			# All with force
			try:
				if self.existsDirectory(path):
					if force:
						import stat
						os.chmod(path, stat.S_IWRITE) # Remove read only.
					os.rmdir(path)
					if not self.existsDirectory(path):
						return True
			except:
				pass

			# Try individual delete
			try:
				if self.existsDirectory(path):
					directories, files = self.listDirectory(path)
					for i in files:
						self.delete(os.path.join(path, i), force = force)
					for i in directories:
						self.deleteDirectory(os.path.join(path, i), force = force)
					try: xbmcvfs.rmdir(path)
					except: pass
					try:
						import shutil
						shutil.rmtree(path)
					except: pass
					try: os.rmdir(path)
					except: pass
			except:
				pass

			return not self.existsDirectory(path)
		except:
			Logger.error()
			return False

	@classmethod
	def size(self, path):
		return xbmcvfs.File(path).size()

	@classmethod
	def timeCreated(self, path):
		return xbmcvfs.Stat(path).st_ctime()

	@classmethod
	def timeAccessed(self, path):
		return xbmcvfs.Stat(path).st_atime()

	@classmethod
	def timeUpdated(self, path):
		return xbmcvfs.Stat(path).st_mtime()

	@classmethod
	def create(self, path):
		return self.writeNow(path, '')

	@classmethod
	def readNow(self, path, bytes = False, native = False):
		try:
			result = None
			if native:
				with open(path, 'rb' if bytes else 'r') as file:
					result = file.read()
			else:
				file = xbmcvfs.File(path)
				result = file.readBytes() if bytes else file.read()
				file.close()
			return result
		except:
			Logger.error()
			return None

	@classmethod
	def writeNow(self, path, value, bytes = False, native = False):
		try:
			if native:
				with open(path, 'wb' if bytes else 'w') as file:
					file.write(value)
			else:
				file = xbmcvfs.File(path, 'w')
				result = file.write(value)
				file.close()
				return result
		except:
			Logger.error()
			return None

	# replaceNow(path, 'from', 'to')
	# replaceNow(path, [['from1', 'to1'], ['from2', 'to2']])
	@classmethod
	def replaceNow(self, path, valueFrom, valueTo = None):
		data = self.readNow(path)
		if not Tools.isArray(valueFrom):
			valueFrom = [[valueFrom, valueTo]]
		for replacement in valueFrom:
			data = data.replace(replacement[0], replacement[1])
		self.writeNow(path, data)

	# Returns: directories, files
	@classmethod
	def listDirectory(self, path, absolute = False):
		directories, files = xbmcvfs.listdir(path)
		if absolute:
			for i in range(len(files)):
				files[i] = File.joinPath(path, files[i])
			for i in range(len(directories)):
				directories[i] = File.joinPath(path, directories[i])
		return directories, files

	@classmethod
	def copy(self, pathFrom, pathTo, bytes = None, overwrite = False, sleep = True):
		if overwrite and xbmcvfs.exists(pathTo):
			try: self.delete(path = pathTo, force = True)
			except: pass
			# This is important, especailly for Windows.
			# When deleteing a file and immediatly replacing it, the old file might still exist and the file is never replaced.
			if sleep: Time.sleep(0.1 if sleep == True else sleep)
		if bytes == None:
			return xbmcvfs.copy(pathFrom, pathTo)
		else:
			try:
				fileFrom = xbmcvfs.File(pathFrom)
				fileTo = xbmcvfs.File(pathTo, 'w')
				chunk = min(bytes, 1048576) # 1 MB
				while bytes > 0:
					size = min(bytes, chunk)
					fileTo.write(fileFrom.read(size))
					bytes -= size
				fileFrom.close()
				fileTo.close()
				return True
			except:
				return False

	@classmethod
	def copyDirectory(self, pathFrom, pathTo, overwrite = True):
		if not pathFrom.endswith('/') and not pathFrom.endswith('\\'): pathFrom += '/'
		if not pathTo.endswith('/') and not pathTo.endswith('\\'): pathTo += '/'

		# NB: Always check if directory exists before copying it on Windows.
		# If the source directory does not exist, Windows will simply copy the entire C: drive.
		if self.existsDirectory(pathFrom):
			try:
				if overwrite: File.deleteDirectory(pathTo)
				import shutil
				shutil.copytree(pathFrom, pathTo)
				return True
			except:
				return False
		else:
			return False

	@classmethod
	def renameDirectory(self, pathFrom, pathTo):
		if not pathFrom.endswith('/') and not pathFrom.endswith('\\'):
			pathFrom += '/'
		if not pathTo.endswith('/') and not pathTo.endswith('\\'):
			pathTo += '/'
		os.rename(pathFrom, pathTo)

	# Not for samba paths
	@classmethod
	def move(self, pathFrom, pathTo, replace = True, sleep = True):
		if pathFrom == pathTo:
			return False
		if replace:
			try: self.delete(path = pathTo, force = True)
			except: pass
			# This is important, especially for Windows.
			# When deleting a file and immediatly replacing it, the old file might still exist and the file is never replaced.
			if sleep: Time.sleep(0.1 if sleep == True else sleep)
		try:
			import shutil
			shutil.move(pathFrom, pathTo)
			return True
		except:
			return False

class System(object):

	PropertyObserve = 'GaiaObserve'
	PropertyLaunch = 'GaiaLaunch'
	PropertyVersion = 'GaiaVersion'
	PropertyInitial = 'GaiaInitial'
	PropertyRestart = 'GaiaRestart'
	PropertyLock = 'GaiaLock'

	StartupScript = 'special://masterprofile/autoexec.py'

	PluginPrefix = 'plugin://'

	GaiaAddon = 'plugin.video.gaia'
	GaiaArtwork = 'script.gaia.artwork'
	GaiaBinaries = 'script.gaia.binaries'
	GaiaResources = 'script.gaia.resources'
	GaiaIcons = 'script.gaia.icons'
	GaiaSkins = 'script.gaia.skins'
	GaiaRepository = 'repository.gaia'
	GaiaRepositoryTest = 'repository.gaia.test'

	KodiVersion = None
	KodiVersionFull = None
	KodiVersionNew = None

	Monitor = None

	@classmethod
	def handle(self):
		return int(sys.argv[1])

	@classmethod
	def osLinux(self):
		return sys.platform == 'linux' or sys.platform == 'linux2'

	# If the developers option is enabled.
	@classmethod
	def developers(self):
		return Settings.getString('general.advanced.code') == Converter.base64From('b3BlbnNlc2FtZQ==')

	@classmethod
	def developersCode(self):
		return Converter.base64From('b3BlbnNlc2FtZQ==')

	@classmethod
	def obfuscate(self, data, iterations = 3, inverse = True):
		if inverse:
			for i in range(iterations):
				data = Converter.base64From(data)[::-1]
		else:
			for i in range(iterations):
				data = Converter.base64To(data[::-1])
		return Converter.unicode(data)

	# Simulated restart of the addon.
	@classmethod
	def restart(self, sleep = True):
		self.restartStart()
		self.exit()
		if sleep: Time.sleep(0.2)
		System.execute('RunAddon(%s)' % System.GaiaAddon)

	@classmethod
	def restartBusy(self):
		try: return int(self.windowPropertyGet(property = System.PropertyRestart))
		except: return False

	@classmethod
	def restartStart(self):
		self.windowPropertySet(property = System.PropertyRestart, value = 1)

	@classmethod
	def restartFinish(self):
		self.windowPropertySet(property = System.PropertyRestart, value = 0)

	@classmethod
	def exit(self):
		System.execute('Container.Update(path,replace)')
		System.execute('ActivateWindow(Home)')
		System.execute('Container.Update(path,replace)')

	@classmethod
	def quit(self, log = True):
		if log: Logger.log('Aborting the execution of the Gaia addon.', type = Logger.TypeFatal)
		try: sys.exit()
		except: pass

	@classmethod
	def aborted(self):
		try:
			return System.Monitor.abortRequested()
		except:
			System.Monitor = xbmc.Monitor()
			return System.Monitor.abortRequested()

	@classmethod
	def visible(self, item):
		return xbmc.getCondVisibility(item)

	@classmethod
	def versionKodi(self, full = False):
		if full:
			if System.KodiVersionFull is None:
				System.KodiVersionFull = self.infoLabel('System.BuildVersion')
			return System.KodiVersionFull
		else:
			if System.KodiVersion is None:
				try: System.KodiVersion = float(re.search('^\d+\.?\d+', self.infoLabel('System.BuildVersion')).group(0))
				except: pass
			return System.KodiVersion

	@classmethod
	def home(self):
		System.execute('ActivateWindow(Home)')

	@classmethod
	def pluginPropertySet(self, property, value, handle = None):
		return xbmcplugin.setProperty(self.handle() if handle is None else handle, property, str(value))

	@classmethod
	def pluginResolvedSet(self, item, success = True, handle = None):
		return xbmcplugin.setResolvedUrl(self.handle() if handle is None else handle, success, item)

	@classmethod
	def windowPropertyGet(self, property, id = 10000):
		return xbmcgui.Window(id).getProperty(property)

	@classmethod
	def windowPropertySet(self, property, value, id = 10000):
		return xbmcgui.Window(id).setProperty(property, str(value))

	@classmethod
	def windowPropertyClear(self, property, id = 10000):
		return xbmcgui.Window(id).clearProperty(property)

	@classmethod
	def globalLock(self, id = ''):
		self.windowPropertySet(property = System.PropertyLock + id, value = 1)

	@classmethod
	def globalUnlock(self, id = ''):
		self.windowPropertySet(property = System.PropertyLock + id, value = 0)

	@classmethod
	def globalLocked(self, id = ''):
		return self.windowPropertyGet(property = System.PropertyLock + id) == '1'

	@classmethod
	def path(self, id = GaiaAddon):
		try: addon = xbmcaddon.Addon(id)
		except: addon = None
		if addon is None: return None
		else: return File.translatePath(addon.getAddonInfo('path'))

	@classmethod
	def pathArtwork(self):
		return self.path(System.GaiaArtwork)

	@classmethod
	def pathBinaries(self):
		return self.path(System.GaiaBinaries)

	@classmethod
	def pathIcons(self):
		return self.path(System.GaiaIcons)

	@classmethod
	def pathResources(self):
		return self.path(System.GaiaResources)

	@classmethod
	def pathSkins(self):
		return self.path(System.GaiaSkins)

	# OS user home directory
	@classmethod
	def pathHome(self):
		try: return os.path.expanduser('~')
		except: return None

	@classmethod
	def pathProviders(self, provider = None):
		path = File.joinPath(self.profile(), 'Providers')
		if provider: path = File.joinPath(path, provider)
		return path

	@classmethod
	def plugin(self, id = GaiaAddon):
		return System.PluginPrefix + str(id)

	@classmethod
	def command(self, action = None, parameters = None, query = None, id = GaiaAddon, duplicates = False, basic = False):
		if query is None:
			if parameters is None: parameters = {}
			if not action is None: parameters['action'] = action

			# urllib.urlencode can take some time, especially for larger parameter sets.
			# Allow to manually encode the string, which is a lot faster, but requires all parameter values to be already urlencoded.
			if basic:
				query = '&'.join([str(key) + '=' + str(value) for key, value in parameters.items()])
			else:
				from lib.modules.network import Networker
				query = Networker.linkEncode(parameters, duplicates = duplicates)

		return '%s?%s' % (self.plugin(id = id), query)

	@classmethod
	def commandPlugin(self, action = None, parameters = None, id = GaiaAddon, duplicates = False, call = True, command = None, basic = False):
		if command is None: command = self.command(action = action, parameters = parameters, id = id, duplicates = duplicates, basic = basic)
		if call: command = 'RunPlugin(%s)' % command
		return command

	@classmethod
	def commandContainer(self, action = None, parameters = None, id = GaiaAddon, duplicates = False, call = True, command = None, basic = False):
		if command is None: command = self.command(action = action, parameters = parameters, id = id, duplicates = duplicates, basic = basic)
		if call: command = 'Container.Update(%s)' % command
		return command

	@classmethod
	def addon(self, id = GaiaAddon):
		return xbmcaddon.Addon(id if id else System.GaiaAddon)

	@classmethod
	def info(self, value, id = GaiaAddon):
		return self.addon(id = id).getAddonInfo(Converter.unicode(value))

	@classmethod
	def id(self, id = GaiaAddon):
		return self.addon(id = id).getAddonInfo('id')

	@classmethod
	def name(self, id = GaiaAddon):
		return self.addon(id = id).getAddonInfo('name')

	@classmethod
	def author(self, id = GaiaAddon):
		return self.addon(id = id).getAddonInfo('author')

	@classmethod
	def profile(self, id = GaiaAddon):
		return File.translatePath(self.addon(id = id).getAddonInfo('profile'))

	@classmethod
	def description(self, id = GaiaAddon):
		return self.addon(id = id).getAddonInfo('description')

	@classmethod
	def disclaimer(self, id = GaiaAddon):
		return self.addon(id = id).getAddonInfo('disclaimer')

	@classmethod
	def version(self, id = GaiaAddon):
		return self.addon(id = id).getAddonInfo('version')

	@classmethod
	def versionNumber(self, id = GaiaAddon, version = None):
		try:
			if version is None: version = self.version(id = id)
			version = version.replace('.', '')
			try:
				version = version.split('~')
				try:
					subversion = version[1].replace('alpha', '').replace('beta', '')
					if not subversion: subversion = '1'
				except: subversion = '0'
				version = version[0] + '.' + str(subversion)
			except: pass
			version = float(version)
		except: version = None
		return version if version else 0

	@classmethod
	def versionMajor(self, id = GaiaAddon, version = None):
		try:
			if version is None: version = self.version(id = id)
			return int(str(version).split('.')[0])
		except: return 0

	@classmethod
	def versionMinor(self, id = GaiaAddon, version = None):
		try:
			if version is None: version = self.version(id = id)
			return int(str(version).split('.')[1])
		except: return 0

	@classmethod
	def versionPatch(self, id = GaiaAddon, version = None):
		try:
			if version is None: version = self.version(id = id)
			return int(str(version).split('.')[2])
		except: return 0

	@classmethod
	def versionDeveloper(self, id = GaiaAddon):
		return self.version(id = id) == '9.9.9'

	@classmethod
	def versionInfo(self, update = False):
		newFull = self.version()
		newNumber = self.versionNumber(version = newFull)
		newMajor = self.versionMajor(version = newFull)
		newMinor = self.versionMinor(version = newFull)
		newPatch = self.versionPatch(version = newFull)

		oldFull = Settings.getString('internal.version')
		oldNumber = self.versionNumber(version = oldFull)
		oldMajor = self.versionMajor(version = oldFull)
		oldMinor = self.versionMinor(version = oldFull)
		oldPatch = self.versionPatch(version = oldFull)

		change = (not newFull == oldFull)
		changeMajor = (not newMajor == oldMajor)
		changeMinor = (not newMinor == oldMinor) or changeMajor
		changePatch = (not newPatch == oldPatch) or changeMinor

		if update: Settings.set('internal.version', newFull)

		return {
			'new' : {
				'full' : newFull,
				'number' : newNumber,
				'major' : newMajor,
				'minor' : newMinor,
				'patch' : newPatch,
			},
			'old' : {
				'full' : oldFull,
				'number' : oldNumber,
				'major' : oldMajor,
				'minor' : oldMinor,
				'patch' : oldPatch,
			},
			'change' : {
				'full' : change,
				'major' : changeMajor,
				'minor' : changeMinor,
				'patch' : changePatch,
			},
		}

	@classmethod
	def infoLabel(self, value):
		return xbmc.getInfoLabel(value)

	# Checks if an addon is installed
	@classmethod
	def installed(self, id = GaiaAddon):
		try:
			addon = xbmcaddon.Addon(id)
			id = addon.getAddonInfo('id')
			return not id == None and not id == ''
		except:
			return False

	@classmethod
	def execute(self, command):
		return xbmc.executebuiltin(command)

	@classmethod
	def executeScript(self, script, parameters = None):
		command = 'RunScript(' + script
		if parameters:
			items = []
			if Tools.isDictionary(parameters):
				for key, value in parameters.items():
					items.append(str(key) + '=' + str(value))
			for item in items:
				command += ',' + str(item)
		command += ')'
		return self.execute(command)

	@classmethod
	def stopScript(self, script):
		return self.execute('StopScript(%s)' % script)

	@classmethod
	def executePlugin(self, action = None, parameters = None, command = None):
		return self.execute(self.commandPlugin(action = action, parameters = parameters, command = command, call = True))

	@classmethod
	def executeContainer(self, action = None, parameters = None, command = None):
		return self.execute(self.commandContainer(action = action, parameters = parameters, command = command, call = True))

	# Either query OR all the other parameters.
	@classmethod
	def executeJson(self, query = None, method = None, parameters = None, version = '2.0', id = 1, addon = False, decode = True):
		if query is None:
			if parameters == None: parameters = {}
			if addon == True: parameters['addonid'] = self.id()
			elif addon: parameters['addonid'] = addon
			query = {}
			query['jsonrpc'] = version
			query['id'] = id
			query['method'] = method
			query['params'] = parameters
			query = Converter.jsonTo(query)
		result = xbmc.executeJSONRPC(query)
		if decode: result = Converter.jsonFrom(result)
		return result

	# sleep for n seconds. Sometimes causes the new window not to show (only in the background). Sleeping seems to solve the problem.
	@classmethod
	def window(self, action = None, parameters = {}, command = None, sleep = None, refresh = False):
		if command == None:
			if action: parameters['action'] = action
			if not parameters == None and not parameters == '' and not parameters == {}:
				if not Tools.isString(parameters):
					from lib.modules.network import Networker
					parameters = network.Networker.linkEncode(parameters)
				if not parameters.startswith('?'):
					parameters = '?' + parameters
			else:
				parameters = ''
			command = '%s%s/%s' % (System.PluginPrefix, System.GaiaAddon, parameters)
		result = System.execute('ActivateWindow(10025,%s,return)' % command) # When launched externally (eg: from shortcut widgets).
		System.execute('Container.Update(%s)' % command)
		if refresh: System.execute('Container.Refresh')
		if sleep: Time.sleep(sleep)
		return result

	@classmethod
	def temporary(self, directory = None, file = None, gaia = True, make = True, clear = False):
		path = File.translatePath('special://temp/')
		if gaia: path = os.path.join(path, System.name().lower())
		if directory: path = os.path.join(path, directory)
		if clear: File.deleteDirectory(path, force = True)
		if make: File.makeDirectory(path)
		if file: path = os.path.join(path, file)
		return path

	@classmethod
	def temporaryRandom(self, directory = None, extension = 'dat', gaia = True, make = True, clear = False):
		if extension and not extension == '' and not extension.startswith('.'):
			extension = '.' + extension
		file = Hash.random() + extension
		path = self.temporary(directory = directory, file = file, gaia = gaia, make = make, clear = clear)
		while File.exists(path):
			file = Hash.random() + extension
			path = self.temporary(directory = directory, file = file, gaia = gaia, make = make, clear = clear)
		return path

	@classmethod
	def temporaryClear(self):
		return File.deleteDirectory(self.temporary(make = False))

	@classmethod
	def openLink(self, link, popup = True, popupForce = False, front = True):
		from lib.modules import interface # Circular import.
		interface.Loader.show() # Needs some time to load. Show busy.
		try:
			success = False
			if sys.platform == 'darwin': # OS X
				try:
					import subprocess
					subprocess.Popen(['open', link])
					success = True
				except: pass
			if not success:
				import webbrowser
				webbrowser.open(link, autoraise = front, new = 2) # new = 2 opens new tab.
		except:
			popupForce = True
		if popupForce:
			from lib.modules import clipboard
			clipboard.Clipboard.copyLink(link, popup)
		interface.Loader.hide()

	@classmethod
	def versionDataGet(self):
		try: return Converter.jsonFrom(self.windowPropertyGet(System.PropertyVersion))
		except: return None

	@classmethod
	def versionDataSet(self, data):
		self.windowPropertySet(System.PropertyVersion, Converter.jsonTo(data))

	@classmethod
	def versionDataClear(self):
		self.windowPropertyClear(System.PropertyVersion)

	@classmethod
	def _observe(self):
		xbmc.Monitor().waitForAbort()
		os._exit(1)

	@classmethod
	def observe(self):
		# Observes when Kodi closes and exits.
		# Reduces the chances the Kodi freezes on exit (might still take a few seconds).
		value = self.windowPropertyGet(System.PropertyObserve)
		if not value:
			self.windowPropertySet(System.PropertyObserve, str(Time.timestamp()))
			thread = threading.Thread(target = self._observe)
			thread.start()

	@classmethod
	def launchAddon(self, wait = True):
		System.execute('RunAddon(%s)' % self.id())
		if wait:
			for i in range(0, 150):
				if self.infoLabel('Container.PluginName') == self.GaiaAddon:
					try: items = int(self.infoLabel('Container.NumItems'))
					except: items = 0
					# Check NumItems, because the addon might have been launched, but the container/directory is still loading.
					# The container must be done loading, otherwise if a container update is executed right afterwards, the main menu items and the container update items might be mixed and displayed as the same list.
					if items > 0: break
				Time.sleep(0.2)

	@classmethod
	def launchDataGet(self):
		try: return Converter.jsonFrom(self.windowPropertyGet(System.PropertyLaunch))
		except: return None

	@classmethod
	def launchDataSet(self, data):
		self.windowPropertySet(System.PropertyLaunch, Converter.jsonTo(data))

	@classmethod
	def launchDataClear(self):
		self.windowPropertyClear(System.PropertyLaunch)

	@classmethod
	def launch(self, hidden = False):
		observe = False
		data = self.launchDataGet()
		if data:
			if Converter.boolean(self.windowPropertyGet(System.PropertyInitial)): return False
			observe = True
		else:
			self.launchDataSet({'progress' : 0, 'status' : None})
		thread = threading.Thread(target = self._launch, kwargs = {'hidden' : hidden, 'observe' : observe})
		thread.start()
		return True

	@classmethod
	def _launch(self, hidden = False, observe = False):
		# Sequential non-threaded and parallel threaded execution seems to take more or less the same time.
		# Sometimes sequential execution is actually faster.
		# Keep sequential execution for now, since it is probably more robust with less mututal exclusion problems.
		#self.tSequential = False
		self.tSequential = True

		self.tSplash = None
		self.tThreads = []
		self.tStatus = ['Initializing Gaia Launch']
		self.tProgress = 1

		def _launchObserve():
			try: self.tSplash.update(progress = 0, status = self.tStatus[0]) # Make sure to intialize to 0, otherwise (due to optimization), the progress is not initially updated in _launchObserve.
			except: pass
			while True:
				data = self.launchDataGet()
				if not data: break
				progress = data['progress']
				try: self.tSplash.update(progress = progress, status = data['status'])
				except:
					try: self.tSplash.update(progress = progress)
					except: pass
				if progress >= 100: break
				Time.sleep(0.5)
			_launchFinalize()

		def _launchProgress(increase = 0):
			if self.tSequential:
				try: status = self.tStatus[-1]
				except: pass
			else:
				index = 0
				for i in range(len(self.tThreads)):
					index = i
					if self.tThreads[i].is_alive(): break
				try: status = self.tStatus[index]
				except: status = self.tStatus[0]
			self.tProgress += increase
			self.launchDataSet({'progress' : self.tProgress, 'status' : status})
			try: self.tSplash.update(progress = self.tProgress, status = status)
			except:
				try: self.tSplash.update(progress = self.tProgress)
				except: pass

		def _launchExecute(_progress, _function, **kwargs):
			_launchProgress(_progress)
			if _function: _function(**kwargs)

		def _launchAdd(_progress, _status, _function, **kwargs):
			self.tStatus.append(_status)
			if self.tSequential:
				 _launchExecute(_progress, _function, **kwargs)
			else:
				thread = threading.Thread(target = _launchExecute, args = (_progress, _function), kwargs = kwargs)
				self.tThreads.append(thread)
				thread.start()

		def _launchFinalize():
			from lib.modules.interface import Splash, Loader
			from lib.modules.window import WindowIntro, WindowAttribution

			version = self.versionDataGet()
			changed = False

			self.tProgress = 99
			self.tStatus = ['Launching Gaia']
			try: self.tSplash.update(progress = self.tProgress, status = self.tStatus[0])
			except: pass
			if not hidden: self.windowPropertySet(System.PropertyInitial, True)

			Loader.enable()

			# Legal Disclaimer
			#gaiaremove - gaiaremove - gaiaremove - enable again for stable release.
			'''if not hidden:
				from lib.modules.interface import Legal
				if not Legal.initialized():
					self.tStatus = ['Configuring Gaia']
					try: self.tSplash.update(progress = self.tProgress, status = self.tStatus[0])
					except: pass
				legal = Legal.launchInitial(exit = False)
				if legal is False:
					self.tProgress = 100
					self.tStatus = ['Exiting Gaia']
					try: self.tSplash.update(progress = self.tProgress, status = self.tStatus[0])
					except: pass
					_launchProgress() # Make sure 100% is written to the global variable for the observer.
					self.launchDataClear()
					Splash.popupClose()
					System.exit()
					return False
				elif legal is True:
					changed = True

			# Initial Launch
			if not hidden:
				from lib.modules.settings import Wizard
				if Wizard().launchInitial(): changed = True'''

			self.tProgress = 100
			self.tStatus = ['Launching Gaia']
			try: self.tSplash.update(progress = self.tProgress, status = self.tStatus[0])
			except: pass
			_launchProgress() # Make sure 100% is written to the global variable for the observer.

			# Updates
			Extensions.versionCheck(wait = False)

			# Attribution
			# Show either on version change or 1% of the time.
			attribution = False
			if not hidden and Settings.getBoolean('general.launch.attribution'):
				if version['change']['minor'] or Math.randomProbability(0.01):
					def splashClose():
						Time.sleep(0.5)
						Splash.popupClose()
					if WindowIntro.visible(): Time.sleep(WindowIntro.duration() * 1.2)
					else: Time.sleep(1)
					attribution = True
					thread = threading.Thread(target = splashClose)
					thread.start()
					WindowAttribution.show()

			# Announcement
			# Do not show if attribution window is showing.
			if not hidden:
				def announcements():
					interval = 0.5
					Time.sleep(interval)
					for i in range(int((WindowAttribution.Duration * 1.1) / interval)): # Wait until the the attribution is closed.
						if not WindowAttribution.visible(): break
						Time.sleep(interval)
					Announcements.show(wait = False, sleep = True)
				thread = threading.Thread(target = announcements)
				thread.start()

			# Splash
			Splash.popupClose()

			# Statistics
			# Put last, in case video pops up.
			# Don't share statistics anymore, even if the user has the setting enabled.
			# Statistics.share(wait = False)

			# Backup - Export
			if hidden or changed:
				def _launchBackup():
					Time.sleep(2)
					Backup.automaticImport() # Check again, in case the initialization corrupted the settings.
					Backup.automaticExport()
				thread = threading.Thread(target = _launchBackup)
				thread.start()

		# Splash
		from lib.modules.interface import Splash, Loader
		if not hidden:
			if not Splash.loader(): Loader.disable()
			self.tSplash = Splash.popup(time = None, wait = False)

		# Only observe progress if the actually code execution happens from service.py.
		if observe:
			thread = threading.Thread(target = _launchObserve)
			thread.start()
			return

		_launchProgress(2) # 2%

		if not self.tSequential:
			# For some reason when using threads that import the external Cloudflare library, the loading screen gets stuck.
			# Import before starting the threads.
			# Update: is this still the case? Some other bugsin this function (that are fixed now) might have actually caused the problem.
			from lib.modules.cloudflare import Cloudflare
			Cloudflare.prepare()

		self.tStatus = ['Initializing Settings Cache']
		Settings.cacheInitialize() # Load into cache in order to not get delays when calling functions below.
		_launchProgress(8) # 10%

		# Version
		self.tStatus = ['Initializing Settings Version']
		version = self.versionInfo(update = True)
		self.versionDataSet(version)
		_launchProgress(1) # 11%

		# gaiaremove
		# Can be removed in later versions.
		if version['old']['number'] < 600 and version['new']['number'] >= 600:
			try: Settings.clear()
			except: Logger.error()

			try: Backup.automaticClear()
			except: Logger.error()

			try:
				from lib.modules.cache import Cache
				Cache()._deleteFile()
			except: Logger.error()

			try:
				from lib.modules.metacache import Metacache
				Metacache.clear()
			except: Logger.error()

			try:
				from lib.modules.history import History
				History()._deleteFile()
			except: Logger.error()
		_launchProgress(4) # 15%

		# Backup - Import
		self.tStatus = ['Initializing Settings Backup']
		Backup.automaticImport()
		_launchProgress(5) # 20%

		# Force Kodi to load the settings into memory.
		self.tStatus = ['Initializing Settings Cache']
		Settings.set('internal.dummy', True)
		_launchProgress(5) # 25%

		self.tStatus = []

		# Initial Launch
		_launchAdd(1, 'Initializing Launch Data', self.launchInitial) # 26%

		# Providers
		from lib.providers.core.manager import Manager
		_launchAdd(15, 'Initializing Provider Structure', Manager.check, progress = False, wait = True) # 41%

		# Audio
		_launchAdd(1, 'Initializing Startup Audio', Audio.startup) # 42%

		# Ambient Lights
		_launchAdd(1, 'Initializing Ambient Lights', Lightpack().launch, execution = Lightpack.ExecutionGaia) # 43%

		# Clear Temporary
		_launchAdd(1, 'Initializing Temporary Directory', System.temporaryClear) # 44%

		# Local Library Update
		from lib.modules.library import Library
		_launchAdd(5, 'Initializing Library Update', Library.service, gaia = True) # 49%

		# Promotions
		_launchAdd(2, 'Initializing New Promotions', Promotions.update, refresh = False) # 51%

		# Window
		if version['change']['full']:
			from lib.modules.window import Window
			_launchAdd(3, 'Initializing Custom Windows', Window.clean) # 54%
		else: _launchProgress(3)

		# VPN
		from lib.modules.vpn import Vpn
		_launchAdd(5, 'Initializing VPN Service', Vpn().launch, execution = Vpn.ExecutionGaia) # 59%

		# Cloudflare
		from lib.modules.cloudflare import Cloudflare
		_launchAdd(5, 'Initializing Cloudflare Bypasser', Cloudflare.initialize) # 64%

		# Elementum & Quasar
		_launchAdd(5, 'Initializing Elementum Handler', Elementum.connect, install = False, background = True, wait = False) # 69%
		_launchAdd(5, 'Initializing Quasar Handler', Quasar.connect, install = False, background = True, wait = False) # 74%

		# Premium
		from lib import debrid
		from lib.modules.orionoid import Orionoid
		_launchAdd(3, 'Initializing Orion Service', lambda : Orionoid().initialize(external = True)) # 77%
		_launchAdd(3, 'Initializing Premiumize Service', debrid.premiumize.Core().initialize) # 80%
		_launchAdd(3, 'Initializing Premiumize Service', debrid.premiumize.Core().deleteLaunch) # 83%
		_launchAdd(3, 'Initializing OffCloud Service', debrid.offcloud.Core().deleteLaunch) # 86%
		_launchAdd(3, 'Initializing RealDebrid Service', debrid.realdebrid.Core().deleteLaunch) # 89%

		# External
		def _launchExternal():
			Resolver.authenticationCheck()
		_launchAdd(5, 'Initializing External Resolvers', _launchExternal) # 94%

		# Copy the select theme background as fanart to the root folder.
		# Ensures that the selected theme also shows outside the addon.
		# Requires first a Gaia restart (to replace the old fanart) and then a Kodi restart (to load the new fanart, since the old one was still in memory).
		def _launchFanart():
			from lib.modules.theme import Theme
			fanartTo = File.joinPath(System.path(), 'fanart.jpg')
			Thumbnail.delete(fanartTo) # Delete from cache
			File.delete(fanartTo) # Delete old fanart
			fanartFrom = Theme.fanart()
			if not fanartFrom == None:
				fanartTo = File.joinPath(System.path(), 'fanart.jpg')
				File.copy(fanartFrom, fanartTo, overwrite = True)
		_launchAdd(4, 'Initializing Fanart Files', _launchFanart) # 98%

		# Clean Old Settings
		# Place this last, since it can take very long, and we do not want to show this status from the start until close to the end of the progress.
		# Do not do this here, but rather in service.py, since there is less file I/O interference than here.
		#_launchAdd(12, 'Cleaning Old Settings', Settings.clean) # 99%

		_launchAdd(1, 'Launching Gaia', None) # 99%

		[thread.join() for thread in self.tThreads]
		_launchFinalize()

	@classmethod
	def launchInitial(self):
		if not Settings.getBoolean('internal.initial.launch'):
			# Check Hardware
			# Leave for now, since it is adjusted by the configurations wizard. If this is enabled again, make sure to not show it on every launch, only the first.
			'''if Hardware.slow():
				from lib.modules import interface
				if interface.Dialog.option(title = 33467, message = 33700, labelConfirm = 33011, labelDeny = 33701):
					Settings.launch()'''
			Settings.set('internal.initial.launch', False, background = True)

	@classmethod
	def launchAutomatic(self):
		if Settings.getBoolean('general.launch.automatic'):
			self.execute('RunAddon(plugin.video.gaia)')

	@classmethod
	def _automaticIdentifier(self, identifier):
		identifier = identifier.upper()
		return ('#[%s]' % identifier, '#[/%s]' % identifier)

	# Checks if a command is in the Kodi startup script.
	@classmethod
	def automaticContains(self, identifier):
		if xbmcvfs.exists(System.StartupScript):
			identifiers = self._automaticIdentifier(identifier)
			file = xbmcvfs.File(System.StartupScript, 'r')
			data = file.read()
			file.close()
			if identifiers[0] in data and identifiers[1] in data:
				return True
		return False

	# Inserts a command into the Kodi startup script.
	@classmethod
	def automaticInsert(self, identifier, command):
		identifiers = self._automaticIdentifier(identifier)
		data = ''
		contains = False

		if xbmcvfs.exists(System.StartupScript):
			file = xbmcvfs.File(System.StartupScript, 'r')
			data = file.read()
			file.close()
			if identifiers[0] in data and identifiers[1] in data:
				contains = True

		if contains:
			return False
		else:
			id = self.id()
			module = identifier.lower() + 'xbmc'
			command = command.replace(System.PluginPrefix, '').replace(id, '')
			while command.startswith('/') or command.startswith('?'):
				command = command[1:]
			command = System.PluginPrefix + id + '/?' + command
			content = '%s\n%s\nimport xbmc as %s\nif %s.getCondVisibility("System.HasAddon(%s)") == 1: %s.executebuiltin("RunPlugin(%s)")\n%s' % (data, identifiers[0], module, module, id, module, command, identifiers[1])
			file = xbmcvfs.File(System.StartupScript, 'w')
			file.write(content)
			file.close()
			return True

	# Removes a command from the Kodi startup script.
	@classmethod
	def automaticRemove(self, identifier):
		identifiers = self._automaticIdentifier(identifier)
		data = ''
		contains = False
		indexStart = 0
		indexEnd = 0
		if xbmcvfs.exists(System.StartupScript):
			file = xbmcvfs.File(System.StartupScript, 'r')
			data = file.read()
			file.close()
			if data and not data == '':
				data += '\n'
				indexStart = data.find(identifiers[0])
				if indexStart >= 0:
					indexEnd = data.find(identifiers[1]) + len(identifiers[1])
					contains = True

		if contains:
			data = data[:indexStart] + data[indexEnd:]
			file = xbmcvfs.File(System.StartupScript, 'w')
			file.write(data)
			file.close()
			return True
		else:
			return False

	#	[
	#		['title' : 'Category 1', 'items' : [{'title' : 'Name 1', 'value' : 'Value 1', 'link' : True}, {'title' : 'Name 2', 'value' : 'Value 2'}]]
	#		['title' : 'Category 2', 'items' : [{'title' : 'Name 3', 'value' : 'Value 3', 'link' : False}, {'title' : 'Name 4', 'value' : 'Value 4'}]]
	#	]
	@classmethod
	def information(self):
		from lib.modules import convert

		items = []

		# System
		system = self.informationSystem()
		subitems = []
		subitems.append({'title' : 'Name', 'value' : system['name']})
		subitems.append({'title' : 'Version', 'value' : system['version']})
		if not system['codename'] == None: subitems.append({'title' : 'Codename', 'value' : system['codename']})
		subitems.append({'title' : 'Family', 'value' : system['family']})
		subitems.append({'title' : 'Bits', 'value' : system['bits']})
		subitems.append({'title' : 'Architecture', 'value' : system['architecture']})
		items.append({'title' : 'System', 'items' : subitems})

		# Python
		system = self.informationPython()
		subitems = []
		subitems.append({'title' : 'Build', 'value' : system['build']})
		subitems.append({'title' : 'Version', 'value' : system['version']})
		subitems.append({'title' : 'Implementation', 'value' : system['implementation']})
		items.append({'title' : 'Python', 'items' : subitems})

		# Kodi
		system = self.informationKodi()
		subitems = []
		subitems.append({'title' : 'Name', 'value' : system['name']})
		subitems.append({'title' : 'Build', 'value' : system['build']})
		subitems.append({'title' : 'Version', 'value' : system['version']})
		subitems.append({'title' : 'Date', 'value' : system['date']})
		items.append({'title' : 'Kodi', 'items' : subitems})

		# Addon
		system = self.informationAddon()
		subitems = []
		subitems.append({'title' : 'Name', 'value' : system['name']})
		subitems.append({'title' : 'Author', 'value' : system['author']})
		subitems.append({'title' : 'Version', 'value' : system['version']})
		items.append({'title' : 'Addon', 'items' : subitems})

		# Usage
		system = self.informationUsage()
		subitems = []
		subitems.append({'title' : 'Processor', 'value' : informationUsage['processor']['label']['description']})
		subitems.append({'title' : 'Memory', 'value' : informationUsage['memory']['label']['description']})
		subitems.append({'title' : 'Storage', 'value' : informationUsage['storage']['label']['description']})
		items.append({'title' : 'Usage', 'items' : subitems})

		from lib.modules import interface
		return interface.Dialog.information(title = 33467, items = items)

	@classmethod
	def informationLoad(self, values = None):
		# Takes some time to retrieve.
		# If not, Kodi sometimes just returns "Busy" as the value.
		if values is None: values = ['System.CpuUsage', 'System.Memory(free)', 'System.Memory(total)', 'System.FreeSpace', 'System.TotalSpace', 'System.BuildVersion', 'System.BuildDate', 'System.Uptime']
		for value in values:
			counter = 0
			while 'busy' in System.infoLabel(value).lower():
				counter += 1
				if counter > 100: break
				Time.sleep(0.1)

	@classmethod
	def informationSystem(self):
		import platform
		system = platform.system().capitalize()
		version = platform.release().capitalize()

		distribution = platform.dist()

		try:
			name = distribution[0].replace('"', '') # "elementary"
			if name == 'elementary os': name = 'elementary'
		except:
			name = ''

		distributionHas = not distribution == None and not distribution[0] == None and not distribution[0] == ''
		distributionName = name.capitalize() if distributionHas else None
		distributionVersion = distribution[1].capitalize() if distributionHas and not distribution[1] == None and not distribution[1] == '' else None
		distributionCodename = distribution[2].capitalize() if distributionHas and not distribution[2] == None and not distribution[2] == '' else None

		# Manually check for Android
		if system == 'Linux' and distributionName == None:
			import subprocess
			id = None
			if 'ANDROID_ARGUMENT' in os.environ:
				id = True
			if id == None or id == '':
				try: id = subprocess.Popen('getprop ril.serialnumber'.split(), stdout = subprocess.PIPE).communicate()[0]
				except: pass
			if id == None or id == '':
				try: id = subprocess.Popen('getprop ro.serialno'.split(), stdout = subprocess.PIPE).communicate()[0]
				except: pass
			if id == None or id == '':
				try: id = subprocess.Popen('getprop sys.serialnumber'.split(), stdout = subprocess.PIPE).communicate()[0]
				except: pass
			if id == None or id == '':
				try: id = subprocess.Popen('getprop gsm.sn1'.split(), stdout = subprocess.PIPE).communicate()[0]
				except: pass
			if not id == None and not id == '':
				distributionName = 'Android'
				distributionHas = True

		# Structure used by Statistics.
		return {
			'family' : system,
			'name' : distributionName if distributionHas else system,
			'codename' : distributionCodename if distributionHas else None,
			'version' : distributionVersion if distributionHas else version,
			'architecture' : platform.processor(),
			'bits' : '64 bit' if '64' in platform.processor() else '32 bit',
		}

	@classmethod
	def informationUsage(self):
		def _sizeExtract(size):
			data = size.lower()
			size = 0
			if 'mb' in data:
				try: size = float(re.search('\d*', data).group(0)) * 1048576
				except: pass
			elif 'gb' in data:
				try: size = float(re.search('\d*', data).group(0)) * 1073741824
				except: pass
			elif 'tb' in data:
				try: size = float(re.search('\d*', data).group(0)) * 1099511627776
				except: pass
			return size

		def _sizeLabel(size):
			return ('%0.1f' % (size / 1073741824)) + ' GB'

		def _percentageLabel(percentage):
			return str(int(percentage * 100)) + '%'

		self.informationLoad(['System.CpuUsage', 'System.Memory(free)', 'System.Memory(total)', 'System.FreeSpace', 'System.TotalSpace'])

		# System
		processorLabel = System.infoLabel('System.CpuUsage')
		processorTotal = 1.0
		processorFree = 0.0
		processorUsed = 0.0
		processorCores = 0
		try:
			usage = re.findall(':\s*(.*?)%', processorLabel)
			processorCores = len(usage)
			average = sum(float(i) for i in usage) / processorCores
			processorFree = int(100 - average) / 100.0
			processorUsed = processorTotal - processorFree
		except: pass

		memoryTotal = _sizeExtract(System.infoLabel('System.Memory(total)'))
		memoryFree = _sizeExtract(System.infoLabel('System.Memory(free)'))
		memoryUsed = memoryTotal - memoryFree

		storageTotal = _sizeExtract(System.infoLabel('System.TotalSpace'))
		storageFree = _sizeExtract(System.infoLabel('System.FreeSpace'))
		storageUsed = storageTotal - storageFree

		return {
			'processor' : {
				'total' : processorTotal,
				'used' : processorUsed,
				'free' : processorFree,
				'cores' : processorCores,
				'label' : {
					'total' : _percentageLabel(processorTotal),
					'used' : _percentageLabel(processorUsed),
					'free' : _percentageLabel(processorFree),
					'cores' : str(processorCores) + ' cores',
					'description' : _percentageLabel(processorFree) + ' free of ' + str(processorCores) + ' cores',
				},
			},
			'memory' : {
				'total' : memoryTotal,
				'used' : memoryUsed,
				'free' : memoryFree,
				'label' : {
					'total' : _sizeLabel(memoryTotal),
					'used' : _sizeLabel(memoryUsed),
					'free' : _sizeLabel(memoryFree),
					'description' : _sizeLabel(memoryFree) + ' free of ' + _sizeLabel(memoryTotal),
				},
			},
			'storage' : {
				'total' : storageTotal,
				'used' : storageUsed,
				'free' : storageFree,
				'label' : {
					'total' : _sizeLabel(storageTotal),
					'used' : _sizeLabel(storageUsed),
					'free' : _sizeLabel(storageFree),
					'description' : _sizeLabel(storageFree) + ' free of ' + _sizeLabel(storageTotal),
				},
			},
		}

	@classmethod
	def informationPython(self):
		import platform

		build = platform.python_build()
		if build: build = '%s (%s)' % build
		else: build = 'Unknown'

		implementation = platform.python_implementation()
		if not implementation: implementation = 'Unknown'
		compiler = platform.python_compiler()
		if compiler: implementation += ' (%s)' % compiler

		return {
			'version' : platform.python_version(),
			'build' : build,
			'implementation' : implementation,
		}

	@classmethod
	def informationKodi(self):
		self.informationLoad(['System.FriendlyName', 'System.BuildVersion', 'System.BuildDate', 'System.Uptime'])

		build = 'Official'
		path = File.translatePath('special://xbmc').lower() + ' ' + File.translatePath('special://logpath').lower()
		for i in ['CoreELEC', 'LibreELEC', 'OpenELEC', 'XBian', 'RasPlex', 'Nodi', 'SPMC', 'OSMC', 'CEMC', 'FTMC', 'MrMC', 'MyGica']:
			if i.lower() in path:
				build = i
				break

		name = System.infoLabel('System.FriendlyName')

		version = System.infoLabel('System.BuildVersion')
		index = version.find(' ')
		if index >= 0: version = version[:index].strip()

		date = System.infoLabel('System.BuildDate')
		uptime = System.infoLabel('System.Uptime')

		# Structure used by Statistics.
		return {
			'name' : name,
			'build' : build,
			'version' : version,
			'date' : date,
			'uptime' : uptime,
		}

	@classmethod
	def informationAddon(self):
		return {
			'name' : self.name(),
			'author' : self.author(),
			'version' : self.version(),
		}

	@classmethod
	def manager(self):
		self.execute('ActivateWindow(systeminfo)')

	@classmethod
	def clean(self, confirm = True):
		from lib.modules import interface
		if confirm:
			choice = interface.Dialog.option(title = 33468, message = 33469)
		else:
			choice = True
		if choice:
			path = File.translate(File.PrefixSpecial + 'masterprofile/addon_data/' + System.id())
			File.deleteDirectory(path = path, force = True)
			self.temporaryClear()
			if File.existsDirectory(path):
				interface.Dialog.confirm(title = 33468, message = 33916)
			else:
				interface.Dialog.notification(title = 33468, message = 35538, icon = interface.Dialog.IconSuccess)

class Screen(object):

	Ratio4x3  =	'4x3'
	Ratio16x9 =	'16x9'
	Ratio20x9 =	'20x9'
	Ratios = (
		(Ratio4x3,  1.33333333),
		(Ratio16x9, 1.77777777),
		(Ratio20x9, 2.22222222),
	)

	@classmethod
	def dimension(self):
		return [self.width(), self.height()]

	@classmethod
	def width(self):
		try: return xbmcgui.getScreenWidth()
		except: return int(System.infoLabel('System.ScreenWidth')) # Older Kodi versions.

	@classmethod
	def height(self):
		try: return xbmcgui.getScreenHeight()
		except: return int(System.infoLabel('System.ScreenHeight')) # Older Kodi versions.

	@classmethod
	def ratio(self, closest = False):
		ratio = self.width() / float(self.height())
		if closest: ratio = Screen.Ratios[min(range(len(Screen.Ratios)), key = lambda i : abs(Screen.Ratios[i][1] - ratio))]
		return ratio

# NB: Make this a global var and not a class var of Settings.
# NB: Otherwise Kodi complaints about xbmcaddon.Addon being left in memory.
SettingsAddon = xbmcaddon.Addon(System.GaiaAddon)

class Settings(object):

	Database = 'settings'
	Lock = threading.Lock()
	Busy = 0

	LevelBasic = 0
	LevelStandard = 1
	LevelAdvanced = 2
	LevelExpert = 3
	LevelInternal = 4

	ParameterDefault = 'default'
	ParameterValue = 'value'

	PropertyCacheInitialized = 'GaiaSettingsCacheInitialized'
	PropertyCacheEnabled = 'GaiaSettingsCacheEnabled'
	PropertyCacheTimeUser = 'GaiaSettingsCacheTimeUser'
	PropertyCacheTimeMain = 'GaiaSettingsCacheTimeMain'
	PropertyCacheDataUser = 'GaiaSettingsCacheDataUser'
	PropertyCacheDataMain = 'GaiaSettingsCacheDataMain'

	CategoryGeneral = 'general'
	CategoryInterface = 'interface'
	CategoryNavigation = 'navigation'
	CategoryMetadata = 'metadata'
	CategoryAccount = 'account'
	CategoryPremium = 'premium'
	CategoryProvider = 'provider'
	CategoryScrape = 'scrape'
	CategoryStream = 'stream'
	CategoryPlayback = 'playback'
	CategorySubtitle = 'subtitle'
	CategoryLibrary = 'library'
	CategoryDownload = 'download'
	CategoryNetwork = 'network'
	CategoryAmbilight = 'ambilight'

	CacheInitialized = False
	CacheEnabled = False
	CacheTimeMain = None
	CacheDataMain = None
	CacheValuesMain = None
	CacheTimeUser = None
	CacheDataUser = None
	CacheValuesUser = None

	DataLabel = 'label'
	DataValue = 'value'

	# Also check downloader.py.
	PathDefault = 'Default'
	Paths = {
		'download.manual.location.combined' 		: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Manual/',
		'download.manual.location.movie'			: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Manual/Movies/',
		'download.manual.location.show'				: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Manual/Shows/',
		'download.manual.location.documentary'		: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Manual/Documentaries/',
		'download.manual.location.short'			: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Manual/Shorts/',
		'download.manual.location.other'			: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Manual/Other/',

		'download.cache.location.combined'			: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Cache/',
		'download.cache.location.movie'				: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Cache/Movies/',
		'download.cache.location.show'				: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Cache/Shows/',
		'download.cache.location.documentary'		: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Cache/Documentaries/',
		'download.cache.location.short'				: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Cache/Shorts/',
		'download.cache.location.other'				: 'special://userdata/addon_data/plugin.video.gaia/Downloads/Cache/Other/',

		'library.location.combined'					: 'special://userdata/addon_data/plugin.video.gaia/Library/',
		'library.location.movie'					: 'special://userdata/addon_data/plugin.video.gaia/Library/Movies/',
		'library.location.show'						: 'special://userdata/addon_data/plugin.video.gaia/Library/Shows/',
		'library.location.documentary'				: 'special://userdata/addon_data/plugin.video.gaia/Library/Documentaries/',
		'library.location.short'					: 'special://userdata/addon_data/plugin.video.gaia/Library/Shorts/',
	}

	@classmethod
	def _database(self):
		from lib.modules.database import Database
		return Database.instance(name = Settings.Database, create = '''
			CREATE TABLE IF NOT EXISTS %s
			(
				id TEXT UNIQUE,
				data TEXT
			);
			'''
		)

	@classmethod
	def level(self, default = LevelBasic):
		try:
			path = File.joinPath('special://userdata', 'guisettings.xml')
			data = File.readNow(path)
			level = Regex.extract(data = data, expression = '<settinglevel>(.*?)<\/settinglevel>')
			level = int(level)
		except:
			level = default
			Logger.error('Cannot read the settings level')
		return level

	# NB: Kodi does not internally update this value if the file is written to, and the value is reset if Kodi restarts.
	# Do not use this function to permanently set the settings level through Python - it won't work.
	@classmethod
	def levelSet(self, level):
		try:
			path = File.joinPath('special://userdata', 'guisettings.xml')
			data = File.readNow(path)
			data = Regex.replace(data = data, expression = '<settinglevel>(.*?)<\/settinglevel>', replacement = str(level), group = 1)
			File.writeNow(path, data)
			return True
		except:
			Logger.error('Cannot write the settings level')
			return False

	# This function is not very reliable.
	# Sometimes when writing the updated settings to file, the file is unchanged.
	# This happens both with Kodi's file I/O and Python's native file I/O.
	# It might be caused because Kodi internally writes the settings to file, and then overwriting the data that was previously wirtten from theis function.
	# We try to write multiple times in a thread, sleeping in between, until the file size has changed or 2.5 seconds have passed.
	# Hence, if this function was not able to write to file during this time, the old settings will remain in the file. On the next launch this will be retried.
	@classmethod
	def clean(self, reload = False, retry = True):
		dataMain = self.cacheDataMain()
		dataUser = self.cacheDataUser()

		idsMain = Regex.extract(data = dataMain, expression = 'id\s*=\s*"(.*?)"', group = None, all = True)
		idsUser = Regex.extract(data = dataUser, expression = '(?:^|[\r\n]+)(.*?id\s*=\s*"(.*?)".*?(?:[\r\n]+|$))', group = None, all = True)

		change = False
		for id in idsUser:
			if not id[1] in idsMain:
				dataUser = dataUser.replace(id[0], '')
				change = True

		def _write(data):
			path = self.pathProfile()
			size = File.size(path)
			for i in range(5):
				File.writeNow(path, data)
				Time.sleep(0.5)
				if not File.size(path) == size: break

		if change:
			# File does not change in Kodi 19 if writeNow() is used, probably due to caching.
			# Sometimes writeNow() seems to work? But just stick with writeNative() to be sure.
			if retry:
				thread = threading.Thread(target = _write, args = (dataUser,))
				thread.start()
			else:
				File.writeNow(self.pathProfile(), dataUser)

			if reload: self.cacheClear()

	@classmethod
	def path(self, id):
		path = self.get(id)
		if path == Settings.PathDefault or not path or path.strip() == '': path = Settings.Paths[id]
		return path

	@classmethod
	def pathAddon(self):
		return File.joinPath(System.path(), 'resources', 'settings.xml')

	@classmethod
	def pathProfile(self):
		return File.joinPath(System.profile(), 'settings.xml')

	@classmethod
	def clear(self):
		File.delete(File.joinPath(System.profile(), 'settings.xml'))
		File.delete(File.joinPath(System.profile(), 'settings.db'))

	@classmethod
	def cache(self):
		# Ensures that the data always stays in memory.
		# Otherwise the "static variables" are deleted if there is no more reference to the Settings class.
		if not Settings.CacheInitialized:
			Settings.Lock.acquire()

			if not Settings.CacheInitialized:
				try: cacheGlobal = int(System.windowPropertyGet(Settings.PropertyCacheInitialized))
				except: cacheGlobal = False

				if cacheGlobal:
					Settings.CacheInitialized = Converter.boolean(System.windowPropertyGet(Settings.PropertyCacheInitialized))
					Settings.CacheEnabled = Converter.boolean(System.windowPropertyGet(Settings.PropertyCacheEnabled))
				else:
					global SettingsAddon
					Settings.CacheInitialized = True

					# NB: Loading the settings through Kodi (SettingsAddon.getSetting) takes more than 3x longer than manually reading the settings from file.
					#Settings.CacheEnabled = Converter.boolean(SettingsAddon.getSetting('general.settings.cache'))
					cache = None
					try:
						Settings.Lock.release()
						data = self.cacheDataUser()
						Settings.Lock.acquire()
						cache = self.raw(id = 'general.settings.cache', parameter = Settings.ParameterValue, data = data)
						if not cache is None: cache = Converter.boolean(cache)
					except: pass
					if cache is None: cache = Converter.boolean(SettingsAddon.getSetting('general.settings.cache'))
					Settings.CacheEnabled = cache

					System.windowPropertySet(Settings.PropertyCacheInitialized, int(Settings.CacheInitialized))
					System.windowPropertySet(Settings.PropertyCacheEnabled, int(Settings.CacheEnabled))

				Settings.CacheValuesMain = {}
				Settings.CacheValuesUser = {}

			Settings.Lock.release()

	@classmethod
	def cacheInitialize(self):
		self.cache()
		if Settings.CacheEnabled:
			self.cacheDataMain()
			self.cacheDataUser()

	@classmethod
	def cacheClear(self):
		# NB: Reset addon in order to clear Kodi's internal settings cache.
		Settings.Lock.acquire()

		global SettingsAddon
		SettingsAddon = xbmcaddon.Addon(System.GaiaAddon)

		Settings.CacheInitialized = False
		Settings.CacheEnabled = False
		Settings.CacheTimeMain = None
		Settings.CacheDataMain = None
		Settings.CacheValuesMain = None
		Settings.CacheTimeUser = None
		Settings.CacheDataUser = None
		Settings.CacheValuesUser = None

		System.windowPropertyClear(Settings.PropertyCacheInitialized)
		System.windowPropertyClear(Settings.PropertyCacheEnabled)
		System.windowPropertyClear(Settings.PropertyCacheTimeMain)
		System.windowPropertyClear(Settings.PropertyCacheDataMain)
		System.windowPropertyClear(Settings.PropertyCacheTimeUser)
		System.windowPropertyClear(Settings.PropertyCacheDataUser)

		Settings.Lock.release()

	@classmethod
	def cacheData(self, valueData, valueTime, propertyData, propertyTime, path, file = True):
		if valueData is None:
			Settings.Lock.acquire()

			if valueData is None:
				if valueTime is None: valueTime = File.timeUpdated(path())
				timeCurrent = valueTime
				timePrevious = System.windowPropertyGet(propertyTime)

				if timePrevious and timeCurrent == int(timePrevious):
					valueData = System.windowPropertyGet(propertyData)

				if not valueData and file:
					valueData = File.readNow(path())
					System.windowPropertySet(propertyTime, timeCurrent)
					System.windowPropertySet(propertyData, valueData)

			Settings.Lock.release()
		return valueData, valueTime

	@classmethod
	def cacheDataMain(self, file = True):
		Settings.CacheDataMain, Settings.CacheTimeMain = self.cacheData(valueData = Settings.CacheDataMain, valueTime = Settings.CacheTimeMain, propertyData = Settings.PropertyCacheDataMain, propertyTime = Settings.PropertyCacheTimeMain, path = self.pathAddon)
		return Settings.CacheDataMain

	@classmethod
	def cacheDataUser(self, file = True):
		Settings.CacheDataUser, Settings.CacheTimeUser = self.cacheData(valueData = Settings.CacheDataUser, valueTime = Settings.CacheTimeUser, propertyData = Settings.PropertyCacheDataUser, propertyTime = Settings.PropertyCacheTimeUser, path = self.pathProfile)
		return Settings.CacheDataUser

	@classmethod
	def cacheEnabled(self):
		self.cache()
		return Settings.CacheEnabled

	@classmethod
	def cacheGet(self, id, raw, database = False):
		try:
			self.cache()
			if raw:
				data = self.cacheDataMain()
				values = Settings.CacheValuesMain
				parameter = Settings.ParameterDefault
			else:
				data = self.cacheDataUser()
				values = Settings.CacheValuesUser
				parameter = Settings.ParameterValue
			if id in values: # Already looked-up previously.
				return values[id]
			elif database:
				result = self._getDatabase(id = id)
				values[id] = result
				return result
			else:
				result = self.raw(id = id, parameter = parameter, data = data)
				if result == None: # Not in the userdata settings yet. Fallback to normal Kodi lookup.
					global SettingsAddon
					result = SettingsAddon.getSetting(Converter.unicode(id))
				values[id] = result
				return result
		except:
			# When the settings cache is cleared (eg: in clean()), the global dictionaries/data might be set to None while this function is busy executing from another thread.
			Logger.error()

	@classmethod
	def cacheSet(self, id, value):
		try:
			self.cache()
			Settings.CacheValuesUser[id] = value
		except:
			# When the settings cache is cleared (eg: in clean()), the global dictionaries/data might be set to None while this function is busy executing from another thread.
			Logger.error()

	# id: the ID of a category, group, or setting.
	# idOld: the ID of the old settings format. Used for external addons that have not upgraded. Might not always work correctly.
	@classmethod
	def launch(self, id = None, idOld = None, addon = None, category = None, wait = False, background = False):
		from lib.modules import interface

		gaia = System.id()
		if addon is None: addon = gaia
		gaiaIs = addon == gaia
		if background is None: background = not gaiaIs

		if background:
			# Kodi has a bug.
			# Sometimes when an external addon's settings dialog is launched from Gaia's settings dialog, labels are empty show up in the external settings.
			# Maybe this is due to Gaia's labels in memory are being used.
			# Launching in an external process might solve this.
			# Problem seems to be gone. But if it comes back, change the function parameter to: "background = None".
			interface.Loader.show()
			parameters = {}
			if not id is None: parameters['id'] = id
			if not addon is None: parameters['addon'] = addon
			if not category is None: parameters['category'] = category
			System.executePlugin(action = 'settingsBackground', parameters = parameters)
		else:
			interface.Loader.hide()
			System.execute('Addon.OpenSettings(%s)' % addon)

			if id:
				try:
					data = self.cacheDataMain()
					level = self.level()

					entry = None
					index = None
					for i in ['setting', 'group', 'category']:
						try:
							entry = '<%s id="%s"' % (i, id)
							index = data.index(entry)
							break
						except: pass
					data = data[:index + len(entry)]

					# Exclude categories that are hidden, because all their children are also hidden.
					index = 0
					values = Regex.extract(data = data, expression = '<category(.*?)<\/category>', group = None, all = True, flags = Regex.FlagAllLines)
					for value in values:
						for i in range(Settings.LevelBasic, level + 1):
							if value.count('<level>%d</level>' % i) > 0:
								index += 1
								break

					System.execute('Control.SetFocus(%d)' % (index - 100))

					if not type == 'category':
						entry = '<category id="'
						index = data.rindex(entry)
						sub = data[index + len(entry):]

						# Count the total number of elements with and ID attribute.
						index = sub.count('id="')

						# The groups are also included in Kodi's focus index.
						index -= sub.count('<group')

						# Exclude groups that are hidden, because all their children are also hidden.
						# Must add 2 and not just 1 to the index. Not sure why, maybe Kodi adds something internally.
						values = Regex.extract(data = sub, expression = '<group(.*?)<\/group>', group = None, all = True, flags = Regex.FlagAllLines)
						for value in values:
							for i in range(Settings.LevelBasic, level + 1):
								if value.count('<level>%d</level>' % i) > 0:
									index += 2
									break

						# Ignore entries with a level lower than the level mode set by the user.
						for i in range(Settings.LevelInternal, level, -1):
							index -= sub.count('<level>%d</level>' % i)

						# For group selection, go to the first entry in the group.
						if ('<group id="%s"' % id) in sub: index += 1

						System.execute('Control.SetFocus(%d)' % (index - 80))
				except:
					Logger.log('Setting ID not found: ' + id)
			elif category:
				System.execute('Control.SetFocus(%d)' % (int(category) - 100)) # Convert to int, when passed from addon.py.
				if not idOld is None: System.execute('Control.SetFocus(%d)' % (int(idOld) - 80))

		if wait: self.launchWait(all = not gaiaIs)

	@classmethod
	def launchWait(self, all = True):
		# Wait for all types of dialogs, an not just the addon settings dialog, since some settings might open other types of dialogs.
		from lib.modules import interface
		interface.Dialog.dialogWait()

		# Some settings dialogs of external addons have other kinds of dialogs that can be shown from the settings.
		# Eg: The PM/RD Oauth dialog when authenticating an account from ResolveURL.
		# Wait a few seconds to make sure that all of those sub-dialogs are also closed.
		if all:
			interface.Loader.show()
			count = 0
			while True:
				if interface.Dialog.dialogVisible(loader = False): # Do not check for the loader, since we show the loader from this code.
					interface.Loader.hide()
					count = 0
					Time.sleep(0.1)
				else:
					interface.Loader.show()
					count += 1
					if count > 15:
						break # 3 seconds. 2 seconds is not enough.
					Time.sleep(0.2)

	@classmethod
	def launchData(self, id = None, wait = False):
		self.launch(id = self.idDataLabel(id), wait = wait)

	@classmethod
	def wait(self):
		while Settings.Busy > 0: Time.sleep(0.3)

	@classmethod
	def idDataLabel(self, id):
		return id + '.' + Settings.DataLabel

	@classmethod
	def idDataValue(self, id):
		return id + '.' + Settings.DataValue

	@classmethod
	def set(self, id, value, cached = False, background = False):
		Settings.Busy += 1
		if Tools.isStructure(value):
			from lib.modules import database
			database = self._database()
			database._insert('INSERT OR IGNORE INTO %s (id) VALUES(?);' % Settings.Database, parameters = (id,))
			database._update('UPDATE %s SET data = ? WHERE id = ?;' % Settings.Database, parameters = (Converter.jsonTo(value), id))
			if cached or self.cacheEnabled(): self.cacheSet(id = id, value = value)
			Settings.Busy -= 1
		else:
			if value is True or value is False: # Use is an not ==, because checks type as well. Otherwise int/float might also be true.
				value = Converter.boolean(value, string = True)
			elif value is None:
				value = ''
			else:
				value = str(value)

			# Updating the settings takes 700ms+.
			# Allow them to update in a background thread.
			def _set(id, value, cached):
				if cached or self.cacheEnabled(): self.cacheSet(id = id, value = value)
				global SettingsAddon
				Settings.Lock.acquire()
				SettingsAddon.setSetting(id = Converter.unicode(id), value = value)
				Settings.Lock.release()
				Settings.Busy -= 1
			if background:
				thread = threading.Thread(target = _set, args = (id, value, cached))
				thread.start()
			else:
				_set(id = id, value = value, cached = cached)

	@classmethod
	def setData(self, id, value, label = None, background = False):
		if not label is None:
			if label is True and Tools.isArray(value): label = len(value)
			self.setLabel(id = id, value = label, background = background)
		self.set(id = id, value = True, background = background) # Set the value in the XML file.
		self.set(id = self.idDataValue(id), value = value, background = background)

	@classmethod
	def setLabel(self, id, value, background = False):
		from lib.modules import interface
		self.set(id = self.idDataLabel(id), value = interface.Translation.string(value), background = background)

	# wait : number of seconds to sleep after command, since it takes a while to send.
	@classmethod
	def external(self, values, wait = 0.1):
		System.executePlugin(action = 'settingsExternal', parameters = values)
		Time.sleep(wait)

	# values is a dictionary.
	@classmethod
	def externalSave(self, values):
		if 'action' in values: del values['action']
		for id, value in values.items():
			self.set(id = id, value = value, external = False)

	@classmethod
	def default(self, id):
		# This does not always work.
		# Sometimes when writing the truncated data to file, Kodi later replaces the content with its in-memory version.
		'''
		data = self.cacheDataUser()
		expression = '(?:^|[\r\n]+)(.*?id\s*=\s*"%s".*?(?:[\r\n]+|$))'
		if not Tools.isArray(id): id = [id]

		for i in id:
			data = Regex.remove(data = data, expression = expression % i, group = 1)
			try: del Settings.CacheValuesUser[i]
			except: pass

		File.writeNow(self.pathProfile(), data)
		System.windowPropertySet(Settings.PropertyCacheDataUser, data)
		'''

		data = self.cacheDataUser()
		expression = '(?:^|[\r\n]+)(.*?id\s*=\s*"%s".*?(?:[\r\n]+|$))'
		if not Tools.isArray(id): id = [id]

		for i in id:
			value = self.raw(id = i, parameter = Settings.ParameterDefault)
			self.set(id = i, value = value)

			data = Regex.remove(data = data, expression = expression % i, group = 1)
			try: del Settings.CacheValuesUser[i]
			except: pass

		System.windowPropertySet(Settings.PropertyCacheDataUser, data)

	@classmethod
	def defaultIs(self, id):
		return self.getString(id = id) == self.raw(id = id, parameter = Settings.ParameterDefault)

	@classmethod
	def defaultData(self, id):
		self.default([id, self.idDataLabel(id), self.idDataValue(id)])

	# Retrieve the values directly from the original settings instead of the saved user XML.
	# This is for internal values/settings that have a default value. If these values change, they are not propagate to the user XML, since the value was already set from a previous version.
	@classmethod
	def raw(self, id, parameter = ParameterDefault, data = None):
		try:
			if data is None: data = self.cacheDataMain()

			if parameter == Settings.ParameterValue: expression = 'id\s*=\s*"' + id + '"[^\/]*?>(.*?)<'
			else: expression = 'id\s*=\s*"' + id + '".*?<' + parameter + '[^\/]*?>(.*?)<'

			match = re.search(expression, data, re.IGNORECASE | re.DOTALL)
			if match: return match.group(1)
		except: pass
		return None

	@classmethod
	def _getDatabase(self, id):
		try:
			from lib.modules import database
			return Converter.jsonFrom(self._database()._selectValue('SELECT data FROM %s WHERE id = "%s";' % (Settings.Database, id)))
		except: return None

	# Kodi reads the settings file on every request, which is slow.
	# If the cached option is used, the settings XML is read manually once, and all requests are done from there, which is faster.
	@classmethod
	def get(self, id, raw = False, cached = True, database = False):
		if cached and self.cacheEnabled():
			return self.cacheGet(id = id, raw = raw, database = database)
		elif raw:
			return self.raw(id)
		elif database:
			return self._getDatabase(id)
		else:
			global SettingsAddon
			return SettingsAddon.getSetting(Converter.unicode(id))

	@classmethod
	def getString(self, id, raw = False, cached = True):
		return self.get(id = id, raw = raw, cached = cached)

	@classmethod
	def getBoolean(self, id, raw = False, cached = True):
		return Converter.boolean(self.get(id = id, raw = raw, cached = cached))

	@classmethod
	def getBool(self, id, raw = False, cached = True):
		return self.getBoolean(id = id, raw = raw, cached = cached)

	@classmethod
	def getNumber(self, id, raw = False, cached = True):
		return self.getDecimal(id = id, raw = raw, cached = cached)

	@classmethod
	def getDecimal(self, id, raw = False, cached = True):
		value = self.get(id = id, raw = raw, cached = cached)
		try: return float(value)
		except: return 0

	@classmethod
	def getFloat(self, id, raw = False, cached = True):
		return self.getDecimal(id = id, raw = raw, cached = cached)

	@classmethod
	def getInteger(self, id, raw = False, cached = True):
		value = self.get(id = id, raw = raw, cached = cached)
		try: return int(value)
		except: return 0

	@classmethod
	def getInt(self, id, raw = False, cached = True):
		return self.getInteger(id = id, raw = raw, cached = cached)

	@classmethod
	def getObject(self, id, raw = False, cached = True, default = None):
		result = self.get(id = id, raw = raw, cached = cached, database = True)
		return default if result is None else result

	@classmethod
	def getList(self, id, raw = False, cached = True, default = []):
		return self.getObject(id = id, raw = raw, cached = cached, default = default)

	@classmethod
	def getData(self, id, raw = False, cached = True, default = None):
		if self.getBoolean(id): return self.getObject(id = self.idDataValue(id), raw = raw, cached = cached, default = default)
		else: return default # Eg: The "Default" button used in the settings dialog will reset the value to False.

	@classmethod
	def getDataObject(self, id, raw = False, cached = True, default = None):
		return self.getData(id = id, raw = raw, cached = cached, default = default)

	@classmethod
	def getDataList(self, id, raw = False, cached = True, default = []):
		return self.getData(id = id, raw = raw, cached = cached, default = default)

	@classmethod
	def has(self, id, raw = False, cached = True):
		result = self.get(id = id, raw = raw, cached = cached, database = True)
		return bool(result)

###################################################################
# MEDIA
###################################################################

class Media(object):

	TypeNone = None
	TypeMovie = 'movie'
	TypeDocumentary = 'documentary'
	TypeShort = 'short'
	TypeShow = 'show'
	TypeSeason = 'season'
	TypeEpisode = 'episode'
	TypePerson = 'person'

	NameSeasonSpecial = xbmcaddon.Addon(System.GaiaAddon).getLocalizedString(35637)
	NameSeasonLong = xbmcaddon.Addon(System.GaiaAddon).getLocalizedString(32055)
	NameSeasonShort = NameSeasonLong[0].upper()
	NameEpisodeLong = xbmcaddon.Addon(System.GaiaAddon).getLocalizedString(33028)
	NameEpisodeShort = NameEpisodeLong[0].upper()

	OrderTitle = 0
	OrderTitleYear = 1
	OrderYearTitle = 2
	OrderSeason = 3
	OrderEpisode = 4
	OrderSeasonEpisode = 5
	OrderEpisodeTitle = 6
	OrderSeasonEpisodeTitle = 7

	Default = 0
	Native = 1

	DefaultMovie = 4
	DefaultDocumentary = 4
	DefaultShort = 4
	DefaultShow = 0
	DefaultSeason = 0
	DefaultEpisode = 11

	DefaultAeonMovie = 0
	DefaultAeonDocumentary = 0
	DefaultAeonShort = 0
	DefaultAeonShow = 0
	DefaultAeonSeason = 0
	DefaultAeonEpisode = 11

	DefaultAeonGaiaMovie = 0
	DefaultAeonGaiaDocumentary = 0
	DefaultAeonGaiaShort = 0
	DefaultAeonGaiaShow = 0
	DefaultAeonGaiaSeason = 0
	DefaultAeonGaiaEpisode = 0

	FormatsTitle = [
		(OrderTitle,		'%s'),
		(OrderTitleYear,	'%s %d'),
		(OrderTitleYear,	'%s. %d'),
		(OrderTitleYear,	'%s - %d'),
		(OrderTitleYear,	'%s (%d)'),
		(OrderTitleYear,	'%s [%d]'),
		(OrderYearTitle,	'%d %s'),
		(OrderYearTitle,	'%d. %s'),
		(OrderYearTitle,	'%d - %s'),
		(OrderYearTitle,	'(%d) %s'),
		(OrderYearTitle,	'[%d] %s'),
	]

	FormatsSeason = [
		(OrderSeason,	NameSeasonLong + ' %01d'),
		(OrderSeason,	NameSeasonLong + ' %02d'),
		(OrderSeason,	NameSeasonShort + '%01d'),
		(OrderSeason,	NameSeasonShort + '%02d'),
		(OrderSeason,	'%01d ' + NameSeasonLong),
		(OrderSeason,	'%02d ' + NameSeasonLong),
		(OrderSeason,	'%01d. ' + NameSeasonLong),
		(OrderSeason,	'%02d. ' + NameSeasonLong),
		(OrderSeason,	'%01d'),
		(OrderSeason,	'%02d'),
	]

	FormatsEpisode = [
		(OrderTitle,				'%s'),
		(OrderEpisodeTitle,			'%01d %s'),
		(OrderEpisodeTitle,			'%02d %s'),
		(OrderEpisodeTitle,			'%01d. %s'),
		(OrderEpisodeTitle,			'%02d. %s'),
		(OrderEpisodeTitle,			'%01d - %s'),
		(OrderEpisodeTitle,			'%02d - %s'),
		(OrderSeasonEpisodeTitle,	'%01dx%01d %s'),
		(OrderSeasonEpisodeTitle,	'%01dx%02d %s'),
		(OrderSeasonEpisodeTitle,	'%02dx%02d %s'),
		(OrderSeasonEpisodeTitle,	'%01dx%01d - %s'),
		(OrderSeasonEpisodeTitle,	'%01dx%02d - %s'),
		(OrderSeasonEpisodeTitle,	'%02dx%02d - %s'),
		(OrderEpisodeTitle,			NameEpisodeShort + '%01d %s'),
		(OrderEpisodeTitle,			NameEpisodeShort + '%02d %s'),
		(OrderEpisodeTitle,			NameEpisodeShort + '%01d. %s'),
		(OrderEpisodeTitle,			NameEpisodeShort + '%02d. %s'),
		(OrderEpisodeTitle,			NameEpisodeShort + '%01d - %s'),
		(OrderEpisodeTitle,			NameEpisodeShort + '%02d - %s'),
		(OrderSeasonEpisodeTitle,	NameSeasonShort + '%01d' + NameEpisodeShort + '%01d %s'),
		(OrderSeasonEpisodeTitle,	NameSeasonShort + '%01d' + NameEpisodeShort + '%02d %s'),
		(OrderSeasonEpisodeTitle,	NameSeasonShort + '%02d' + NameEpisodeShort + '%02d %s'),
		(OrderSeasonEpisodeTitle,	NameSeasonShort + '%01d' + NameEpisodeShort + '%01d - %s'),
		(OrderSeasonEpisodeTitle,	NameSeasonShort + '%01d' + NameEpisodeShort + '%02d - %s'),
		(OrderSeasonEpisodeTitle,	NameSeasonShort + '%02d' + NameEpisodeShort + '%02d - %s'),
		(OrderEpisode,				'%01d'),
		(OrderEpisode,				'%02d'),
		(OrderSeasonEpisode,		'%01dx%01d'),
		(OrderSeasonEpisode,		'%01dx%02d'),
		(OrderSeasonEpisode,		'%02dx%02d'),
		(OrderEpisode,				NameEpisodeShort + '%01d'),
		(OrderEpisode,				NameEpisodeShort + '%02d'),
		(OrderSeasonEpisode,		NameSeasonShort + '%01d' + NameEpisodeShort + '%01d'),
		(OrderSeasonEpisode,		NameSeasonShort + '%01d' + NameEpisodeShort + '%02d'),
		(OrderSeasonEpisode,		NameSeasonShort + '%02d' + NameEpisodeShort + '%02d'),
	]

	FormatsSkin = None
	FormatsDefault = None

	@classmethod
	def _format(self, format, title = None, year = None, season = None, episode = None, special = False):
		order = format[0]
		format = format[1]
		if order == Media.OrderTitle:
			return format % (title)
		elif order == Media.OrderTitleYear:
			return format % (title, year)
		elif order == Media.OrderYearTitle:
			return format % (year, title)
		elif order == Media.OrderSeason:
			if season == 0 and special and len(format) > 5: return Media.NameSeasonSpecial
			else: return format % (season)
		elif order == Media.OrderEpisode:
			return format % (episode)
		elif order == Media.OrderSeasonEpisode:
			return format % (season, episode)
		elif order == Media.OrderEpisodeTitle:
			return format % (episode, title)
		elif order == Media.OrderSeasonEpisodeTitle:
			return format % (season, episode, title)
		else:
			return title

	@classmethod
	def _extract(self, metadata, encode = False):
		title = metadata['tvshowtitle'] if 'tvshowtitle' in metadata else metadata['title']
		if encode: title = Converter.unicodeNormalize(string = title, umlaut = True)
		try: year = int(metadata['year'])
		except: year = None
		try: season = int(metadata['season']) if 'season' in metadata else None
		except: season = None
		try: episode = int(metadata['episode']) if 'episode' in metadata else None
		except: episode = None
		try: pack = bool(metadata['pack'])
		except: pack = None
		return (title, year, season, episode, pack)

	@classmethod
	def _data(self, title, year, season, episode, encode = False):
		if not title is None and encode: title = Converter.unicodeNormalize(string = title, umlaut = True)
		if not year is None: year = int(year)
		if not season is None: season = int(season)
		if not episode is None: episode = int(episode)
		return (title, year, season, episode)

	@classmethod
	def _initialize(self, skin = True):
		data = Media.FormatsSkin if skin else Media.FormatsDefault
		if data is None:
			from lib.modules import interface
			aeon = interface.Skin.isAeon() if skin else False
			aeonGaia = interface.Skin.isGaiaAeonNox() if skin else False
			data = {}

			enabled = Settings.getBoolean('metadata.title.layout')

			setting = Settings.getInteger('metadata.title.layout.movie') if enabled else Media.Default
			if setting == Media.Native: setting = Media.Default
			if setting == Media.Default: setting = Media.DefaultAeonGaiaMovie if aeonGaia else Media.DefaultAeonMovie if aeon else Media.DefaultMovie
			else: setting -= 2
			data[Media.TypeMovie] = Media.FormatsTitle[setting]

			setting = Settings.getInteger('metadata.title.layout.documentary') if enabled else Media.Default
			if setting == Media.Native: setting = Media.Default
			if setting == Media.Default: setting = Media.DefaultAeonGaiaDocumentary if aeonGaia else Media.DefaultAeonDocumentary if aeon else Media.DefaultDocumentary
			else: setting -= 2
			data[Media.TypeDocumentary] = Media.FormatsTitle[setting]

			setting = Settings.getInteger('metadata.title.layout.short') if enabled else Media.Default
			if setting == Media.Native: setting = Media.Default
			if setting == Media.Default: setting = Media.DefaultAeonGaiaShort if aeonGaia else Media.DefaultAeonShort if aeon else Media.DefaultShort
			else: setting -= 2
			data[Media.TypeShort] = Media.FormatsTitle[setting]

			setting = Settings.getInteger('metadata.title.layout.show') if enabled else Media.Default
			if setting == Media.Native: setting = Media.Default
			if setting == Media.Default: setting = Media.DefaultAeonGaiaShow if aeonGaia else Media.DefaultAeonShow if aeon else Media.DefaultShow
			else: setting -= 2
			data[Media.TypeShow] = Media.FormatsTitle[setting]

			setting = Settings.getInteger('metadata.title.layout.season') if enabled else Media.Default
			if setting == Media.Native: setting = Media.Default
			if setting == Media.Default: setting = Media.DefaultAeonGaiaSeason if aeonGaia else Media.DefaultAeonSeason if aeon else Media.DefaultSeason
			else: setting -= 2
			data[Media.TypeSeason] = Media.FormatsSeason[setting]

			setting = Settings.getInteger('metadata.title.layout.episode') if enabled else Media.Default
			if setting == Media.Native: setting = Media.Default
			if setting == Media.Default: setting = Media.DefaultAeonGaiaEpisode if aeonGaia else Media.DefaultAeonEpisode if aeon else Media.DefaultEpisode
			else: setting -= 2

			data[Media.TypeEpisode] = Media.FormatsEpisode[setting]

			if skin: Media.FormatsSkin = data
			else: Media.FormatsDefault = data
		return data

	@classmethod
	def force(self, type):
		setting = Settings.getInteger('metadata.title.layout.' + type)
		if setting is None: return False
		else: return not setting == Media.Native

	@classmethod
	def title(self, type = TypeNone, metadata = None, title = None, year = None, season = None, episode = None, encode = False, pack = False, special = False, skin = True):
		if not metadata == None: title, year, season, episode, packs = self._extract(metadata = metadata, encode = encode)
		title, year, season, episode = self._data(title = title, year = year, season = season, episode = episode, encode = encode)

		if type == Media.TypeNone:
			pack = (pack and packs)
			if not season is None and not episode is None and not pack:
				type = Media.TypeEpisode
			elif not season is None:
				type = Media.TypeSeason
			else:
				type = Media.TypeMovie

		formats = self._initialize(skin = skin)
		format = formats[type]
		return self._format(format = format, title = title, year = year, season = season, episode = episode, special = special)

	# Raw title to search on the web/scrapers.
	@classmethod
	def titleUniversal(self, metadata = None, title = None, year = None, season = None, episode = None, encode = False):
		if not metadata is None: title, year, season, episode, packs = self._extract(metadata = metadata, encode = encode)
		title, year, season, episode = self._data(title = title, year = year, season = season, episode = episode, encode = encode)

		if not season is None and not episode is None:
			return '%s S%02dE%02d' % (title, season, episode)
		elif not year is None:
			year = '(%s)' % year
			if not year in title: title = '%s %s' % (title, year)
			return title
		else:
			return title

	@classmethod
	def number(self, type = TypeNone, metadata = None, season = None, episode = None, encode = False, pack = False, special = False, skin = True):
		if not metadata == None: title, year, season, episode, packs = self._extract(metadata = metadata, encode = encode)
		title, year, season, episode = self._data(title = None, year = None, season = season, episode = episode, encode = encode)

		if type == Media.TypeNone:
			pack = (pack and packs)
			if not season is None and not episode is None and not pack:
				type = Media.TypeEpisode
			elif not season is None:
				type = Media.TypeSeason

		formats = self._initialize(skin = skin)
		format = formats[type]
		return self._format(format = format, season = season, episode = episode, special = special)

	@classmethod
	def typeMovie(self, type):
		return type == Media.TypeMovie or type == Media.TypeDocumentary or type == Media.TypeShort

	@classmethod
	def typeTelevision(self, type):
		return type == Media.TypeShow or type == Media.TypeSeason or type == Media.TypeEpisode

	@classmethod
	def metadataClean(self, metadata, exclude = None):
		# Filter out non-existing/custom keys.
		# Otherise there are tons of errors in Kodi 18 log.
		if metadata is None: return metadata
		allowed = ['genre',	'country', 'year', 'episode', 'season', 'sortepisode', 'sortseason', 'episodeguide', 'showlink', 'top250', 'setid', 'tracknumber', 'rating', 'userrating', 'watched', 'playcount', 'overlay', 'cast', 'castandrole', 'director', 'mpaa', 'plot', 'plotoutline', 'title', 'originaltitle', 'sorttitle', 'duration', 'studio', 'tagline', 'writer', 'tvshowtitle', 'premiered', 'status', 'set', 'setoverview', 'tag', 'imdbnumber', 'code', 'aired', 'credits', 'lastplayed', 'album', 'artist', 'votes', 'path', 'trailer', 'dateadded', 'mediatype', 'dbid']
		if exclude:
			if not Tools.isArray(exclude): exclude = ['userrating', 'watched', 'playcount', 'overlay', 'duration', 'title']
			allowed = [i for i in allowed if not i in exclude]
		return {k: v for k, v in metadata.items() if k in allowed}

###################################################################
# LIGHTPACK
###################################################################

class Lightpack(object):

	ExecutionKodi = 'kodi'
	ExecutionGaia = 'gaia'

	StatusUnknown = None
	StatusOn = 'on'
	StatusOff = 'off'

	# Number of LEDs in a Lightpack.
	MapSize = 10

	PathWindows = ['C:\\Program Files (x86)\\Prismatik\\Prismatik.exe', 'C:\\Program Files\\Prismatik\\Prismatik.exe']
	PathLinux = ['/usr/bin/prismatik', '/usr/local/bin/prismatik']

	DefaultAddress = '127.0.0.1'
	DefaultPort = 3636

	def __init__(self):
		self.mError = False

		self.mEnabled = Settings.getBoolean('ambilight.lightpack.enabled')

		self.mPrismatikMode = Settings.getInteger('ambilight.lightpack.prismatik')
		self.mPrismatikLocation = Settings.getString('ambilight.lightpack.prismatik.location')

		self.mLaunchAutomatic = Settings.getInteger('ambilight.lightpack.launch')
		self.mLaunchAnimation = Settings.getBoolean('ambilight.lightpack.launch.animation')

		self.mProfileCustom = Settings.getBoolean('ambilight.lightpack.profile')
		self.mProfileName = Settings.getString('ambilight.lightpack.profile.name')

		self.mCount = Settings.getInteger('ambilight.lightpack.count')
		self.mMap = self._map()

		if Settings.getBoolean('ambilight.lightpack.connection'):
			self.mHost = Settings.getString('ambilight.lightpack.connection.host')
			self.mPort = Settings.getInteger('ambilight.lightpack.connection.port')
			self.mKey = Settings.getString('ambilight.lightpack.connection.key').strip()
		else:
			self.mHost = Lightpack.DefaultAddress
			self.mPort = Lightpack.DefaultPort
			self.mKey = ''

		self.mLightpack = None
		self._initialize()

	def __del__(self):
		try: self._unlock()
		except: pass
		try: self._disconnect()
		except: pass

	def _map(self):
		result = []
		set = 10
		for i in range(self.mCount):
			start = Lightpack.MapSize * i
			for j in range(1, Lightpack.MapSize + 1):
				result.append(start + j)
		return result

	def _initialize(self):
		if not self.mEnabled: return
		from lib.externals.lightpack import lightpack
		self.mLightpack = lightpack.lightpack(self.mHost, self.mPort, self.mKey, self.mMap)

	def _error(self):
		return self.mError

	def _errorSuccess(self):
		return not self.mError

	def _errorSet(self):
		self.mError = True

	def _errorClear(self):
		self.mError = False

	def _connect(self):
		from lib.externals.lightpack import lightpack
		return self.mLightpack.connect() >= 0

	def _disconnect(self):
		from lib.externals.lightpack import lightpack
		self.mLightpack.disconnect()

	def _lock(self):
		from lib.externals.lightpack import lightpack
		self.mLightpack.lock()

	def _unlock(self):
		from lib.externals.lightpack import lightpack
		self.mLightpack.unlock()

	# Color is RGB array or hex. If index is None, uses all LEDs.
	def _colorSet(self, color, index = None, lock = False):
		from lib.externals.lightpack import lightpack
		if lock: self.mLightpack.lock()

		if Tools.isString(color):
			color = color.replace('#', '')
			if len(color) == 6:
				color = 'FF' + color
			color = [int(color[i : i + 2], 16) for i in range(2, 8, 2)]

		if index == None:
			self.mLightpack.setColorToAll(color[0], color[1], color[2])
		else:
			self.mLightpack.setColor(index, color[0], color[1], color[2])

		if lock: self.mLightpack.unlock()

	def _profileSet(self, profile):
		from lib.externals.lightpack import lightpack
		try:
			self._errorClear()
			self._lock()
			self.mLightpack.setProfile(profile)
			self._unlock()
		except:
			self._errorSet()
		return self._errorSuccess()

	def _message(self):
		from lib.modules import interface
		interface.Dialog.confirm(title = 33406, message = 33410)

	def _launchEnabled(self, execution):
		if self.mEnabled:
			if execution == Lightpack.ExecutionKodi and (self.mLaunchAutomatic == 1 or self.mLaunchAutomatic == 3):
				return True
			if execution == Lightpack.ExecutionGaia and (self.mLaunchAutomatic == 2 or self.mLaunchAutomatic == 3):
				return True
		return False

	def _launch(self):
		try:
			if not self._connect():
				raise Exception()
		except:
			try:
				if self.mLaunchAutomatic > 0:
					automatic = self.mPrismatikMode == 0 or not self.mPrismatikLocation

					if 'win' in sys.platform or 'nt' in sys.platform:
						command = 'start "Prismatik" /B /MIN "%s"'
						if automatic:
							executed = False
							for path in Lightpack.PathWindows:
								if os.path.exists(path):
									os.system(command % path)
									executed = True
									break
							if not executed:
								os.system('prismatik') # Global path
						else:
							os.system(command % self.mPrismatikLocation)
					elif 'darwin' in sys.platform or 'max' in sys.platform:
						os.system('open "' + self.mPrismatikLocation + '"')
					else:
						command = '"%s" &'
						if automatic:
							executed = False
							for path in Lightpack.PathLinux:
								if os.path.exists(path):
									os.system(command % path)
									executed = True
									break
							if not executed:
								os.system('prismatik') # Global path
						else:
							os.system(command % self.mPrismatikLocation)

					Time.sleep(3)
					self._connect()
					self.switchOn()
			except:
				self._errorSet()

		try:
			if self.status() == Lightpack.StatusUnknown:
				self.mLightpack = None
			else:
				try:
					if self.mProfileCustom and self.mProfileName and not self.mProfileName == '':
						self._profileSet(self.mProfileName)
				except:
					self._errorSet()
		except:
			self.mLightpack = None

		self.animate(force = False)

	def launchAutomatic(self):
		self.launch(Lightpack.ExecutionKodi)

	def launch(self, execution):
		if self._launchEnabled(execution = execution):
			thread = threading.Thread(target = self._launch)
			thread.start()

	@classmethod
	def settings(self):
		Settings.launch(Settings.CategoryAmbilight)

	def enabled(self):
		return self.mEnabled

	def status(self):
		if not self.mEnabled:
			return Lightpack.StatusUnknown

		try:
			from lib.externals.lightpack import lightpack
			self._errorClear()
			self._lock()
			status = self.mLightpack.getStatus()
			self._unlock()
			return status.strip()
		except:
			self._errorSet()
		return Lightpack.StatusUnknown

	def statusUnknown(self):
		return self.status() == Lightpack.StatusUnknown

	def statusOn(self):
		return self.status() == Lightpack.StatusOn

	def statusOff(self):
		return self.status() == Lightpack.StatusOff

	def switchOn(self, message = False):
		if not self.mEnabled:
			return False

		try:
			from lib.externals.lightpack import lightpack
			self._errorClear()
			self._lock()
			self.mLightpack.turnOn()
			self._unlock()
		except:
			self._errorSet()
		success = self._errorSuccess()
		if not success and message: self._message()
		return success

	def switchOff(self, message = False):
		if not self.mEnabled:
			return False

		try:
			from lib.externals.lightpack import lightpack
			self._errorClear()
			self._lock()
			self.mLightpack.turnOff()
			self._unlock()
		except:
			self._errorSet()
		success = self._errorSuccess()
		if not success and message: self._message()
		return success

	def _animateSpin(self, color):
		for i in range(len(self.mMap)):
			self._colorSet(color = color, index = i)
			Time.sleep(0.1)

	def animate(self, force = True, message = False, delay = False):
		if not self.mEnabled:
			return False

		if force or self.mLaunchAnimation:
			try:
				self.switchOn()
				self._errorClear()
				if delay: # The Lightpack sometimes gets stuck on the red light on startup animation. Maybe this delay will solve that?
					Time.sleep(1)
				self._lock()

				for i in range(2):
					self._animateSpin('FFFF0000')
					self._animateSpin('FFFF00FF')
					self._animateSpin('FF0000FF')
					self._animateSpin('FF00FFFF')
					self._animateSpin('FF00FF00')
					self._animateSpin('FFFFFF00')

				self._unlock()
			except:
				self._errorSet()
		else:
			return False
		success = self._errorSuccess()
		if not success and message: self._message()
		return success

###################################################################
# PLATFORM
###################################################################

PlatformInstance = None

class Platform:

	FamilyWindows = 'windows'
	FamilyUnix = 'unix'

	SystemWindows = 'windows'
	SystemMacintosh = 'macintosh'
	SystemLinux = 'linux'
	SystemAndroid = 'android'

	Architecture64bit = '64bit'
	Architecture32bit = '32bit'
	ArchitectureArm = 'arm'

	def __init__(self):
		self.mFamilyType = None
		self.mFamilyName = None
		self.mSystemType = None
		self.mSystemName = None
		self.mDistributionType = None
		self.mDistributionName = None
		self.mVersionShort = None
		self.mVersionFull = None
		self.mArchitecture = None
		self.mAgent = None
		self._detect()

	@classmethod
	def instance(self):
		global PlatformInstance
		if PlatformInstance == None:
			PlatformInstance = Platform()
		return PlatformInstance

	@classmethod
	def familyType(self):
		return self.instance().mFamilyType

	@classmethod
	def familyName(self):
		return self.instance().mFamilyName

	@classmethod
	def systemType(self):
		return self.instance().mSystemType

	@classmethod
	def systemName(self):
		return self.instance().mSystemName

	@classmethod
	def distributionType(self):
		return self.instance().mDistributionType

	@classmethod
	def distributionName(self):
		return self.instance().mDistributionName

	@classmethod
	def versionShort(self):
		return self.instance().mVersionShort

	@classmethod
	def versionFull(self):
		return self.instance().mVersionFull

	@classmethod
	def architecture(self):
		return self.instance().mArchitecture

	@classmethod
	def agent(self):
		return self.instance().mAgent

	@classmethod
	def _detectWindows(self):
		import platform
		try: return Platform.SystemWindows in platform.system().lower()
		except: return False

	@classmethod
	def _detectMacintosh(self):
		import platform
		try:
			version = platform.mac_ver()
			return not version[0] == None and not version[0] == ''
		except: return False

	@classmethod
	def _detectLinux(self):
		import platform
		try: return platform.system().lower() == 'linux' and not self._detectAndroid()
		except: return False

	@classmethod
	def _detectAndroid(self):
		import platform
		try:
			system = platform.system().lower()
			try: distribution = platform.linux_distribution()
			except: distribution = None # linux_distribution() not on CoreElec.
			if Platform.SystemAndroid in system or Platform.SystemAndroid in system or (distribution and len(distribution) > 0 and Tools.isString(distribution[0]) and Platform.SystemAndroid in distribution[0].lower()):
				return True
			if system == Platform.SystemLinux:
				import subprocess
				id = ''
				if 'ANDROID_ARGUMENT' in os.environ:
					id = True
				if id == None or id == '':
					try: id = subprocess.Popen('getprop ril.serialnumber'.split(), stdout = subprocess.PIPE).communicate()[0].trim()
					except: pass
				if id == None or id == '':
					try: id = subprocess.Popen('getprop ro.serialno'.split(), stdout = subprocess.PIPE).communicate()[0].trim()
					except: pass
				if id == None or id == '':
					try: id = subprocess.Popen('getprop sys.serialnumber'.split(), stdout = subprocess.PIPE).communicate()[0].trim()
					except: pass
				if id == None or id == '':
					try: id = subprocess.Popen('getprop gsm.sn1'.split(), stdout = subprocess.PIPE).communicate()[0].trim()
					except: pass
				if not id == None and not id == '':
					try: return not 'not found' in id
					except: return True
		except: pass
		return False

	def _detect(self):
		import platform
		try:
			if self._detectWindows():
				self.mFamilyType = Platform.FamilyWindows
				self.mFamilyName = self.mFamilyType.capitalize()

				self.mSystemType = Platform.SystemWindows
				self.mSystemName = self.mSystemType.capitalize()

				version = platform.win32_ver()
				self.mVersionShort = version[0]
				self.mVersionFull = version[1]
			elif self._detectAndroid():
				self.mFamilyType = Platform.FamilyUnix
				self.mFamilyName = self.mFamilyType.capitalize()

				self.mSystemType = Platform.SystemAndroid
				self.mSystemName =  self.mSystemType.capitalize()

				try:
					distribution = platform.linux_distribution()
					self.mVersionShort = distribution[1]
					self.mVersionFull = distribution[2]
				except: # linux_distribution() not on CoreElec.
					self.mVersionShort = None
					self.mVersionFull = None
			elif self._detectMacintosh():
				self.mFamilyType = Platform.FamilyUnix
				self.mFamilyName = self.mFamilyType.capitalize()

				self.mSystemType = Platform.SystemMacintosh
				self.mSystemName =  self.mSystemType.capitalize()

				mac = platform.mac_ver()
				self.mVersionShort = mac[0]
				self.mVersionFull = self.mVersionShort
			elif self._detectLinux():
				self.mFamilyType = Platform.FamilyUnix
				self.mFamilyName = self.mFamilyType.capitalize()

				self.mSystemType = Platform.SystemLinux
				self.mSystemName =  self.mSystemType.capitalize()

				try:
					distribution = platform.linux_distribution()
					self.mDistributionType = distribution[0].lower().replace('"', '').replace(' ', '')
					self.mDistributionName = distribution[0].replace('"', '')

					self.mVersionShort = distribution[1]
					self.mVersionFull = distribution[2]
				except: # linux_distribution() not on CoreElec.
					self.mDistributionType = None
					self.mDistributionName = None
					self.mVersionShort = None
					self.mVersionFull = None

			machine = platform.machine().lower()
			if '64' in machine: self.mArchitecture = Platform.Architecture64bit
			elif '86' in machine or '32' in machine or 'i386' in machine or 'i686' in machine: self.mArchitecture = Platform.Architecture32bit
			elif 'arm' in machine or 'risc' in machine or 'acorn' in machine: self.mArchitecture = Platform.ArchitectureArm

			try:
				system = ''
				if self.mSystemType == Platform.SystemWindows:
					system += 'Windows NT'
					if self.mVersionFull: system += ' ' + self.mVersionFull
					if self.mArchitecture == Platform.Architecture64bit: system += '; Win64; x64'
					elif self.mArchitecture == Platform.ArchitectureArm: system += '; ARM'
				elif self.mSystemType == Platform.SystemMacintosh:
					system += 'Macintosh; Intel Mac OS X ' + self.mVersionShort.replace('.', '_')
				elif self.mSystemType == Platform.SystemLinux:
					system += 'X11;'
					if self.mDistributionName: system += ' ' + self.mDistributionName + ';'
					system += ' Linux;'
					if self.mArchitecture == Platform.Architecture32bit: system += ' x86'
					elif self.mArchitecture == Platform.Architecture64bit: system += ' x86_64'
					elif self.mArchitecture == Platform.ArchitectureArm: system += ' arm'
				elif self.mSystemType == Platform.SystemAndroid:
					system += 'Linux; Android ' + self.mVersionShort
				if not system == '': system = '(' + system + ') '
				system = System.name() + '/' + System.version() + ' ' + system + 'Kodi/' + str(System.versionKodi())

				# Do in 2 steps, previous statement can fail
				self.mAgent = system
			except:
				Logger.error()

		except:
			Logger.error()

###################################################################
# HARDWARE
###################################################################

class Hardware(object):

	PerformanceSlow = 'slow'
	PerformanceMedium = 'medium'
	PerformanceFast = 'fast'

	ConfigurationSlow = {'processors' : 2, 'memory' : 2147483648}
	ConfigurationMedium = {'processors' : 4, 'memory' : 4294967296}

	@classmethod
	def identifier(self):
		import subprocess
		id = None

		# Windows
		if os.name == 'nt':
			if id is None or ' ' in id:
				try:
					import _winreg
					registry = _winreg.HKEY_LOCAL_MACHINE
					address = 'SOFTWARE\\Microsoft\\Cryptography'
					keyargs = _winreg.KEY_READ | _winreg.KEY_WOW64_64KEY
					key = _winreg.OpenKey(registry, address, 0, keyargs)
					value = _winreg.QueryValueEx(key, 'MachineGuid')
					_winreg.CloseKey(key)
					id = value[0]
				except: pass

			if id is None or ' ' in id:
				try:
					id = subprocess.Popen('wmic csproduct get uuid'.split(), stdout = subprocess.PIPE).communicate()[0]
				except: pass

			if id is None or ' ' in id:
				try:
					id = subprocess.Popen('dmidecode.exe -s system-uuid'.split(), stdout = subprocess.PIPE).communicate()[0]
				except: pass

		# Android
		if id is None or ' ' in id:
			try:
				id = subprocess.Popen('getprop ril.serialnumber'.split(), stdout = subprocess.PIPE).communicate()[0]
			except: pass
		if id is None or ' ' in id:
			try:
				id = subprocess.Popen('getprop ro.serialno'.split(), stdout = subprocess.PIPE).communicate()[0]
			except: pass
		if id is None or ' ' in id:
			try:
				id = subprocess.Popen('getprop sys.serialnumber'.split(), stdout = subprocess.PIPE).communicate()[0]
			except: pass
		if id is None or ' ' in id:
			try:
				id = subprocess.Popen('getprop gsm.sn1'.split(), stdout = subprocess.PIPE).communicate()[0]
			except: pass

		# Linux
		if id is None or ' ' in id:
			try:
				id = subprocess.Popen('hal-get-property --udi /org/freedesktop/Hal/devices/computer --key system.hardware.uuid'.split(), stdout = subprocess.PIPE).communicate()[0]
			except: pass

		# Linux
		if id is None or ' ' in id:
			try:
				id = subprocess.Popen('/sys/class/dmi/id/board_serial', stdout = subprocess.PIPE).communicate()[0]
			except: pass

		# Linux
		if id is None or ' ' in id:
			try:
				id = subprocess.Popen('/sys/class/dmi/id/product_uuid', stdout = subprocess.PIPE).communicate()[0]
			except: pass

		# Linux
		if id is None or ' ' in id:
			try:
				id = subprocess.Popen('cat /var/lib/dbus/machine-id', stdout = subprocess.PIPE).communicate()[0]
			except: pass

		# If still not found, get the MAC address
		if id is None or ' ' in id:
			try:
				import psutil
				nics = psutil.net_if_addrs()
				nics.pop('lo')
				for i in nics:
					for j in nics[i]:
						if j.family == 17:
							id = j.address
							break
			except: pass

		# If still not found, get the MAC address
		if id is None or ' ' in id:
			try:
				import netifaces
				interface = [i for i in netifaces.interfaces() if not i.startswith('lo')][0]
				id = netifaces.ifaddresses(interface)[netifaces.AF_LINK]
			except: pass

		# If still not found, get the MAC address
		if id is None or ' ' in id:
			try:
				import uuid
				# Might return a random ID on failure
				# In such a case, save it to the settings and return it, ensuring that the same ID is used.
				id = Settings.getString('general.statistics.identifier')
				if id == None or id == '':
					id = uuid.getnode()
					Settings.set('general.statistics.identifier', id)
			except: pass

		if id is None: id = ''
		else: id = str(id)

		try: id += str(System.informationSystem()['name'])
		except: pass

		try: id += str(self.processors())
		except: pass

		try: id += str(self.memory())
		except: pass

		return Hash.sha256(id)

	@classmethod
	def identifierReset(self):
		Settings.set('general.statistics.identifier', '')

	@classmethod
	def performance(self):
		processors = self.processors()
		memory = self.memory()

		if processors == None and memory == None:
			return Hardware.PerformanceMedium

		if not processors == None and not Hardware.ConfigurationSlow['processors'] == None and processors <= Hardware.ConfigurationSlow['processors']:
			return Hardware.PerformanceSlow
		if not memory == None and not Hardware.ConfigurationSlow['memory'] == None and memory <= Hardware.ConfigurationSlow['memory']:
			return Hardware.PerformanceSlow

		if not processors == None and not Hardware.ConfigurationMedium['processors'] == None and processors <= Hardware.ConfigurationMedium['processors']:
			return Hardware.PerformanceMedium
		if not memory == None and not Hardware.ConfigurationMedium['memory'] == None and memory <= Hardware.ConfigurationMedium['memory']:
			return Hardware.PerformanceMedium

		return Hardware.PerformanceFast

	@classmethod
	def slow(self):
		processors = self.processors()
		if not processors == None and not Hardware.ConfigurationSlow['processors'] == None and processors <= Hardware.ConfigurationSlow['processors']:
			return True
		memory = self.memory()
		if not memory == None and not Hardware.ConfigurationSlow['memory'] == None and memory <= Hardware.ConfigurationSlow['memory']:
			return True
		return False

	@classmethod
	def processors(self):
		# http://stackoverflow.com/questions/1006289/how-to-find-out-the-number-of-cpus-using-python

		import subprocess

		# Python 2.6+
		try:
			import multiprocessing
			return multiprocessing.cpu_count()
		except: pass

		# PSUtil
		try:
			import psutil
			return psutil.cpu_count() # psutil.NUM_CPUS on old versions
		except: pass

		# POSIX
		try:
			result = int(os.sysconf('SC_NPROCESSORS_ONLN'))
			if result > 0: return result
		except: pass

		# Windows
		try:
			result = int(os.environ['NUMBER_OF_PROCESSORS'])
			if result > 0: return result
		except: pass

		# jython
		try:
			from java.lang import Runtime
			runtime = Runtime.getRuntime()
			result = runtime.availableProcessors()
			if result > 0: return result
		except: pass

		# cpuset
		# cpuset may restrict the number of *available* processors
		try:
			result = re.search(r'(?m)^Cpus_allowed:\s*(.*)$', open('/proc/self/status').read())
			if result:
				result = bin(int(result.group(1).replace(',', ''), 16)).count('1')
				if result > 0: return result
		except: pass

		# BSD
		try:
			sysctl = subprocess.Popen(['sysctl', '-n', 'hw.ncpu'], stdout=subprocess.PIPE)
			scStdout = sysctl.communicate()[0]
			result = int(scStdout)
			if result > 0: return result
		except: pass

		# Linux
		try:
			result = open('/proc/cpuinfo').read().count('processor\t:')
			if result > 0: return result
		except: pass

		# Solaris
		try:
			pseudoDevices = os.listdir('/devices/pseudo/')
			result = 0
			for pd in pseudoDevices:
				if re.match(r'^cpuid@[0-9]+$', pd):
					result += 1
			if result > 0: return result
		except: pass

		# Other UNIXes (heuristic)
		try:
			try:
				dmesg = open('/var/run/dmesg.boot').read()
			except IOError:
				dmesgProcess = subprocess.Popen(['dmesg'], stdout=subprocess.PIPE)
				dmesg = dmesgProcess.communicate()[0]
			result = 0
			while '\ncpu' + str(result) + ':' in dmesg:
				result += 1
			if result > 0: return result
		except: pass

		return None

	@classmethod
	def memory(self):
		try:
			from psutil import virtual_memory
			memory = virtual_memory().total
			if memory > 0: return memory
		except: pass

		try:
			memory = os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES')
			if memory > 0: return memory
		except: pass

		try:
			memory = dict((i.split()[0].rstrip(':'),int(i.split()[1])) for i in open('/proc/meminfo').readlines())
			memory = memory['MemTotal'] * 1024
			if memory > 0: return memory
		except: pass

		try:
			from ctypes import Structure, c_int32, c_uint64, sizeof, byref, windll
			class MemoryStatusEx(Structure):
				_fields_ = [
					('length', c_int32),
					('memoryLoad', c_int32),
					('totalPhys', c_uint64),
					('availPhys', c_uint64),
					('totalPageFile', c_uint64),
					('availPageFile', c_uint64),
					('totalVirtual', c_uint64),
					('availVirtual', c_uint64),
					('availExtendedVirtual', c_uint64)]
				def __init__(self):
					self.length = sizeof(self)
			memory = MemoryStatusEx()
			windll.kernel32.GlobalMemoryStatusEx(byref(memory))
			memory = memory.totalPhys
			if memory > 0: return memory
		except: pass

		return None

###################################################################
# EXTENSIONS
###################################################################

class Extensions(object):

	# Types
	TypeRequired = 'required'
	TypeRecommended = 'recommended'
	TypeOptional = 'optional'

	# IDs
	IdGaiaAddon = 'plugin.video.gaia'
	IdGaiaRepository = 'repository.gaia'
	IdGaiaArtwork = 'script.gaia.artwork'
	IdGaiaBinaries = 'script.gaia.binaries'
	IdGaiaResources = 'script.gaia.resources'
	IdGaiaIcons = 'script.gaia.icons'
	IdGaiaSkins = 'script.gaia.skins'
	IdGaiaAeonNox = 'skin.gaia.aeon.nox' if System.versionKodi() < 18 else 'skin.gaia.aeon.nox.18'
	IdResolveUrl = 'script.module.resolveurl'
	IdUrlResolver = 'script.module.urlresolver'
	IdOpeScrapers = 'script.module.openscrapers'
	IdFenScrapers = 'script.module.fenomscrapers'
	IdOatScrapers = 'script.module.oathscrapers'
	IdLamScrapers = 'script.module.lambdascrapers'
	IdCivScrapers = 'script.module.civitasscrapers'
	IdGloScrapers = 'script.module.globalscrapers'
	IdUniScrapers = 'script.module.universalscrapers'
	IdNanScrapers = 'script.module.nanscrapers'
	IdMetaHandler = 'script.module.metahandler'
	IdTrakt = 'script.trakt'
	IdElementum = 'plugin.video.elementum'
	IdElementumRepository = 'repository.elementum'
	IdQuasar = 'plugin.video.quasar'
	IdQuasarRepository = 'repository.quasar'
	IdExtendedInfo = 'script.extendedinfo'
	IdDiamondInfo = 'script.diamondinfo'
	IdEmbuaryInfo = 'script.embuary.info'
	IdYouTube = 'plugin.video.youtube'
	IdUpNext = 'service.upnext'
	IdAddonSignals = 'script.module.addon.signals'

	@classmethod
	def settings(self, id, setting = None, wait = False):
		try:
			Settings.launch(addon = id, id = setting, wait = wait)
			return True
		except:
			return False

	@classmethod
	def launch(self, id):
		try:
			System.execute('RunAddon(%s)' % id)
			return True
		except:
			return False

	@classmethod
	def installed(self, id):
		try:
			idReal = xbmcaddon.Addon(id).getAddonInfo('id')
			return id == idReal
		except:
			return False

	@classmethod
	def enable(self, id, refresh = False, confirm = False):
		from lib.modules.interface import Loader
		Loader.show()

		try: System.execute('InstallAddon(%s)' % id)
		except: pass
		try: System.executeJson(addon = id, method = 'Addons.SetAddonEnabled', parameters = {'enabled' : True})
		except: pass
		if refresh:
			Time.sleep(0.1)
			System.execute('Container.Refresh')
			Time.sleep(0.1)
			System.execute('Container.Refresh')

		# If an addon is not compatible with Kodi 19, a loader is shown that cannot be manually canceled (eg: UrlResolver).
		# Sleep a bit, since this loader takes a while to popup.
		Time.sleep(0.5)
		Loader.hide()

	@classmethod
	def disable(self, id, refresh = False):
		from lib.modules.interface import Loader
		Loader.show()

		try: System.executeJson(addon = id, method = 'Addons.SetAddonEnabled', parameters = {'enabled' : False})
		except: pass
		if refresh:
			# Sometimes when disabling an addon (eg: Orion), the container does not refresh and remove the menu entry.
			# Trying twice seems to work.
			Time.sleep(0.1)
			System.execute('Container.Refresh')
			Time.sleep(0.1)
			System.execute('Container.Refresh')

		# If an addon is not compatible with Kodi 19, a loader is shown that cannot be manually canceled (eg: UrlResolver).
		# Sleep a bit, since this loader takes a while to popup.
		Time.sleep(0.5)
		Loader.hide()

	@classmethod
	def list(self):
		from lib.modules import orionoid
		from lib.modules import interface

		result = [
			{
				'id' : Extensions.IdGaiaRepository,
				'name' : 'Gaia Repository',
				'type' : Extensions.TypeRequired,
				'description' : 33917,
				'icon' : 'extensionsgaia.png',
			},
			{
				'id' : Extensions.IdGaiaResources,
				'name' : 'Gaia Resources',
				'type' : Extensions.TypeRequired,
				'description' : 33726,
				'icon' : 'extensionsgaia.png',
			},
			{
				'id' : Extensions.IdGaiaArtwork,
				'name' : 'Gaia Artwork',
				'type' : Extensions.TypeRecommended,
				'description' : 33727,
				'icon' : 'extensionsgaia.png',
			},
			{
				'id' : Extensions.IdGaiaBinaries,
				'name' : 'Gaia Binaries',
				'type' : Extensions.TypeOptional,
				'description' : 33728,
				'icon' : 'extensionsgaia.png',
			},
			{
				'id' : Extensions.IdGaiaIcons,
				'name' : 'Gaia Icons',
				'type' : Extensions.TypeOptional,
				'description' : 33729,
				'icon' : 'extensionsgaia.png',
			},
			{
				'id' : Extensions.IdGaiaSkins,
				'name' : 'Gaia Skins',
				'type' : Extensions.TypeOptional,
				'description' : 33730,
				'icon' : 'extensionsgaia.png',
			},
			#{
			#	'id' : Extensions.IdGaiaAeonNox,
			#	'name' : 'Gaia Aeon Nox',
			#	'type' : Extensions.TypeOptional,
			#	'description' : 33731,
			#	'icon' : 'extensionsgaia.png',
			#},
			{
				'id' : Extensions.IdResolveUrl,
				'name' : 'ResolveUrl',
				'type' : Extensions.TypeRecommended,
				'description' : 33732,
				'icon' : 'extensionsresolveurl.png',
			},
			{
				'id' : Extensions.IdUrlResolver,
				'name' : 'UrlResolver',
				'type' : Extensions.TypeOptional,
				'description' : 33732,
				'icon' : 'extensionsurlresolver.png',
			},
			{
				'id' : orionoid.Orionoid.Id,
				'name' : orionoid.Orionoid.Name + ' Scrapers',
				'type' : Extensions.TypeRecommended,
				'description' : 35401,
				'icon' : 'extensionsorion.png',
			},
			{
				'id' : Extensions.IdOpeScrapers,
				'name' : 'Open Scrapers',
				'type' : Extensions.TypeOptional,
				'description' : 33963,
				'icon' : 'extensionsopescrapers.png',
			},
			{
				'id' : Extensions.IdFenScrapers,
				'name' : 'Fenom Scrapers',
				'type' : Extensions.TypeOptional,
				'description' : 33963,
				'icon' : 'extensionsfenscrapers.png',
			},
			{
				'id' : Extensions.IdOatScrapers,
				'name' : 'Oath Scrapers',
				'type' : Extensions.TypeOptional,
				'description' : 33963,
				'icon' : 'extensionsfenscrapers.png',
			},
			{
				'id' : Extensions.IdLamScrapers,
				'name' : 'Lambda Scrapers',
				'type' : Extensions.TypeOptional,
				'description' : 33963,
				'icon' : 'extensionslamscrapers.png',
			},
			{
				'id' : Extensions.IdCivScrapers,
				'name' : 'Civitas Scrapers',
				'type' : Extensions.TypeOptional,
				'description' : 33963,
				'icon' : 'extensionscivscrapers.png',
			},
			{
				'id' : Extensions.IdGloScrapers,
				'name' : 'Global Scrapers',
				'type' : Extensions.TypeOptional,
				'description' : 33963,
				'icon' : 'extensionsgloscrapers.png',
			},
			{
				'id' : Extensions.IdUniScrapers,
				'name' : 'Universal Scrapers',
				'type' : Extensions.TypeOptional,
				'description' : 33963,
				'icon' : 'extensionsuniscrapers.png',
			},
			{
				'id' : Extensions.IdNanScrapers,
				'name' : 'NaN Scrapers',
				'type' : Extensions.TypeOptional,
				'description' : 33963,
				'icon' : 'extensionsnanscrapers.png',
			},
			{
				'id' : Extensions.IdMetaHandler,
				'name' : 'MetaHandler',
				'type' : Extensions.TypeOptional,
				'description' : 33733,
				'icon' : 'extensionsmetahandler.png',
			},
			{
				'id' : Extensions.IdTrakt,
				'name' : 'Trakt',
				'type' : Extensions.TypeRecommended,
				'description' : 33734,
				'icon' : 'extensionstrakt.png',
			},
			{
				'id' : Extensions.IdElementum,
				'dependencies' : [Extensions.IdElementumRepository],
				'name' : 'Elementum',
				'type' : Extensions.TypeOptional,
				'description' : 33735,
				'icon' : 'extensionselementum.png',
			},
			{
				'id' : Extensions.IdQuasar,
				'dependencies' : [Extensions.IdQuasarRepository],
				'name' : 'Quasar',
				'type' : Extensions.TypeOptional,
				'description' : 33735,
				'icon' : 'extensionsquasar.png',
			},
			{
				'id' : Extensions.IdExtendedInfo,
				'name' : 'ExtendedInfo',
				'type' : Extensions.TypeOptional,
				'description' : 35570,
				'icon' : 'extensionsextendedinfo.png',
			},
			{
				'id' : Extensions.IdDiamondInfo,
				'name' : 'DiamondInfo',
				'type' : Extensions.TypeOptional,
				'description' : 35570,
				'icon' : 'extensionsdiamondinfo.png',
			},
			{
				'id' : Extensions.IdEmbuaryInfo,
				'name' : 'EmbuaryInfo',
				'type' : Extensions.TypeRecommended,
				'description' : 35570,
				'icon' : 'extensionsembuaryinfo.png',
			},
			{
				'id' : Extensions.IdYouTube,
				'name' : 'YouTube',
				'type' : Extensions.TypeRecommended,
				'description' : 35297,
				'icon' : 'extensionsyoutube.png',
			},
			{
				'id' : Extensions.IdUpNext,
				'name' : 'UpNext',
				'type' : Extensions.TypeOptional,
				'description' : 35409,
				'icon' : 'extensionsupnext.png',
			},
			{
				'id' : Extensions.IdAddonSignals,
				'name' : 'AddonSignals',
				'type' : Extensions.TypeOptional,
				'description' : 35410,
				'icon' : 'extensionsaddonsignals.png',
			},
		]

		for i in range(len(result)):
			result[i]['installed'] = self.installed(result[i]['id'])
			if 'dependencies' in result[i]:
				for dependency in result[i]['dependencies']:
					if not self.installed(dependency):
						result[i]['installed'] = False
						break
			result[i]['description'] = interface.Translation.string(result[i]['description'])

		return result

	@classmethod
	def dialog(self, id):
		extensions = self.list()
		for extension in extensions:
			if extension['id'] == id:
				from lib.modules import interface

				type = ''
				if extension['type'] == Extensions.TypeRequired:
					type = 33723
				elif extension['type'] == Extensions.TypeRecommended:
					type = 33724
				elif extension['type'] == Extensions.TypeOptional:
					type = 33725
				if not type == '':
					type = ' (%s)' % interface.Translation.string(type)

				message = ''
				message += interface.Format.fontBold(extension['name'] + type)
				message += interface.Format.newline() + extension['description']

				action = 33737 if extension['installed'] else 33736

				choice = interface.Dialog.option(title = 33391, message = message, labelConfirm = action, labelDeny = 33486)
				if choice:
					if extension['installed']:
						if extension['type'] == Extensions.TypeRequired:
							interface.Dialog.confirm(title = 33391, message = 33738)
						else:
							self.disable(extension['id'], refresh = True)
					else:
						if 'dependencies' in extension:
							for dependency in extension['dependencies']:
								self.enable(dependency, refresh = True)
						self.enable(extension['id'], refresh = True)

				return True
		return False

	# Get Gaiaa addon versions from the Gaia repo.
	@classmethod
	def version(self, id = IdGaiaAddon):
		path = System.path(System.GaiaRepository)
		if not path: path = System.path(System.GaiaRepositoryTest)
		if not path: return None # No repo installed.
		path = File.joinPath(path, 'addon.xml')
		data = File.readNow(path)
		link = None
		for match in re.findall('<info.*?>(.*?)<\/info>', data, flags = re.IGNORECASE):
			if not 'common' in match:
				link = match
				break
		if link:
			from lib.modules import network
			data = network.Networker().requestText(link)
			if data:
				match = re.search('id\s*=\s*[\'"]' + id + '[\'"].*?version\s*=\s*[\'"](.*?)[\'"]', data, flags = re.IGNORECASE)
				if match:
					return match.group(1)
		return None

	@classmethod
	def versionCheck(self, id = IdGaiaAddon, wait = True):
		thread = threading.Thread(target = self._versionCheck, args = (id,))
		thread.start()
		if wait: thread.join()

	@classmethod
	def _versionCheck(self, id = IdGaiaAddon):
		try:
			versionCurrent = System.versionNumber(version = System.version(id = id))
			versionRepoFull = self.version(id = id)
			versionRepo = System.versionNumber(version = versionRepoFull)
			if versionRepo > versionCurrent:
				from lib.modules import interface
				message = interface.Translation.string(35705) % (System.name(), versionRepoFull)
				interface.Dialog.notification(title = 35704, message = message, icon = interface.Dialog.IconInformation)
		except:
			Logger.error()

###################################################################
# ELEMENTUM
###################################################################

class Elementum(object):

	Id = Extensions.IdElementum
	Name = 'Elementum'

	@classmethod
	def settings(self, settings = False):
		Extensions.settings(id = Elementum.Id, wait = settings)
		if settings: self.settingsLocal('settings')

	@classmethod
	def settingsLocal(self, type = None):
		if type is None: type = 'connection' if self.installed() else 'installation'
		Settings.launch('stream.elementum.' + type)

	@classmethod
	def launch(self):
		Extensions.launch(id = Elementum.Id)

	@classmethod
	def install(self):
		Extensions.enable(id = Elementum.Id, refresh = False)

	@classmethod
	def installed(self):
		return Extensions.installed(Elementum.Id)

	@classmethod
	def interface(self):
		System.openLink(self.linkWeb())

	@classmethod
	def link(self, type = None, parameters = None):
		host = Settings.getString('stream.elementum.host')
		port = Settings.getString('stream.elementum.port')
		if type is None: type = ''
		if parameters is None or parameters == [] or parameters == {}: parameters = ''
		else: parameters = '?' + ('&'.join(['%s=%s' % (key, value) for key, value in parameters.items()]))
		return 'http://%s:%s/%s%s' % (host, port, type, parameters)

	@classmethod
	def linkWeb(self, parameters = None):
		return self.link(type = 'web', parameters = parameters)

	@classmethod
	def linkPlay(self, parameters = None):
		return self.link(type = 'playuri', parameters = parameters)

	@classmethod
	def linkAdd(self, parameters = None):
		return self.link(type = 'torrents/add', parameters = parameters)

	@classmethod
	def connect(self, install = False, background = False, settings = False, wait = True):
		thread = threading.Thread(target = self._connect, args = (install, background, settings))
		thread.start()
		if wait: thread.join()

	@classmethod
	def _connect(self, install = False, background = False, settings = False):
		from lib.modules.interface import Dialog, Translation, Loader

		if install and not self.installed():
			if background:
				self.install()
			else:
				message = Translation.string(35318) % (Elementum.Name, Elementum.Name, Translation.string(35317))
				if Dialog.option(title = Elementum.Name, message = message): self.install()

		if self.installed():
			if not background: Loader.show()
			from lib.modules.network import Networker
			result = Networker().requestJson(link = self.link())
			if not background: Loader.hide()

			if result:
				Settings.set('stream.elementum.connection', Translation.string(35857))
				if settings: self.settingsLocal()
				return True

		self.disconnect(settings = settings)
		return False

	@classmethod
	def disconnect(self, settings = False):
		from lib.modules.interface import Translation
		Settings.set('stream.elementum.connection', Translation.string(35858))
		if settings: self.settingsLocal()

###################################################################
# QUASAR
###################################################################

class Quasar(object):

	Id = Extensions.IdQuasar
	Name = 'Quasar'

	@classmethod
	def settings(self, settings = False):
		Extensions.settings(id = Quasar.Id, wait = settings)
		if settings: self.settingsLocal('settings')

	@classmethod
	def settingsLocal(self, type = None):
		if type is None: type = 'connection' if self.installed() else 'installation'
		Settings.launch('stream.quasar.' + type)

	@classmethod
	def launch(self):
		Extensions.launch(id = Quasar.Id)

	@classmethod
	def install(self):
		Extensions.enable(id = Quasar.Id, refresh = False)

	@classmethod
	def installed(self):
		return Extensions.installed(Quasar.Id)

	@classmethod
	def interface(self):
		System.openLink(self.linkWeb())

	@classmethod
	def link(self, type = None, parameters = None):
		host = Settings.getString('stream.quasar.host')
		port = Settings.getString('stream.quasar.port')
		if type is None: type = ''
		if parameters is None or parameters == [] or parameters == {}: parameters = ''
		else: parameters = '?' + ('&'.join(['%s=%s' % (key, value) for key, value in parameters.items()]))
		return 'http://%s:%s/%s%s' % (host, port, type, parameters)

	@classmethod
	def linkWeb(self, parameters = None):
		return self.link(type = 'web', parameters = parameters)

	@classmethod
	def linkPlay(self, parameters = None):
		return self.link(type = 'playuri', parameters = parameters)

	@classmethod
	def linkAdd(self, parameters = None):
		return self.link(type = 'torrents/add', parameters = parameters)

	@classmethod
	def connect(self, confirm = False, wait = True, settings = False):
		thread = threading.Thread(target = self._connect, args = (confirm, settings))
		thread.start()
		if wait: thread.join()

	@classmethod
	def connect(self, install = False, background = False, settings = False, wait = True):
		thread = threading.Thread(target = self._connect, args = (install, background, settings))
		thread.start()
		if wait: thread.join()

	@classmethod
	def _connect(self, install = False, background = False, settings = False):
		from lib.modules.interface import Dialog, Translation, Loader

		if install and not self.installed():
			if background:
				self.install()
			else:
				message = Translation.string(35318) % (Quasar.Name, Quasar.Name, Translation.string(35317))
				if Dialog.option(title = Quasar.Name, message = message): self.install()

		if self.installed():
			if not background: Loader.show()
			from lib.modules.network import Networker
			result = Networker().requestJson(link = self.link())
			if not background: Loader.hide()

			if result:
				Settings.set('stream.quasar.connection', Translation.string(35857))
				if settings: self.settingsLocal()
				return True

		self.disconnect(settings = settings)
		return False

	@classmethod
	def disconnect(self, settings = False):
		from lib.modules.interface import Translation
		Settings.set('stream.quasar.connection', Translation.string(35858))
		if settings: self.settingsLocal()

###################################################################
# TRAKT
###################################################################

class Trakt(object):

	Id = Extensions.IdTrakt
	Website = 'https://trakt.tv'

	@classmethod
	def settings(self):
		Extensions.settings(id = Trakt.Id)

	@classmethod
	def launch(self):
		Extensions.launch(id = Trakt.Id)

	@classmethod
	def installed(self):
		return Extensions.installed(id = Trakt.Id)

	@classmethod
	def enable(self, refresh = False):
		return Extensions.enable(id = Trakt.Id, refresh = refresh)

	@classmethod
	def disable(self, refresh = False):
		return Extensions.disable(id = Trakt.Id, refresh = refresh)

	@classmethod
	def website(self, open = False):
		if open: System.openLink(Trakt.Website)
		return Trakt.Website

	@classmethod
	def accountEnabled(self):
		from lib.modules.account import Trakt
		return Trakt().authenticated()

###################################################################
# RESOLVER
###################################################################

class Resolver(object):

	@classmethod
	def settings(self, settings = False):
		Extensions.settings(id = self.Addon, wait = settings)
		if settings: self.settingsLocal('settings')

	@classmethod
	def settingsLocal(self, type = None):
		if type is None: type = 'connection' if self.installed() else 'installation'
		Settings.launch('stream.%s.%s' % (self.Id, type))

	@classmethod
	def installed(self):
		return Extensions.installed(id = self.Addon)

	@classmethod
	def enable(self, refresh = False, settings = False, confirm = False):
		install = False
		if not self.installed():
			if confirm:
				from lib.modules.interface import Dialog, Translation
				message = Translation.string(35318) % (self.Name, self.Name, Translation.string(33475))
				if Dialog.option(title = self.Name, message = message): install = True
			else:
				install = True

		if install: Extensions.enable(id = self.Addon, refresh = refresh)
		if settings: self.settingsLocal()

	@classmethod
	def disable(self, refresh = False, settings = False):
		Extensions.disable(id = self.Addon, refresh = refresh)
		if settings: self.settingsLocal()

	@classmethod
	def resolvers(self, installed = True):
		resolvers = [ResolveUrl, UrlResolver]
		if installed: resolvers = [i for i in resolvers if i.installed()]
		return resolvers

	@classmethod
	def authentication(self, type = None, settings = False):
		from lib.modules.interface import Translation

		resolvers = self.resolvers()
		count = len(resolvers)

		if count == 0: return False
		if count > 1:
			from lib.modules.interface import Dialog, Directory
			directory = Directory()
			items = [directory.item(label = i.Name, label2 = Translation.string(33216 if i.authenticated(type = type) else 33642), icon = i.Id) for i in resolvers]
			choice = Dialog.select(title = 33101, items = items, details = True)
		else:
			choice = 0

		id = self._authenticationId(type = type)
		if choice >= 0:
			resolver = resolvers[choice]
			data = resolver._authenticationData()
			Settings.launch(addon = resolver.Addon, category = 1, idOld = data[type]['offset'], wait = True)
			if self.authenticated(type = type): Settings.set(id, Translation.string(33216))
			else: Settings.default(id)

		if settings: Settings.launch(id = id)

	@classmethod
	def authenticationCheck(self):
		from lib.modules.interface import Translation
		data = self._authenticationData()
		for type in data.keys():
			id = self._authenticationId(type = type)
			if self.authenticated(type = type): Settings.set(id, Translation.string(33216))
			else: Settings.default(id)

	@classmethod
	def authenticated(self, type):
		try:
			addon = System.addon(self.Addon)
			data = self._authenticationData()
			return all([addon.getSettingBool(i) for i in data[type]['authentication']['bool']]) and all([addon.getSettingString(i) for i in data[type]['authentication']['string']])
		except:
			resolvers = self.resolvers()
			return any([i.authenticated(type = type) for i in resolvers])

	@classmethod
	def _authenticationId(self, type):
		return 'premium.external.%s' % type

	@classmethod
	def _authenticationData(self):
		data = {
			'alldebrid' : {
				'authentication' : {
					'bool' : ['AllDebridResolver_enabled'],
					'string' : ['AllDebridResolver_token'],
				},
				'offset' : 6,
			},
			'debridlink' : {
				'authentication' : {
					'bool' : ['DebridLinkResolver_enabled'],
					'string' : ['DebridLinkResolver_token'],
				},
				'offset' : 16,
			},
			'linksnappy' : {
				'authentication' : {
					'bool' : ['LinksnappyResolver_enabled'],
					'string' : ['LinksnappyResolver_username', 'LinksnappyResolver_password'],
				},
				'offset' : 27,
			},
			'megadebrid' : {
				'authentication' : {
					'bool' : ['MegaDebridResolver_enabled', 'MegaDebridResolver_login'],
					'string' : ['MegaDebridResolver_username', 'MegaDebridResolver_password'],
				},
				'offset' : 38,
			},
			'rapidpremium' : {
				'authentication' : {
					'bool' : ['RPnetResolver_enabled', 'RPnetResolver_login'],
					'string' : ['RPnetResolver_username', 'RPnetResolver_password'],
				},
				'offset' : 70,
			},
			'simplydebrid' : {
				'authentication' : {
					'bool' : ['SimplyDebridResolver_enabled', 'SimplyDebridResolver_login'],
					'string' : ['SimplyDebridResolver_username', 'SimplyDebridResolver_password'],
				},
				'offset' : 77,
			},
			'smoozed' : {
				'authentication' : {
					'bool' : ['SmoozedResolver_enabled', 'SmoozedResolver_login'],
					'string' : ['SmoozedResolver_username', 'SmoozedResolver_password'],
				},
				'offset' : 83,
			},
		}
		try: data = Tools.update(data, self.Authentication)
		except: pass
		return data

###################################################################
# RESOLVEURL
###################################################################

class ResolveUrl(Resolver):

	Id = 'resolveurl'
	Name = 'ResolveUrl'
	Addon = Extensions.IdResolveUrl

	Authentication = {
	}

###################################################################
# URLRESOLVER
###################################################################

class UrlResolver(Resolver):

	Id = 'urlresolver'
	Name = 'UrlResolver'
	Addon = Extensions.IdUrlResolver

	Authentication = {
		'linksnappy' : {
			'offset' : 28,
		},
		'megadebrid' : {
			'offset' : 39,
		},
		'rapidpremium' : {
			'offset' : 71,
		},
		'simplydebrid' : {
			'offset' : 78,
		},
		'smoozed' : {
			'offset' : 84,
		},
	}

###################################################################
# OPESCRAPERS
###################################################################

class OpeScrapers(object):

	Name = 'OpenScrapers'

	IdAddon = Extensions.IdOpeScrapers
	IdLibrary = 'openscrapers'
	IdGaia = 'opescrapersx'

	@classmethod
	def settings(self):
		Extensions.settings(id = OpeScrapers.IdAddon)

	@classmethod
	def providers(self, settings = True):
		from lib.providers.core.manager import Manager
		from lib.providers.core.base import ProviderBase
		Manager.settings(addon = OpeScrapers.IdGaia, type = ProviderBase.TypeExternal, mode = ProviderBase.ModeUniversal, access = ProviderBase.AccessOpen, settings = settings)

	@classmethod
	def installed(self):
		return Extensions.installed(id = OpeScrapers.IdAddon)

	@classmethod
	def enable(self, refresh = False, settings = False):
		result = Extensions.enable(id = OpeScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

	@classmethod
	def disable(self, refresh = False, settings = False):
		result = Extensions.disable(id = OpeScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

###################################################################
# FENSCRAPERS
###################################################################

class FenScrapers(object):

	Name = 'FenomScrapers'

	IdAddon = Extensions.IdFenScrapers
	IdLibrary = 'fenomscrapers'
	IdGaia = 'fenscrapersx'

	@classmethod
	def settings(self):
		Extensions.settings(id = FenScrapers.IdAddon)

	@classmethod
	def providers(self, settings = True):
		from lib.providers.core.manager import Manager
		from lib.providers.core.base import ProviderBase
		Manager.settings(addon = FenScrapers.IdGaia, type = ProviderBase.TypeExternal, mode = ProviderBase.ModeUniversal, access = ProviderBase.AccessOpen, settings = settings)

	@classmethod
	def installed(self):
		return Extensions.installed(id = FenScrapers.IdAddon)

	@classmethod
	def enable(self, refresh = False, settings = False):
		result = Extensions.enable(id = FenScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

	@classmethod
	def disable(self, refresh = False, settings = False):
		result = Extensions.disable(id = FenScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

###################################################################
# OATSCRAPERS
###################################################################

class OatScrapers(object):

	Name = 'OathScrapers'

	IdAddon = Extensions.IdOatScrapers
	IdLibrary = 'oathscrapers'
	IdGaia = 'oatscrapersx'

	@classmethod
	def settings(self):
		Extensions.settings(id = OatScrapers.IdAddon)

	@classmethod
	def providers(self, settings = True):
		from lib.providers.core.manager import Manager
		from lib.providers.core.base import ProviderBase
		Manager.settings(addon = OatScrapers.IdGaia, type = ProviderBase.TypeExternal, mode = ProviderBase.ModeUniversal, access = ProviderBase.AccessOpen, settings = settings)

	@classmethod
	def installed(self):
		return Extensions.installed(id = OatScrapers.IdAddon)

	@classmethod
	def enable(self, refresh = False, settings = False):
		result = Extensions.enable(id = OatScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

	@classmethod
	def disable(self, refresh = False, settings = False):
		result = Extensions.disable(id = OatScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

###################################################################
# LAMSCRAPERS
###################################################################

class LamScrapers(object):

	Name = 'LambdaScrapers'

	IdAddon = Extensions.IdLamScrapers
	IdLibrary = 'lambdascrapers'
	IdGaia = 'lamscrapersx'

	@classmethod
	def settings(self):
		Extensions.settings(id = LamScrapers.IdAddon)

	@classmethod
	def providers(self, settings = True):
		from lib.providers.core.manager import Manager
		from lib.providers.core.base import ProviderBase
		Manager.settings(addon = LamScrapers.IdGaia, type = ProviderBase.TypeExternal, mode = ProviderBase.ModeUniversal, access = ProviderBase.AccessOpen, settings = settings)

	@classmethod
	def installed(self):
		return Extensions.installed(id = LamScrapers.IdAddon)

	@classmethod
	def enable(self, refresh = False, settings = False):
		result = Extensions.enable(id = LamScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

	@classmethod
	def disable(self, refresh = False, settings = False):
		result = Extensions.disable(id = LamScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

###################################################################
# CIVSCRAPERS
###################################################################

class CivScrapers(object):

	Name = 'CivitasScrapers'

	IdAddon = Extensions.IdCivScrapers
	IdLibrary = 'civitasscrapers'
	IdGaia = 'civscrapersx'

	@classmethod
	def settings(self):
		Extensions.settings(id = CivScrapers.IdAddon)

	@classmethod
	def providers(self, settings = True):
		from lib.providers.core.manager import Manager
		from lib.providers.core.base import ProviderBase
		Manager.settings(addon = CivScrapers.IdGaia, type = ProviderBase.TypeExternal, mode = ProviderBase.ModeUniversal, access = ProviderBase.AccessOpen, settings = settings)

	@classmethod
	def installed(self):
		return Extensions.installed(id = CivScrapers.IdAddon)

	@classmethod
	def enable(self, refresh = False, settings = False):
		result = Extensions.enable(id = CivScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

	@classmethod
	def disable(self, refresh = False, settings = False):
		result = Extensions.disable(id = CivScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

###################################################################
# GLOSCRAPERS
###################################################################

class GloScrapers(object):

	Name = 'GlobalScrapers'

	IdAddon = Extensions.IdGloScrapers
	IdLibrary = 'globalscrapers'
	IdGaia = 'gloscrapersx'

	@classmethod
	def settings(self):
		Extensions.settings(id = GloScrapers.IdAddon)

	@classmethod
	def providers(self, settings = True):
		from lib.providers.core.manager import Manager
		from lib.providers.core.base import ProviderBase
		Manager.settings(addon = GloScrapers.IdGaia, type = ProviderBase.TypeExternal, mode = ProviderBase.ModeUniversal, access = ProviderBase.AccessOpen, settings = settings)

	@classmethod
	def installed(self):
		return Extensions.installed(id = GloScrapers.IdAddon)

	@classmethod
	def enable(self, refresh = False, settings = False):
		result = Extensions.enable(id = GloScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

	@classmethod
	def disable(self, refresh = False, settings = False):
		result = Extensions.disable(id = GloScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

###################################################################
# UNISCRAPERS
###################################################################

class UniScrapers(object):

	Name = 'UniversalScrapers'

	IdAddon = Extensions.IdUniScrapers
	IdLibrary = 'universalscrapers'
	IdGaia = 'uniscrapersx'

	@classmethod
	def settings(self):
		Extensions.settings(id = UniScrapers.IdAddon)

	@classmethod
	def providers(self, settings = True):
		from lib.providers.core.manager import Manager
		from lib.providers.core.base import ProviderBase
		Manager.settings(addon = UniScrapers.IdGaia, type = ProviderBase.TypeExternal, mode = ProviderBase.ModeUniversal, access = ProviderBase.AccessOpen, settings = settings)

	@classmethod
	def installed(self):
		return Extensions.installed(id = UniScrapers.IdAddon)

	@classmethod
	def enable(self, refresh = False, settings = False):
		result = Extensions.enable(id = UniScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

	@classmethod
	def disable(self, refresh = False, settings = False):
		result = Extensions.disable(id = UniScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

###################################################################
# NANSCRAPERS
###################################################################

class NanScrapers(object):

	Name = 'NanScrapers'

	IdAddon = Extensions.IdNanScrapers
	IdLibrary = 'nanscrapers'
	IdGaia = 'nanscrapersx'

	@classmethod
	def settings(self):
		Extensions.settings(id = NanScrapers.IdAddon)

	@classmethod
	def providers(self, settings = True):
		from lib.providers.core.manager import Manager
		from lib.providers.core.base import ProviderBase
		Manager.settings(addon = NanScrapers.IdGaia, type = ProviderBase.TypeExternal, mode = ProviderBase.ModeUniversal, access = ProviderBase.AccessOpen, settings = settings)

	@classmethod
	def installed(self):
		return Extensions.installed(id = NanScrapers.IdAddon)

	@classmethod
	def enable(self, refresh = False, settings = False):
		result = Extensions.enable(id = NanScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

	@classmethod
	def disable(self, refresh = False, settings = False):
		result = Extensions.disable(id = NanScrapers.IdAddon, refresh = refresh)
		if settings: Settings.launch(Settings.CategoryProvider)
		return result

###################################################################
# YOUTUBE
###################################################################

class YouTube(object):

	Id = Extensions.IdYouTube
	Website = 'https://youtube.com'

	@classmethod
	def settings(self, settings = False):
		Extensions.settings(id = YouTube.Id, wait = settings)
		if settings: self.settingsLocal('settings')

	@classmethod
	def settingsLocal(self, type = None):
		if type is None: type = 'connection' if self.installed() else 'installation'
		Settings.launch('stream.youtube.' + type)

	@classmethod
	def launch(self):
		Extensions.launch(id = YouTube.Id)

	@classmethod
	def installed(self):
		return Extensions.installed(id = YouTube.Id)

	@classmethod
	def enable(self, refresh = False, settings = False):
		result = Extensions.enable(id = YouTube.Id, refresh = refresh)
		if settings: self.settingsLocal('settings')
		return result

	@classmethod
	def disable(self, refresh = False):
		return Extensions.disable(id = YouTube.Id, refresh = refresh)

	@classmethod
	def website(self, open = False):
		if open: System.openLink(YouTube.Website)
		return YouTube.Website

###################################################################
# UPNEXT
###################################################################

class UpNext(object):

	Id = Extensions.IdUpNext

	@classmethod
	def settings(self):
		Extensions.settings(id = UpNext.Id)

	@classmethod
	def installed(self):
		return Extensions.installed(id = UpNext.Id)

	@classmethod
	def enable(self, refresh = False):
		return Extensions.enable(id = UpNext.Id, refresh = refresh)

	@classmethod
	def disable(self, refresh = False):
		return Extensions.disable(id = UpNext.Id, refresh = refresh)

###################################################################
# METAHANDLER
###################################################################

class MetaHandler(object):

	Id = Extensions.IdMetaHandler

	@classmethod
	def settings(self):
		Extensions.settings(id = MetaHandler.Id)

	@classmethod
	def installed(self):
		return Extensions.installed(id = MetaHandler.Id)

	@classmethod
	def enable(self, refresh = False):
		return Extensions.enable(id = MetaHandler.Id, refresh = refresh)

	@classmethod
	def disable(self, refresh = False):
		return Extensions.disable(id = MetaHandler.Id, refresh = refresh)

###################################################################
# BACKUP
###################################################################

class Backup(object):

	Extension = 'zip'
	Directory = 'Backups'

	TypeEverything = 'everything'
	TypeSettings = 'settings'
	TypeDatabases = 'databases'

	ResultFailure = 'failure'
	ResultPartial = 'partial'
	ResultSuccess = 'success'
	ResultVersion = 'version'

	@classmethod
	def _path(self, clear = False):
		return System.temporary(directory = 'backup', gaia = True, make = True, clear = clear)

	@classmethod
	def _name(self):
		from lib.modules import interface
		from lib.modules import convert
		date = convert.ConverterTime(Time.timestamp(), convert.ConverterTime.FormatTimestamp).string(convert.ConverterTime.FormatDateTime)
		date = date.replace(':', '.') # Windows does not support colons in file names.
		return System.name() + ' ' + interface.Translation.string(33773) + ' '+ date + '%s.' + Backup.Extension

	@classmethod
	def _import(self, path):
		try:
			Logger.log('Importing Settings Backup')

			directory = self._path(clear = True)
			directoryData = System.profile()

			import zipfile
			file = zipfile.ZipFile(path, 'r')

			# Do not allow to import old settings backups.
			with file.open('settings.xml') as subfile:
				version = Regex.extract(data = Converter.unicode(subfile.read()), expression = 'id\s*=\s*"internal.version".*?>(.*?)<')
				version = int(version.replace('.', ''))
				if version < 600:
					file.close()
					return Backup.ResultVersion

			file.extractall(directory)
			file.close()

			directories, files = File.listDirectory(directory)
			counter = 0
			for file in files:
				fileFrom = File.joinPath(directory, file)
				fileTo = File.joinPath(directoryData, file)
				if File.move(fileFrom, fileTo, replace = True):
					counter += 1

			File.deleteDirectory(path = directory, force = True)

			Hardware.identifierReset()
			Settings.cacheClear() # Clear the data from the old file.

			if counter == 0: return Backup.ResultFailure
			elif counter == len(files): return Backup.ResultSuccess
			else: return Backup.ResultPartial
		except:
			return Backup.ResultFailure

	@classmethod
	def _export(self, type, path, automatic = False):
		try:
			Logger.log('Exporting Settings Backup')

			File.makeDirectory(path)
			name = self._name()
			path = File.joinPath(path, name)
			if automatic:
				path = path % ''
			else:
				counter = 0
				suffix = ''
				while File.exists(path % suffix):
					counter += 1
					suffix = ' [%d]' % counter
				path = path % suffix

			import zipfile
			file = zipfile.ZipFile(path, 'w')

			content = []
			directory = self._path(clear = True)
			directoryData = System.profile()
			directories, files = File.listDirectory(directoryData)

			from lib.modules import database
			settingsDatabase = (Settings.Database + database.Database.Extension).lower()

			if type == Backup.TypeEverything or type == Backup.TypeSettings:
				settings = ['settings.xml', settingsDatabase]
				for i in range(len(files)):
					if files[i].lower() in settings:
						content.append(files[i])

			if type == Backup.TypeEverything or type == Backup.TypeDatabases:
				extension = '.db'
				for i in range(len(files)):
					if files[i].lower().endswith(extension) and not files[i].lower() == settingsDatabase:
						content.append(files[i])

			tos = [File.joinPath(directory, i) for i in content]
			froms = [File.joinPath(directoryData, i) for i in content]

			for i in range(len(content)):
				try:
					File.copy(froms[i], tos[i], overwrite = True)
					file.write(tos[i], content[i])
				except: pass

			file.close()
			File.deleteDirectory(path = directory, force = True)
			return Backup.ResultSuccess
		except:
			Logger.error()
			return Backup.ResultFailure

	@classmethod
	def automaticPath(self):
		return File.joinPath(System.profile(), Backup.Directory)

	@classmethod
	def automaticClear(self):
		return File.deleteDirectory(self.automaticPath())

	@classmethod
	def automaticClean(self):
		limit = Settings.getInteger('general.settings.backup.limit', cached = False)
		path = self.automaticPath()
		directories, files = File.listDirectory(path)
		count = len(files)
		if count >= limit:
			files.sort(reverse = False)
			i = 0
			while count >= limit:
				File.delete(File.joinPath(path, files[i]), force = True)
				i += 1
				count -= 1

	@classmethod
	def automaticImport(self, force = False):
		try:
			from lib.modules import interface

			# The problem here is that if the settings are corrupt, the user's preferences, set previously, cannot be determined.
			# Hence, always load the last backup if settings are corrupt. Then check if automatic/selection was enabled.
			# If automatic, don't do anything further.
			# If selection, ask the user which backup to load.

			# For some reasons the setting returns nothing, but when getting it again immediately afterwards, it returns a value.
			timestamp = Settings.getInteger('general.settings.backup.time', cached = False)
			if not timestamp:
				Time.sleep(0.5)
				timestamp = Settings.getInteger('general.settings.backup.time', cached = False)

			if force or (not timestamp and File.existsDirectory(self.automaticPath())):
				directories, files = File.listDirectory(self.automaticPath())
				Settings.set('general.settings.backup.time', Time.timestamp(), cached = True)

				if len(files) > 0:
					files.sort(reverse = True)
					result = self._import(path = File.joinPath(self.automaticPath(), files[0]))
					if result == Backup.ResultSuccess or result == Backup.ResultPartial:
						Settings.set('general.settings.backup.time', Time.timestamp(), cached = True)

					if not Settings.getBoolean('general.settings.backup.enabled', cached = False):
						return False

					restore = Settings.getInteger('general.settings.backup.restore', cached = False)
					choice = -1
					if not force and restore == 0:
						choice = 0
					elif force or (restore == 1 and interface.Dialog.option(title = 33773, message = 35210)):
						items = [interface.Format.fontBold(re.search('\\d*-\\d*-\\d*\\s*\\d*\\.\\d*\\.\\d*', file).group(0).replace('.', ':')) for file in files]
						choice = interface.Dialog.select(title = 33773, items = items)

					if choice >= 0:
						result = self._import(path = File.joinPath(self.automaticPath(), files[choice]))
						if result == Backup.ResultSuccess or result == Backup.ResultPartial:
							Settings.set('general.settings.backup.time', Time.timestamp(), cached = True)
							interface.Dialog.notification(title = 33773, message = 35211, icon = interface.Dialog.IconSuccess)
						return result == Backup.ResultSuccess

					return False

			# Not returned from the inner if.
			if force: interface.Dialog.notification(title = 33773, message = 35247, icon = interface.Dialog.IconError)
			return False
		except:
			Logger.error()
		return False

	@classmethod
	def automaticExport(self, force = False):
		try:
			if Settings.getBoolean('general.settings.backup.enabled', cached = False) or force:
				self.automaticClean()
				Settings.set('general.settings.backup.time', Time.timestamp(), cached = True)
				return self._export(type = Backup.TypeSettings, path = self.automaticPath(), automatic = True) == Backup.ResultSuccess
		except:
			Logger.error()
		return False

	@classmethod
	def automatic(self):
		from lib.modules import interface

		interface.Dialog.confirm(title = 33773, message = 35209)

		items = [
			interface.Format.bold(interface.Translation.string(33774) + ':') + ' ' + interface.Translation.string(35214),
			interface.Format.bold(interface.Translation.string(35212) + ':') + ' ' + interface.Translation.string(35215),
			interface.Format.bold(interface.Translation.string(33011) + ':') + ' ' + interface.Translation.string(35216),
		]

		choice = interface.Dialog.select(title = 33773, items = items)
		if choice == 0:
			if interface.Dialog.option(title = 33773, message = 35217):
				self.automaticImport(force = True)
		elif choice == 1:
			if self.automaticExport(force = True):
				interface.Dialog.notification(title = 33773, message = 35218, icon = interface.Dialog.IconSuccess)
			else:
				interface.Dialog.notification(title = 33773, message = 35219, icon = interface.Dialog.IconError)
		elif choice == 2:
			Settings.launch(Settings.CategoryGeneral)

	@classmethod
	def manualImport(self):
		from lib.modules import interface

		choice = interface.Dialog.option(title = 33773, message = 33782)
		if not choice: return

		path = interface.Dialog.browse(title = 33773, type = interface.Dialog.BrowseFile, mask = Backup.Extension)
		result = self._import(path = path)

		if result == Backup.ResultSuccess:
			interface.Dialog.notification(title = 33773, message = 33785, icon = interface.Dialog.IconSuccess)
		elif result == Backup.ResultPartial:
			interface.Dialog.confirm(title = 33773, message = interface.Translation.string(33783) % System.id())
		elif result == Backup.ResultVersion:
			interface.Dialog.confirm(title = 33773, message = 33980)
		else:
			interface.Dialog.confirm(title = 33773, message = 33778)

	@classmethod
	def manualExport(self):
		from lib.modules import interface

		choice = interface.Dialog.option(title = 33773, message = 35213)
		if not choice: return

		types = [
			Backup.TypeEverything,
			Backup.TypeSettings,
			Backup.TypeDatabases,
		]
		items = [
			interface.Format.bold(interface.Translation.string(33776) + ':') + ' ' + interface.Translation.string(33779),
			interface.Format.bold(interface.Translation.string(33011) + ':') + ' ' + interface.Translation.string(33780),
			interface.Format.bold(interface.Translation.string(33775) + ':') + ' ' + interface.Translation.string(33781),
		]

		choice = interface.Dialog.select(title = 33773, items = items)
		if choice >= 0:
			path = interface.Dialog.browse(title = 33773, type = interface.Dialog.BrowseDirectoryWrite)
			result = self._export(type = types[choice], path = path)

			if result == Backup.ResultSuccess:
				interface.Dialog.notification(title = 33773, message = 33784, icon = interface.Dialog.IconSuccess)
			else:
				interface.Dialog.confirm(title = 33773, message = 33777)

	@classmethod
	def directImport(self, path):
		from lib.modules import interface
		self._import(path)
		interface.Dialog.notification(title = 33773, message = 35326, icon = interface.Dialog.IconSuccess)

	'''
	msgctxt "#33229"
	msgid "This option will replace the internal settings structure of Gaia with a structure from a remote source. You can therefore use other third-party developers' settings instead of the one provided by Gaia."

	msgctxt "#33230"
	msgid "Only continue if you know what you are doing and if you have informed yourself on Reddit or similar site about this feature."

	msgctxt "#35538"
	msgid "Settings Replacement Successful - Restart Kodi"

	msgctxt "#35539"
	msgid "Settings Replacement Failure"

	@classmethod
	def replace(self):
		from lib.modules import interface
		from lib.modules import network
		if interface.Dialog.option(title = 33011, message = 33229, labelConfirm = 33821, labelDeny = 33743):
			if interface.Dialog.option(title = 33011, message = 33230, labelConfirm = 33821, labelDeny = 33743):
				link = interface.Dialog.input(title = 35540)
				interface.Loader.show()
				success = network.Networker().download(link = link, path = Settings.pathAddon())
				interface.Loader.hide()
				if success: interface.Dialog.notification(title = 33011, message = 35538, icon = interface.Dialog.IconSuccess)
				else: interface.Dialog.notification(title = 33011, message = 35539, icon = interface.Dialog.IconError)
				return success
		return False'''

###################################################################
# DONATIONS
###################################################################

class Donations(object):

	# Type
	TypeNone = None
	TypePaypal = 'paypal'
	TypeBitcoin = 'bitcoin'
	TypeBitcoinCash = 'bitcoincash'
	TypeDash = 'dash'
	TypeEthereum = 'ethereum'
	TypeLitecoin = 'litecoin'
	TypeRipple = 'ripple'
	TypeZcash = 'zcash'
	TypeMonero = 'monero'
	TypeDogecoin = 'dogecoin'

	# Popup
	PopupThreshold = 50

	@classmethod
	def donor(self):
		return System.developers() or Settings.getString('general.advanced.code') == Converter.base64From('ZG9ub3I=')

	@classmethod
	def coinbase(self, openLink = True):
		link = Settings.getString('internal.link.coinbase')
		if openLink: System.openLink(link)
		return link

	@classmethod
	def exodus(self, openLink = True):
		link = Settings.getString('internal.link.exodus')
		if openLink: System.openLink(link)
		return link

	@classmethod
	def other(self, openLink = True):
		link = Settings.getString('internal.link.donation')
		if openLink: System.openLink(link)
		from lib.modules import interface
		return interface.Splash.popupDonations()
		return link

	@classmethod
	def show(self, type = None):
		if type == None:
			System.window(action = 'donationsNavigator')
		else:
			from lib.modules import interface
			from lib.modules import api
			data = api.Api.donations(type)
			return interface.Splash.popupDonations(donation = data)

	@classmethod
	def popup(self, wait = False):
		thread = threading.Thread(target = self._popup)
		thread.start()
		if wait: thread.join()

	@classmethod
	def _popup(self):
		from lib.modules import interface
		if not self.donor():
			counter = Settings.getInteger('internal.donation')
			counter += 1
			if counter >= Donations.PopupThreshold:
				Settings.set('internal.donation', 0)
				if interface.Dialog.option(title = 33505, message = 35014, labelConfirm = 33505, labelDeny = 35015):
					self.show()
					interface.Loader.hide()
					return True
			else:
				Settings.set('internal.donation', counter)
		interface.Loader.hide()
		return False

	@classmethod
	def types(self):
		return [
			{
				'identifier' : Donations.TypePaypal,
				'name' : 'PayPal',
				'color' : '029BDE',
				'icon' : 'donationspaypal.png',
			},
			{
				'identifier' : Donations.TypeBitcoin,
				'name' : 'Bitcoin',
				'color' : 'F7931A',
				'icon' : 'donationsbitcoin.png',
			},
			{
				'identifier' : Donations.TypeBitcoinCash,
				'name' : 'Bitcoin Cash',
				'color' : '2DB300',
				'icon' : 'donationsbitcoincash.png',
			},
			{
				'identifier' : Donations.TypeEthereum,
				'name' : 'Ethereum',
				'color' : '62688F',
				'icon' : 'donationsethereum.png',
			},
			{
				'identifier' : Donations.TypeLitecoin,
				'name' : 'Litecoin',
				'color' : 'A7A7A7',
				'icon' : 'donationslitecoin.png',
			},
			{
				'identifier' : Donations.TypeDogecoin,
				'name' : 'Dogecoin',
				'color' : 'BA9F33',
				'icon' : 'donationsdogecoin.png',
			},
			{
				'identifier' : Donations.TypeRipple,
				'name' : 'Ripple',
				'color' : '00A3DB',
				'icon' : 'donationsripple.png',
			},
			{
				'identifier' : Donations.TypeMonero,
				'name' : 'Monero',
				'color' : 'FF6600',
				'icon' : 'donationsmonero.png',
			},
			{
				'identifier' : Donations.TypeZcash,
				'name' : 'Zcash',
				'color' : 'F5BA0D',
				'icon' : 'donationszcash.png',
			},
			{
				'identifier' : Donations.TypeDash,
				'name' : 'Dash',
				'color' : '2588DC',
				'icon' : 'donationsdash.png',
			},
		]

###################################################################
# PLAYLIST
###################################################################

class Playlist(object):

	Id = xbmc.PLAYLIST_VIDEO

	@classmethod
	def playlist(self):
		return xbmc.PlayList(Playlist.Id)

	@classmethod
	def show(self):
		from lib.modules import window
		window.Window.show(window.Window.IdWindowPlaylist)

	@classmethod
	def clear(self, notification = True):
		self.playlist().clear()
		if notification:
			from lib.modules import interface
			interface.Dialog.notification(title = 35515, message = 35521, icon = interface.Dialog.IconSuccess)

	@classmethod
	def items(self):
		try: return [i['label'] for i in System.executeJson(method = 'Playlist.GetItems', parameters = {'playlistid' : Playlist.Id})['result']['items']]
		except: return []

	@classmethod
	def empty(self):
		return len(self.items()) == 0

	@classmethod
	def contains(self, label):
		return label in self.items()

	@classmethod
	def position(self, label):
		try: return self.items().index(label)
		except: return -1

	@classmethod
	def add(self, link = None, label = None, metadata = None, art = None, context = None, notification = True):
		if link == None:
			System.execute('Action(Queue)')
		else:
			if Tools.isString(metadata): metadata = Converter.jsonFrom(metadata)
			if Tools.isString(art): art = Converter.jsonFrom(art)
			if Tools.isString(context): context = Converter.jsonFrom(context)

			item = xbmcgui.ListItem(label = label)
			item.setArt(art)
			item.setInfo(type = 'Video', infoLabels = Media.metadataClean(metadata))

			# Use the global context menu instead.
			'''if not context == None:
				from lib.modules import interface
				menu = interface.Context()
				menu.jsonFrom(context)
				item.addContextMenuItems([menu.menu()])'''

			self.playlist().add(url = link, listitem = item)
			if notification:
				from lib.modules import interface
				interface.Dialog.notification(title = 35515, message = 35519, icon = interface.Dialog.IconSuccess)

	@classmethod
	def remove(self, label, notification = True):
		#self.playlist().remove(link) # This doesn't seem to work all the time.
		position = self.position(label = label)
		if position >= 0:
			System.executeJson(method = 'Playlist.Remove', parameters = {'playlistid' : Playlist.Id, 'position' : position})
			if notification:
				from lib.modules import interface
				interface.Dialog.notification(title = 35515, message = 35520, icon = interface.Dialog.IconSuccess)

###################################################################
# STATISTICS
###################################################################

class Statistics(object):

	@classmethod
	def enabled(self):
		# Do not share if developer is enabled or sharing is switched off.
		return not System.developers() and self.sharing()

	@classmethod
	def enable(self, enable = True):
		Settings.set('general.statistics.sharing', enable)

	@classmethod
	def sharing(self):
		return Settings.getBoolean('general.statistics.sharing')

	@classmethod
	def share(self, wait = False):
		thread = threading.Thread(target = self._share)
		thread.start()
		if wait: thread.join()

	@classmethod
	def _share(self):
		try:
			if not self.enabled(): return

			from lib import debrid
			from lib.modules import api
			from lib.modules import network
			from lib.modules import orionoid

			orion = orionoid.Orionoid()
			data = {
				'version' : System.version(),
				'orion' : orion.accountValid(),

				'system' : System.informationSystem(),
				'python' : System.informationPython(),
				'kodi' : System.informationKodi(),

				'hardware' :
				{
					'processors' : Hardware.processors(),
					'memory' : Hardware.memory(),
				},

				'premium' :
				{
					'premiumize' : debrid.premiumize.Core().accountValid(),
					'offcloud' : debrid.offcloud.Core().accountValid(),
					'realdebrid' : debrid.realdebrid.Core().accountValid(),
					'easynews' : debrid.easynews.Core().accountValid(),
				},
			}

			if self.sharing():
				information = network.Information.retrieve(obfuscate = True)
				information = information['global']

				# Strip important data to make it anonymous.
				information['connection']['address'] = None
				information['connection']['name'] = None
				information['location']['coordinates']['latitude'] = None
				information['location']['coordinates']['longitude'] = None

				data.update(information)

			api.Api.deviceUpdate(data = data)
		except:
			Logger.error()

###################################################################
# BINGE
###################################################################

class Binge(object):

	ModeNone = 0
	ModeFirst = 1
	ModeContinue = 2
	ModeBackground = 3

	DialogNone = 0
	DialogFull = 1
	DialogOverlay = 2
	DialogUpNext = 3

	ActionContinue = 0
	ActionCancel = 1

	ActionInterrupt = 0
	ActionFinish = 1

	@classmethod
	def enabled(self):
		return Settings.getBoolean('playback.binge.enabled')

	@classmethod
	def dialog(self):
		return Settings.getInteger('playback.binge.dialog')

	@classmethod
	def dialogNone(self):
		return self.dialog() == Binge.DialogNone

	@classmethod
	def dialogFull(self):
		return self.dialog() == Binge.DialogFull

	@classmethod
	def dialogOverlay(self):
		return self.dialog() == Binge.DialogOverlay

	@classmethod
	def dialogUpNext(self):
		return self.dialog() == Binge.DialogUpNext

	@classmethod
	def delay(self):
		return Settings.getInteger('playback.binge.delay')

	@classmethod
	def suppress(self):
		return Settings.getBoolean('playback.binge.suppress')

	@classmethod
	def actionNone(self):
		return Settings.getInteger('playback.binge.action.none')

	@classmethod
	def actionContinue(self):
		return Settings.getInteger('playback.binge.action.continue')

	@classmethod
	def actionCancel(self):
		return Settings.getInteger('playback.binge.action.cancel')

###################################################################
# ANNOUNCEMENT
###################################################################

class Announcements(object):

	@classmethod
	def show(self, force = False, wait = False, sleep = False):
		thread = threading.Thread(target = self._show, args = (force, sleep))
		thread.start()
		if wait: thread.join()

	@classmethod
	def _show(self, force = False, sleep = False):
		from lib.modules import api
		from lib.modules import interface
		if sleep: Time.sleep(2) # Wait a bit so that everything has been loaded.
		last = Settings.getInteger('internal.announcement')
		if force:
			interface.Loader.show()
			result = api.Api.announcements(version = System.version())
		else:
			result = api.Api.announcements(last = last, version = System.version())
		try:
			time = result['time']
			mode = result['mode']
			text = result['format']
			if not force: Settings.set('internal.announcement', time)
			if mode == 'dialog': interface.Dialog.confirm(title = 33962, message = text)
			elif mode == 'splash': interface.Splash.popupMessage(message = text)
			elif mode == 'page': interface.Dialog.text(title = 33962, message = text)
		except: pass
		if force: interface.Loader.hide()

###################################################################
# PROMOTIONS
###################################################################

class Promotions(object):

	Cache = None
	OrionAnonymous = 'orionanonymous'

	@classmethod
	def update(self, wait = False, refresh = True):
		thread = threading.Thread(target = self._update, args = (refresh,))
		thread.start()

	@classmethod
	def _update(self, refresh = True):
		try:
			from lib.modules import api
			self._cache()
			enabled = self.enabled()
			result = []
			promotions = api.Api.promotions()
			for i in promotions:
				i['viewed'] = False
				for j in Promotions.Cache:
					if i['id'] == j['id']:
						i['viewed'] = j['viewed']
						break
				result.append(i)
			self._cacheUpdate(result)
			if refresh and self.enabled() and not enabled:
				from lib.modules import interface
				interface.Directory.refresh(clear = True)
		except: pass

	@classmethod
	def _cache(self):
		if Promotions.Cache == None: Promotions.Cache = Settings.getList('internal.promotions')
		return Promotions.Cache

	@classmethod
	def _cacheUpdate(self, data = None):
		if not data == None: Promotions.Cache = data
		Settings.set('internal.promotions', Promotions.Cache)

	@classmethod
	def _fixed(self):
		try:
			from lib.modules import interface
			from lib.modules import orionoid
			orion = orionoid.Orionoid()
			return [{
				'id' : Promotions.OrionAnonymous,
				'viewed' : not orion.accountPromotionEnabled(),
				'provider' : 'Orion',
				'start' : Time.timestamp(),
				'expiration' : None,
				'title' : interface.Translation.string(35428),
			}]
		except:
			Logger.error()

	@classmethod
	def enabled(self):
		try:
			from lib.modules import orionoid
			if not Settings.getBoolean('navigation.menu.promotion'): return False
			elif orionoid.Orionoid().accountPromotionEnabled(): return True
			current = Time.timestamp()
			for i in self._cache():
				if not i['viewed'] and (i['expiration'] == None or i['expiration'] > current):
					return True
		except:
			Logger.error()
		return False

	@classmethod
	def navigator(self, force = False):
		from lib.modules import interface

		if force:
			interface.Loader.show()
			self.update(wait = True, refresh = False)
			interface.Loader.hide()
		elif not Settings.getBoolean('internal.initial.promotions'):
			Settings.set('internal.initial.promotions', True)
			interface.Dialog.confirm(title = 35442, message = 35445)

		items = []
		promotions = [i['provider'] for i in self._fixed()]
		lower = []
		for i in self._cache():
			if not i['provider'] in promotions:
				promotions.append(i['provider'])
				lower.append(i['provider'].lower())

		if len(promotions) == 0:
			interface.Dialog.notification(title = 35443, message = 35444, icon = interface.Dialog.IconNativeInformation)
		else:
			# Use a specific order.
			for i in ['orion', 'premiumize', 'offcloud', 'realdebrid']:
				try:
					i = lower.index(i)
					items.append(promotions[i])
					del promotions[i]
					del lower[i]
				except: pass
			items.extend(promotions)

			directory = interface.Directory()
			for i in items:
				directory.add(label = i, action = 'promotionsSelect', parameters = {'provider' : i}, icon = '%s.png' % (i.lower() if interface.Icon.exists(i.lower()) else 'promotion'), iconDefault = 'DefaultAddonProgram.png')
			directory.finish()

	@classmethod
	def select(self, provider):
		from lib.modules import interface
		from lib.modules import convert

		current = Time.timestamp()
		promotions = []
		items = Tools.copy(self._cache()) # Deep copy becuase we append Orion.

		if provider.lower() == 'orion':
			items.extend(self._fixed())

		for i in items:
			if i['provider'].lower() == provider.lower():
				if i['expiration']:
					time = i['expiration'] - current
					if time < 0: continue
					time = convert.ConverterDuration(value = time, unit = convert.ConverterDuration.UnitSecond).string(format = convert.ConverterDuration.FormatWordMinimal).title()
					time += ' ' + interface.Translation.string(35449)
				else:
					time = interface.Translation.string(35446)
				status = interface.Translation.string(35448 if i['viewed'] else 35447)
				status = '[%s]' % status
				status = interface.Format.font(status, bold = True, color = interface.Format.colorPoor() if i['viewed'] else interface.Format.colorExcellent())
				promotions.append({
					'id' : i['id'],
					'title' : '%s %s: %s' % (status, i['title'], time),
					'time' : i['start'],
				})
		promotions = sorted(promotions, key = lambda i : i['time'], reverse = True)

		choice = interface.Dialog.select(title = provider + ' ' + interface.Translation.string(provider), items = [i['title'] for i in promotions])
		if choice >= 0:
			choice = promotions[choice]['id']
			if choice == Promotions.OrionAnonymous:
				try:
					from lib.modules import orionoid
					orionoid.Orionoid().accountPromotion()
				except: Logger.error()
			else:
				for i in range(len(Promotions.Cache)):
					if Promotions.Cache[i]['id'] == choice:
						Promotions.Cache[i]['viewed'] = True
						self._cacheUpdate()
						message = interface.Format.fontBold(Promotions.Cache[i]['title']) + interface.Format.newline()
						if Promotions.Cache[i]['expiration']: message += interface.Format.newline() + interface.Format.fontBold('Expiration: ') + convert.ConverterTime(Promotions.Cache[i]['expiration']).string(format = convert.ConverterTime.FormatDateTime)
						if Promotions.Cache[i]['link']: message += interface.Format.newline() + interface.Format.fontBold('Link: ') + interface.Format.fontItalic(Promotions.Cache[i]['link'])
						if Promotions.Cache[i]['expiration'] or Promotions.Cache[i]['link']: message += interface.Format.newline()
						message += interface.Format.newline() + Promotions.Cache[i]['description'] + interface.Format.newline()
						interface.Dialog.text(title = Promotions.Cache[i]['provider'] +' ' + interface.Translation.string(35442), message = message)
						break

###################################################################
# RATER
###################################################################

class Rater(object):

	ModeRating = 'rating'
	ModeVotes = 'votes'

	@classmethod
	def _extract(self, mode, item, own, order):
		if own: order.insert(0, 'own')
		for i in order:
			i = mode + i
			if i in item and item[i] and not item[i] == '0':
				if mode == Rater.ModeRating:
					try: return float(item[i])
					except: continue
				else:
					try: return int(item[i])
					except: continue
		return item[mode] if mode in item else None

	@classmethod
	def _average(self, item, own):
		ratingGlobal = []
		votesGlobal = []
		for i in ['imdb', 'tmdb', 'tvdb', 'trakt', 'tvmaze']:
			key = Rater.ModeRating + i
			if key in item and item[key] and not item[key] == '0':
				try:
					ratingGlobal.append(float(item[key]))
					found = False
					key = Rater.ModeVotes + i
					if key in item and item[key] and not item[key] == '0':
						try:
							votesGlobal.append(int(re.sub(',', '', item[key])))
							found = True
						except: pass
					if not found: votesGlobal.append(0)
				except: pass

		if len(ratingGlobal) == 0:
			try:
				ratingGlobal.append(float(item[Rater.ModeRating]))
				try: votesGlobal.append(int(re.sub(',', '', item[Rater.ModeVotes])))
				except: votesGlobal.append(0)
			except: pass

		rating = 0
		total = sum(votesGlobal)
		if own and 'ratingown' in item and item['ratingown'] and not item['ratingown'] == '0':
			rating = item['ratingown']
		elif total > 0:
			for i in range(len(ratingGlobal)):
				rating += (ratingGlobal[i] / total) * votesGlobal[i]

		return rating, total

	@classmethod
	def extract(self, item, mode = None):
		rating = None
		votes = None

		if 'tvshowtitle' in item or 'season' in item or 'episode' in item:
			type = Settings.getInteger('metadata.rating.show.type')
			own = Settings.getBoolean('metadata.rating.show.own')

			if type == 0:
				rating, votes = self._average(item = item, own = own)
				if mode == Rater.ModeRating: return rating
				if mode == Rater.ModeVotes: return votes
			else:
				if mode is None or mode == Rater.ModeRating:
					if type == 1: rating = self._extract(mode = Rater.ModeRating, item = item, own = own, order = ['imdb', 'tvdb', 'trakt', 'tvmaze'])
					elif type == 2: rating = self._extract(mode = Rater.ModeRating, item = item, own = own, order = ['trakt', 'imdb', 'tvdb', 'tvmaze'])
					elif type == 3: rating = self._extract(mode = Rater.ModeRating, item = item, own = own, order = ['tvdb', 'imdb', 'trakt', 'tvmaze'])
					elif type == 4: rating = self._extract(mode = Rater.ModeRating, item = item, own = own, order = ['tvmaze', 'imdb', 'tvdb', 'trakt'])
					if mode == Rater.ModeRating: return rating

				if mode is None or mode == Rater.ModeVotes:
					if type == 1: votes = self._extract(mode = Rater.ModeVotes, item = item, own = own, order = ['imdb', 'tvdb', 'trakt', 'tvmaze'])
					elif type == 2: votes = self._extract(mode = Rater.ModeVotes, item = item, own = own, order = ['trakt', 'imdb', 'tvdb', 'tvmaze'])
					elif type == 3: votes = self._extract(mode = Rater.ModeVotes, item = item, own = own, order = ['tvdb', 'imdb', 'trakt', 'tvmaze'])
					elif type == 4: votes = self._extract(mode = Rater.ModeVotes, item = item, own = own, order = ['tvmaze', 'imdb', 'tvdb', 'trakt'])
					if mode == Rater.ModeVotes: return votes
		else:
			type = Settings.getInteger('metadata.rating.movie.type')
			own = Settings.getBoolean('metadata.rating.movie.own')

			if type == 0:
				rating, votes = self._average(item = item, own = own)
				if mode == Rater.ModeRating: return rating
				if mode == Rater.ModeVotes: return votes
			else:
				if mode is None or mode == Rater.ModeRating:
					if type == 1: rating = self._extract(mode = Rater.ModeRating, item = item, own = own, order = ['imdb', 'tmdb', 'trakt'])
					elif type == 2: rating = self._extract(mode = Rater.ModeRating, item = item, own = own, order = ['trakt', 'imdb', 'tmdb'])
					elif type == 3: rating = self._extract(mode = Rater.ModeRating, item = item, own = own, order = ['tmdb', 'imdb', 'trakt'])
					if mode == Rater.ModeRating: return rating

				if mode is None or mode == Rater.ModeVotes:
					if type == 1: votes = self._extract(mode = Rater.ModeVotes, item = item, own = own, order = ['imdb', 'tmdb', 'trakt'])
					elif type == 2: votes = self._extract(mode = Rater.ModeVotes, item = item, own = own, order = ['trakt', 'imdb', 'tmdb'])
					elif type == 3: votes = self._extract(mode = Rater.ModeVotes, item = item, own = own, order = ['tmdb', 'imdb', 'trakt'])
					if mode == Rater.ModeVotes: return votes

		ratingown = 0
		if 'ratingown' in item and item['ratingown'] and not item['ratingown'] == '0': ratingown = item['ratingown']
		return {Rater.ModeRating : str(rating), Rater.ModeVotes : str(votes), 'userrating' : str(ratingown)}

	@classmethod
	def rating(self, item):
		return self.extract(mode = Rater.ModeRating, item = item)

	@classmethod
	def votes(self, item):
		return self.extract(mode = Rater.ModeVotes, item = item)
