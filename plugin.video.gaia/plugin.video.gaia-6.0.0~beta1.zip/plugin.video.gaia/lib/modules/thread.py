# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# NB: Do not import Gaia modules/classes here, since most other modules import this file, causing circular imports.
import threading

Lock = threading.Lock
Semaphore = threading.Semaphore
Event = threading.Event

class Thread(threading.Thread):

	StatusUnknown	= 0
	StatusInitial	= 1	# Initialized, but not started yet.
	StatusStarted	= 2	# Started, but not running yet.
	StatusRunning	= 3	# Running, that is, executing the target code.
	StatusFinished	= 4	# Finished executing.
	StatusFailed	= 5	# Failed executing.
	StatusBusy		= [StatusStarted, StatusRunning]

	def __init__(self, target = None, group = None, name = None, daemon = None, args = (), kwargs = {}):
		self._statusSet(Thread.StatusUnknown)
		threading.Thread.__init__(self, target = target, group = group, name = name, daemon = daemon, args = args, kwargs = kwargs)
		self._statusSet(Thread.StatusInitial)

	def id(self):
		return id(self)

	def _statusSet(self, status):
		self.mStatus = status

	def status(self):
		return self.mStatus

	def alive(self):
		return self.status() in Thread.StatusBusy

	def start(self):
		self._statusSet(Thread.StatusStarted)
		try: threading.Thread.start(self)
		except:
			from lib.modules.tools import Logger
			Logger.error()
			self._finish(Thread.StatusFailed)

	def run(self):
		self._statusSet(Thread.StatusRunning)
		threading.Thread.run(self)
		self._finish(Thread.StatusFinished)

	def _finish(self, status):
		self._statusSet(status)
		Pool.remove(self)

class Pool(object):

	SettingsLimit = 'general.concurrency.limit'

	Threads = {}
	Lock = Lock()
	Semaphore = None

	@classmethod
	def limit(self):
		from lib.modules.tools import Settings
		limit = Settings.getCustom(id = Pool.SettingsLimit)
		return limit if limit else 0

	# Returns the maximum number of threads allowed by the system.
	# Returns None if there is probably no maximum limit, aka an unlimited number of threads can be created.
	@classmethod
	def benchmark(self):
		from lib.modules.tools import Logger, Time

		self.tStop = False
		def _benchmark():
			while not self.tStop: Time.sleep(0.3)

		threads = []
		unlimited = 10000 # Do not create too many, otherwise systems with unlimited threads starting lagging.
		for i in range(unlimited):
			try:
				thread = threading.Thread(target = _benchmark)
				thread.start()
				threads.append(thread)
			except RuntimeError:
				break

		count = len(threads)
		if count == unlimited: count = None

		self.tStop = True
		[thread.join() for thread in threads]

		Logger.log('THREAD POOL: %s' % ('unlimited threads' if count is None else ('maximum of %d threads' % count)))
		return count

	@classmethod
	def join(self):
		# Wait for all threads to finish.
		# Low-end devices have a limited number of threads (eg: 400) that can be created.
		# If the threads are not joined and cleaned up (eg: Gaia throws an exception and exits while threads are still running), the threads seem to not be returned to the OS for reuse.
		# If trying to create a new thread in such a case, Python throws an error: RuntimeError: can't start new thread
		# It seems that no new threads can be created, because the limit has been reached, and the ones created before were not returned to the OS properley.
		# Wait for all threads to return before exiting Gaia - not sure if this solves the problem.

		from lib.modules.tools import Logger, System, Time
		developer = System.developer()
		if developer:
			time = Time(start = True)
			Logger.log('THREAD POOL: waiting for %d threads' % self.count())
			for id, thread in Pool.Threads.items():
				Logger.log('   THREAD: %s [%s]' % (id, thread.getName()))

		# Not all threads might have been started yet.
		# Do multiple loops, so that we can wait on threads that might have started during the first iteration.
		recheck = True
		while recheck:
			running = False
			nonrunning = False
			for thread in list(Pool.Threads.values()): # Use a list, since threads can be removed while iterating. Otherwise throws: dictionary changed size during iteration.
				try:
					if thread and not thread.isDaemon():
						thread.join()
						running = True
				except:
					nonrunning = True
			recheck = running and nonrunning

		if developer: Logger.log('THREAD POOL: threads finished in %s seconds' % time.elapsed())

	@classmethod
	def thread(self, target = None, args = (), kwargs = {}, start = False):
		try:
			Pool.Lock.acquire()

			if Pool.Semaphore is None:
				limit = self.limit()
				if limit: Pool.Semaphore = Semaphore(limit)
				else: Pool.Semaphore = True
			try: Pool.Semaphore.acquire()
			except: pass

			thread = Thread(target = target, name = target.__qualname__, args = args, kwargs = kwargs)
			Pool.Threads[thread.id()] = thread
			if start: thread.start()

			return thread
		finally:
			try: Pool.Lock.release()
			except: pass

	@classmethod
	def remove(self, thread):
		try:
			del Pool.Threads[thread.id()]
			try: Pool.Semaphore.release()
			except: pass
		except:
			from lib.modules.tools import Logger
			Logger.log('Cannot find thread to remove: %s' % thread.id())

	@classmethod
	def count(self):
		return len(Pool.Threads.keys())
