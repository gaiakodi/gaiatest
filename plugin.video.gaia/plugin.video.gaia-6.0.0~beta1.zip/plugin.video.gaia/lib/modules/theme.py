# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import xbmc
from lib.modules.tools import System, Settings, File

class Theme(object):

	PropertyThumbnail = 'GaiaThemeThumbnail'
	PropertyPoster = 'GaiaThemePoster'
	PropertyBanner = 'GaiaThemeBanner'
	PropertyFanart = 'GaiaThemeFanart'

	@classmethod
	def kodiSkin(self):
		return xbmc.getSkinDir()

	@classmethod
	def kodiSkinPath(self):
		return File.translatePath('special://skin/')

	@classmethod
	def skin(self):
		return Settings.getString('interface.theme.skin').lower()

	@classmethod
	def skinPath(self):
		skin = self.skin()
		skin = skin.replace(' ', '').lower()
		index = skin.find('(')
		if index >= 0: skin = skin[:index]
		addon = System.pathResources() if skin == 'default' or 'gaia1' in skin else System.pathSkins()
		return File.joinPath(addon, 'resources', 'media', 'skins', skin)

	@classmethod
	def icon(self):
		return System.info('icon')

	@classmethod
	def artwork(self):
		return Settings.getBoolean('interface.theme.artwork')

	@classmethod
	def thumbnail(self):
		type = Settings.getInteger('interface.theme.poster')
		if type == 0: return None

		# This function is called often during menu navigation.
		# Save it as a Kodi variable to speed up getting the value.
		result = System.windowPropertyGet(Theme.PropertyThumbnail)
		if result: return result

		path = self.skinPath()
		skin = self.skin()
		default = skin in ['default', '-', '']
		if default:
			result = 'DefaultFolder.png'
			System.windowPropertySet(Theme.PropertyThumbnail, result)
			return result
		elif not path is None:
			name = None
			if type == 1: name = 'plain'
			elif type == 2: name = 'artwork'
			elif type == 3: name = 'discbox'
			if name is None:
				return None
			else:
				result = File.joinPath(path, 'posters', name + '.png')
				if File.exists(result):
					System.windowPropertySet(Theme.PropertyThumbnail, result)
					return result
		result = System.info('icon')
		System.windowPropertySet(Theme.PropertyThumbnail, result)
		return result

	@classmethod
	def thumbnailClear(self):
		System.windowPropertyClear(Theme.PropertyThumbnail)

	@classmethod
	def poster(self):
		type = Settings.getInteger('interface.theme.poster')
		if type == 0: return None

		# This function is called often during menu navigation.
		# Save it as a Kodi variable to speed up getting the value.
		result = System.windowPropertyGet(Theme.PropertyPoster)
		if result: return result

		path = self.skinPath()
		skin = self.skin()
		default = skin in ['default', '-', '']
		if default:
			result = 'DefaultVideo.png'
			System.windowPropertySet(Theme.PropertyPoster, result)
			return result
		elif not path is None:
			name = None
			if type == 1: name = 'plain'
			elif type == 2: name = 'artwork'
			elif type == 3: name = 'discbox'
			if name is None:
				return None
			else:
				result = File.joinPath(path, 'posters', name + '.png')
				if File.exists(result):
					System.windowPropertySet(Theme.PropertyPoster, result)
					return result
		result = System.info('icon')
		System.windowPropertySet(Theme.PropertyPoster, result)
		return result

	@classmethod
	def posterClear(self):
		System.windowPropertyClear(Theme.PropertyPoster)

	@classmethod
	def banner(self):
		type = Settings.getInteger('interface.theme.banner')
		if type == 0: return None

		# This function is called often during menu navigation.
		# Save it as a Kodi variable to speed up getting the value.
		result = System.windowPropertyGet(Theme.PropertyBanner)
		if result: return result

		path = self.skinPath()
		skin = self.skin()
		default = skin in ['default', '-', '']
		if default:
			result = 'DefaultVideo.png'
			System.windowPropertySet(Theme.PropertyBanner, result)
			return result
		elif not path is None:
			name = None
			if type == 1: name = 'plain'
			elif type == 2: name = 'artwork'
			if name is None:
				return None
			else:
				result = File.joinPath(path, 'banners', name + '.png')
				if File.exists(result):
					System.windowPropertySet(Theme.PropertyBanner, result)
					return result
		result = System.info('icon')
		System.windowPropertySet(Theme.PropertyBanner, result)
		return result

	@classmethod
	def bannerClear(self):
		System.windowPropertyClear(Theme.PropertyBanner)

	@classmethod
	def fanart(self):
		if Settings.getBoolean('interface.theme.background'):
			# This function is called often during menu navigation.
			# Save it as a Kodi variable to speed up getting the value.
			result = System.windowPropertyGet(Theme.PropertyFanart)
			if result: return result

			path = self.skinPath()
			skin = self.skin()
			if not path is None:
				result = File.joinPath(path, 'background.jpg')
				if File.exists(result):
					System.windowPropertySet(Theme.PropertyFanart, result)
					return result
				else:
					result = File.joinPath(path, 'background.png') # Glass
					if File.exists(result):
						System.windowPropertySet(Theme.PropertyFanart, result)
						return result
		return None

	@classmethod
	def fanartClear(self):
		System.windowPropertyClear(Theme.PropertyFanart)
