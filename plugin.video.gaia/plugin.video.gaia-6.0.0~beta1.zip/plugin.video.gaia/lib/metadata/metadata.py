# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.modules.serializer import Serializer
from lib.modules.convert import ConverterTime
from lib.modules.tools import Regex, Tools, Time, Converter, Language, Country, Media, Logger

class Metadata(Serializer):

	# Default

	Default	= None

	# Selection

	SelectionSingle				= False
	SelectionList				= True
	SelectionDefault			= Default

	# Fallback
	FallbackNone				= 0	# If not found, do not fall back, but return None.
	FallbackPrimary				= 1	# If not found, fall back to the next best option.
	FallbackSecondary			= 2	# If not found, fall back to the next best option. If not found, fall back to the next-next best option.
	FallbackTertiary			= 3
	FallbackQuaternary			= 4
	FallbackDefault				= Default

	# Media

	MediaMovie					= 'movie'
	MediaShow					= 'show'
	MediaSeason					= 'season'
	MediaEpisode				= 'episode'
	MediaCollection				= 'collection'
	MediaPerson					= 'person'
	MediaCharacter				= 'character'
	MediaCompany				= 'company'
	MediaDefault				= Default
	MediaAll					= [MediaMovie, MediaShow, MediaSeason, MediaEpisode, MediaCollection, MediaPerson, MediaCharacter, MediaCompany]
	MediaContent				= [MediaMovie, MediaShow, MediaSeason, MediaEpisode, MediaCollection]
	MediaFilm					= [MediaMovie, MediaCollection]
	MediaTelevision				= [MediaShow, MediaSeason, MediaEpisode]
	MediaEntity					= [MediaPerson, MediaCharacter, MediaCompany]
	MediaIndividual				= [MediaPerson, MediaCharacter]

	# Character

	CharacterTypeActor			= 'actor'
	CharacterTypeDirector		= 'director'
	CharacterTypeWriter			= 'writer'
	CharacterTypeEditor			= 'editor'
	CharacterTypeCreator		= 'creator'
	CharacterTypeHost			= 'host'
	CharacterTypeCrew			= 'crew'
	CharacterTypeProducer		= 'producer'
	CharacterTypeGuest			= 'guest'
	CharacterTypeDefault		= Default

	# Role

	CharacterRoleRunner			= 'runner'		# Showrunner
	CharacterRoleExecutive		= 'executive'	# Executive Producer
	CharacterRoleAssociate		= 'associate'	# Associate Producer
	CharacterRoleCo				= 'co'			# Co-Producer
	CharacterRoleLine			= 'line'		# Line Producer
	CharacterRoleCoordinate		= 'coordinate'	# Coordinate Producer
	CharacterRoleSupervise		= 'supervise'	# Supervise Producer
	CharacterRoleConsult		= 'consult'		# Consult Producer
	CharacterRoleSegment		= 'segment'		# Segment Producer
	CharacterRoleField			= 'field'		# Field Producer
	CharacterRoleStar			= 'star'		# Guest Star
	CharacterRoleMusical		= 'musical'		# Musical Guest
	CharacterRoleDefault		= Default

	# Company

	CompanyTypeNetwork			= 'network'
	CompanyTypeStudio			= 'studio'
	CompanyTypeProducer			= 'producer'
	CompanyTypeDistributor		= 'distributor'
	CompanyTypeEffects			= 'effects'
	CompanyTypeDefault			= Default

	# Provider

	ProviderOrion				= 'orion'
	ProviderImdb				= 'imdb'
	ProviderTmdb				= 'tmdb'
	ProviderTvdb				= 'tvdb'
	ProviderTrakt				= 'trakt'
	ProviderDefault				= Default
	Providers					= [ProviderOrion, ProviderImdb, ProviderTmdb, ProviderTvdb, ProviderTrakt]

	# Language

	LanguageOriginal			= 'original'
	LanguageAudio				= 'audio'
	LanguageSubtitle			= 'subtitle'
	LanguageSettings			= 'settings'
	LanguageUniversal			= Language.UniversalCode
	LanguageEnglish				= Language.EnglishCode
	LanguageUnknown				= False
	LanguageDefault				= Default
	LanguageCommon				= [LanguageUniversal, LanguageEnglish, LanguageUnknown]

	# Country

	CountryOriginal				= 'original'
	CountrySettings				= 'settings'
	CountryUniversal			= Country.UniversalCode
	CountryDefault				= Default

	# Image

	ImageTypeIcon				= 'icon'
	ImageTypePoster				= 'poster'
	ImageTypePhoto				= 'photo'
	ImageTypeBanner				= 'banner'
	ImageTypeBackground			= 'background'
	ImageTypeArtwork			= 'artwork'
	ImageTypeThumbnail			= 'thumbnail'
	ImageTypeCinemagraph		= 'cinemagraph'
	ImageTypeDefault			= Default

	ImageQualityHigh			= 'high'
	ImageQualityLow				= 'low'
	ImageQualityDefault			= Default

	ImageOpacitySolid			= 'solid'
	ImageOpacityClear			= 'clear'
	ImageOpacityDefault			= Default

	# Genre

	GenreAction					= 'action'
	GenreScience				= 'science'
	GenreFantasy				= 'fantasy'
	GenreAdventure				= 'adventure'
	GenreHorror					= 'horror'
	GenreDisaster				= 'disaster'
	GenreMystery				= 'mystery'
	GenreSuspense				= 'suspense'
	GenreThriller				= 'thriller'
	GenreCrime					= 'crime'
	GenreMartial				= 'martial'
	GenreEastern				= 'eastern'
	GenreWestern				= 'western'
	GenreWar					= 'war'
	GenreHistory				= 'history'
	GenreComedy					= 'comedy'
	GenreRomance				= 'romance'
	GenreDrama					= 'drama'

	GenreFamily					= 'family'
	GenreChildren				= 'children'
	GenreAnimation				= 'animation'
	GenreAnime					= 'anime'
	GenreMusic					= 'music'
	GenreMusical				= 'musical'

	GenreDocumentary			= 'documentary'
	GenreBiography				= 'biography'
	GenreSport					= 'sport'
	GenreSporting				= 'sporting'
	GenreTravel					= 'travel'
	GenreHoliday				= 'holiday'
	GenreHome					= 'home'
	GenreFood					= 'food'

	GenreSoap					= 'soap'
	GenreReality				= 'reality'
	GenreNews					= 'news'
	GenreTalk					= 'talk'
	GenreGame					= 'game'
	GenreAward					= 'award'
	GenreMini					= 'mini'
	GenrePodcast				= 'podcast'
	GenreTelevision				= 'television'

	GenreShort					= 'short'
	GenreIndie					= 'indie'
	GenreNoir					= 'noir'
	GenreFan					= 'fan'

	GenreDefault				= Default

	GenreNames					= {
		GenreAction				: 'Action',
		GenreScience			: 'Science Fiction',
		GenreFantasy			: 'Fantasy',
		GenreAdventure			: 'Adventure',
		GenreHorror				: 'Horror',
		GenreDisaster			: 'Disaster',
		GenreMystery			: 'Mystery',
		GenreSuspense			: 'Suspense',
		GenreThriller			: 'Thriller',
		GenreCrime				: 'Crime',
		GenreMartial			: 'Martial Arts',
		GenreEastern			: 'Eastern',
		GenreWestern			: 'Western',
		GenreWar				: 'War',
		GenreHistory			: 'History',
		GenreComedy				: 'Comedy',
		GenreRomance			: 'Romance',
		GenreDrama				: 'Drama',

		GenreFamily				: 'Family',
		GenreChildren			: 'Children',
		GenreAnimation			: 'Animation',
		GenreAnime				: 'Anime',
		GenreMusic				: 'Music',
		GenreMusical			: 'Musical',

		GenreDocumentary		: 'Documentary',
		GenreBiography			: 'Biography',
		GenreSport				: 'Sport',
		GenreSporting			: 'Sporting Event',
		GenreTravel				: 'Travel',
		GenreHoliday			: 'Holiday',
		GenreHome				: 'Home and Garden',
		GenreFood				: 'Food',

		GenreSoap				: 'Soap',
		GenreReality			: 'Reality',
		GenreNews				: 'News',
		GenreTalk				: 'Talk Show',
		GenreGame				: 'Game Show',
		GenreAward				: 'Awards Show',
		GenreMini				: 'Mini Series',
		GenrePodcast			: 'Podcast',
		GenreTelevision			: 'Television',

		GenreShort				: 'Short',
		GenreIndie				: 'Indie',
		GenreNoir				: 'Noir',
		GenreFan				: 'Fan',
	}

	# Vote

	VoteAbsolute				= 'absolute'	# Absolute score [0,inf]
	VoteRating					= 'rating'		# Cast rating [0,10]
	VotePercent					= 'percent'		# Cast rating as a percentage [0,1]
	VoteCount					= 'count'		# Number of votes cast [0,inf]

	# Status

	StatusRumoured				= 'rumoured'		# Rumoured, but not officially announced.
	StatusPlanned				= 'planned'			# Planned or announced, but production has not started.
	StatusPreproduction			= 'preproduction'	# Busy with initial production phase.
	StatusProduction			= 'production'		# Busy filming.
	StatusPostproduction		= 'postproduction'	# Busy with post production phase.
	StatusCompleted				= 'completed'		# Completed with production, but not yet released.
	StatusPilot					= 'pilot'			# First pilot episode released. For shows.
	StatusReleased				= 'released'		# Released and in theaters. For movies.
	StatusContinuing			= 'continuing'		# Continuing show on returning for a next season. For shows.
	StatusEnded					= 'ended'			# Ended with last episode. For shows.
	StatusCanceled				= 'canceled'		# Canceled without ending properley. For shows.
	StatusDefault				= Default

	StatusLabels				= {
		StatusRumoured			: 'Rumoured',
		StatusPlanned			: 'Planned',
		StatusPreproduction		: 'In Pre-Production',
		StatusProduction		: 'In Production',
		StatusPostproduction	: 'In Post-Production',
		StatusCompleted			: 'Completed',
		StatusPilot				: 'Pilot',
		StatusReleased			: 'Released',
		StatusContinuing		: 'Continuing',
		StatusEnded				: 'Ended',
		StatusCanceled			: 'Canceled',
	}

	# Duration

	DurationSeconds				= 'seconds'
	DurationMinutes				= 'minutes'
	DurationHours				= 'hours'
	DurationDefault				= DurationSeconds

	# Day

	DayMonday					= 'monday'
	DayTuesday					= 'tuesday'
	DayWednesday				= 'wednesday'
	DayThursday					= 'thursday'
	DayFriday					= 'friday'
	DaySaturday					= 'saturday'
	DaySunday					= 'sunday'
	DayDefault					= Default

	# Zone

	ZoneOriginal				= 'original'
	ZoneLocal					= 'local'
	ZoneUtc						= 'utc'
	ZoneDefault					= Default

	# Format

	FormatDate				= ConverterTime.FormatDate
	FormatDateTime			= ConverterTime.FormatDateTimeShort
	FormatTime				= ConverterTime.FormatTimeShort
	FormatTimestamp			= ConverterTime.FormatTimestamp
	FormatComma				= ', '
	FormatSlash				= ' / '
	FormatBar				= ' | '
	FormatDefault			= True
	FormatNone				= Default

	# Data

	DataMedia					= {}
	DataProvider				= {}
	DataCharacterType			= {}
	DataCharacterRole			= {}
	DataCompany					= {}
	DataImageType				= {}
	DataImageQuality			= {}
	DataImageOpacity			= {}
	DataGenre					= {}
	DataCountry					= {}
	DataDay						= {}
	DataStatus					= {}

	###################################################################
	# CONSTRUCTOR
	###################################################################

	def __init__(self, media = None, data = None):
		Serializer.__init__(self)

		self.mData = {}
		self.mediaSet(value = media)
		self.dataUpdate(data = data)

	###################################################################
	# DATA
	###################################################################

	def dataRetrieve(self, type = None, attribute = None, unique = False, sort = None, inverse = False, extract = None, media = MediaDefault, flatten = SelectionSingle, selection = SelectionDefault, metadata = None):
		result = metadata if metadata else self.mData
		media = self.mediaDefault(media = media)
		selection = self.selectionDefault(selection = selection)

		if not media is False and not media is None and not media == self.media():
			try: result = result[media]
			except: return None

		# Match according to keys.
		if not type is None:
			if Tools.isArray(result):
				temp = []
				result = Tools.copy(result, deep = False) # Since the list is changed below.
				for i in range(len(result)):
					if Tools.isArray(type):
						found = True
						for j in type:
							try: result[i] = result[i][j]
							except:
								found = False
								break
						if not found: continue
						temp.append(result[i])
					else:
						try: temp.append(result[i][type])
						except: continue
				result = temp
			else:
				if Tools.isArray(type):
					for i in type:
						try: result = result[i]
						except: return None
				else:
					try: result = result[type]
					except: return None

		if Tools.isArray(result):
			# Match according to attributes.
			if not attribute is None:
				def attributeMatch(data, attribute):
					match = True
					for k, v in attribute.items():
						if k in data:
							if v is None:
								if not data[k] is v:
									match = False
									break
							elif Tools.isDictionary(v):
								if not attributeMatch(data = data[k], attribute = v):
									match = False
									break
							else:
								if not data[k] == v:
									match = False
									break
						else:
							match = False
							break

					return match

				temp = []
				for i in result:
					if attributeMatch(data = i, attribute = attribute):
						temp.append(i)
				result = temp

			# Flatten list-of-lists.
			if flatten is Metadata.SelectionSingle or flatten is Metadata.SelectionList:
				if len(result) > 0 and Tools.isArray(result[0]):
					if Metadata.SelectionSingle: result = [i[0] for i in result if len(i) > 0]
					else: result = Tools.listFlatten(result)

			# Remove duplicate values.
			if unique: result = Tools.listUnique(result)

			# Sort according to attribute.
			if sort:
				def getValue(dictionary, keys):
					try: return Tools.dictionaryGet(dictionary = dictionary, keys = keys)
					except: return 0

				keys = None
				if Tools.isArray(sort) and len(sort) > 0 and Tools.isArray(sort[0]):
					# Alternative sorting keys. Pick the first one available in the results.
					for i in sort:
						try:
							temp = result[0]
							for j in i: temp = temp[j]
							keys = i
							break
						except: pass
				else:
					keys = sort

				result.sort(key = lambda i : getValue(dictionary = i, keys = keys), reverse = not inverse)

			# Extract a specific attribute.
			if extract: result = [i[extract] for i in result]

		return self.dataSelect(data = result, selection = selection)

	def dataUpdate(self, data, media = False, unique = True, metadata = None):
		if data:
			if not media is False: data = self.mediaWrap(media = media, data = data)
			Tools.update(metadata if metadata else self.mData, data, none = False, lists = True, unique = unique)

	def dataSelect(self, data, selection = SelectionDefault):
		if Tools.isArray(data):
			if selection is Metadata.SelectionSingle:
				try: return data[0]
				except: return None
			elif Tools.isInteger(selection):
				try: return data[selection]
				except: return None
			elif Tools.isArray(selection):
				try: return data[selection[0] : selection[1]]
				except: return None
		return data

	def dataList(self, data):
		if not data is None and not Tools.isArray(data): data = [data]
		return data

	@classmethod
	def dataClean(self, data, newline = True, space = True):
		# TVDb character names sometimes contain space characters (eg: "Self \n  \n  \n  (archive footage)").
		if Tools.isDictionary(data):
			for key, value in data.items():
				for i in range(len(value)):
					value[i] = self.dataClean(data = value[i], newline = newline, space = space)
		else:
			if newline:
				data = Regex.remove(data = data, expression = '[\r\n]')
			if space:
				data = Regex.remove(data = data, expression = '\t')
				data = Regex.replace(data = data, expression = '\s{2,}', replacement = ' ')
		return data

	@classmethod
	def dataCreate(self, media, data):
		metadata = Metadata(media = media)
		metadata.dataImport(data = data)
		return metadata

	def dataExportBefore(self):
		items = {}
		for media in Metadata.MediaAll:
			try:
				item = self.mData[media]
				if item:
					items[media] = item
					if Tools.isArray(item): self.mData[media] = [i.dataExport() for i in item]
					else: self.mData[media] = item.dataExport()
			except: pass
		return items

	def dataExportAfter(self, data):
		for media, item in data.items():
			self.mData[media] = item

	def dataImportBefore(self, data = None):
		try:
			for media in Metadata.MediaAll:
				try:
					item = data[media]
					if item:
						if Tools.isArray(item): data[media] = [self.dataCreate(media = media, data = i) for i in item]
						else: data[media] = self.dataCreate(media = media, data = item)
				except: pass
		except: Logger.error()
		return data

	###################################################################
	# SELECTION
	###################################################################

	@classmethod
	def selectionDefault(self, selection, default = SelectionList):
		if selection is Metadata.SelectionDefault: selection = default
		return selection

	###################################################################
	# FALLBACK
	###################################################################

	@classmethod
	def fallbackDefault(self, fallback, default = FallbackDefault):
		if fallback is Metadata.FallbackDefault: fallback = Metadata.FallbackQuaternary if default is Metadata.FallbackDefault else default
		return fallback

	###################################################################
	# FORMAT
	###################################################################

	@classmethod
	def format(self, value, format = FormatDefault):
		if Tools.isArray(value) and format: value = format.join(value)
		return value

	###################################################################
	# PROVIDER
	###################################################################

	@classmethod
	def providerExtract(self, data):
		try: return Metadata.DataProvider[data]
		except: pass

		provider = Metadata.ProviderDefault
		if Regex.match(data = data, expression = '(?:the[\s\-\_\.]*)?i(?:nternet[\s\-\_\.]*)?m(?:ovie[\s\-\_\.]*)?d(?:ata[\s\-\_\.]*)?b(?:ase)?'): provider = Metadata.ProviderImdb
		elif Regex.match(data = data, expression = '(?:the[\s\-\_\.]*)?m(?:ovie[\s\-\_\.]*)?d(?:ata[\s\-\_\.]*)?b(?:ase)?'): provider = Metadata.ProviderTmdb
		elif Regex.match(data = data, expression = '(?:the[\s\-\_\.]*)?tv[\s\-\_\.]*d(?:ata[\s\-\_\.]*)?b(?:ase)?'): provider = Metadata.ProviderTvdb
		elif Regex.match(data = data, expression = 'trakt'): provider = Metadata.ProviderTrakt
		elif Regex.match(data = data, expression = 'orion(?:[\s\-\_\.]*oid)?'): provider = Metadata.ProviderOrion

		Metadata.DataProvider[data] = provider
		return provider

	###################################################################
	# PERSON
	###################################################################

	def person(self, type = CharacterTypeDefault, role = CharacterRoleDefault, selection = SelectionDefault):
		result = self.dataRetrieve(type = 'person', selection = selection)
		if result is None:
			character = self.character(type = type, role = role, selection = selection)
			if character:
				if Tools.isArray(character):
					result = [i.person(selection = self.selectionDefault(selection = selection, default = Metadata.SelectionSingle)) for i in character]

					# Some actors play multiple roles (eg: Family Guy).
					# Filter out duplicate entries.
					names = []
					temp = []
					for i in result:
						name = i.name()
						if not name in names:
							names.append(name)
							temp.append(i)
					result = temp
				else:
					result = character.person(selection = self.selectionDefault(selection = selection, default = Metadata.SelectionSingle))
		return result

	def personActor(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.person(type = Metadata.CharacterTypeActor, role = role, selection = selection)

	def personDirector(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.person(type = Metadata.CharacterTypeDirector, role = role, selection = selection)

	def personWriter(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.character(type = Metadata.CharacterTypeWriter, role = role, selection = selection)

	def personEditor(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.person(type = Metadata.CharacterTypeEditor, role = role, selection = selection)

	def personCreator(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.person(type = Metadata.CharacterTypeCreator, role = role, selection = selection)

	def personHost(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.person(type = Metadata.CharacterTypeHost, role = role, selection = selection)

	def personCrew(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.person(type = Metadata.CharacterTypeCrew, role = role, selection = selection)

	def personProducer(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.person(type = Metadata.CharacterTypeProducer, role = role, selection = selection)

	def personGuest(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.person(type = Metadata.CharacterTypeGuest, role = role, selection = selection)

	def personName(self, type = CharacterTypeDefault, role = CharacterRoleDefault, language = LanguageDefault, format = FormatNone, selection = SelectionDefault, fallback = FallbackDefault):
		person = self.person(type = type, role = role, selection = selection)
		if person:
			if Tools.isArray(person):
				person = [i.name(language = language, selection = Metadata.SelectionSingle, fallback = fallback) for i in person]
				person = [i for i in person if i]
				return self.format(value = person, format = format)
			else:
				return person.name(language = language, selection = Metadata.SelectionSingle, fallback = fallback)
		return None

	def personNameActor(self, role = CharacterRoleDefault, language = LanguageDefault, format = FormatNone, selection = SelectionDefault, fallback = FallbackDefault):
		return self.personName(type = Metadata.CharacterTypeActor, role = role, language = language, format = format, selection = selection, fallback = fallback)

	def personNameDirector(self, role = CharacterRoleDefault, language = LanguageDefault, format = FormatNone, selection = SelectionDefault, fallback = FallbackDefault):
		return self.personName(type = Metadata.CharacterTypeDirector, role = role, language = language, format = format, selection = selection, fallback = fallback)

	def personNameWriter(self, role = CharacterRoleDefault, language = LanguageDefault, format = FormatNone, selection = SelectionDefault, fallback = FallbackDefault):
		return self.personName(type = Metadata.CharacterTypeWriter, role = role, language = language, format = format, selection = selection, fallback = fallback)

	def personNameEditor(self, role = CharacterRoleDefault, language = LanguageDefault, format = FormatNone, selection = SelectionDefault, fallback = FallbackDefault):
		return self.personName(type = Metadata.CharacterTypeEditor, role = role, language = language, format = format, selection = selection, fallback = fallback)

	def personNameCreator(self, role = CharacterRoleDefault, language = LanguageDefault, format = FormatNone, selection = SelectionDefault, fallback = FallbackDefault):
		return self.personName(type = Metadata.CharacterTypeCreator, role = role, language = language, format = format, selection = selection, fallback = fallback)

	def personNameHost(self, role = CharacterRoleDefault, language = LanguageDefault, format = FormatNone, selection = SelectionDefault, fallback = FallbackDefault):
		return self.personName(type = Metadata.CharacterTypeHost, role = role, language = language, format = format, selection = selection, fallback = fallback)

	def personNameCrew(self, role = CharacterRoleDefault, language = LanguageDefault, format = FormatNone, selection = SelectionDefault, fallback = FallbackDefault):
		return self.personName(type = Metadata.CharacterTypeCrew, role = role, language = language, format = format, selection = selection, fallback = fallback)

	def personNameProducer(self, role = CharacterRoleDefault, language = LanguageDefault, format = FormatNone, selection = SelectionDefault, fallback = FallbackDefault):
		return self.personName(type = Metadata.CharacterTypeProducer, role = role, language = language, format = format, selection = selection, fallback = fallback)

	def personNameGuest(self, role = CharacterRoleDefault, language = LanguageDefault, format = FormatNone, selection = SelectionDefault, fallback = FallbackDefault):
		return self.personName(type = Metadata.CharacterTypeGuest, role = role, language = language, format = format, selection = selection, fallback = fallback)

	def personSet(self, value):
		if value: self.dataUpdate(data = {'person' : value})

	###################################################################
	# CHARACTER
	###################################################################

	def character(self, type = CharacterTypeDefault, role = CharacterRoleDefault, selection = SelectionDefault):
		attribute = {}
		if type: attribute['type'] = type
		if role: attribute['role'] = role
		return self.dataRetrieve(type = 'character', attribute = attribute, sort = [['vote', Metadata.VotePercent], ['vote', Metadata.VoteAbsolute]], selection = selection)

	def characterActor(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.character(type = Metadata.CharacterTypeActor, role = role, selection = selection)

	def characterDirector(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.character(type = Metadata.CharacterTypeDirector, role = role, selection = selection)

	def characterWriter(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.character(type = Metadata.CharacterTypeWriter, role = role, selection = selection)

	def characterEditor(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.character(type = Metadata.CharacterTypeEditor, role = role, selection = selection)

	def characterCreator(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.character(type = Metadata.CharacterTypeCreator, role = role, selection = selection)

	def characterHost(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.character(type = Metadata.CharacterTypeHost, role = role, selection = selection)

	def characterCrew(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.character(type = Metadata.CharacterTypeCrew, role = role, selection = selection)

	def characterProducer(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.character(type = Metadata.CharacterTypeProducer, role = role, selection = selection)

	def characterGuest(self, role = CharacterRoleDefault, selection = SelectionDefault):
		return self.character(type = Metadata.CharacterTypeGuest, role = role, selection = selection)

	def characterSet(self, value):
		if value:
			if self.mediaCharacter(): self.dataUpdate(data = value)
			else: self.dataUpdate(data = {'character' : self.dataList(value)})

	@classmethod
	def characterExtract(self, data):
		type = self.characterTypeExtract(data)
		if not type: return None
		return {
			'type' : type,
			'role' : self.characterRoleExtract(data),
		}

	@classmethod
	def characterTypeExtract(self, data):
		try: return Metadata.DataCharacterType[data]
		except: pass

		character = Metadata.CharacterTypeDefault
		if Regex.match(data = data, expression = '(?:actor)'): character = Metadata.CharacterTypeActor
		elif Regex.match(data = data, expression = '(?:director)'): character = Metadata.CharacterTypeDirector
		elif Regex.match(data = data, expression = '(?:writer)'): character = Metadata.CharacterTypeWriter
		elif Regex.match(data = data, expression = '(?:editor)'): character = Metadata.CharacterTypeEditor
		elif Regex.match(data = data, expression = '(?:creator)'): character = Metadata.CharacterTypeCreator
		elif Regex.match(data = data, expression = '(?:host)'): character = Metadata.CharacterTypeHost
		elif Regex.match(data = data, expression = '(?:crew)'): character = Metadata.CharacterTypeCrew
		elif Regex.match(data = data, expression = '(?:producer|show.*runner)'): character = Metadata.CharacterTypeProducer
		elif Regex.match(data = data, expression = '(?:guest)'): character = Metadata.CharacterTypeGuest

		Metadata.DataCharacterType[data] = character
		return character

	@classmethod
	def characterRoleExtract(self, data):
		try: return Metadata.DataCharacterRole[data]
		except: pass

		character = Metadata.CharacterTypeDefault
		if Regex.match(data = data, expression = '(?:show.*runner)'): character = Metadata.CharacterRoleRunner
		elif Regex.match(data = data, expression = '(?:executive)'): character = Metadata.CharacterRoleExecutive
		elif Regex.match(data = data, expression = '(?:associat(?:e|ive))'): character = Metadata.CharacterRoleAssociate
		elif Regex.match(data = data, expression = '(?:co[\s\-]*producer)'): character = Metadata.CharacterRoleCo
		elif Regex.match(data = data, expression = '(?:line)'): character = Metadata.CharacterRoleLine
		elif Regex.match(data = data, expression = '(?:coordinate)'): character = Metadata.CharacterRoleCoordinate
		elif Regex.match(data = data, expression = '(?:supervise)'): character = Metadata.CharacterRoleSupervise
		elif Regex.match(data = data, expression = '(?:consult)'): character = Metadata.CharacterRoleConsult
		elif Regex.match(data = data, expression = '(?:segment)'): character = Metadata.CharacterRoleSegment
		elif Regex.match(data = data, expression = '(?:field)'): character = Metadata.CharacterRoleField
		elif Regex.match(data = data, expression = '(?:star)'): character = Metadata.CharacterRoleStar
		elif Regex.match(data = data, expression = '(?:music)'): character = Metadata.CharacterRoleMusical

		Metadata.DataCharacterRole[data] = character
		return character

	###################################################################
	# COMPANY
	###################################################################

	def company(self, type = CompanyTypeDefault, selection = SelectionDefault):
		attribute = {}
		if type: attribute['type'] = type
		return self.dataRetrieve(type = 'company', attribute = attribute, selection = selection)

	def companyNetwork(self, selection = SelectionDefault):
		return self.company(type = Metadata.CompanyTypeNetwork, selection = selection)

	def companyStudio(self, selection = SelectionDefault):
		return self.company(type = Metadata.CompanyTypeStudio, selection = selection)

	def companyProducer(self, selection = SelectionDefault):
		return self.company(type = Metadata.CompanyTypeProducer, selection = selection)

	def companyDistributor(self, selection = SelectionDefault):
		return self.company(type = Metadata.CompanyTypeDistributor, selection = selection)

	def companyEffects(self, selection = SelectionDefault):
		return self.company(type = Metadata.CompanyTypeEffects, selection = selection)

	def companyName(self, type = CompanyTypeDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		company = self.company(type = type, selection = selection)
		if company:
			if Tools.isArray(company):
				company = [i.name(language = language, selection = Metadata.SelectionSingle, fallback = fallback) for i in comapny]
				return [i for i in company if i]
			else:
				return company.name(language = language, selection = Metadata.SelectionSingle, fallback = fallback)
		return None

	def companyNameNetwork(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.companyName(type = Metadata.CompanyTypeNetwork, language = language, selection = selection, fallback = fallback)

	def companyNameStudio(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.companyName(type = Metadata.CompanyTypeStudio, language = language, selection = selection, fallback = fallback)

	def companyNameProducer(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.companyName(type = Metadata.CompanyTypeProducer, language = language, selection = selection, fallback = fallback)

	def companyNameDistributor(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.companyName(type = Metadata.CompanyTypeDistributor, language = language, selection = selection, fallback = fallback)

	def companyNameEffects(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.companyName(type = Metadata.CompanyTypeEffects, language = language, selection = selection, fallback = fallback)

	def companySet(self, value):
		if value: self.dataUpdate(data = {'company' : self.dataList(value)})

	@classmethod
	def companyExtract(self, data):
		try: return Metadata.DataCompany[data]
		except: pass

		company = Metadata.CompanyTypeDefault
		if Regex.match(data = data, expression = '(?:network)'): company = Metadata.CompanyTypeNetwork
		elif Regex.match(data = data, expression = '(?:studio)'): company = Metadata.CompanyTypeStudio
		elif Regex.match(data = data, expression = '(?:produc(?:tion|er))'): company = Metadata.CompanyTypeProducer
		elif Regex.match(data = data, expression = '(?:distribut(?:tion|or))'): company = Metadata.CompanyTypeDistributor
		elif Regex.match(data = data, expression = '(?:effect)'): company = Metadata.CompanyTypeEffects

		Metadata.DataCompany[data] = company
		return company

	###################################################################
	# GENERAL
	###################################################################

	def item(self, media, attribute = Default, sort = Default, selection = SelectionDefault):
		return self.dataRetrieve(type = media, attribute = attribute, sort = 'number' if sort is True else sort, inverse = True, selection = selection)

	def movie(self, attribute = Default, selection = SelectionDefault):
		return self.item(media = Metadata.MediaMovie, attribute = attribute, selection = selection)

	def collection(self, attribute = Default, selection = SelectionDefault):
		return self.item(media = Metadata.MediaCollection, attribute = attribute, selection = selection)

	def show(self, attribute = Default, selection = SelectionDefault):
		return self.item(media = Metadata.MediaShow, attribute = attribute, selection = selection)

	def season(self, number = Default, numberSeason = Default, exclude = Default, excludeSeason = Default, attribute = Default, sort = Default, selection = SelectionDefault):
		if excludeSeason is Metadata.Default: excludeSeason = exclude
		if not excludeSeason is Metadata.Default and not Tools.isArray(excludeSeason): excludeSeason = [excludeSeason]

		if numberSeason is Metadata.Default: numberSeason = number
		if not numberSeason is Metadata.Default and not Tools.isArray(numberSeason): numberSeason = [numberSeason]

		if selection is Metadata.SelectionDefault and numberSeason and len(numberSeason) == 1: selection = Metadata.SelectionSingle

		result = self.item(media = Metadata.MediaSeason, attribute = attribute, sort = sort)

		if result:
			if not numberSeason is Metadata.Default: result = [i for i in result if i.numberSeason() in numberSeason]
			if not excludeSeason is Metadata.Default: result = [i for i in result if not i.numberSeason() in excludeSeason]

		return self.dataSelect(data = result, selection = selection)

	def episode(self, number = Default, numberSeason = Default, numberEpisode = Default, exclude = Default, excludeSeason = Default, excludeEpisode = Default, attribute = Default, sort = Default, selection = SelectionDefault):
		if excludeSeason is Metadata.Default: excludeSeason = exclude
		if excludeEpisode is Metadata.Default: excludeEpisode = exclude
		if not excludeSeason is Metadata.Default and not Tools.isArray(excludeSeason): excludeSeason = [excludeSeason]
		if not excludeEpisode is Metadata.Default and not Tools.isArray(excludeEpisode): excludeEpisode = [excludeEpisode]

		if numberEpisode is Metadata.Default: numberEpisode = number
		if not numberSeason is Metadata.Default and not Tools.isArray(numberSeason): numberSeason = [numberSeason]
		if not numberEpisode is Metadata.Default and not Tools.isArray(numberEpisode): numberEpisode = [numberEpisode]

		if selection is Metadata.SelectionDefault and numberSeason and len(numberSeason) == 1 and numberEpisode and len(numberEpisode) == 1: selection = Metadata.SelectionSingle

		if self.mediaShow():
			season = self.season(number = numberSeason, excludeSeason = excludeSeason, attribute = attribute, sort = sort, selection = Metadata.SelectionList)
			if season:
				result = []
				for i in season:
					episode = i.episode(number = numberEpisode, excludeEpisode = excludeEpisode, attribute = attribute, sort = sort)
					if episode: result.extend(episode)
				return self.dataSelect(data = result, selection = selection)
			else: return None

		result = self.item(media = Metadata.MediaEpisode, attribute = attribute, sort = sort)

		if result:
			if not numberSeason is Metadata.Default: result = [i for i in result if i.numberSeason() in numberSeason]
			if not numberEpisode is Metadata.Default: result = [i for i in result if i.numberEpisode() in numberEpisode]

			if not excludeSeason is Metadata.Default: result = [i for i in result if not i.numberSeason() in excludeSeason]
			if not excludeEpisode is Metadata.Default: result = [i for i in result if not i.numberEpisode() in excludeEpisode]

		return self.dataSelect(data = result, selection = selection)

	def itemSet(self, value, unique = Default, media = MediaDefault):
		if value:
			if media is Metadata.MediaDefault:
				try: media = value.media()
				except:
					try: media = value[0].media()
					except: pass
			if media:
				if unique and unique in Metadata.Providers: unique = ['id', unique]
				self.dataUpdate(data = {media : value}, unique = unique)

	def movieSet(self, value, unique = Default):
		self.itemSet(value = value, unique = unique, media = Metadata.MediaMovie)

	def collectionSet(self, value, unique = Default):
		self.itemSet(value = value, unique = unique, media = Metadata.MediaCollection)

	def showSet(self, value, unique = Default):
		self.itemSet(value = value, unique = unique, media = Metadata.MediaShow)

	def seasonSet(self, value, unique = Default):
		self.itemSet(value = value, unique = unique, media = Metadata.MediaSeason)

	def episodeSet(self, value, unique = Default):
		if self.mediaShow():
			if not Tools.isArray(value): value = [value]
			for i in value:
				found = False
				number = i.numberSeason()
				if not number is None:
					season = self.season(number = number, selection = Metadata.SelectionSingle)
					if not season:
						season = i.season(selection = Metadata.SelectionSingle)
						if season: self.seasonSet(season)
					if season:
						found = True
						season.episodeSet(value = self.dataList(i), unique = unique)
				if not found: Logger.log('Metadata: Season not found')
		else:
			self.itemSet(value = value, unique = unique, media = Metadata.MediaEpisode)

	###################################################################
	# MEDIA
	###################################################################

	def media(self):
		return self.dataRetrieve(type = 'media', media = False)

	def mediaContent(self, media = MediaDefault):
		return self.mediaDefault(media = media) in Metadata.MediaContent

	def mediaFilm(self, media = MediaDefault):
		return self.mediaDefault(media = media) in Metadata.MediaFilm

	def mediaTelevision(self, media = MediaDefault):
		return self.mediaDefault(media = media) in Metadata.MediaTelevision

	def mediaEntity(self, media = MediaDefault):
		return self.mediaDefault(media = media) in Metadata.MediaEntity

	def mediaIndividual(self, media = MediaDefault):
		return self.mediaDefault(media = media) in Metadata.MediaIndividual

	def mediaMovie(self):
		return self.media() == Metadata.MediaMovie

	def mediaCollection(self):
		return self.media() == Metadata.MediaCollection

	def mediaShow(self):
		return self.media() == Metadata.MediaShow

	def mediaSeason(self):
		return self.media() == Metadata.MediaSeason

	def mediaEpisode(self):
		return self.media() == Metadata.MediaEpisode

	def mediaPerson(self):
		return self.media() == Metadata.MediaPerson

	def mediaCharacter(self):
		return self.media() == Metadata.MediaCharacter

	def mediaCompany(self):
		return self.media() == Metadata.MediaCompany

	def mediaSet(self, value):
		self.mData['media'] = value

	def mediaDefault(self, media):
		if media is Metadata.MediaDefault: media = self.media()
		return media

	def mediaWrap(self, media, data):
		media = self.mediaDefault(media = media)
		if not media == self.media(): data = {media : data}
		return data

	@classmethod
	def mediaExtract(self, data):
		if not Tools.isString(data): return None

		try: return Metadata.DataMedia[data]
		except: pass

		media = Metadata.MediaDefault
		if Regex.match(data = data, expression = '(?:movie|film)'): media = Metadata.MediaMovie
		elif Regex.match(data = data, expression = '(?:show|serie)'): media = Metadata.MediaShow
		elif Regex.match(data = data, expression = '(?:season)'): media = Metadata.MediaSeason
		elif Regex.match(data = data, expression = '(?:ep(?:isode)?|part)'): media = Metadata.MediaEpisode
		elif Regex.match(data = data, expression = '(?:collection|box|set)'): media = Metadata.MediaCollection
		elif Regex.match(data = data, expression = '(?:person|people)'): media = Metadata.MediaPerson
		elif Regex.match(data = data, expression = '(?:character|actor|director|writer|producer|creator|crew|star|host|guest|showrunner)'): media = Metadata.MediaCharacter
		elif Regex.match(data = data, expression = '(?:company|network|studio|distribut(?:or|ion)|production|special.*effects)'): media = Metadata.MediaCompany

		Metadata.DataMedia[data] = media
		return media

	###################################################################
	# ID
	###################################################################

	def id(self, provider = ProviderDefault, media = MediaDefault):
		type = ['id']
		if provider: type.append(provider)
		return self.dataRetrieve(type = type, media = media)

	def idOrion(self, media = MediaDefault):
		return self.id(provider = Metadata.ProviderOrion, media = media)

	def idImdb(self, media = MediaDefault):
		return self.id(provider = Metadata.ProviderImdb, media = media)

	def idTmdb(self, media = MediaDefault):
		return self.id(provider = Metadata.ProviderTmdb, media = media)

	def idTvdb(self, media = MediaDefault):
		return self.id(provider = Metadata.ProviderTvdb, media = media)

	def idTrakt(self, media = MediaDefault):
		return self.id(provider = Metadata.ProviderTrakt, media = media)

	def idSet(self, value, provider = ProviderDefault, media = MediaDefault):
		if value:
			if Tools.isDictionary(value): value = {k : str(v) for k, v in value.items()}
			else: value = {provider : str(value)}
			self.dataUpdate(data = {'id' : value}, media = media)

	def idOrionSet(self, value, media = MediaDefault):
		self.idSet(value = value, provider = Metadata.ProviderOrion, media = media)

	def idImdbSet(self, value, media = MediaDefault):
		self.idSet(value = value, provider = Metadata.ProviderImdb, media = media)

	def idTmdbSet(self, value, media = MediaDefault):
		self.idSet(value = value, provider = Metadata.ProviderTmdb, media = media)

	def idTvdbSet(self, value, media = MediaDefault):
		self.idSet(value = value, provider = Metadata.ProviderTvdb, media = media)

	def idTraktSet(self, value, media = MediaDefault):
		self.idSet(value = value, provider = Metadata.ProviderTrakt, media = media)

	###################################################################
	# ID - MOVIE
	###################################################################

	def idMovie(self, provider):
		return self.id(provider = provider, media = Metadata.MediaMovie)

	def idMovieOrion(self):
		return self.idMovie(provider = Metadata.ProviderOrion)

	def idMovieImdb(self):
		return self.idMovie(provider = Metadata.ProviderImdb)

	def idMovieTmdb(self):
		return self.idMovie(provider = Metadata.ProviderTmdb)

	def idMovieTvdb(self):
		return self.idMovie(provider = Metadata.ProviderTvdb)

	def idMovieTrakt(self):
		return self.idMovie(provider = Metadata.ProviderTrakt)

	def idMovieSet(self, value, provider):
		self.idSet(value = value, provider = provider, media = Metadata.MediaMovie)

	def idMovieOrionSet(self, value):
		self.idMovieSet(value = value, provider = Metadata.ProviderOrion)

	def idMovieImdbSet(self, value):
		self.idMovieSet(value = value, provider = Metadata.ProviderImdb)

	def idMovieTmdbSet(self, value):
		self.idMovieSet(value = value, provider = Metadata.ProviderTmdb)

	def idMovieTvdbSet(self, value):
		self.idMovieSet(value = value, provider = Metadata.ProviderTvdb)

	def idMovieTraktSet(self, value):
		self.idMovieSet(value = value, provider = Metadata.ProviderTrakt)

	###################################################################
	# ID - COLLECTION
	###################################################################

	def idCollection(self, provider):
		return self.id(provider = provider, media = Metadata.MediaCollection)

	def idCollectionOrion(self):
		return self.idCollection(provider = Metadata.ProviderOrion)

	def idCollectionImdb(self):
		return self.idCollection(provider = Metadata.ProviderImdb)

	def idCollectionTmdb(self):
		return self.idCollection(provider = Metadata.ProviderTmdb)

	def idCollectionTvdb(self):
		return self.idCollection(provider = Metadata.ProviderTvdb)

	def idCollectionTrakt(self):
		return self.idCollection(provider = Metadata.ProviderTrakt)

	def idCollectionSet(self, value, provider):
		self.idSet(value = value, provider = provider, media = Metadata.MediaCollection)

	def idCollectionOrionSet(self, value):
		self.idCollectionSet(value = value, provider = Metadata.ProviderOrion)

	def idCollectionImdbSet(self, value):
		self.idCollectionSet(value = value, provider = Metadata.ProviderImdb)

	def idCollectionTmdbSet(self, value):
		self.idCollectionSet(value = value, provider = Metadata.ProviderTmdb)

	def idCollectionTvdbSet(self, value):
		self.idCollectionSet(value = value, provider = Metadata.ProviderTvdb)

	def idCollectionTraktSet(self, value):
		self.idCollectionSet(value = value, provider = Metadata.ProviderTrakt)

	###################################################################
	# ID - SHOW
	###################################################################

	def idShow(self, provider):
		return self.id(provider = provider, media = Metadata.MediaShow)

	def idShowOrion(self):
		return self.idShow(provider = Metadata.ProviderOrion)

	def idShowImdb(self):
		return self.idShow(provider = Metadata.ProviderImdb)

	def idShowTmdb(self):
		return self.idShow(provider = Metadata.ProviderTmdb)

	def idShowTvdb(self):
		return self.idShow(provider = Metadata.ProviderTvdb)

	def idShowTrakt(self):
		return self.idShow(provider = Metadata.ProviderTrakt)

	def idShowSet(self, value, provider):
		self.idSet(value = value, provider = provider, media = Metadata.MediaShow)

	def idShowOrionSet(self, value):
		self.idShowSet(value = value, provider = Metadata.ProviderOrion)

	def idShowImdbSet(self, value):
		self.idShowSet(value = value, provider = Metadata.ProviderImdb)

	def idShowTmdbSet(self, value):
		self.idShowSet(value = value, provider = Metadata.ProviderTmdb)

	def idShowTvdbSet(self, value):
		self.idShowSet(value = value, provider = Metadata.ProviderTvdb)

	def idShowTraktSet(self, value):
		self.idShowSet(value = value, provider = Metadata.ProviderTrakt)

	###################################################################
	# ID - SEASON
	###################################################################

	def idSeason(self, provider):
		return self.id(provider = provider, media = Metadata.MediaSeason)

	def idSeasonOrion(self):
		return self.idSeason(provider = Metadata.ProviderOrion)

	def idSeasonImdb(self):
		return self.idSeason(provider = Metadata.ProviderImdb)

	def idSeasonTmdb(self):
		return self.idSeason(provider = Metadata.ProviderTmdb)

	def idSeasonTvdb(self):
		return self.idSeason(provider = Metadata.ProviderTvdb)

	def idSeasonTrakt(self):
		return self.idSeason(provider = Metadata.ProviderTrakt)

	def idSeasonSet(self, value, provider):
		self.idSet(value = value, provider = provider, media = Metadata.MediaSeason)

	def idSeasonOrionSet(self, value):
		self.idSeasonSet(value = value, provider = Metadata.ProviderOrion)

	def idSeasonImdbSet(self, value):
		self.idSeasonSet(value = value, provider = Metadata.ProviderImdb)

	def idSeasonTmdbSet(self, value):
		self.idSeasonSet(value = value, provider = Metadata.ProviderTmdb)

	def idSeasonTvdbSet(self, value):
		self.idSeasonSet(value = value, provider = Metadata.ProviderTvdb)

	def idSeasonTraktSet(self, value):
		self.idSeasonSet(value = value, provider = Metadata.ProviderTrakt)

	###################################################################
	# ID - EPISODE
	###################################################################

	def idEpisode(self, provider):
		return self.id(provider = provider, media = Metadata.MediaEpisode)

	def idEpisodeOrion(self):
		return self.idEpisode(provider = Metadata.ProviderOrion)

	def idEpisodeImdb(self):
		return self.idEpisode(provider = Metadata.ProviderImdb)

	def idEpisodeTmdb(self):
		return self.idEpisode(provider = Metadata.ProviderTmdb)

	def idEpisodeTvdb(self):
		return self.idEpisode(provider = Metadata.ProviderTvdb)

	def idEpisodeTrakt(self):
		return self.idEpisode(provider = Metadata.ProviderTrakt)

	def idEpisodeSet(self, value, provider):
		self.idSet(value = value, provider = provider, media = Metadata.MediaEpisode)

	def idEpisodeOrionSet(self, value):
		self.idEpisodeSet(value = value, provider = Metadata.ProviderOrion)

	def idEpisodeImdbSet(self, value):
		self.idEpisodeSet(value = value, provider = Metadata.ProviderImdb)

	def idEpisodeTmdbSet(self, value):
		self.idEpisodeSet(value = value, provider = Metadata.ProviderTmdb)

	def idEpisodeTvdbSet(self, value):
		self.idEpisodeSet(value = value, provider = Metadata.ProviderTvdb)

	def idEpisodeTraktSet(self, value):
		self.idEpisodeSet(value = value, provider = Metadata.ProviderTrakt)

	###################################################################
	# ID - PERSON
	###################################################################

	def idPerson(self, provider):
		return self.id(provider = provider, media = Metadata.MediaPerson)

	def idPersonOrion(self):
		return self.idPerson(provider = Metadata.ProviderOrion)

	def idPersonImdb(self):
		return self.idPerson(provider = Metadata.ProviderImdb)

	def idPersonTmdb(self):
		return self.idPerson(provider = Metadata.ProviderTmdb)

	def idPersonTvdb(self):
		return self.idPerson(provider = Metadata.ProviderTvdb)

	def idPersonTrakt(self):
		return self.idPerson(provider = Metadata.ProviderTrakt)

	def idPersonSet(self, value, provider):
		self.idSet(value = value, provider = provider, media = Metadata.MediaPerson)

	def idPersonOrionSet(self, value):
		self.idPersonSet(value = value, provider = Metadata.ProviderOrion)

	def idPersonImdbSet(self, value):
		self.idPersonSet(value = value, provider = Metadata.ProviderImdb)

	def idPersonTmdbSet(self, value):
		self.idPersonSet(value = value, provider = Metadata.ProviderTmdb)

	def idPersonTvdbSet(self, value):
		self.idPersonSet(value = value, provider = Metadata.ProviderTvdb)

	def idPersonTraktSet(self, value):
		self.idPersonSet(value = value, provider = Metadata.ProviderTrakt)

	###################################################################
	# ID - CHARACTER
	###################################################################

	def idCharacter(self, provider):
		return self.id(provider = provider, media = Metadata.MediaCharacter)

	def idCharacterOrion(self):
		return self.idCharacter(provider = Metadata.ProviderOrion)

	def idCharacterImdb(self):
		return self.idCharacter(provider = Metadata.ProviderImdb)

	def idCharacterTmdb(self):
		return self.idCharacter(provider = Metadata.ProviderTmdb)

	def idCharacterTvdb(self):
		return self.idCharacter(provider = Metadata.ProviderTvdb)

	def idCharacterTrakt(self):
		return self.idCharacter(provider = Metadata.ProviderTrakt)

	def idCharacterSet(self, value, provider):
		self.idSet(value = value, provider = provider, media = Metadata.MediaCharacter)

	def idCharacterOrionSet(self, value):
		self.idCharacterSet(value = value, provider = Metadata.ProviderOrion)

	def idCharacterImdbSet(self, value):
		self.idCharacterSet(value = value, provider = Metadata.ProviderImdb)

	def idCharacterTmdbSet(self, value):
		self.idCharacterSet(value = value, provider = Metadata.ProviderTmdb)

	def idCharacterTvdbSet(self, value):
		self.idCharacterSet(value = value, provider = Metadata.ProviderTvdb)

	def idCharacterTraktSet(self, value):
		self.idCharacterSet(value = value, provider = Metadata.ProviderTrakt)

	###################################################################
	# ID - COMPANY
	###################################################################

	def idCompany(self, provider):
		return self.id(provider = provider, media = Metadata.MediaCompany)

	def idCompanyOrion(self):
		return self.idCompany(provider = Metadata.ProviderOrion)

	def idCompanyImdb(self):
		return self.idCompany(provider = Metadata.ProviderImdb)

	def idCompanyTmdb(self):
		return self.idCompany(provider = Metadata.ProviderTmdb)

	def idCompanyTvdb(self):
		return self.idCompany(provider = Metadata.ProviderTvdb)

	def idCompanyTrakt(self):
		return self.idCompany(provider = Metadata.ProviderTrakt)

	def idCompanySet(self, value, provider):
		self.idSet(value = value, provider = provider, media = Metadata.MediaCompany)

	def idCompanyOrionSet(self, value):
		self.idCompanySet(value = value, provider = Metadata.ProviderOrion)

	def idCompanyImdbSet(self, value):
		self.idCompanySet(value = value, provider = Metadata.ProviderImdb)

	def idCompanyTmdbSet(self, value):
		self.idCompanySet(value = value, provider = Metadata.ProviderTmdb)

	def idCompanyTvdbSet(self, value):
		self.idCompanySet(value = value, provider = Metadata.ProviderTvdb)

	def idCompanyTraktSet(self, value):
		self.idCompanySet(value = value, provider = Metadata.ProviderTrakt)

	###################################################################
	# TYPE
	###################################################################

	def type(self, media = MediaDefault, selection = SelectionDefault):
		return self.dataRetrieve(type = 'type', media = media, unique = True, selection = selection)

	def typeCharacter(self, selection = SelectionDefault):
		return self.type(media = Metadata.MediaCharacter if self.mediaPerson() else Metadata.MediaDefault, selection = selection)

	def typeCompany(self, selection = SelectionDefault):
		return self.type(media = Metadata.MediaCompany, selection = selection)

	def typeSet(self, value, media = MediaDefault):
		if value: self.dataUpdate(data = {'type' : value}, media = media)

	###################################################################
	# ROLE
	###################################################################

	def role(self, media = MediaDefault, selection = SelectionDefault):
		return self.dataRetrieve(type = 'role', media = media, unique = True, selection = selection)

	def roleCharacter(self, selection = SelectionDefault):
		return self.role(media = Metadata.MediaCharacter if self.mediaPerson() else Metadata.MediaDefault, selection = selection)

	def roleSet(self, value, media = MediaDefault):
		if value: self.dataUpdate(data = {'role' : value}, media = media)

	###################################################################
	# SLUG
	###################################################################

	def slug(self, media = MediaDefault):
		return self.dataRetrieve(type = 'slug', media = media)

	def slugMovie(self):
		return self.slug(media = Metadata.MediaMovie)

	def slugCollection(self):
		return self.slug(media = Metadata.MediaCollection)

	def slugShow(self):
		return self.slug( media = Metadata.MediaShow)

	def slugSeason(self):
		return self.slug(media = Metadata.MediaSeason)

	def slugEpisode(self):
		return self.slug(media = Metadata.MediaEpisode)

	def slugSet(self, value, media = MediaDefault):
		if value: self.dataUpdate(data = {'slug' : value}, media = media)

	def slugMovieSet(self, value):
		self.slugSet(value = value, media = Metadata.MediaMovie)

	def slugCollectionSet(self, value):
		self.slugSet(value = value, media = Metadata.MediaCollection)

	def slugShowSet(self, value):
		self.slugSet(value = value, media = Metadata.MediaShow)

	def slugSeasonSet(self, value):
		self.slugSet(value = value, media = Metadata.MediaSeason)

	def slugEpisodeSet(self, value):
		self.slugSet(value = value, media = Metadata.MediaEpisode)

	###################################################################
	# NUMBER
	###################################################################

	def number(self, format = Default, media = MediaDefault):
		if media is Metadata.MediaDefault and self.mediaEpisode() and format:
			numberSeason = self.numberSeason()
			numberEpisode = self.numberEpisode()
			try: return format % (numberSeason, numberEpisode)
			except: return Media.number(season = numberSeason, episode = numberEpisode)
		else:
			result = self.dataRetrieve(type = 'number', media = media)
			if not result is None and format:
				if format is True: result = '%01d' % result
				else: result = format % result
			return result

	def numberSeason(self, format = Default):
		return self.number(format = format, media = Metadata.MediaSeason)

	def numberEpisode(self, format = Default):
		return self.number(format = format, media = Metadata.MediaEpisode)

	def numberSet(self, value, media = MediaDefault):
		if not value is None: self.dataUpdate(data = {'number' : value}, media = media)

	def numberSeasonSet(self, value):
		self.numberSet(value = value, media = Metadata.MediaSeason)

	def numberEpisodeSet(self, value):
		self.numberSet(value = value, media = Metadata.MediaEpisode)

	###################################################################
	# LANGUAGE
	###################################################################

	def language(self, language, media = MediaDefault, selection = SelectionDefault):
		return self.dataRetrieve(type = ['language', language], media = media, selection = selection)

	def languageOriginal(self, media = MediaDefault, selection = SelectionDefault):
		return self.language(language = Metadata.LanguageOriginal, media = media, selection = selection)

	def languageAudio(self, media = MediaDefault, selection = SelectionDefault):
		return self.language(language = Metadata.LanguageAudio, media = media, selection = selection)

	def languageSubtitle(self, media = MediaDefault, selection = SelectionDefault):
		return self.language(language = Metadata.LanguageSubtitle, media = media, selection = selection)

	def languageSet(self, value, language, media = MediaDefault):
		if value: self.dataUpdate(data = {'language' : {language : self.dataList(value)}}, media = media)

	def languageOriginalSet(self, value, media = MediaDefault):
		self.languageSet(value = value, language = Metadata.LanguageOriginal, media = media)

	def languageAudioSet(self, value, media = MediaDefault):
		self.languageSet(value = value, language = Metadata.LanguageAudio, media = media)

	def languageSubtitleSet(self, value, media = MediaDefault):
		self.languageSet(value = value, language = Metadata.LanguageSubtitle, media = media)

	def languageDefault(self, language, universal = True):
		if language is Metadata.LanguageUnknown: language = Metadata.LanguageDefault
		elif language is Metadata.LanguageDefault: language = Metadata.LanguageOriginal
		elif language == Metadata.LanguageSettings: language = Language.settingsCustom('metadata.location.language')
		if universal and language == Metadata.LanguageOriginal: language = Metadata.LanguageUniversal
		return language

	###################################################################
	# COUNTRY
	###################################################################

	def countryDefault(self, country, universal = True):
		if country is Metadata.CountryDefault: country = Metadata.CountryOriginal
		elif country == Metadata.CountrySettings: country = Country.settings('metadata.location.country')
		if country == Country.Automatic: country = Metadata.CountryOriginal
		if universal and country == Metadata.CountryOriginal: country = Metadata.CountryUniversal
		return country

	###################################################################
	# NAME
	###################################################################

	def name(self, language = LanguageDefault, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		language = self.languageDefault(language = language)
		if selection is Metadata.SelectionDefault:
			media = self.mediaDefault(media)
			if media in [self.media(), Metadata.MediaPerson]: selection = Metadata.SelectionSingle
		result = self.dataRetrieve(type = ['name', language], media = media, selection = selection)
		if not result:
			fallback = self.fallbackDefault(fallback = fallback)
			if fallback:
				if fallback >= Metadata.FallbackPrimary and not result and not language == Metadata.LanguageOriginal: result = self.dataRetrieve(type = ['name', self.languageDefault(language = Metadata.LanguageOriginal)], media = media, selection = selection)
				if fallback >= Metadata.FallbackSecondary and not result and not language == Metadata.LanguageEnglish: result = self.dataRetrieve(type = ['name', self.languageDefault(language = Metadata.LanguageEnglish)], media = media, selection = selection)
		return result

	def nameOriginal(self, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.name(language = Metadata.LanguageOriginal, media = media, selection = selection, fallback = fallback)

	def nameEnglish(self, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.name(language = Metadata.LanguageEnglish, media = media, selection = selection, fallback = fallback)

	def nameSettings(self, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.name(language = Metadata.LanguageSettings, media = media, selection = selection, fallback = fallback)

	def nameSet(self, value, language = LanguageDefault, media = MediaDefault):
		if value:
			if not Tools.isDictionary(value): value = {self.languageDefault(language = language) : self.dataList(value)}
			value = self.dataClean(data = value, newline = True, space = True)
			media = self.mediaDefault(media)
			if media == self.media(): self.dataUpdate(data = {'name' : value}, media = media)
			else:
				person = Metadata(media = Metadata.MediaPerson)
				person.nameSet(value = value, language = language)
				self.personSet(person)

	def nameOriginalSet(self, value, media = MediaDefault):
		self.nameSet(value = value, language = Metadata.LanguageOriginal, media = media)

	def nameEnglishSet(self, value, media = MediaDefault):
		self.nameSet(value = value, language = Metadata.LanguageEnglish, media = media)

	def nameSettingsSet(self, value, media = MediaDefault):
		self.nameSet(value = value, language = Metadata.LanguageSettings, media = media)

	###################################################################
	# NAME - PERSON
	###################################################################

	def namePerson(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		person = self.person(selection = selection)
		if Tools.isArray(person):
			result = [i.name(language = language, selection = selection, fallback = fallback) for i in person]
			result = Tools.listUnique([i for i in result if i])
			return result
		else: return person.name(language = language, selection = selection, fallback = fallback)

	def namePersonOriginal(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.namePerson(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def namePersonEnglish(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.namePerson(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def namePersonSettings(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.namePerson(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	###################################################################
	# NAME - CHARACTER
	###################################################################

	def nameCharacter(self, type = CharacterTypeDefault, role = CharacterRoleDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		character = self.character(type = type, role = role, selection = selection)
		if Tools.isArray(character):
			result = [i.name(language = language, selection = selection, fallback = fallback) for i in character]
			result = Tools.listUnique([i for i in result if i])
			return result
		else: return character.name(language = language, selection = selection, fallback = fallback)

	def nameCharacterOriginal(self, type = CharacterTypeDefault, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = type, role = role, language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCharacterEnglish(self, type = CharacterTypeDefault, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = type, role = role, language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCharacterSettings(self, type = CharacterTypeDefault, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = type, role = role, language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCharacterActor(self, role = CharacterRoleDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = Metadata.CharacterTypeActor, role = role, language = language, selection = selection, fallback = fallback)

	def nameCharacterActorOriginal(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterActor(role = role, language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCharacterActorEnglish(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterActor(role = role, language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCharacterActorSettings(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterActor(role = role, language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCharacterDirector(self, role = CharacterRoleDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = Metadata.CharacterTypeDirector, role = role, language = language, selection = selection, fallback = fallback)

	def nameCharacterDirectorOriginal(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterDirector(role = role, language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCharacterDirectorEnglish(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterDirector(role = role, language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCharacterDirectorSettings(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterDirector(role = role, language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCharacterWriter(self, role = CharacterRoleDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = Metadata.CharacterTypeWriter, role = role, language = language, selection = selection, fallback = fallback)

	def nameCharacterWriterOriginal(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterWriter(role = role, language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCharacterWriterEnglish(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterWriter(role = role, language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCharacterWriterSettings(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterWriter(role = role, language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCharacterEditor(self, role = CharacterRoleDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = Metadata.CharacterTypeEditor, role = role, language = language, selection = selection, fallback = fallback)

	def nameCharacterEditorOriginal(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterEditor(role = role, language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCharacterEditorEnglish(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterEditor(role = role, language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCharacterEditorSettings(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterEditor(role = role, language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCharacterCreator(self, role = CharacterRoleDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = Metadata.CharacterTypeCreator, role = role, language = language, selection = selection, fallback = fallback)

	def nameCharacterCreatorOriginal(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterCreator(role = role, language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCharacterCreatorEnglish(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterCreator(role = role, language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCharacterCreatorSettings(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterCreator(role = role, language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCharacterHost(self, role = CharacterRoleDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = Metadata.CharacterTypeHost, role = role, language = language, selection = selection, fallback = fallback)

	def nameCharacterHostOriginal(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterHost(role = role, language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCharacterHostEnglish(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterHost(role = role, language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCharacterHostSettings(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterHost(role = role, language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCharacterCrew(self, role = CharacterRoleDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = Metadata.CharacterTypeCrew, role = role, language = language, selection = selection, fallback = fallback)

	def nameCharacterCrewOriginal(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterCrew(role = role, language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCharacterCrewEnglish(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterCrew(role = role, language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCharacterCrewSettings(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterCrew(role = role, language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCharacterProducer(self, role = CharacterRoleDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = Metadata.CharacterTypeProducer, role = role, language = language, selection = selection, fallback = fallback)

	def nameCharacterProducerOriginal(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterProducer(role = role, language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCharacterProducerEnglish(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterProducer(role = role, language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCharacterProducerSettings(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterProducer(role = role, language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCharacterGuest(self, role = CharacterRoleDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacter(type = Metadata.CharacterTypeGuest, role = role, language = language, selection = selection, fallback = fallback)

	def nameCharacterGuestOriginal(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterGuest(role = role, language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCharacterGuestEnglish(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterGuest(role = role, language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCharacterGuestSettings(self, role = CharacterRoleDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCharacterGuest(role = role, language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	###################################################################
	# NAME - COMPANY
	###################################################################

	def nameCompany(self, type = CompanyTypeDefault, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		company = self.company(type = type, selection = selection)
		if Tools.isArray(company):
			result = [i.name(language = language, selection = selection, fallback = fallback) for i in company]
			result = Tools.listUnique([i for i in result if i])
			return result
		else: return company.name(language = language, selection = selection, fallback = fallback)

	def nameCompanyOriginal(self, company = CompanyTypeDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompany(company = company, language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCompanyEnglish(self, company = CompanyTypeDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompany(company = company, language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCompanySettings(self, company = CompanyTypeDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompany(company = company, language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCompanyNetwork(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompany(company = Metadata.CompanyTypeNetwork, language = language, selection = selection, fallback = fallback)

	def nameCompanyNetworkOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyNetwork(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCompanyNetworkEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyNetwork(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCompanyNetworkSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyNetwork(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCompanyStudio(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompany(company = Metadata.CompanyTypeStudio, language = language, selection = selection, fallback = fallback)

	def nameCompanyStudioOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyStudio(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCompanyStudioEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyStudio(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCompanyStudioSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyStudio(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCompanyProducer(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompany(company = Metadata.CompanyTypeProducer, language = language, selection = selection, fallback = fallback)

	def nameCompanyProducerOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyProducer(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCompanyProducerEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyProducer(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCompanyProducerSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyProducer(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCompanyDistributor(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompany(company = Metadata.CompanyTypeDistributor, language = language, selection = selection, fallback = fallback)

	def nameCompanyDistributorOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyDistributor(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCompanyDistributorEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyDistributor(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCompanyDistributorSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyDistributor(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def nameCompanyEffects(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompany(company = Metadata.CompanyTypeEffects, language = language, selection = selection, fallback = fallback)

	def nameCompanyEffectsOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyEffects(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def nameCompanyEffectsEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyEffects(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def nameCompanyEffectsSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.nameCompanyEffects(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	###################################################################
	# TITLE
	###################################################################

	def title(self, language = LanguageDefault, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		if language is True: return self.dataRetrieve(type = 'title', media = media, selection = selection) # Retrieve dictionary of all translations.

		language = self.languageDefault(language = language)
		result = self.dataRetrieve(type = ['title', language], media = media, selection = selection)
		if not result:
			fallback = self.fallbackDefault(fallback = fallback)
			if fallback:
				if fallback >= Metadata.FallbackPrimary and not result and not language == Metadata.LanguageOriginal: result = self.dataRetrieve(type = ['title', self.languageDefault(language = Metadata.LanguageOriginal)], media = media, selection = selection)
				if fallback >= Metadata.FallbackSecondary and not result and not language == Metadata.LanguageEnglish: result = self.dataRetrieve(type = ['title', self.languageDefault(language = Metadata.LanguageEnglish)], media = media, selection = selection)
		return result

	def titleOriginal(self, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.title(language = Metadata.LanguageOriginal, media = media, selection = selection, fallback = fallback)

	def titleEnglish(self, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.title(language = Metadata.LanguageEnglish, media = media, selection = selection, fallback = fallback)

	def titleSettings(self, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.title(language = Metadata.LanguageSettings, media = media, selection = selection, fallback = fallback)

	def titleSet(self, value, language = LanguageDefault, media = MediaDefault):
		if value:
			if not Tools.isDictionary(value): value = {self.languageDefault(language = language) : self.dataList(value)}
			value = self.dataClean(data = value, newline = True, space = True)
			self.dataUpdate(data = {'title' : value}, media = media)

	def titleOriginalSet(self, value, media = MediaDefault):
		self.titleSet(value = value, language = Metadata.LanguageOriginal, media = media)

	def titleEnglishSet(self, value, media = MediaDefault):
		self.titleSet(value = value, language = Metadata.LanguageEnglish, media = media)

	def titleSettingsSet(self, value, media = MediaDefault):
		self.titleSet(value = value, language = Metadata.LanguageSettings, media = media)

	###################################################################
	# TITLE - MOVIE
	###################################################################

	def titleMovie(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.title(language = language, media = Metadata.MediaMovie, selection = selection, fallback = fallback)

	def titleMovieOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleMovie(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def titleMovieEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleMovie(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def titleMovieSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleMovie(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def titleMovieSet(self, value, language = LanguageDefault):
		self.titleSet(value = value, language = language, media = Metadata.MediaMovie)

	def titleMovieOriginalSet(self, value):
		self.titleMovieSet(value = value, language = Metadata.LanguageOriginal)

	def titleMovieEnglishSet(self, value):
		self.titleMovieSet(value = value, language = Metadata.LanguageEnglish)

	def titleMovieSettingsSet(self, value):
		self.titleMovieSet(value = value, language = Metadata.LanguageSettings)

	###################################################################
	# TITLE - COLLECTION
	###################################################################

	def titleCollection(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.title(language = language, media = Metadata.MediaCollection, selection = selection, fallback = fallback)

	def titleCollectionOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleCollection(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def titleCollectionEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleCollection(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def titleCollectionSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleCollection(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def titleCollectionSet(self, value, language = LanguageDefault):
		self.titleSet(value = value, language = language, media = Metadata.MediaCollection)

	def titleCollectionOriginalSet(self, value):
		self.titleCollectionSet(value = value, language = Metadata.LanguageOriginal)

	def titleCollectionEnglishSet(self, value):
		self.titleCollectionSet(value = value, language = Metadata.LanguageEnglish)

	def titleCollectionSettingsSet(self, value):
		self.titleCollectionSet(value = value, language = Metadata.LanguageSettings)

	###################################################################
	# TITLE - SHOW
	###################################################################

	def titleShow(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.title(language = language, media = Metadata.MediaShow, selection = selection, fallback = fallback)

	def titleShowOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleShow(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def titleShowEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleShow(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def titleShowSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleShow(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def titleShowSet(self, value, language = LanguageDefault):
		self.titleSet(value = value, language = language, media = Metadata.MediaShow)

	def titleShowOriginalSet(self, value):
		self.titleShowSet(value = value, language = Metadata.LanguageOriginal)

	def titleShowEnglishSet(self, value):
		self.titleShowSet(value = value, language = Metadata.LanguageEnglish)

	def titleShowSettingsSet(self, value):
		self.titleShowSet(value = value, language = Metadata.LanguageSettings)

	###################################################################
	# TITLE - SEASON
	###################################################################

	def titleSeason(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.title(language = language, media = Metadata.MediaSeason, selection = selection, fallback = fallback)

	def titleSeasonOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleSeason(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def titleSeasonEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleSeason(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def titleSeasonSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleSeason(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def titleSeasonSet(self, value, language = LanguageDefault):
		self.titleSet(value = value, language = language, media = Metadata.MediaSeason)

	def titleSeasonOriginalSet(self, title):
		self.titleSeasonSet(value = value, language = Metadata.LanguageOriginal)

	def titleSeasonEnglishSet(self, title):
		self.titleSeasonSet(value = value, language = Metadata.LanguageEnglish)

	def titleSeasonSettingsSet(self, title):
		self.titleSeasonSet(value = value, language = Metadata.LanguageSettings)

	###################################################################
	# TITLE - EPISODE
	###################################################################

	def titleEpisode(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.title(language = language, media = Metadata.MediaEpisode, selection = selection, fallback = fallback)

	def titleEpisodeOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleEpisode(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def titleEpisodeEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleEpisode(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def titleEpisodeSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.titleEpisode(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def titleEpisodeSet(self, value, language = LanguageDefault):
		self.titleSet(value = value, language = language, media = Metadata.MediaEpisode)

	def titleEpisodeOriginalSet(self, title):
		self.titleEpisodeSet(value = value, language = Metadata.LanguageOriginal)

	def titleEpisodeEnglishSet(self, title):
		self.titleEpisodeSet(value = value, language = Metadata.LanguageEnglish)

	def titleEpisodeSettingsSet(self, title):
		self.titleEpisodeSet(value = value, language = Metadata.LanguageSettings)

	###################################################################
	# OVERVIEW
	###################################################################

	def overview(self, language = LanguageDefault, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		if language is True: return self.dataRetrieve(type = 'overview', media = media, selection = selection) # Retrieve dictionary of all translations.

		language = self.languageDefault(language = language)
		result = self.dataRetrieve(type = ['overview', language], media = media, selection = selection)
		if not result:
			fallback = self.fallbackDefault(fallback = fallback)
			if fallback:
				if fallback >= Metadata.FallbackPrimary and not result and not language == Metadata.LanguageOriginal: result = self.dataRetrieve(type = ['overview', Metadata.LanguageOriginal], media = media, selection = selection)
				if fallback >= Metadata.FallbackSecondary and not result and not language == Metadata.LanguageEnglish: result = self.dataRetrieve(type = ['overview', Metadata.LanguageEnglish], media = media, selection = selection)
		return result

	def overviewOriginal(self, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overview(language = Metadata.LanguageOriginal, media = media, selection = selection, fallback = fallback)

	def overviewEnglish(self, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overview(language = Metadata.LanguageEnglish, media = media, selection = selection, fallback = fallback)

	def overviewSettings(self, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overview(language = Metadata.LanguageSettings, media = media, selection = selection, fallback = fallback)

	def overviewSet(self, value, language = LanguageDefault, media = MediaDefault):
		if value:
			if not Tools.isDictionary(value): value = {self.languageDefault(language = language) : self.dataList(value)}
			value = self.dataClean(data = value, newline = False, space = True)
			self.dataUpdate(data = {'overview' : value}, media = media)

	def overviewOriginalSet(self, value, media = MediaDefault):
		self.overviewSet(value = value, language = Metadata.LanguageOriginal, media = media)

	def overviewEnglishSet(self, value, media = MediaDefault):
		self.overviewSet(value = value, language = Metadata.LanguageEnglish, media = media)

	def overviewSettingsSet(self, value, media = MediaDefault):
		self.overviewSet(value = value, language = Metadata.LanguageSettings, media = media)

	###################################################################
	# OVERVIEW - MOVIE
	###################################################################

	def overviewMovie(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overview(language = language, media = Metadata.MediaMovie, selection = selection, fallback = fallback)

	def overviewMovieOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewMovie(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def overviewMovieEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewMovie(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def overviewMovieSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewMovie(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def overviewMovieSet(self, value, language = LanguageDefault):
		self.overviewSet(value = value, language = language, media = Metadata.MediaMovie)

	def overviewMovieOriginalSet(self, value):
		self.overviewMovieSet(value = overview, language = Metadata.LanguageOriginal)

	def overviewMovieEnglishSet(self, value):
		self.overviewMovieSet(value = value, language = Metadata.LanguageEnglish)

	def overviewMovieSettingsSet(self, value):
		self.overviewMovieSet(value = value, language = Metadata.LanguageSettings)

	###################################################################
	# OVERVIEW - COLLECTION
	###################################################################

	def overviewCollection(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overview(language = language, media = Metadata.MediaCollection, selection = selection, fallback = fallback)

	def overviewCollectionOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewCollection(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def overviewCollectionEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewCollection(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def overviewCollectionSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewCollection(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def overviewCollectionSet(self, value, language = LanguageDefault):
		self.overviewSet(value = value, language = language, media = Metadata.MediaCollection)

	def overviewCollectionOriginalSet(self, value):
		self.overviewCollectionSet(value = value, language = Metadata.LanguageOriginal)

	def overviewCollectionEnglishSet(self, value):
		self.overviewCollectionSet(value = value, language = Metadata.LanguageEnglish)

	def overviewCollectionSettingsSet(self, value):
		self.overviewCollectionSet(value = value, language = Metadata.LanguageSettings)

	###################################################################
	# OVERVIEW - SHOW
	###################################################################

	def overviewShow(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overview(language = language, media = Metadata.MediaShow, selection = selection, fallback = fallback)

	def overviewShowOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewShow(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def overviewShowEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewShow(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def overviewShowSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewShow(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def overviewShowSet(self, value, language = LanguageDefault):
		self.overviewSet(value = value, language = language, media = Metadata.MediaShow)

	def overviewShowOriginalSet(self, value):
		self.overviewShowSet(value = value, language = Metadata.LanguageOriginal)

	def overviewShowEnglishSet(self, value):
		self.overviewShowSet(value = value, language = Metadata.LanguageEnglish)

	def overviewShowSettingsSet(self, value):
		self.overviewShowSet(value = value, language = Metadata.LanguageSettings)

	###################################################################
	# OVERVIEW - SEASON
	###################################################################

	def overviewSeason(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overview(language = language, media = Metadata.MediaSeason, selection = selection, fallback = fallback)

	def overviewSeasonOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewSeason(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def overviewSeasonEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewSeason(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def overviewSeasonSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewSeason(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def overviewSeasonSet(self, value, language = LanguageDefault):
		self.overviewSet(value = value, language = language, media = Metadata.MediaSeason)

	def overviewSeasonOriginalSet(self, value):
		self.overviewSeasonSet(value = value, language = Metadata.LanguageOriginal)

	def overviewSeasonEnglishSet(self, value):
		self.overviewSeasonSet(value = value, language = Metadata.LanguageEnglish)

	def overviewSeasonSettingsSet(self, value):
		self.overviewSeasonSet(value = value, language = Metadata.LanguageSettings)

	###################################################################
	# OVERVIEW - EPISODE
	###################################################################

	def overviewEpisode(self, language = LanguageDefault, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overview(language = language, media = Metadata.MediaEpisode, selection = selection, fallback = fallback)

	def overviewEpisodeOriginal(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewEpisode(language = Metadata.LanguageOriginal, selection = selection, fallback = fallback)

	def overviewEpisodeEnglish(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewEpisode(language = Metadata.LanguageEnglish, selection = selection, fallback = fallback)

	def overviewEpisodeSettings(self, selection = SelectionDefault, fallback = FallbackDefault):
		return self.overviewEpisode(language = Metadata.LanguageSettings, selection = selection, fallback = fallback)

	def overviewEpisodeSet(self, value, language = LanguageDefault):
		self.overviewSet(value = value, language = language, media = Metadata.MediaEpisode)

	def overviewEpisodeOriginalSet(self, value):
		self.overviewEpisodeSet(value = value, language = Metadata.LanguageOriginal)

	def overviewEpisodeEnglishSet(self, value):
		self.overviewEpisodeSet(value = value, language = Metadata.LanguageEnglish)

	def overviewEpisodeSettingsSet(self, value):
		self.overviewEpisodeSet(value = value, language = Metadata.LanguageSettings)

	###################################################################
	# YEAR
	###################################################################

	def year(self, media = MediaDefault):
		return self.dataRetrieve(type = 'year', media = media)

	def yearSet(self, value, media = MediaDefault):
		if value: self.dataUpdate(data = {'year' : int(value)}, media = media)

	@classmethod
	def yearExtract(self, data):
		if data:
			year = Regex.extract(data = data, expression = '((?:19|2\d)\d{2})')
			if year: return int(year)
		return None

	###################################################################
	# IMAGE
	###################################################################

	def image(self, type = ImageTypeDefault, quality = ImageQualityDefault, opacity = ImageOpacityDefault, language = LanguageDefault, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault, internal = False):
		type = self.imageTypeDefault(type = type)
		quality = self.imageQualityDefault(quality = quality)
		opacity = self.imageOpacityDefault(opacity = opacity)

		if not Tools.isArray(language): language = [language]
		language = [self.languageDefault(language = i) for i in language]
		language = Tools.listUnique(language)

		result = []
		for i in language:
			images = self.dataRetrieve(type = 'image', attribute = {'type' : type, 'quality' : quality, 'opacity' : opacity, 'language' : i}, sort = 'vote', extract = 'link', media = media, selection = selection)
			if images:
				if Tools.isArray(images): result.extend(images)
				else: result.append(images)

		fallback = self.fallbackDefault(fallback = fallback, default = Metadata.FallbackSecondary if (opacity == Metadata.ImageOpacityClear) else Metadata.FallbackTertiary) # Do not fal back to solid for clear images. Otherwise solid images are displayed in the GUI where opacity is required.
		if fallback and not result:
			# Put False (unknown language) last, since TVDb has images with an unknow language.
			# Some of these unknown languages are indeed the universal (or common English) images, but some contain writing from other languages (eg: Avatar).
			# Try to avoid these images by preferring English images.

			if fallback >= Metadata.FallbackPrimary: language.extend([Metadata.LanguageUniversal, Metadata.LanguageEnglish, Metadata.LanguageUnknown])
			language = Tools.listUnique(language)

			# Prefer the same type/quality/opacity over language.
			for i in language:
				result = self.dataRetrieve(type = 'image', attribute = {'type' : type, 'quality' : quality, 'opacity' : opacity, 'language' : i}, sort = 'vote', extract = 'link', media = media, selection = selection)
				if result: break

			if not result:
				order = [[quality, opacity]]
				if quality == Metadata.ImageQualityHigh and opacity == Metadata.ImageOpacitySolid:
					if fallback >= Metadata.FallbackPrimary: order.extend([[Metadata.ImageQualityLow, Metadata.ImageOpacitySolid]])
					if fallback >= Metadata.FallbackTertiary: order.extend([[Metadata.ImageQualityHigh, Metadata.ImageOpacityClear], [Metadata.ImageQualityLow, Metadata.ImageOpacityClear]])
				elif quality == Metadata.ImageQualityLow and opacity == Metadata.ImageOpacitySolid:
					if fallback >= Metadata.FallbackPrimary: order.extend([[Metadata.ImageQualityHigh, Metadata.ImageOpacitySolid]])
					if fallback >= Metadata.FallbackTertiary: order.extend([[Metadata.ImageQualityLow, Metadata.ImageOpacityClear], [Metadata.ImageQualityHigh, Metadata.ImageOpacityClear]])
				elif quality == Metadata.ImageQualityHigh and opacity == Metadata.ImageOpacityClear:
					if fallback >= Metadata.FallbackPrimary: order.extend([[Metadata.ImageQualityLow, Metadata.ImageOpacityClear]])
					if fallback >= Metadata.FallbackTertiary: order.extend([[Metadata.ImageQualityHigh, Metadata.ImageOpacitySolid], [Metadata.ImageQualityLow, Metadata.ImageOpacitySolid]])
				elif quality == Metadata.ImageQualityLow and opacity == Metadata.ImageOpacityClear:
					if fallback >= Metadata.FallbackPrimary: order.extend([[Metadata.ImageQualityHigh, Metadata.ImageOpacityClear]])
					if fallback >= Metadata.FallbackTertiary: order.extend([[Metadata.ImageQualityLow, Metadata.ImageOpacitySolid], [Metadata.ImageQualityHigh, Metadata.ImageOpacitySolid]])

				# Select a similar quality/opacity.
				for i in language:
					for j in order:
						result = self.dataRetrieve(type = 'image', attribute = {'type' : type, 'quality' : j[0], 'opacity' : j[1], 'language' : i}, sort = 'vote', extract = 'link', media = media, selection = selection)
						if result: break
					if result: break

				# Select any available language.
				if not result and fallback >= Metadata.FallbackSecondary:
					for j in order:
						result = self.dataRetrieve(type = 'image', attribute = {'type' : type, 'quality' : j[0], 'opacity' : j[1]}, sort = 'vote', extract = 'link', media = media, selection = selection)
						if result: break

				# Select alterntives.
				if not result and fallback >= Metadata.FallbackTertiary and not internal:
					alternatives = {
						Metadata.ImageTypePoster : Metadata.ImageTypeThumbnail,
						Metadata.ImageTypeThumbnail : Metadata.ImageTypePoster,

						Metadata.ImageTypeBackground : Metadata.ImageTypeArtwork,
						Metadata.ImageTypeArtwork : Metadata.ImageTypeBackground,
					}
					if type in alternatives:
						for i in language:
							result = self.image(type = alternatives[type], quality = quality, opacity = opacity, language = i, media = media, selection = selection, fallback = fallback, internal = True)
							if result: break

				# Select any available.
				if not result and fallback >= Metadata.FallbackQuaternary:
					result = self.dataRetrieve(type = 'image', sort = 'vote', extract = 'link', media = media, selection = selection)

		result = self.dataSelect(data = result, selection = selection)
		if Tools.isArray(result): result = Tools.listUnique(result)
		return result

	def imageIcon(self, quality = ImageQualityDefault, opacity = ImageOpacityDefault, language = LanguageDefault, media = MediaDefault, selection = SelectionSingle, fallback = FallbackDefault):
		return self.image(type = Metadata.ImageTypeIcon, quality = quality, opacity = opacity, language = language, media = media, selection = selection, fallback = fallback)

	def imageIconClear(self, quality = ImageQualityDefault, language = LanguageDefault, media = MediaDefault, selection = SelectionSingle, fallback = FallbackDefault):
		return self.imageIcon(quality = quality, opacity = Metadata.ImageOpacityClear, language = language, media = media, selection = selection, fallback = fallback)

	def imagePoster(self, quality = ImageQualityDefault, opacity = ImageOpacityDefault, language = LanguageDefault, media = MediaDefault, selection = SelectionSingle, fallback = FallbackDefault):
		return self.image(type = Metadata.ImageTypePoster, quality = quality, opacity = opacity, language = language, media = media, selection = selection, fallback = fallback)

	def imagePhoto(self, quality = ImageQualityDefault, opacity = ImageOpacityDefault, language = LanguageDefault, media = MediaDefault, selection = SelectionSingle, fallback = FallbackDefault):
		return self.image(type = Metadata.ImageTypePhoto, quality = quality, opacity = opacity, language = language, media = media, selection = selection, fallback = fallback)

	def imageBanner(self, quality = ImageQualityDefault, opacity = ImageOpacityDefault, language = LanguageDefault, media = MediaDefault, selection = SelectionSingle, fallback = FallbackDefault):
		return self.image(type = Metadata.ImageTypeBanner, quality = quality, opacity = opacity, language = language, media = media, selection = selection, fallback = fallback)

	def imageBackground(self, quality = ImageQualityDefault, opacity = ImageOpacityDefault, language = LanguageDefault, media = MediaDefault, selection = SelectionSingle, fallback = FallbackDefault):
		return self.image(type = Metadata.ImageTypeBackground, quality = quality, opacity = opacity, language = language, media = media, selection = selection, fallback = fallback)

	def imageArtwork(self, quality = ImageQualityDefault, opacity = ImageOpacityDefault, language = LanguageDefault, media = MediaDefault, selection = SelectionSingle, fallback = FallbackDefault):
		return self.image(type = Metadata.ImageTypeArtwork, quality = quality, opacity = opacity, language = language, media = media, selection = selection, fallback = fallback)

	def imageArtworkClear(self, quality = ImageQualityDefault, opacity = ImageOpacityDefault, language = LanguageDefault, media = MediaDefault, selection = SelectionSingle, fallback = FallbackDefault):
		return self.imageArtwork(quality = quality, opacity = Metadata.ImageOpacityClear, language = language, media = media, selection = selection, fallback = fallback)

	def imageThumbnail(self, quality = ImageQualityDefault, opacity = ImageOpacityDefault, language = LanguageDefault, media = MediaDefault, selection = SelectionSingle, fallback = FallbackDefault):
		return self.image(type = Metadata.ImageTypeThumbnail, quality = quality, opacity = opacity, language = language, media = media, selection = selection, fallback = fallback)

	def imageCinemagraph(self, quality = ImageQualityDefault, opacity = ImageOpacityDefault, language = LanguageDefault, media = MediaDefault, selection = SelectionSingle, fallback = FallbackDefault):
		return self.image(type = Metadata.ImageTypeCinemagraph, quality = quality, opacity = opacity, language = language, media = media, selection = selection, fallback = fallback)

	def imageSet(self, value, id = None, provider = ProviderDefault, type = ImageTypeDefault, quality = ImageQualityDefault, opacity = ImageOpacityDefault, language = LanguageDefault, vote = 0, media = MediaDefault):
		# Set images as a list, so that a list of images can be passed to imageSet().
		# This reduces the time of dataUpdate() compared to setting images individually.
		if value:
			if not Tools.isArray(value): value = [value]
			for i in range(len(value)):
				item = value[i]

				if not media:
					try: media = item['media']
					except: pass

				if not Tools.isStructure(item):
					item = {
						'type' : type,
						'quality' : quality,
						'opacity' : opacity,
						'language' : language,
						'vote' : vote,
						'link' : item,
					}
				itemDefault = {
					'type' : self.imageTypeDefault(type = item['type']),
					'quality' : self.imageQualityDefault(quality = item['quality']),
					'opacity' : self.imageOpacityDefault(opacity = item['opacity']),
					'language' : self.languageDefault(language = item['language']),
					'vote' : self.voteDefault(item['vote']),
					'link' : item['link'],
				}

				media = self.mediaDefault(media = media)

				# TVDb returns artwork in the main structure (eg: show) that belongs to substructures (eg: season or episode).
				if id and self.mediaContent():
					item = self.item(media = media, attribute = {'id' : {provider : str(id)}}, selection = Metadata.SelectionSingle)

					# TVDb has character images but they have the person ID.
					if not item and media == Metadata.MediaCharacter: item = self.item(media = media, attribute = {'person' : {'id' : {provider : str(id)}}}, selection = Metadata.SelectionSingle)

					if item: item.imageSet(item = itemDefault, media = media)

				# Character photos should be added to the main "image" list and not the "character" list.
				if self.mediaContent() and (self.mediaEntity(media = media) or id): media = Metadata.MediaDefault

				# If the image is overwritten multiple times (eg: TVDb might have the image in "artwork" and "season"), use the best values between them.
				# This is especially important for the vote. Always use the highest vote instead of overwritting it with the last value.
				result = self.dataRetrieve(type = 'image', attribute = {'link' : itemDefault['link']}, media = media, selection = Metadata.SelectionSingle)
				if result:
					for k, v in result.items():
						if item[k] is None:
							if not v is None: item[k] = v
					try: item['vote'] = max(item['vote'], result['vote'])
					except: pass
				else:
					item = itemDefault

				value[i] = item

			# Always add character photos to the content/main image list as well, even if already added to the subcontent.
			# Allows the character photos to be part of the movie/show images.
			self.dataUpdate(data = {'image' : self.dataList(value)}, media = media, unique = 'link')

	@classmethod
	def imageTypeExtract(self, data):
		try: return Metadata.DataImageType[data]
		except: pass

		image = Metadata.ImageTypeDefault
		if Regex.match(data = data, expression = '(?:icon|logo)'): image = Metadata.ImageTypeIcon
		elif Regex.match(data = data, expression = 'poster'): image = Metadata.ImageTypePoster
		elif Regex.match(data = data, expression = '(?:ph|f)oto'): image = Metadata.ImageTypePhoto
		elif Regex.match(data = data, expression = 'banner'): image = Metadata.ImageTypeBanner
		elif Regex.match(data = data, expression = 'background'): image = Metadata.ImageTypeBackground
		elif Regex.match(data = data, expression = '(?:fan[\s\-\_\.]*)?art(?:[\s\-\_\.]*work)?'): image = Metadata.ImageTypeArtwork
		elif Regex.match(data = data, expression = '(?:thumb(?:[\s\-\_\.]*nail)?|screens?(?:[\s\-\_\.]*caps?)?)'): image = Metadata.ImageTypeThumbnail
		elif Regex.match(data = data, expression = 'cinema(?:[\s\-\_\.]*graph)?'): image = Metadata.ImageTypeCinemagraph
		elif Regex.match(data = data, expression = '(?:person|people|character|actor|director|producer)'): image = Metadata.ImageTypePhoto # Eg: https://artworks.thetvdb.com/banners/person/xxx/primary.jpg

		Metadata.DataImageType[data] = image
		return image

	def imageTypeDefault(self, type):
		if type is Metadata.ImageTypeDefault:
			if self.mediaEntity(): type = Metadata.ImageTypePhoto
			else: type = Metadata.ImageTypePoster
		return type

	@classmethod
	def imageQualityExtract(self, data):
		try: return Metadata.DataImageQuality[data]
		except: pass

		quality = Metadata.ImageQualityDefault
		if Regex.match(data = data, expression = '(?:high|[^a-z0-9]*h[qd][^a-z0-9]*|16\s*:\s*\d)'): quality = Metadata.ImageQualityHigh
		elif Regex.match(data = data, expression = '(?:low|[^a-z0-9]*[sl][qd][^a-z0-9]*|4\s*:\s*3)'): quality = Metadata.ImageQualityLow

		Metadata.DataImageQuality[data] = quality
		return quality

	@classmethod
	def imageQualityDefault(self, quality):
		if quality is Metadata.ImageQualityDefault: quality = Metadata.ImageQualityHigh
		return quality

	@classmethod
	def imageOpacityExtract(self, data):
		try: return Metadata.DataImageOpacity[data]
		except: pass

		opacity = Metadata.ImageOpacityDefault
		if Regex.match(data = data, expression = '(?:clear|transparent)'): opacity = Metadata.ImageOpacityClear
		elif Regex.match(data = data, expression = '(?:opaque|solid)'): opacity = Metadata.ImageOpacitySolid

		Metadata.DataImageOpacity[data] = opacity
		return opacity

	@classmethod
	def imageOpacityDefault(self, opacity):
		if opacity is Metadata.ImageOpacityDefault: opacity = Metadata.ImageOpacitySolid
		return opacity

	###################################################################
	# GENRE
	###################################################################

	def genre(self, name = False, media = MediaDefault, selection = SelectionDefault):
		result = self.dataRetrieve(type = 'genre', media = media, selection = selection)
		if name and result: result = [Metadata.GenreNames[i] for i in result]
		return result

	def genreName(self, format = FormatNone, media = MediaDefault, selection = SelectionDefault):
		genre = self.genre(name = True, media = media, selection = selection)
		return self.format(value = genre, format = format)

	def genreSet(self, value,  media = MediaDefault):
		if value: self.dataUpdate(data = {'genre' : self.dataList(value)}, media = media)

	@classmethod
	def genreExtract(self, data):
		try: return Metadata.DataGenre[genre]
		except: pass

		provider = Metadata.GenreDefault
		if Regex.match(data = data, expression = '(?:action)'): genre = Metadata.GenreAction
		elif Regex.match(data = data, expression = '(?:sci(?:ence)?[\s\-]*fi(?:ction)?)'): genre = Metadata.GenreScience
		elif Regex.match(data = data, expression = '(?:fantasy)'): genre = Metadata.GenreFantasy
		elif Regex.match(data = data, expression = '(?:adventure)'): genre = Metadata.GenreAdventure
		elif Regex.match(data = data, expression = '(?:horror)'): genre = Metadata.GenreHorror
		elif Regex.match(data = data, expression = '(?:disaster|apocalyp)'): genre = Metadata.GenreDisaster
		elif Regex.match(data = data, expression = '(?:mystery)'): genre = Metadata.GenreMystery
		elif Regex.match(data = data, expression = '(?:suspense)'): genre = Metadata.GenreSuspense
		elif Regex.match(data = data, expression = '(?:thriller)'): genre = Metadata.GenreThriller
		elif Regex.match(data = data, expression = '(?:crime)'): genre = Metadata.GenreCrime
		elif Regex.match(data = data, expression = '(?:martial|karate|kong[\s\-]*fu)'): genre = Metadata.GenreMartial
		elif Regex.match(data = data, expression = '(?:east)'): genre = Metadata.GenreEastern
		elif Regex.match(data = data, expression = '(?:west)'): genre = Metadata.GenreWestern
		elif Regex.match(data = data, expression = '(?:war)'): genre = Metadata.GenreWar
		elif Regex.match(data = data, expression = '(?:histor(?:y|ical))'): genre = Metadata.GenreHistory
		elif Regex.match(data = data, expression = '(?:comedy)'): genre = Metadata.GenreComedy
		elif Regex.match(data = data, expression = '(?:romance|love)'): genre = Metadata.GenreRomance
		elif Regex.match(data = data, expression = '(?:drama)'): genre = Metadata.GenreDrama

		elif Regex.match(data = data, expression = '(?:family)'): genre = Metadata.GenreFamily
		elif Regex.match(data = data, expression = '(?:child)'): genre = Metadata.GenreChildren
		elif Regex.match(data = data, expression = '(?:animat(?:ion|ed))'): genre = Metadata.GenreAnimation
		elif Regex.match(data = data, expression = '(?:anime)'): genre = Metadata.GenreAnime
		elif Regex.match(data = data, expression = '(?:musical)'): genre = Metadata.GenreMusical
		elif Regex.match(data = data, expression = '(?:music)'): genre = Metadata.GenreMusic

		elif Regex.match(data = data, expression = '(?:docu)'): genre = Metadata.GenreDocumentary
		elif Regex.match(data = data, expression = '(?:bio)'): genre = Metadata.GenreBiography
		elif Regex.match(data = data, expression = '(?:sporting)'): genre = Metadata.GenreSporting
		elif Regex.match(data = data, expression = '(?:sport)'): genre = Metadata.GenreSport
		elif Regex.match(data = data, expression = '(?:travel|road|trip)'): genre = Metadata.GenreTravel
		elif Regex.match(data = data, expression = '(?:holiday|vacation)'): genre = Metadata.GenreHoliday
		elif Regex.match(data = data, expression = '(?:home|garde|living)'): genre = Metadata.GenreHome
		elif Regex.match(data = data, expression = '(?:food|cook)'): genre = Metadata.GenreFood

		elif Regex.match(data = data, expression = '(?:soap)'): genre = Metadata.GenreSoap
		elif Regex.match(data = data, expression = '(?:reality)'): genre = Metadata.GenreReality
		elif Regex.match(data = data, expression = '(?:news)'): genre = Metadata.GenreNews
		elif Regex.match(data = data, expression = '(?:talk)'): genre = Metadata.GenreTalk
		elif Regex.match(data = data, expression = '(?:game)'): genre = Metadata.GenreGame
		elif Regex.match(data = data, expression = '(?:award)'): genre = Metadata.GenreAward
		elif Regex.match(data = data, expression = '(?:mini)'): genre = Metadata.GenreMini
		elif Regex.match(data = data, expression = '(?:pod[\s\-]*cast)'): genre = Metadata.GenrePodcast
		elif Regex.match(data = data, expression = '(?:tv|television)'): genre = Metadata.GenreTelevision

		elif Regex.match(data = data, expression = '(?:short)'): genre = Metadata.GenreShort
		elif Regex.match(data = data, expression = '(?:ind(?:ie|ependent))'): genre = Metadata.GenreIndie
		elif Regex.match(data = data, expression = '(?:noir)'): genre = Metadata.GenreNoir
		elif Regex.match(data = data, expression = '(?:fan)'): genre = Metadata.GenreFan

		Metadata.DataGenre[data] = genre
		return genre

	###################################################################
	# VOTE
	###################################################################

	def vote(self, type, media = MediaDefault):
		result = self.dataRetrieve(type = ['vote', Metadata.VotePercent if type == Metadata.VoteRating else type], media = media)
		if result and type == Metadata.VoteRating: result = result * 10.0
		return result

	def voteAbsolute(self, media = MediaDefault):
		return self.vote(type = Metadata.VoteAbsolute, media = media)

	def voteRating(self, media = MediaDefault):
		return self.vote(type = Metadata.VoteRating, media = media)

	def votePercent(self, media = MediaDefault):
		return self.vote(type = Metadata.VotePercent, media = media)

	def voteCount(self, media = MediaDefault):
		return self.vote(type = Metadata.VoteCount, media = media)

	def voteSet(self, value, type, media = MediaDefault):
		if not value is None:
			if type == Metadata.VoteRating:
				type = Metadata.VotePercent
				value = value / 10.0
			self.dataUpdate(data = {'vote' : {type : value}}, media = media)

	def voteAbsoluteSet(self, value, media = MediaDefault):
		self.voteSet(value = value, type = Metadata.VoteAbsolute, media = media)

	def voteRatingSet(self, value, media = MediaDefault):
		self.voteSet(value = value, type = Metadata.VoteRating, media = media)

	def votePercentSet(self, value, media = MediaDefault):
		self.voteSet(value = value, type = Metadata.VotePercent, media = media)

	def voteCountSet(self, value, media = MediaDefault):
		self.voteSet(value = value, type = Metadata.VoteCount, media = media)

	@classmethod
	def voteDefault(self, value):
		return value if value else 0

	###################################################################
	# STATUS
	###################################################################

	def status(self, media = MediaDefault):
		return self.dataRetrieve(type = 'status', media = media)

	def statusRumoured(self, media = MediaDefault):
		return self.status() == Metadata.StatusRumoured

	def statusPlanned(self, media = MediaDefault):
		return self.status() == Metadata.StatusPlanned

	def statusPreproduction(self, media = MediaDefault):
		return self.status() == Metadata.StatusPreproduction

	def statusProduction(self, media = MediaDefault):
		return self.status() == Metadata.StatusProduction

	def statusPostproduction(self, media = MediaDefault):
		return self.status() == Metadata.StatusPostproduction

	def statusCompleted(self, media = MediaDefault):
		return self.status() == Metadata.StatusCompleted

	def statusPilot(self, media = MediaDefault):
		return self.status() == Metadata.StatusPilot

	def statusReleased(self, media = MediaDefault):
		return self.status() == Metadata.StatusReleased

	def statusContinuing(self, media = MediaDefault):
		return self.status() == Metadata.StatusContinuing

	def statusEnded(self, media = MediaDefault):
		return self.status() == Metadata.StatusEnded

	def statusCanceled(self, media = MediaDefault):
		return self.status() == Metadata.StatusCanceled

	def statusLabel(self, media = MediaDefault):
		status = self.status(media = media)
		if status: return Metadata.StatusLabels[status]
		return None

	def statusSet(self, value, media = MediaDefault):
		if value: self.dataUpdate(data = {'status' : value}, media = media)

	@classmethod
	def statusExtract(self, data):
		try: return Metadata.DataStatus[data]
		except: pass

		# TMDb:
		#	Movies: Canceled, In Production, Planned, Post Production, Released, Rumoured
		#	Shows: Returning Series, Planned, In Production, Ended, Canceled, Pilot
		# TVDb:
		#	Movies: Announced, Pre-Production, Filming / Post-Production, Completed, Released
		#	Shows: Continuing, Ended, Upcoming
		# Trakt:
		#	Movies: released, in production, post production, planned, Rumoured, or canceled
		#	Shows: returning series, in production, planned, canceled, ended

		status = Metadata.StatusDefault
		if Regex.match(data = data, expression = '(?:rumou?r)'): status = Metadata.StatusRumoured
		elif Regex.match(data = data, expression = '(?:plan)'): status = Metadata.StatusPlanned
		elif Regex.match(data = data, expression = '(?:pre.?product)'): status = Metadata.StatusPreproduction
		elif Regex.match(data = data, expression = '(?:post.?product)'): status = Metadata.StatusPostproduction
		elif Regex.match(data = data, expression = '(?:product|film|upcoming)'): status = Metadata.StatusProduction
		elif Regex.match(data = data, expression = '(?:complet)'): status = Metadata.StatusCompleted
		elif Regex.match(data = data, expression = '(?:pilot|test)'): status = Metadata.StatusPilot
		elif Regex.match(data = data, expression = '(?:release)'): status = Metadata.StatusReleased
		elif Regex.match(data = data, expression = '(?:contin|return|busy|running)'): status = Metadata.StatusContinuing
		elif Regex.match(data = data, expression = '(?:end|finish)'): status = Metadata.StatusEnded
		elif Regex.match(data = data, expression = '(?:cancel)'): status = Metadata.StatusCanceled

		Metadata.DataStatus[data] = status
		return status

	###################################################################
	# DURATION
	###################################################################

	def duration(self, type = DurationDefault, media = MediaDefault):
		result = self.dataRetrieve(type = 'duration', media = media)
		if result:
			if type == Metadata.DurationMinutes: result = result / 60.0
			elif type == Metadata.DurationHours: result = result / 3600.0
		return result

	def durationSeconds(self, media = MediaDefault):
		return self.duration(type = Metadata.DurationSeconds, media = media)

	def durationMinutes(self, media = MediaDefault):
		return self.duration(type = Metadata.DurationMinutes, media = media)

	def durationHours(self, media = MediaDefault):
		return self.duration(type = Metadata.DurationHours, media = media)

	def durationSet(self, value, type = DurationDefault, media = MediaDefault):
		if not value is None:
			if type == Metadata.DurationMinutes: value = value * 60.0
			elif type == Metadata.DurationHours: value = value * 3600.0
			value = int(value)
			self.dataUpdate(data = {'duration' : value}, media = media)

	def durationSecondsSet(self, value, type = DurationDefault, media = MediaDefault):
		self.durationSet(value = value, type = Metadata.DurationSeconds, media = media)

	def durationMinutesSet(self, value, type = DurationDefault, media = MediaDefault):
		self.durationSet(value = value, type = Metadata.DurationMinutes, media = media)

	def durationHoursSet(self, value, type = DurationDefault, media = MediaDefault):
		self.durationSet(value = value, type = Metadata.DurationHours, media = media)

	###################################################################
	# RELEASE - DATE
	###################################################################

	def releaseDate(self, type = None, zone = ZoneDefault, format = FormatDefault, media = MediaDefault):
		types = ['release', 'date']
		if type: types.append(type)
		result = self.dataRetrieve(type = types, media = media)
		if result and (zone or format):
			offset = self.releaseZoneOffsetDefault(zone = zone)
			if format is Metadata.FormatDefault: format = Metadata.FormatDate
			converter = ConverterTime(result, offset = Metadata.ZoneUtc)
			if format and not format == Metadata.FormatTimestamp: result = converter.string(format = format, offset = offset)
			else: result = converter.timestamp(offset = offset)
		return result

	def releaseDateFirst(self, zone = ZoneDefault, format = FormatDefault, media = MediaDefault):
		return self.releaseDate(type = 'first', zone = zone, format = format, media = media)

	def releaseDateLast(self, zone = ZoneDefault, format = FormatDefault, media = MediaDefault):
		return self.releaseDate(type = 'last', zone = zone, format = format, media = media)

	def releaseDateNext(self, zone = ZoneDefault, format = FormatDefault, media = MediaDefault):
		return self.releaseDate(type = 'next', zone = zone, format = format, media = media)

	def releaseDateSet(self, value, type = None, zone = ZoneDefault, media = MediaDefault):
		if value:
			if not Tools.isInteger(value):
				offset = self.releaseZoneOffsetDefault(zone = zone)
				if not ':' in value:
					time = self.releaseTime(zone = zone, format = Metadata.FormatTime)
					if time: value += ' ' + time
				value = ConverterTime(value, offset = offset).timestamp(offset = Metadata.ZoneUtc)
			if type: value = {type : value}
			self.dataUpdate(data = {'release' : {'date' : value}}, media = media)

	def releaseDateFirstSet(self, value, zone = ZoneDefault, media = MediaDefault):
		self.releaseDateSet(value = value, type = 'first', zone = zone, media = media)

	def releaseDateLastSet(self, value, zone = ZoneDefault, media = MediaDefault):
		self.releaseDateSet(value = value, type = 'last', zone = zone, media = media)

	def releaseDateNextSet(self, value, zone = ZoneDefault, media = MediaDefault):
		self.releaseDateSet(value = value, type = 'next', zone = zone, media = media)

	###################################################################
	# RELEASE - TIME
	###################################################################

	def releaseTime(self, zone = ZoneDefault, format = FormatDefault, media = MediaDefault):
		result = self.dataRetrieve(type = ['release', 'time'], media = media)
		if result and (zone or format):
			offset = self.releaseZoneOffsetDefault(zone = zone)
			if format is Metadata.FormatDefault: format = Metadata.FormatTime
			base = ConverterTime('2020-05-15 00:00:00', offset = Metadata.ZoneUtc).timestamp()
			converter = ConverterTime(result + base, offset = Metadata.ZoneUtc)
			if format and not format == Metadata.FormatTimestamp: result = converter.string(format = format, offset = offset)
			else: result = converter.timestamp(offset = offset) - base
		return result

	def releaseTimeSet(self, value, zone = ZoneDefault, media = MediaDefault):
		if value:
			if not Tools.isInteger(value):
				date = '2020-05-15 '
				offset = self.releaseZoneOffsetDefault(zone = zone)
				value = ConverterTime(date + value, offset = offset).timestamp() - ConverterTime(date + '00:00').timestamp()
			self.dataUpdate(data = {'release' : {'time' : value}}, media = media)

	###################################################################
	# RELEASE - DAY
	###################################################################

	def releaseDay(self, media = MediaDefault, selection = SelectionDefault):
		return self.dataRetrieve(type = ['release', 'day'], media = media, selection = selection)

	def releaseDaySet(self, value, media = MediaDefault):
		if value: self.dataUpdate(data = {'release' : {'day' : self.dataList(value)}}, media = media)

	@classmethod
	def releaseDayExtract(self, data):
		try: return Metadata.DataDay[data]
		except: pass

		day = Metadata.DayDefault
		if Regex.match(data = data, expression = 'mon'): day = Metadata.DayMonday
		elif Regex.match(data = data, expression = 'tue'): day = Metadata.DayTuesday
		elif Regex.match(data = data, expression = 'wed'): day = Metadata.DayWednesday
		elif Regex.match(data = data, expression = 'thu'): day = Metadata.DayThursday
		elif Regex.match(data = data, expression = 'fri'): day = Metadata.DayFriday
		elif Regex.match(data = data, expression = 'sat'): day = Metadata.DaySaturday
		elif Regex.match(data = data, expression = 'sun'): day = Metadata.DaySunday

		Metadata.DataDay[data] = day
		return day

	###################################################################
	# RELEASE - COUNTRY
	###################################################################

	def releaseCountry(self, media = MediaDefault):
		return self.dataRetrieve(type = ['release', 'country'], media = media)

	def releaseCountrySet(self, value, media = MediaDefault):
		if value: self.dataUpdate(data = {'release' : {'country' : value}}, media = media)

	@classmethod
	def releaseCountryExtract(self, data):
		try: return Metadata.DataCountry[data]
		except: pass
		country = Country.code(data)
		Metadata.DataCountry[data] = country
		return country

	###################################################################
	# RELEASE - ZONE
	###################################################################

	def releaseZoneName(self, media = MediaDefault, fallback = FallbackDefault):
		result = self.dataRetrieve(type = ['release', 'zone'], media = media)
		if not result and fallback:
			country = self.country(media = media)
			if country: result = Country.zone(country)
		return result

	def releaseZoneOffset(self, media = MediaDefault, fallback = FallbackDefault):
		return Time.offset(zone = self.releaseZoneName())

	def releaseZoneSeconds(self, media = MediaDefault, fallback = FallbackDefault):
		return ConverterTime.offset(self.releaseZoneOffset(media = media, fallback = fallback))

	def releaseZoneSet(self, value, media = MediaDefault):
		if value: self.dataUpdate(data = {'release' : {'zone' : value}}, media = media)

	def releaseZoneOffsetDefault(self, zone, default = FallbackDefault):
		offset = None
		if not zone: zone = self.releaseZoneName()

		if zone == Metadata.ZoneOriginal: offset = self.releaseZoneOffset()
		elif zone == Metadata.ZoneLocal: offset = Time.offset()
		elif zone: offset = Time.offset(zone)

		return offset

	###################################################################
	# MONEY
	###################################################################

	def moneyBudget(self, media = MediaDefault):
		return self.dataRetrieve(type = ['money', 'budget'], media = media)

	def moneyIncome(self, media = MediaDefault):
		return self.dataRetrieve(type = ['money', 'income'], media = media)

	def moneyProfit(self, media = MediaDefault):
		try: return self.moneyIncome(media = media) - self.moneyBudget(media = media)
		except: return None

	def moneyBudgetSet(self, value, media = MediaDefault):
		if value: self.dataUpdate(data = {'money' : {'budget' : value}}, media = media)

	def moneyIncomeSet(self, value, media = MediaDefault):
		if value: self.dataUpdate(data = {'money' : {'income' : value}}, media = media)

	###################################################################
	# CERTIFICATE
	###################################################################

	def certificate(self, country = CountryDefault, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		country = self.countryDefault(country = country)
		result = self.dataRetrieve(type = ['certificate'], attribute = {'country' : country}, media = media, selection = selection)
		if not result:
			fallback = self.fallbackDefault(fallback = fallback)
			if fallback: result = self.dataRetrieve(type = ['certificate'], media = media, selection = selection)
		return result

	def certificateCode(self, country = CountryDefault, media = MediaDefault, selection = SelectionDefault, fallback = FallbackDefault):
		result = self.certificate(country = country, media = media, selection = selection, fallback = fallback)
		if result:
			if Tools.isDictionary(result): return result['code']
			else: return [i['code'] for i in result]
		return None

	def certificateSet(self, value, name = Default, description = Default, country = CountryDefault, media = MediaDefault):
		if value:
			if not Tools.isStructure(value):
				value = {
					'code' : value,
					'name' : name,
					'description' : description,
					'media' : self.mediaDefault(media = media),
					'country' : self.countryDefault(country = country),
				}
			self.dataUpdate(data = {'certificate' : self.dataList(value)}, media = media)


class Metawrap(Metadata):

	###################################################################
	# CONSTRUCTOR
	###################################################################

	def __init__(self):
		Metadata.__init__(self)
		self.mData = {}

	###################################################################
	# DATA
	###################################################################

	def dataRetrieve(self, type = None, attribute = None, unique = False, sort = None, inverse = False, extract = None, media = Metadata.MediaDefault, flatten = Metadata.SelectionSingle, selection = Metadata.SelectionDefault):
		for provider in self.providers():
			metadata = self.metadata(provider = provider)
			if not metadata is None:
				result = Metadata.dataRetrieve(self, type = type, attribute = attribute, unique = unique, sort = sort, inverse = inverse, extract = extract, media = media, flatten = flatten, selection = selection, metadata = metadata)
				if not result is None: return result
		return None

	def dataUpdate(self, data, media = False, unique = True, structure = None):
		Metadata.dataUpdate(self, data = data, media = media, unique = unique, metadata = self.metadata())

	@classmethod
	def dataCreate(self, media, data):
		metawrap = Metawrap()
		metawrap.dataImport(data = data)
		return metawrap

	def dataExportBefore(self):
		items = {}
		for provider, metadata in self.mData.items():
			items[provider] = metadata
			self.mData[provider] = metadata.dataExport()
		return items

	def dataExportAfter(self, data):
		for provider, metadata in data.items():
			self.mData[provider] = metadata

	def dataImportBefore(self, data = None):
		try:
			for provider, metadata in data.items():
				data[provider] = metadata.dataImport(data = metadata)
		except: pass
		return data

	###################################################################
	# PROVIDER
	###################################################################

	def providers(self):
		return list(self.mData.keys())

	def providerDefault(self, provider):
		if provider is Metadata.ProviderDefault:
			try: return self.providers()[0]
			except: pass
		return provider

	###################################################################
	# METADATA
	###################################################################

	def metadata(self, provider = Metadata.ProviderDefault):
		try: return self.mData[self.providerDefault(provider = provider)]
		except: return None

	def metadataSet(self, value, provider = Metadata.ProviderDefault):
		if not value is None:
			provider = self.providerDefault(provider = provider)
			if provider: self.mData[provider] = value
