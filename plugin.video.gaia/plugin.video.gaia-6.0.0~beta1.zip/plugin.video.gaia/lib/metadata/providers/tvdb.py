# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# https://thetvdb.github.io/v4-api

from lib.metadata.provider import Provider
from lib.metadata.metadata import Metadata
from lib.modules.tools import Converter, Settings, System, Language, Country, Tools, Regex, Logger
from lib.modules.network import Networker
from lib.modules.account import Tvdb as Account
from lib.modules.cache import Cache

class Tvdb(Provider):

	# Link

	LinkApi					= 'https://api4.thetvdb.com/v4'
	LinkImage				= 'https://artworks.thetvdb.com'

	# Cache

	CacheToken				= Cache.TimeoutMonth1 # Tokens are valid for 1 month according to API documentation.
	CacheTypes				= Cache.TimeoutMonth3

	# Status

	StatusSuccess			= 'success'
	StatusError				= 'failure'

	# Parameter

	ParameterLogin			= 'login'
	ParameterSearch			= 'search'
	ParameterMovies			= 'movies'
	ParameterSeries			= 'series'
	ParameterSeasons		= 'seasons'
	ParameterEpisodes		= 'episodes'
	ParameterPeople			= 'people'
	ParameterCharacters		= 'characters'
	ParameterCompanies		= 'companies'
	ParameterLanguages		= 'languages'
	ParameterArtwork		= 'artwork'
	ParameterGenres			= 'genres'
	ParameterSources		= 'sources'
	ParameterPeople			= 'people'
	ParameterCompanies		= 'companies'
	ParameterType			= 'type'
	ParameterTypes			= 'types'
	ParameterExtended		= 'extended'
	ParameterMeta			= 'meta'
	ParameterTranslations	= 'translations'
	ParameterQuery			= 'query'
	ParameterRemoteId		= 'remote_id'
	ParameterYear			= 'year'
	ParameterLimit			= 'limit'
	ParameterOffset			= 'offset'
	ParameterContent		= 'content'
	ParameterRatings		= 'ratings'
	ParameterStatuses		= 'statuses'

	# Vote

	VoteMain				= 1
	VoteBest				= 2
	VoteWorst				= -1

	# Data

	DataProvider			= None
	DataSeason				= None
	DataPerson				= None
	DataCompany				= None
	DataImage				= None
	DataGenre				= None
	DataCertificate			= None
	DataStatusMovie			= None
	DataStatusShow			= None

	###################################################################
	# LOG
	###################################################################

	@classmethod
	def _log(self, message, data1 = None, data2 = None, data3 = None, type = Logger.TypeError):
		if data1 and Tools.isStructure(data1): data1 = Converter.jsonTo(data1)
		if data2 and Tools.isStructure(data2): data2 = Converter.jsonTo(data2)
		if data3 and Tools.isStructure(data3): data3 = Converter.jsonTo(data3)
		Logger.log('TVDb %s: ' % message, data1, data2, data3, type = type)

	@classmethod
	def _error(self):
		Logger.error()

	###################################################################
	# REQUEST
	###################################################################

	@classmethod
	def _request(self, parts, data = None, method = None, authentication = True, cache = None):
		link = Networker.linkJoin(Tvdb.LinkApi, parts)

		headers = None
		if authentication: headers = self._authenticationHeader()

		# For the series endpoint: meta=translations,episodes
		if data:
			for key, value in data.items():
				if Tools.isArray(value):
					data[key] = ','.join(value)

		result = self._requestJson(link = link, headers = headers, data = data, method = method if method else Networker.MethodGet, type = Networker.DataJson, cache = cache)

		# Do not check the status, since company requests returns a 500 error, although the (partial) data is returned.
		# Might be a temporary problem.
		#if result and result['status'] == Tvdb.StatusSuccess:
		if result and 'data' in result:
			result = result['data']
			return result if result else None
		else:
			self._log('Request Failure', link, data, result)
			return None

	###################################################################
	# RETRIEVE
	###################################################################

	@classmethod
	def _retrieve(self, media, type, extended = False, translations = False, episodes = False, id = None, level = None):
		if id:
			parts = [type, id]
			if extended and level >= Provider.Level2: parts.append(Tvdb.ParameterExtended)

			data = {}
			if translations or episodes:
				data[Tvdb.ParameterMeta] = []
				if translations and level >= Provider.Level3: data[Tvdb.ParameterMeta].append(Tvdb.ParameterTranslations)
				if episodes and level >= Provider.Level4: data[Tvdb.ParameterMeta].append(Tvdb.ParameterEpisodes)

			data = self._request(parts = parts, data = data)
			return self._process(media = media, data = data)
		return None

	###################################################################
	# AUTHENTICATION
	###################################################################

	@classmethod
	def authenticationVerify(self, pin = None):
		return bool(self._authenticationToken(pin = pin))

	@classmethod
	def _authenticationKey(self):
		return System.obfuscate(Settings.raw('internal.key.tvdb'))

	@classmethod
	def _authenticationPin(self):
		return Account().dataPin()

	@classmethod
	def _authenticationToken(self, key = None, pin = None):
		if key is None: key = self._authenticationKey()
		if pin is None: pin = self._authenticationPin()
		data = self._request(cache = Tvdb.CacheToken, parts = Tvdb.ParameterLogin, data = {'apikey' : key, 'pin' : pin}, method = Networker.MethodPost, authentication = False)
		try: return data['token']
		except: return None

	@classmethod
	def _authenticationHeader(self, token = None):
		if token is None: token = self._authenticationToken()
		return Account.headerBearer(token = token)

	###################################################################
	# EXTRACT
	###################################################################

	@classmethod
	def _extract(self, data, type):
		if not Tools.isArray(type): type = [type]
		for i in type:
			try:
				if Tools.isArray(i):
					result = data
					for j in i:
						result = result[j]
				else:
					result = data[i]
				if not result is None: return result
			except: pass
		return None

	@classmethod
	def _extractContains(self, data, type):
		if not Tools.isArray(type): type = [type]
		for i in type:
			if Tools.isArray(i):
				for j in i:
					if not j in data:
						return False
				return True
			elif i in data:
				return True
		return False

	@classmethod
	def _extractMedia(self, data):
		result = self._extract(data = data, type = [
			'type',			# Search
			'recordType',	# Image
		])
		if result:
			result = Metadata.mediaExtract(result)
			if result: return result

		if self._extractContains(data = data, type = ['companyType', 'primaryCompanyType']): return Metadata.MediaCompany
		elif self._extractContains(data = data, type = ['birth', 'death', 'birthPlace', 'gender', 'races']): return Metadata.MediaPerson
		elif self._extractContains(data = data, type = ['peopleId', 'peopleType', 'personName']): return Metadata.MediaCharacter
		elif self._extractContains(data = data, type = ['boxOffice', 'budget', 'personName', 'releases']): return Metadata.MediaMovie
		elif self._extractContains(data = data, type = ['firstAired', 'lastAired', 'airsTime', 'airsDays']): return Metadata.MediaShow
		elif self._extractContains(data = data, type = [['number', 'seasonNumber']]): return Metadata.MediaEpisode
		elif self._extractContains(data = data, type = [['number', 'seriesId']]): return Metadata.MediaSeason # Check after episode.

		return None

	@classmethod
	def _extractId(self, data, media = None, all = True):
		if media is None:
			if all:
				ids = self._extract(data = data, type = [
					'remoteIds',
					'remote_ids',	# Search
				])
				if ids:
					result = {}
					for i in ids:
						try:
							try: provider = self._typeProvider(id = i['type'])
							except: provider = None

							# Search results have "type : 0".
							if not provider:
								name = self._extract(data = i, type = [
									'sourceName',
									'name',
								])
								if name: provider = Metadata.providerExtract(name)

							if provider: result[provider] = i['id']
						except: pass
					return result
			else:
				result = self._extract(data = data, type = [
					'tvdb_id',	# Search - must be first, since it also has an "id" attribute
					'id',
				])
				if result: return result
		elif media == Metadata.MediaMovie:
			return self._extract(data = data, type = ['movieId'])
		elif media == Metadata.MediaShow:
			return self._extract(data = data, type = ['seriesId'])
		elif media == Metadata.MediaSeason:
			result = self._extract(data = data, type = ['seasonId'])
			if result:
				return result
			elif self._extractMedia(data = data) == Metadata.MediaEpisode: # Do not extract for shows.
				seasons = self._extract(data = data, type = ['seasons'])
				if seasons:
					for i in [self._typeSeasonPrimary(), self._typeSeasonSecondary()]:
						for j in seasons:
							type = self._extract(data = j, type = ['type', 'type'])
							if type == i: return self._extract(data = j, type = ['id'])
					return self._extract(data = seasons[0], type = ['id'])
		elif media == Metadata.MediaEpisode:
			return self._extract(data = data, type = ['episodeId'])
		elif media == Metadata.MediaPerson:
			return self._extract(data = data, type = ['peopleId', 'seriesPeopleId'])

		return None

	@classmethod
	def _extractTranslation(self, data, type, translation, aliases = None, language = None, extra = None, unknown = False):
		result = {}

		if language is None: language = self._extractLanguage(data = data, language = Metadata.LanguageOriginal, single = True)

		original = [[], []]
		try: original[0].append(data[type])
		except: pass
		result[Metadata.LanguageUniversal] = original

		# In Search, aliases is a list of foreign title strings.
		# This will fail (since they are no dictionaries), and it should, since we do not want to add them if we do not know the language.
		# Only allow non-language aliases for characters, persons, and companies.
		try:
			for i in data[aliases]:
				if Tools.isDictionary(i):
					try: code = Language.code(i['language'])
					except: pass
					i = i['name']
				if not code:
					if unknown: code = Metadata.LanguageUniversal
					else: continue
				if not code in result: result[code] = [[], []]
				result[code][1].append(i)
		except: pass

		try:
			for i in self._extract(data = data, type = [['translations', translation]]):
				code = Language.code(i['language'])
				if code:
					value = i[type]
					primary = self._extract(data = i, type = ['isPrimary', 'IsPrimary'])
					alias = self._extract(data = i, type = ['isAlias', 'IsAlias'])

					# Some languages have multiple names, where the first name is the same as the original name.
					# Prefer the non-original name, except if it is the original language.
					# Example:
					#	French = ["Game of Thrones", "Le Trône de fer"]
					#	English = ["Game of Thrones", "GOT"]
					if not alias:
						if value in original[0] or value in original[1]:
							if not code == language: alias = True

					if not code in result: result[code] = [[], []]
					if primary or not alias: result[code][0].append(value)
					elif alias: result[code][1].append(value)
					try:
						value = i[aliases]
						if Tools.isDictionary(value):
							try:
								code = Language.code(value['language'])
								if not code in result: result[code] = [[], []]
							except: pass
							value = value['name']
						result[code][1].extend(value)
					except: pass
		except: pass

		# Search
		try:
			for key, value in self._extract(data = data, type = [extra]).items():
				code = Language.code(key)
				if code:
					if not code in result: result[code] = [[], []]
					try: result[code][1].append(value)
					except: pass
		except: pass

		if result:
			if language:
				if not language in result: result[language] = [[], []]
				result[language][0].extend(original[0])
				result[language][1].extend(original[1])

			for key, value in result.items():
				value = value[0] + value[1]
				value = [i for i in value if i]
				value = Tools.listUnique(value)
				result[key] = value

			filtered = {}
			for key, value in result.items():
				if value:
					# TVDb seems to have a bug.
					# If a season is retrieved and the season name is null, when retrieving the same season but with "extended", the name is sometimes the season type name.
					# Eg: https://api4.thetvdb.com/v4/seasons/567215/extended returns the season name as "Aired Order".
					# Remove these names.
					value = [i for i in value if not Regex.match(data = i, expression = '^(?:aired|dvd|absolute|alternate(?:\s*dvd)?|regional)\s*order$')]
					if value: filtered[key] = value
			return filtered

		return None

	@classmethod
	def _extractTitle(self, data):
		return self._extractTranslation(data = data, type = 'name', translation = 'nameTranslations', aliases = 'aliases')

	@classmethod
	def _extractOverview(self, data):
		return self._extractTranslation(data = data, type = 'overview', translation = 'overviewTranslations', extra = 'overviews')

	@classmethod
	def _extractName(self, data, person = False):
		if person and 'personName' in data:
			type = 'personName'
			translation = None
			aliases = None
		else:
			type = 'name'
			translation = 'nameTranslations'
			aliases = 'aliases'
		return self._extractTranslation(data = data, type = type, translation = translation, extra = 'translations', aliases = aliases, unknown = True)

	@classmethod
	def _extractSlug(self, data):
		return self._extract(data = data, type = ['slug'])

	@classmethod
	def _extractNumber(self, data, media = None):
		return self._extract(data = data, type = ['seasonNumber' if media == Metadata.MediaSeason else 'number'])

	@classmethod
	def _extractLanguage(self, data, language = None, single = False):
		result = []

		if language == Metadata.LanguageOriginal:
			result.append(self._extract(data = data, type = ['originalLanguage']))
			result.append(self._extract(data = data, type = ['language']))
			result.append(self._extract(data = data, type = ['primary_language'])) # Search
		elif language == Metadata.LanguageAudio:
			result.append(self._extract(data = data, type = ['audioLanguages']))
			result.append(self._extract(data = data, type = ['spokenLanguages']))
			result.append(self._extract(data = data, type = ['spoken_languages']))
		elif language == Metadata.LanguageSubtitle:
			result.append(self._extract(data = data, type = ['subtitleLanguages']))

		if result:
			result = Tools.listFlatten(result)
			result = [Language.code(i) for i in result]
			result = [i for i in result if i]
			result = Tools.listUnique(result)
			if result: return result[0] if single else result

		return None

	@classmethod
	def _extractImage(self, data):
		result = []

		link = self._extract(data = data, type = [
			'image',
			'image_url', # Search
		])
		if link:
			link = self._linkImage(link = link)
			image = self._extractImageType(link = link, type = self._extract(data = data, type = 'imageType'))
			image['vote'] = Tvdb.VoteMain # Prefer the main image over others from "artworks" with a vote of 0.
			result.append(image)

			link = self._extract(data = data, type = [
				'thumbnail',
				'thumbnail_url',
			])
			if link:
				link = self._linkImage(link = link)
				image = Tools.copy(image)
				image.update({
					'link' : link,
					'quality' : Metadata.ImageQualityLow,
				})
				result.append(image)

		artworks = self._extract(data = data, type = [
			'artworks',
			'artwork',	# Season
		])
		if artworks:
			for artwork in artworks:
				link = self._extract(data = artwork, type = 'image')
				if link:
					link = self._linkImage(link = link)
					image = self._extractImageType(link = link, type = self._extract(data = artwork, type = 'type'))

					# Some images have null as the language.
					# These are not English/Universal, but some other languages (eg: Avatar).
					# Set to unknown to only use if no English/Universal images are available.
					language = Language.code(self._extract(data = artwork, type = 'language'))
					if not language: language = Metadata.LanguageUnknown
					image['language'] = language

					vote = self._extract(data = artwork, type = 'score')
					if vote:
						try: image['vote'] = max(vote, image['vote'])
						except: image['vote'] = vote

					try:
						id = self._extractId(data = artwork, media = image['media'])
						if id: image['id'] = id
					except: pass

					result.append(image)

					link = self._extract(data = artwork, type = ['thumbnail'])
					if link:
						link = self._linkImage(link = link)
						image = Tools.copy(image)
						image.update({
							'link' : link,
							'quality' : Metadata.ImageQualityLow,
						})
						result.append(image)

		if self._extractMedia(data = data) == Metadata.MediaEpisode:
			seasons = self._extract(data = data, type = 'seasons')
			if seasons:
				primary = self._typeSeasonPrimary()
				for season in seasons:
					link = self._extract(data = season, type = 'image')
					if link:
						link = self._linkImage(link = link)
						image = self._extractImageType(link = link, type = self._extract(data = season, type = 'type'))

						vote = 0
						if not self._extract(data = season, type = [['type', 'type']]) == primary: vote = Tvdb.VoteWorst
						if vote:
							try: image['vote'] = max(vote, image['vote'])
							except: image['vote'] = vote

						try:
							id = self._extractId(data = season, media = image['media'])
							if id: image['id'] = id
						except: pass

						result.append(image)

						link = self._extract(data = season, type = ['thumbnail'])
						if link:
							link = self._linkImage(link = link)
							image = Tools.copy(image)
							image.update({
								'link' : link,
								'quality' : Metadata.ImageQualityLow,
							})
							result.append(image)

		if result: return result
		return None

	@classmethod
	def _extractImageType(self, link, type = None):
		id = None
		media = None
		vote = None

		# To avoid incorrect classification (art and banner).
		data = Networker.linkPath(link = link, parameters = True)
		data = data.lstrip('banners')

		match = Regex.extract(data = data, expression = '\/?([a-z]+)\/(\d+)[\/\-\_]', group = None, all = True)
		if match:
			match = match[0]
			media = Metadata.mediaExtract(match[0])
			id = match[1]

		# TVDb sometimes has a crappy poster as the default one (eg: poster for season 0 in Game of Thrones).
		# Assign a higher vote to images that have a random alpha-numeric filename, which seem to be a best ones.
		# Eg: This one is listed as the main image for Season 0:
		#	https://artworks.thetvdb.com/banners/seasons/121361-0.jpg
		# Although we prefer this one:
		#	https://artworks.thetvdb.com/banners/seasons/5cc751ad03661.jpg
		if Regex.match(data = data, expression = '\/([a-z]+\d+|\d+[a-z]+)+\.[a-z]+$'):
			vote = Tvdb.VoteBest

		result = {
			'id' : id,
			'link' : link,
			'vote' : vote,
			'language' : None,
			'media' : media if media else Metadata.mediaExtract(data),
			'type' : Metadata.imageTypeExtract(data = data),
			'quality' : Metadata.imageQualityExtract(data = data),
			'opacity' : Metadata.imageOpacityExtract(data = data),
		}
		if not type is None:
			type = self._typeImage(id = type)
			if type: result.update(type)

		return result

	@classmethod
	def _extractYear(self, data):
		result = self._extractReleaseFirst(data = data)
		if not result: result = self._extractReleaseDate(data = data) # Movie
		if not result: result = self._extract(data = data, type = ['birth']) # Person
		if result:
			result = Metadata.yearExtract(result)
			if result: return result
		return None

	@classmethod
	def _extractGenre(self, data):
		try:
			result = []
			for i in data['genres']:
				genre = None
				if Tools.isString(i): genre = Metadata.genreExtract(i) # Search
				else:
					genre = self._typeGenre(id = i['id'])
					if not genre: genre = Metadata.genreExtract(i['name'])
				if genre: result.append(genre)
			if result: return result
		except: pass
		return None

	@classmethod
	def _extractDuration(self, data):
		result = self._extract(data = data, type = [
			'runtime',
			'averageRuntime',
		])
		if not result is None: return int(result)
		return None

	@classmethod
	def _extractBudget(self, data):
		result = self._extract(data = data, type = ['budget'])
		if result: return float(result)
		return None

	@classmethod
	def _extractIncome(self, data):
		result = self._extract(data = data, type = ['boxOffice'])
		if result: return float(result)
		return None

	@classmethod
	def _extractVote(self, data):
		result = self._extract(data = data, type = ['score'])
		if not result is None: return float(result)

		result = self._extract(data = data, type = ['sort']) # Character
		if not result is None: return -1 * float(result) # Ascending order, change to descending.

		return None

	@classmethod
	def _extractStatus(self, data, media):
		try:
			id = data['status']['id']
			if media == Metadata.MediaMovie: return self._typeStatusMovie(id = id)
			elif media == Metadata.MediaShow: return self._typeStatusShow(id = id)
		except: return None

	@classmethod
	def _extractReleaseCountry(self, data):
		result = self._extract(data = data, type = [
			'originalCountry',	# Movie and Show
			'country',			# Search
		])
		if result: return Metadata.releaseCountryExtract(result)
		return None

	@classmethod
	def _extractReleaseZone(self, data):
		country = self._extractReleaseCountry(data = data)
		if country: return Country.zone(country)
		return None

	@classmethod
	def _extractReleaseTime(self, data):
		result = self._extract(data = data, type = ['airsTime'])
		if result:
			return {'time' : result, 'zone' : None}
		else:
			result = self._extract(data = data, type = ['airsTimeUTC'])
			if result: return {'time' : result, 'zone' : Metadata.AirZoneUtc}
		return None

	@classmethod
	def _extractReleaseDate(self, data):
		try:
			for i in ['global', 'usa', self._extractReleaseCountry(data = data)]:
				for j in data['releases']:
					try:
						if j['country'] == i:
							result = j['date']
							if result: return result
					except: pass
			result = data['releases'][0]['date']
			if result: return result
		except: pass
		return None

	@classmethod
	def _extractReleaseFirst(self, data):
		return self._extract(data = data, type = [
			'firstAired',
			'first_air_time',	# Search
			'aired',			# Episode
		])

	@classmethod
	def _extractReleaseLast(self, data):
		return self._extract(data = data, type = ['lastAired'])

	@classmethod
	def _extractReleaseNext(self, data):
		return self._extract(data = data, type = ['nextAired'])

	@classmethod
	def _extractReleaseDay(self, data):
		result = self._extract(data = data, type = ['airsDays'])
		if result:
			result = [Metadata.releaseDayExtract(k) for k, v in result.items() if v]
			return [i for i in result if i]
		return None

	@classmethod
	def _extractCertificate(self, data):
		result = self._extract(data = data, type = ['contentRatings'])
		if result:
			result = [self._typeCertificate(i['id']) for i in result]
			return [i for i in result if i]
		return None

	###################################################################
	# PROCESS
	###################################################################

	@classmethod
	def _process(self, media, data):
		try:
			if data:
				if media is Metadata.MediaDefault: media = self._extractMedia(data = data)
				metadata = Metadata(media = media)

				if metadata.mediaContent(): self._processContent(metadata = metadata, data = data)
				elif metadata.mediaPerson(): self._processPerson(metadata = metadata, data = data)
				elif metadata.mediaCharacter(): self._processCharacter(metadata = metadata, data = data, single = True)
				elif metadata.mediaCompany(): self._processCompany(metadata = metadata, data = data)

				return metadata
		except: self._error()
		return None

	@classmethod
	def _processContent(self, metadata, data):
		self._processShow(metadata = metadata, data = data)
		self._processSeason(metadata = metadata, data = data)
		self._processEpisode(metadata = metadata, data = data)

		self._processId(metadata = metadata, data = data)
		self._processSlug(metadata = metadata, data = data)
		self._processNumber(metadata = metadata, data = data)

		# Do first, since other functions require these values.
		self._processLanguage(metadata = metadata, data = data) # Needed by title, overview, etc.
		self._processRelease(metadata = metadata, data = data) # Needed by air date and time (time zones).

		self._processTitle(metadata = metadata, data = data)
		self._processOverview(metadata = metadata, data = data)
		self._processYear(metadata = metadata, data = data)

		self._processGenre(metadata = metadata, data = data)

		self._processCharacter(metadata = metadata, data = data)
		self._processCompany(metadata = metadata, data = data)

		self._processVote(metadata = metadata, data = data)
		self._processStatus(metadata = metadata, data = data)
		self._processDuration(metadata = metadata, data = data)
		self._processMoney(metadata = metadata, data = data)
		self._processCertificate(metadata = metadata, data = data)

		# Do last, since some images are added to the characters.
		self._processImage(metadata = metadata, data = data)

	@classmethod
	def _processShow(self, metadata, data):
		try:
			if metadata.mediaSeason() or metadata.mediaEpisode():
				metadata.showSet(value = Metadata(media = Metadata.MediaShow))
		except: self._error()

	@classmethod
	def _processSeason(self, metadata, data):
		try:
			if 'seasons' in data and data['seasons']:
				primary = self._typeSeasonPrimary()
				if metadata.mediaShow():
					type = None
					for i in data['seasons']:
						if i['type']['type'] == primary:
							type = i['type']['type']
							break
					if type is None:
						secondary = self._typeSeasonSecondary()
						for i in data['seasons']:
							if i['type']['type'] == secondary:
								type = i['type']['type']
								break
						if type is None:
							type = data['seasons'][0]['type']['type']
					if type:
						seasons = []
						for i in data['seasons']:
							if i['type']['type'] == type:
								season = self._process(media = Metadata.MediaSeason, data = i)
								if season: seasons.append(season)
						if seasons: metadata.seasonSet(value = seasons)
				elif metadata.mediaEpisode():
					season = None
					for i in data['seasons']:
						if i['type']['type'] == primary:
							season = i
							break
					if season is None:
						try: season = data['seasons'][0]
						except: pass
					if not season is None:
						season = self._process(media = Metadata.MediaSeason, data = season)
						if season: metadata.seasonSet(value = season)
		except: self._error()

	@classmethod
	def _processEpisode(self, metadata, data):
		try:
			if 'episodes' in data and data['episodes']:
				if metadata.mediaShow() or metadata.mediaSeason():
					episodes = []
					for i in data['episodes']:
						episode = self._process(media = Metadata.MediaEpisode, data = i)
						if episode: episodes.append(episode)
					if episodes: metadata.episodeSet(value = episodes)
		except: self._error()

	@classmethod
	def _processPerson(self, metadata, data):
		try:
			self._processId(metadata = metadata, data = data)

			# The character structure contains both the person and the character attributes.
			# Only do this for the person structure.
			if self._extractMedia(data = data) == Metadata.MediaPerson:
				self._processImage(metadata = metadata, data = data)
				self._processVote(metadata = metadata, data = data)

			self._processName(metadata = metadata, data = data)
			self._processCharacter(metadata = metadata, data = data)
		except:	pass

	@classmethod
	def _processCharacter(self, metadata, data, single = False):
		try:
			if 'characters' in data:
				if data['characters']: # Sometimes null.
					characters = []
					for i in data['characters']:
						character = self._process(media = Metadata.MediaCharacter, data = i)
						if character: characters.append(character)
					metadata.characterSet(value = characters)
			elif single:
				self._processId(metadata = metadata, data = data)
				self._processSlug(metadata = metadata, data = data)
				self._processName(metadata = metadata, data = data)
				self._processImage(metadata = metadata, data = data)

				try:
					person = self._typePerson(id = data['type'])
					metadata.typeSet(value = person['type'])
					metadata.roleSet(value = person['role'])
				except: pass

				person = self._process(media = Metadata.MediaPerson, data = data)
				if person: metadata.personSet(person)

				self._processVote(metadata = metadata, data = data)

			if 'director' in data: # Search
				person = self._process(media = Metadata.MediaCharacter, data = {'name' : data['director']})
				if person: metadata.personSet(person)
		except: Logger.error()

	@classmethod
	def _processCompany(self, metadata, data):
		try:
			if 'companies' in data:
				if data['companies']: # Sometimes null.
					if Tools.isDictionary(data['companies']): data = Tools.listFlatten(data['companies'].values())
					else: data = data['companies']
					companies = []
					for i in data:
						company = self._process(media = Metadata.MediaCompany, data = i)
						if company: companies.append(company)
					metadata.companySet(value = companies)
			elif self._extractMedia(data = data) == Metadata.MediaCompany:
				self._processId(metadata = metadata, data = data)
				self._processSlug(metadata = metadata, data = data)
				self._processName(metadata = metadata, data = data)
				self._processImage(metadata = metadata, data = data)

				type = None
				if not type:
					try: type = self._typeCompany(id = data['companyType']['companyTypeId'])
					except: pass
				if not type:
					try: type = self._typeCompany(id = data['primaryCompanyType'])
					except: pass
				if type: metadata.typeSet(value = type)
			else: # Search
				companies = []
				types = {
					Metadata.CompanyTypeNetwork : ['network', 'networks'],
					Metadata.CompanyTypeStudio : ['studio', 'studios'],
					Metadata.CompanyTypeProducer : ['production_company', 'production_companies', 'productioncompany', 'productioncompanies'],
					Metadata.CompanyTypeDistributor : ['distributor', 'distributors'],
					Metadata.CompanyTypeEffects : ['special_effect', 'special_effects', 'specialeffect', 'specialeffects'],
				}
				for key, value in types.items():
					try:
						names = None
						for v in value:
							try:
								names = data[v]
								break
							except: pass
						if names:
							if not Tools.isArray(names): names = [names]
							for i in names:
								company = Metadata(media = Metadata.MediaCompany)
								company.typeSet(value = Metadata.CompanyTypeNetwork)
								company.nameSet(value = i)
								companies.append(company)
					except: pass
				metadata.companySet(value = companies)
		except: Logger.error()

	@classmethod
	def _processId(self, metadata, data):
		metadata.idTvdbSet(value = self._extractId(data = data, all = False))

		metadata.idSet(value = self._extractId(data = data, all = True))

		if not metadata.mediaPerson(): # Do not extract if a person is extracted from character data.
			metadata.idMovieTvdbSet(value = self._extractId(data = data, media = Metadata.MediaMovie))
			metadata.idShowTvdbSet(value = self._extractId(data = data, media = Metadata.MediaShow))
			metadata.idSeasonTvdbSet(value = self._extractId(data = data, media = Metadata.MediaSeason))
			metadata.idEpisodeTvdbSet(value = self._extractId(data = data, media = Metadata.MediaEpisode))

		metadata.idPersonTvdbSet(value = self._extractId(data = data, media = Metadata.MediaPerson))

	@classmethod
	def _processSlug(self, metadata, data):
		metadata.slugSet(value = self._extractSlug(data = data))

	@classmethod
	def _processNumber(self, metadata, data):
		metadata.numberSet(value = self._extractNumber(data = data))
		metadata.numberSeasonSet(value = self._extractNumber(data = data, media = Metadata.MediaSeason))

	@classmethod
	def _processLanguage(self, metadata, data):
		for i in [Metadata.LanguageOriginal, Metadata.LanguageAudio, Metadata.LanguageSubtitle]:
			metadata.languageSet(value = self._extractLanguage(data = data, language = i), language = i)

	@classmethod
	def _processTitle(self, metadata, data):
		metadata.titleSet(value = self._extractTitle(data = data))

	@classmethod
	def _processOverview(self, metadata, data):
		metadata.overviewSet(value = self._extractOverview(data = data))

	@classmethod
	def _processYear(self, metadata, data):
		metadata.yearSet(value = self._extractYear(data = data))

	@classmethod
	def _processImage(self, metadata, data):
		images = self._extractImage(data = data)
		entity = metadata.mediaEntity()
		if images:
			# Set all images in one go to reduce processing time.
			if entity:
				for image in images:
				 	if image['media'] == Metadata.MediaPerson: image['media'] = Metadata.MediaCharacter # Character images are detected as person.
			metadata.imageSet(value = images, provider = Metadata.ProviderTvdb)

	@classmethod
	def _processGenre(self, metadata, data):
		metadata.genreSet(value = self._extractGenre(data = data))

	@classmethod
	def _processName(self, metadata, data):
		metadata.nameSet(value = self._extractName(data = data, person = metadata.mediaPerson()))

	@classmethod
	def _processVote(self, metadata, data):
		# Seems that movies have an absolute score [0,inf], while shows have a rating [0,10].
		vote = self._extractVote(data = data)
		if metadata.mediaShow(): metadata.voteRatingSet(value = vote)
		else: metadata.voteAbsoluteSet(value = vote)

	@classmethod
	def _processStatus(self, metadata, data):
		metadata.statusSet(value = self._extractStatus(data = data, media = metadata.media()))

	@classmethod
	def _processDuration(self, metadata, data):
		metadata.durationMinutesSet(value = self._extractDuration(data = data))

	@classmethod
	def _processRelease(self, metadata, data):
		country = self._extractReleaseCountry(data = data)
		metadata.releaseCountrySet(value = country)

		zone = self._extractReleaseZone(data = data)
		metadata.releaseZoneSet(value = zone)

		if metadata.mediaTelevision():
			# Used by date functions below.
			time = self._extractReleaseTime(data = data)
			if time: metadata.releaseTimeSet(value = time['time'], zone = time['zone'])

			metadata.releaseDateFirstSet(value = self._extractReleaseFirst(data = data), zone = zone)
			metadata.releaseDateLastSet(value = self._extractReleaseLast(data = data), zone = zone)
			metadata.releaseDateNextSet(value = self._extractReleaseNext(data = data), zone = zone)

			metadata.releaseDaySet(value = self._extractReleaseDay(data = data))
		else:
			metadata.releaseDateSet(value = self._extractReleaseDate(data = data), zone = zone)

	@classmethod
	def _processMoney(self, metadata, data):
		metadata.moneyBudgetSet(value = self._extractBudget(data = data))
		metadata.moneyIncomeSet(value = self._extractIncome(data = data))

	@classmethod
	def _processCertificate(self, metadata, data):
		metadata.certificateSet(value = self._extractCertificate(data = data))

	###################################################################
	# TYPE
	###################################################################

	@classmethod
	def _typeRequest(self, type, sub = True):
		parts = [type]
		if sub is True: parts.append(Tvdb.ParameterTypes)
		elif sub: parts.append(sub)
		return self._request(parts = parts, cache = Tvdb.CacheTypes)

	@classmethod
	def _typeProvider(self, id = None):
		try:
			if Tvdb.DataProvider is None:
				data = self._typeRequest(type = Tvdb.ParameterSources)
				if data:
					Tvdb.DataProvider = {}
					for item in data:
						provider = Metadata.providerExtract(item['name'])
						if provider: Tvdb.DataProvider[item['id']] = provider
		except: self._error()

		if id is None:
			return Tvdb.DataProvider
		else:
			try: return Tvdb.DataProvider[id]
			except: return None

	@classmethod
	def _typeSeason(self, index = None):
		try:
			if Tvdb.DataSeason is None:
				data = self._typeRequest(type = Tvdb.ParameterSeasons)
				if data:
					Tvdb.DataSeason = []
					for item in data:
						if Regex.match(data = item['type'], expression = '(?:official|air|release)'):
							Tvdb.DataSeason.append(item['id'])
							break
					for item in data:
						if Regex.match(data = item['type'], expression = '(?<!alt)(?<!alternative)(?:dvd|blu.?ray|dis[ck])'):
							Tvdb.DataSeason.append(item['id'])
							break
					for item in data:
						Tvdb.DataSeason.append(item['id'])
					Tvdb.DataSeason = Tools.listUnique(Tvdb.DataSeason)
		except: self._error()

		if index is None:
			return Tvdb.DataSeason
		else:
			try: return Tvdb.DataSeason[index]
			except: return None

	@classmethod
	def _typeSeasonPrimary(self):
		return self._typeSeason(index = 0)

	@classmethod
	def _typeSeasonSecondary(self):
		return self._typeSeason(index = 1)

	@classmethod
	def _typePerson(self, id = None):
		try:
			if Tvdb.DataPerson is None:
				data = self._typeRequest(type = Tvdb.ParameterPeople)
				if data:
					Tvdb.DataPerson = {}
					for item in data:
						person = Metadata.characterExtract(item['name'])
						if person: Tvdb.DataPerson[item['id']] = person
		except: self._error()

		if id is None:
			return Tvdb.DataPerson
		else:
			try: return Tvdb.DataPerson[id]
			except: return None

	@classmethod
	def _typeCompany(self, id = None):
		try:
			if Tvdb.DataCompany is None:
				data = self._typeRequest(type = Tvdb.ParameterCompanies)
				if data:
					Tvdb.DataCompany = {}
					for item in data:
						try: name = item['companyTypeName']
						except: name = item['name']
						company = Metadata.companyExtract(name)
						if company:
							try: type = item['companyTypeId']
							except: type = item['id']
							Tvdb.DataCompany[type] = company
		except: self._error()

		if id is None:
			return Tvdb.DataCompany
		else:
			try: return Tvdb.DataCompany[id]
			except: return None

	@classmethod
	def _typeImage(self, id = None):
		try:
			if Tvdb.DataImage is None:
				data = self._typeRequest(type = Tvdb.ParameterArtwork)
				if data:
					Tvdb.DataImage = {}
					for item in data:
						type = Metadata.imageTypeExtract(item['name'])
						if type:
							media = self._extractMedia(data = item)
							quality = Metadata.imageQualityExtract(item['name'])
							opacity = Metadata.imageOpacityExtract(item['name'])
							Tvdb.DataImage[item['id']] = {'media' : media, 'type' : type, 'quality' : quality, 'opacity' : opacity}
						else: self._log('Unknown Image Type', item)
		except: self._error()

		# Make a copy, since the dictionary might be reused by different images.
		try: return Tools.copy(Tvdb.DataImage[id])
		except: return None

	@classmethod
	def _typeGenre(self, id = None):
		try:
			if Tvdb.DataGenre is None:
				data = self._typeRequest(type = Tvdb.ParameterGenres, sub = False)
				if data:
					Tvdb.DataGenre = {}
					for item in data:
						genre = Metadata.genreExtract(item['name'])
						if genre: Tvdb.DataGenre[item['id']] = genre
						else: self._log('Unknown Genre Type', item)
		except: self._error()

		if id is None:
			return Tvdb.DataGenre
		else:
			try: return Tvdb.DataGenre[id]
			except: return None

	@classmethod
	def _typeCertificate(self, id = None):
		try:
			if Tvdb.DataCertificate is None:
				data = self._typeRequest(type = Tvdb.ParameterContent, sub = Tvdb.ParameterRatings)
				if data:
					Tvdb.DataCertificate = {}
					for item in data:
						Tvdb.DataCertificate[item['id']] = {
							'code' : item['name'],
							'name' : item['fullname'],
							'description' : item['description'],
							'media' : Metadata.mediaExtract(item['contentType']),
							'country' : Country.code(item['country']),
						}
		except: self._error()

		if id is None:
			return Tvdb.DataCertificate
		else:
			try: return Tvdb.DataCertificate[id]
			except: return None

	@classmethod
	def _typeStatusMovie(self, id = None):
		try:
			if Tvdb.DataStatusMovie is None:
				data = self._typeRequest(type = Tvdb.ParameterMovies, sub = Tvdb.ParameterStatuses)
				if data:
					Tvdb.DataStatusMovie = {}
					for item in data:
						status = Metadata.statusExtract(item['name'])
						if status: Tvdb.DataStatusMovie[item['id']] = status
						else: self._log('Unknown Movie Status Type', item)
		except: self._error()

		if id is None:
			return Tvdb.DataStatusMovie
		else:
			try: return Tvdb.DataStatusMovie[id]
			except: return None

	@classmethod
	def _typeStatusShow(self, id = None):
		try:
			if Tvdb.DataStatusShow is None:
				data = self._typeRequest(type = Tvdb.ParameterSeries, sub = Tvdb.ParameterStatuses)
				if data:
					Tvdb.DataStatusShow = {}
					for item in data:
						status = Metadata.statusExtract(item['name'])
						if status: Tvdb.DataStatusShow[item['id']] = status
						else: self._log('Unknown Show Status Type', item)
		except: self._error()

		if id is None:
			return Tvdb.DataStatusShow
		else:
			try: return Tvdb.DataStatusShow[id]
			except: return None

	###################################################################
	# LANGUAGE
	###################################################################

	@classmethod
	def _language(self):
		try:
			result = []
			data = self._request(parts = Tvdb.ParameterLanguages)
			if data:
				for item in data:
					item = Language.code(item['id'])
					if item: result.append(item)
			return result
		except: self._error()
		return None

	###################################################################
	# LINK
	###################################################################

	@classmethod
	def _link(self, link, domain):
		if link and not Networker.linkIs(link): link = Networker.linkJoin(domain, link)
		return link

	@classmethod
	def _linkImage(self, link):
		# Some links do not contain the domain, but only the path (eg: /banners/movies/xxx/backgrounds/xxx.jpg).
		return self._link(link = link, domain = Tvdb.LinkImage)

	###################################################################
	# SEARCH
	###################################################################

	# Supported searches:
	#	Movie: Movie ID (idImdb/idTmdb/idTvdb) or Movie Title (query with optional year)
	#	Collection: No
	#	Show: Show ID (idImdb/idTmdb/idTvdb) or Show Title (query with optional year)
	#	Season: Show ID (idImdb/idTmdb/idTvdb) or Show Title (query with optional year) together with numberSeason
	#	Episode: Show ID (idImdb/idTmdb/idTvdb) or Show Title (query with optional year) together with numberSeason and numberEpisode
	#	Character: No
	#	Person: Person ID (idImdb/idTmdb/idTvdb) or Person Name (query)
	#	Company: Company ID (idImdb/idTmdb/idTvdb) or Company Name (query)
	@classmethod
	def _search(self, id = None, idImdb = None, idTmdb = None, idTvdb = None, idTrakt = None, query = None, year = None, numberSeason = None, numberEpisode = None, media = None, limit = None, offset = None, page = None, level = None):
		data = {}
		result = []
		id = idImdb if idImdb else idTmdb if idTmdb else None # TVDb does not support Trakt.

		if query:
			data[Tvdb.ParameterQuery] = query
		elif id:
			data[Tvdb.ParameterRemoteId] = id
			if not query: data[Tvdb.ParameterQuery] = id
		elif idTvdb:
			data[Tvdb.ParameterQuery] = idTvdb
		else:
			return None if limit == 1 else result

		if limit: data[Tvdb.ParameterLimit] = limit
		if offset: data[Tvdb.ParameterOffset] = offset
		if year: data[Tvdb.ParameterYear] = year

		if not media:
			if not numberEpisode is None: media = Metadata.MediaEpisode
			elif not numberSeason is None: media = Metadata.MediaSeason
		if media:
			type = None
			if media == Metadata.MediaMovie: type = 'movie'
			elif media == Metadata.MediaPerson: type = 'person'
			elif media == Metadata.MediaCompany: type = 'company'
			elif media in Metadata.MediaTelevision: type = 'series'
			if type: data[Tvdb.ParameterType] = type

		data = self._request(parts = Tvdb.ParameterSearch, data = data)
		if data:
			try:
				for item in data:
					item = self._process(media = Metadata.MediaDefault, data = item)
					if item: result.append(item)
			except: Logger.error()

			if media in [Metadata.MediaSeason, Metadata.MediaEpisode]:
				# Reset so that the correct item from "result" is returned below (for limit == 1).
				id = None
				idTvdb = None
				query = True

				show = [i.idShowTvdb() for i in result]
				show = [i for i in show if i]
				show = self.show(idTvdb = show, level = level if level >= Provider.Level4 else Provider.Level4)
				result = []
				if media == Metadata.MediaSeason: result = [i.season(numberSeason = numberSeason) for i in show]
				elif media == Metadata.MediaEpisode: result = [i.episode(numberSeason = numberSeason, numberEpisode = numberEpisode) for i in show]
				result = [i for i in result if i]

		if limit == 1:
			if idImdb and id == idImdb:
				for i in result:
					if i.idImdb() == idImdb: return i
			elif idTmdb and id == idTmdb:
				for i in result:
					if i.idTmdb() == idTmdb: return i
			elif idTvdb:
				for i in result:
					if i.idTvdb() == idTvdb: return i
			elif query and result:
				return result[0]
			return None
		return result

	###################################################################
	# ID
	###################################################################

	@classmethod
	def _id(self, id = None, idImdb = None, idTmdb = None, idTvdb = None, idTrakt = None, query = None, year = None, numberSeason = None, numberEpisode = None, media = None, level = None):
		result = self.search(id = id, idImdb = idImdb, idTmdb = idTmdb, idTvdb = idTvdb, idTrakt = idTrakt, query = query, year = year, numberSeason = numberSeason, numberEpisode = numberEpisode, media = media, limit = 1, level = level)
		try: return result.id()
		except: return None

	###################################################################
	# MOVIE
	###################################################################

	@classmethod
	def _movie(self, id = None, idImdb = None, idTmdb = None, idTvdb = None, idTrakt = None, query = None, year = None, level = None):
		return self._retrieve(media = Metadata.MediaMovie, type = Tvdb.ParameterMovies, extended = True, translations = True, id = id, level = level)

	###################################################################
	# SHOW
	###################################################################

	@classmethod
	def _show(self, id = None, idImdb = None, idTmdb = None, idTvdb = None, idTrakt = None, query = None, year = None, level = None):
		return self._retrieve(media = Metadata.MediaShow, type = Tvdb.ParameterSeries, extended = True, translations = True, episodes = True, id = id, level = level)

	###################################################################
	# SEASON
	###################################################################

	@classmethod
	def _season(self, id = None, idImdb = None, idTmdb = None, idTvdb = None, idTrakt = None, query = None, year = None, numberSeason = None, level = None):
		return self._retrieve(media = Metadata.MediaSeason, type = Tvdb.ParameterSeasons, extended = True, translations = True, id = id, level = level)

	###################################################################
	# EPISODE
	###################################################################

	@classmethod
	def _episode(self, id = None, idImdb = None, idTmdb = None, idTvdb = None, idTrakt = None, query = None, year = None, numberSeason = None, numberEpisode = None, level = None):
		return self._retrieve(media = Metadata.MediaEpisode, type = Tvdb.ParameterEpisodes, extended = True, translations = True, id = id, level = level)

	###################################################################
	# CHARACTER
	###################################################################

	@classmethod
	def _character(self, id = None, idImdb = None, idTmdb = None, idTvdb = None, idTrakt = None, query = None, level = None):
		return self._retrieve(media = Metadata.MediaCharacter, type = Tvdb.ParameterCharacters, id = id, level = level)

	###################################################################
	# PERSON
	###################################################################

	@classmethod
	def _person(self, id = None, idImdb = None, idTmdb = None, idTvdb = None, idTrakt = None, query = None, level = None):
		return self._retrieve(media = Metadata.MediaPerson, type = Tvdb.ParameterPeople, extended = True, translations = True, id = id, level = level)

	###################################################################
	# COMPANY
	###################################################################

	@classmethod
	def _company(self, id = None, idImdb = None, idTmdb = None, idTvdb = None, idTrakt = None, query = None, level = None):
		return self._retrieve(media = Metadata.MediaCompany, type = Tvdb.ParameterCompanies, id = id, level = level)

	###################################################################
	# TRANSLATION
	###################################################################

	@classmethod
	def _translation(self, id = None, idImdb = None, idTmdb = None, idTvdb = None, idTrakt = None, query = None, year = None, numberSeason = None, numberEpisode = None, media = None, translation = None, level = None):
		level = Provider.Level3
		if media == Metadata.MediaMovie: result = self.movie(id = id, idImdb = idImdb, idTmdb = idTmdb, idTvdb = idTvdb, idTrakt = idTrakt, query = query, year = year, level = level)
		elif media == Metadata.MediaShow: result = self.show(id = id, idImdb = idImdb, idTmdb = idTmdb, idTvdb = idTvdb, idTrakt = idTrakt, query = query, year = year, level = level)
		elif media == Metadata.MediaSeason: result = self.season(id = id, idImdb = idImdb, idTmdb = idTmdb, idTvdb = idTvdb, idTrakt = idTrakt, query = query, year = year, numberSeason = numberSeason, level = level)
		elif media == Metadata.MediaEpisode: result = self.episode(id = id, idImdb = idImdb, idTmdb = idTmdb, idTvdb = idTvdb, idTrakt = idTrakt, query = query, year = year, numberSeason = numberSeason, numberEpisode = numberEpisode, level = level)
		if result:
			if translation == Provider.TranslationTitle: return result.title(language = True)
			elif translation == Provider.TranslationOverview: return result.overview(language = True)
		return None
