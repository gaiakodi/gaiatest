from lib.externals.hachoir.wx.main import main
main()
