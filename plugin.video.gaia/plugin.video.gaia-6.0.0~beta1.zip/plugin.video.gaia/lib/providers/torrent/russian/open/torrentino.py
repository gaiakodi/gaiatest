# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.providers.core.html import ProviderHtml, Html, HtmlResults, HtmlResult, HtmlLink, HtmlDiv

class Provider(ProviderHtml):

	_Link					= ['https://torrentino.download']
	_Path					= 'search.php'

	_ParameterQuery			= 'q'
	_ParameterSort			= 'orderby'
	_ParameterSeeds			= 'seeders'
	_ParameterOrder			= 'ft'
	_ParameterDescending	= 'desc'

	_AttributeTable			= 'table_list'
	_AttributeDetails		= 'torrent_content'

	##############################################################################
	# INITIALIZE
	##############################################################################

	def initialize(self):
		ProviderHtml.initialize(self,
			name					= 'Torrentino',
			description				= '{name} is less-known open {container} site from Russia. The site contains results in various languages, but most of them are in Russian. {name} requests subpages in order to extract the magnet link, which substantially increases scraping time.',
			rank					= 2,

			link					= Provider._Link,

			formatEncode			= ProviderHtml.FormatEncodePlus,

			searchQuery				= {
										ProviderHtml.RequestMethod : ProviderHtml.RequestMethodGet,
										ProviderHtml.RequestPath : Provider._Path,
										ProviderHtml.RequestData : {
											Provider._ParameterQuery	: ProviderHtml.TermQuery,
											Provider._ParameterSort		: Provider._ParameterSeeds,
											Provider._ParameterOrder	: Provider._ParameterDescending,
										},
									},

			extractList				= [HtmlResults(class_ = Provider._AttributeTable, start = 1)],
			extractDetails			= [HtmlResult(index = 1), HtmlLink(extract = Html.AttributeHref)],
			extractLink				= [ProviderHtml.Details, HtmlDiv(class_ = Provider._AttributeDetails), HtmlLink(href_ = ProviderHtml.ExpressionMagnet, extract = Html.AttributeHref)],
			extractFileName			= [HtmlResult(index = 1), HtmlLink()],
			extractFileSize			= [HtmlResult(index = 4)],
			extractSourceTime		= [HtmlResult(index = 0)],
			extractSourceSeeds		= [HtmlResult(index = 2)],
			extractSourceLeeches	= [HtmlResult(index = 3)],
		)
