# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.providers.core.html import ProviderHtml, Html, HtmlDiv, HtmlLink, HtmlHeading1
from lib.modules.tools import Regex

class Provider(ProviderHtml):

	_Link					= ['https://lapumia.org']

	_Path					= 'page'

	_ParameterSearch		= 's'

	_AttributePosts			= 'posts'
	_AttributePost			= 'post'
	_AttributeTitle			= 'title'
	_AttributeContent		= 'content'
	_AttributeMore			= 'more-link'

	_ExpressionFormat		= u'formato\s*:*\s*(.*)'
	_ExpressionSize			= u'tamanho\s*:*\s*(\d+(?:\.\d+)?\s*[mg]b)'
	_ExpressionLanguage		= u'idioma\s*:*\s*(.*)'
	_ExpressionSubtitle		= u'legenda\s*:*\s*(.*)'

	##############################################################################
	# INITIALIZE
	##############################################################################

	#gaiaremove - finish this - with all description, extractEntries, etc.
	def initialize(self):
		ProviderHtml.initialize(self,
			name							= 'Lapumia',
			description						= '{name} is less-known open {container} site from Spain. The site contains results in various languages, but most of them are in Spanish. {name} has torrent files instead of magnet links, and has missing metadata, such as file size, hashes, and peer counts. {name} requests subpages and sub-subpages in order to extract the magnet link, which substantially increases scraping time.',
			rank							= 3,
			performance						= ProviderHtml.PerformanceBad,

			link							= Provider._Link,

			supportSpecial					= False, # Has episodes, but they are not directly searchable.

			offsetStart						= 1,
			offsetIncrease					= 1,

			formatEncode					= ProviderHtml.FormatEncodePlus,

			searchQuery						= {
												ProviderHtml.RequestMethod : ProviderHtml.RequestMethodGet,
												ProviderHtml.RequestPath : [Provider._Path, ProviderHtml.TermOffset],
												ProviderHtml.RequestData : {
													Provider._ParameterSearch : ProviderHtml.TermQuery,
												},
											},

			extractOptimizeData				= HtmlDiv(class_ = Provider._AttributePosts),
			extractOptimizeDetails			= [HtmlDiv(class_ = Provider._AttributePost), HtmlDiv(class_ = Provider._AttributeContent)],
			extractList						= [HtmlDiv(class_ = Provider._AttributePost)],
			extractDetails					= [HtmlLink(class_ = Provider._AttributeMore, extract = Html.AttributeHref)],
			#extractEntries					= [ProviderHtml.Details, Html(extract = [Html.ParseTextNested, Provider._ExpressionSize])],
			extractLink						= [ProviderHtml.Details, HtmlLink(href_ = ProviderHtml.ExpressionMagnet, extract = Html.AttributeHref)],
			extractFileNameInexact			= [ProviderHtml.Details, HtmlDiv(class_ = Provider._AttributeTitle), HtmlHeading1()],
			extractFileSize					= [ProviderHtml.Details, Html(extract = [Html.ParseTextNested, Provider._ExpressionSize])],
			extractAudioLanguage			= [ProviderHtml.Details, Html(extract = [Html.ParseTextNested, Provider._ExpressionLanguage])],
			extractSubtitleType				= [ProviderHtml.Details, Html(extract = [Html.ParseTextNested, Provider._ExpressionSubtitle])],
			extractSubtitleLanguage			= [ProviderHtml.Details, Html(extract = [Html.ParseTextNested, Provider._ExpressionSubtitle])],
		)

	##############################################################################
	# PROCESS
	##############################################################################

	def processBefore(self, item):
		try:
			# Validate to only retrieve sub-pages that are valid.
			name = self.extractHtml(item, [HtmlDiv(class_ = Provider._AttributeTitle), HtmlLink(extract = Html.ParseText)])
			self.log("OOOOOOOOOOOOO: "+str(name))#gaiaremove
			if not self.searchValidate(name): return ProviderHtml.Skip
		except: self.logError()

	def processFileNameInexact(self, value, item, details = None, entry = None):
		if value: value = value.rstrip(' Download')
		return value
