# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# https://popcorntime.api-docs.io/api/welcome/introduction
# https://github.com/popcorn-official/popcorn-api

from lib.providers.core.json import ProviderJson

class Provider(ProviderJson):

	# https://upaste.me/803c51640d33c812b
	# Only .tk domain works, but keep the other ones in case they come up again.
	# Although movies/shows/anime have different subdomains, it seems all of them can be used to search anything.
	_Link				= [
							'https://popcorn-ru.tk',
							'https://tv-v2.api-fetch.sh',
							'https://tv-v2.api-fetch.am',
							'https://tv-v2.api-fetch.website',
						]
	_Path				= '%s/%s'

	_CategoryMovie		= 'movie'
	_CategoryShow		= 'show'

	_AttributeTorrents	= 'torrents'
	_AttributeEpisodes	= 'episodes'
	_AttributeEpisode	= 'episode'
	_AttributeSeason	= 'season'
	_AttributeLink		= 'url'
	_AttributeSize		= 'size'
	_AttributeProvider	= 'provider'
	_AttributeSeeds		= 'seeds'
	_AttributeSeed		= 'seed'
	_AttributeLeeches	= 'peers'
	_AttributeLeech		= 'peer'

	_AttributeQuality	= 'quality'
	_AttributeLanguage	= 'language'

	##############################################################################
	# INITIALIZE
	##############################################################################

	def initialize(self):
		ProviderJson.initialize(self,
			name					= 'PopcornTime',
			description				= '{name} is one of the oldest and most well-known {container} APIs. The API contains results in various languages, but most of them are in English. {name} has few results, but they are of good quality. The API does not have file names and sizes for movies and episodes respectively.',
			rank					= 4,

			link					= Provider._Link,

			supportMovie			= True,
			supportShow				= True,
			supportPack				= True,

			searchQuery				= Provider._Path % (ProviderJson.TermCategory, ProviderJson.TermIdImdb),
			searchCategoryMovie		= Provider._CategoryMovie,
			searchCategoryShow		= Provider._CategoryShow,

			extractLink				= Provider._AttributeLink,
			extractVideoQuality		= Provider._AttributeQuality,
			extractFileName			= True,
			extractFileExtra		= Provider._AttributeProvider,
			extractFileSize			= Provider._AttributeSize,
			extractSourceSeeds		= Provider._AttributeSeeds,
			extractSourceLeeches	= Provider._AttributeLeeches,
		)

	##############################################################################
	# EXTRACT
	##############################################################################

	def extractList(self, data):
		# Movies and shows have different structures and attribute names.

		items = []
		if self.parameterMediaMovie():
			for language, item in data[Provider._AttributeTorrents].items():
				for quality, item in item.items():
					item[Provider._AttributeLanguage] = language
					item[Provider._AttributeQuality] = quality
					items.append(item)
		else:
			season = self.parameterNumberSeason()
			episode = self.parameterNumberEpisode()
			for item in data[Provider._AttributeEpisodes]:
				if item[Provider._AttributeSeason] == season and item[Provider._AttributeEpisode] == episode:
					for quality, item in item[Provider._AttributeTorrents].items():
						item[Provider._AttributeQuality] = quality
						items.append(item)
					break

		for i in range(len(items)):
			try: items[i][Provider._AttributeSeeds] = items[i][Provider._AttributeSeed]
			except: pass
			try: items[i][Provider._AttributeLeeches] = items[i][Provider._AttributeLeech]
			except: pass

		return items
