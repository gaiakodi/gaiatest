# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.providers.core.html import ProviderHtml, Html, HtmlBody, HtmlResults, HtmlResult, HtmlTable, HtmlLink, HtmlDiv
from lib.modules.tools import Regex, Time

class Provider(ProviderHtml):

	_Link					= {
								ProviderHtml.Version1 : ['https://extratorrent.st'],
								ProviderHtml.Version2 : ['https://extratorrent.si'],
								ProviderHtml.Version3 : ['https://extratorrents.it', 'https://extratorrent.ag'],
							}
	_Mirror					= ['https://www.elitetricks.net/extratorrent-proxy/', 'https://traqq.com/blog/2020-top-proxies-for-extratorrent-absolutely-working/']
	_Unblock				= {
								ProviderHtml.Version1 : None,
								ProviderHtml.Version2 : None,
								ProviderHtml.Version3 : {ProviderHtml.UnblockFormat1 : 'extratorrent2', ProviderHtml.UnblockFormat2 : 'extratorrent', ProviderHtml.UnblockFormat3 : 'extratorrent', ProviderHtml.UnblockFormat4 : 'extratorrent'}
							}
	_Path					= 'search/' # Must end with a slash.

	_CategoryMovie			= {
								ProviderHtml.Version1 : '1',
								ProviderHtml.Version2 : '4',
								ProviderHtml.Version3 : '4',
							}
	_CategoryShow			= {
								ProviderHtml.Version1 : '2',
								ProviderHtml.Version2 : '8',
								ProviderHtml.Version3 : '8',
							}

	_ParameterSearch		= 'search'
	_ParameterCategory		= 's_cat'
	_ParameterPage			= 'page'
	_ParameterSort			= 'srt'
	_ParameterSeeds			= 'seeds'
	_ParameterOrder			= 'order'
	_ParameterDescending	= 'desc'

	_AttributeTable			= 'tl'
	_AttributeUploader		= 'usr'
	_AttributePage			= 'pager_link'
	_AttributeDisabled		= 'pager_no_link'

	_ExpressionVideo		= '(video|anime)'
	_ExpressionMovie		= '(movie)'
	_ExpressionShow			= '(tv)'
	_ExpressionExclude		= '(book|tutorial|adult|porn|software|picture|music|game)'

	_ExpressionNext			= '(>|&gt;)'
	_ExpressionToday		= '(today\-*(?:\d{4})?)'
	_ExpressionYesterday	= '(y[\-\s]*day\-*(?:\d{4})?)'

	##############################################################################
	# INITIALIZE
	##############################################################################

	def initialize(self):
		version = self.customVersion()
		if version == ProviderHtml.Version1:
			extractFileName				= [HtmlResult(index = 1), HtmlLink()]
			extractFileSize				= [HtmlResult(index = 3)]
			extractReleaseUploader		= [HtmlResult(index = 1), HtmlDiv(class_ = Provider._AttributeUploader)]
			extractSourceTime			= None
			extractSourceTimeInexact	= [HtmlResult(index = 2)]
			extractSourceSeeds			= [HtmlResult(index = 4)]
			extractSourceLeeches		= [HtmlResult(index = 5)]
		elif version == ProviderHtml.Version2:
			extractFileName				= [HtmlResult(index = 2), HtmlLink()]
			extractFileSize				= [HtmlResult(index = 4)]
			extractReleaseUploader		= [HtmlResult(index = 2), HtmlDiv(class_ = Provider._AttributeUploader)]
			extractSourceTime			= [HtmlResult(index = 3)]
			extractSourceTimeInexact	= None
			extractSourceSeeds			= [HtmlResult(index = 6)]
			extractSourceLeeches		= [HtmlResult(index = 7)]
		elif version == ProviderHtml.Version3:
			extractFileName				= [HtmlResult(index = 2), HtmlLink()]
			extractFileSize				= [HtmlResult(index = 4)]
			extractReleaseUploader		= [HtmlResult(index = 2), HtmlDiv(class_ = Provider._AttributeUploader)]
			extractSourceTime			= None
			extractSourceTimeInexact	= [HtmlResult(index = 3)] # Old torrents are inaccurate (eg: 3 years).
			extractSourceSeeds			= [HtmlResult(index = 6)]
			extractSourceLeeches		= [HtmlResult(index = 7)]

		ProviderHtml.initialize(self,
			name						= 'ExtraTorrent',
			description					= '{name} is one of the oldest and most well-known {container} sites. The site contains results in various languages, but most of them are in English. There are different versions of {name} with version %s having some missing metadata.'  % ProviderHtml.Version3,
			rank						= 4,
			performance					= ProviderHtml.PerformancePoor,

			link						= Provider._Link[version],
			mirror						= Provider._Mirror,
			unblock						= Provider._Unblock,

			customVersion				= 3,

			streamTime					= '%m-%d-%Y', # Has US date format (month first). Pass custom format in and do not use the built-in formats that place the day first.

			supportMovie				= True,
			supportShow					= True,
			supportPack					= True,

			offsetStart					= 1,
			offsetIncrease				= 1,

			formatEncode				= ProviderHtml.FormatEncodeQuote,

			searchQuery					= {
											ProviderHtml.RequestMethod : ProviderHtml.RequestMethodGet,
											ProviderHtml.RequestPath : Provider._Path,
											ProviderHtml.RequestData : {
												Provider._ParameterSearch	: ProviderHtml.TermQuery,
												Provider._ParameterCategory	: ProviderHtml.TermCategory,
												Provider._ParameterPage		: ProviderHtml.TermOffset,
												Provider._ParameterSort		: Provider._ParameterSeeds,
												Provider._ParameterOrder	: Provider._ParameterDescending,
											},
										},
			searchCategoryMovie			= Provider._CategoryMovie[version],
			searchCategoryShow			= Provider._CategoryShow[version],

			extractOptimizeData			= HtmlBody(), # To detect the last page in processOffset().
			extractList					= [HtmlResults(class_ = Provider._AttributeTable)],
			extractLink					= [HtmlResult(index = 0), HtmlLink(href_ = ProviderHtml.ExpressionMagnet, extract = Html.AttributeHref)],
			extractFileName				= extractFileName,
			extractFileSize				= extractFileSize,
			extractReleaseUploader		= extractReleaseUploader,
			extractSourceTime			= extractSourceTime,
			extractSourceTimeInexact	= extractSourceTimeInexact,
			extractSourceSeeds			= extractSourceSeeds,
			extractSourceLeeches		= extractSourceLeeches,
		)

	##############################################################################
	# PROCESS
	##############################################################################

	def processOffset(self, data, items):
		try:
			if self.customVersion2():
				last = self.extractHtml(data, [HtmlTable(), Html(class_ = Provider._AttributePage, index = -1, extract = Html.ParseText)])
				if last:
					last = int(last)
					next = self.extractHtml(data, [HtmlTable(), Html(class_ = Provider._AttributeDisabled, index = -1, extract = Html.ParseText)])
					if next:
						next = int(next)
						if next > last: return ProviderHtml.Skip
			else:
				# Seems that subsequent pages contain the same results as page 1.
				last = self.extractHtml(data, [HtmlTable(), Html(class_ = Provider._AttributePage, index = -1, extract = Html.ParseText)])
				if last and not Regex.match(data = last, expression = Provider._ExpressionNext):
					return ProviderHtml.Skip
		except: self.logError()

	def processBefore(self, item):
		# Seems that the category query parameter does not have an affect.
		# Filter the category manually.
		category = self.extractHtml(item, [HtmlResult(index = 1), HtmlLink(extract = Html.AttributeTitle)])
		if category:
			if self.customVersion2():
				target = Provider._ExpressionMovie if self.parameterMediaMovie() else Provider._ExpressionShow
				if not (Regex.match(data = category, expression = target) or Regex.match(data = category, expression = Provider._ExpressionVideo)):
					return ProviderHtml.Skip
			else:
				# There can be too many subcategories to check. Rather just check some exclude categories.
				# https://extratorrents.it/category/4/Movies+Torrents.html
				if Regex.match(data = category, expression = Provider._ExpressionExclude):
					return ProviderHtml.Skip

	def processSourceTime(self, value, item, details = None, entry = None):
		if self.customVersion2():
			# Y-day-2021
			# Today-13:10
			# 03-29-2019
			if Regex.match(data = value, expression = Provider._ExpressionToday):
				value = Regex.replace(data = value, expression = Provider._ExpressionToday, replacement = Time.format(format = Time.FormatDate) + ' ')
			elif Regex.match(data = value, expression = Provider._ExpressionYesterday):
				value = Regex.replace(data = value, expression = Provider._ExpressionYesterday, replacement = Time.past(days = 1, format = Time.FormatDate) + ' ')
		return value
