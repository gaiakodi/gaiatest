# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.providers.core.html import ProviderHtml, Html, HtmlResults, HtmlResult, HtmlTable, HtmlLink, HtmlSpan, HtmlSmall

class Provider(ProviderHtml):

	_Link					= ['https://pirateiro.com']
	_Mirror					= ['https://torrends.to/site/pirateiro']
	_Unblock				= {ProviderHtml.UnblockFormat2 : 'pirateiro', ProviderHtml.UnblockFormat3 : 'pirateiro'}
	_Path					= 'torrents'

	_CategoryMovie			= 'c300'
	_CategoryShow			= 'c700'
	_CategoryAnime			= 'c100'

	_ParameterSearch		= 'search'
	_ParameterPage			= 'page'
	_ParameterSort			= 'orderby'
	_ParameterSeeds			= 'seeders'
	_ParameterYes			= '1'

	_AttributeContainer		= 'main'
	_AttributeTable			= 'torrenttable'
	_AttributePage			= 'pagercurrent'

	_ExpressionVerified		= '(verified)'

	##############################################################################
	# INITIALIZE
	##############################################################################

	def initialize(self):
		ProviderHtml.initialize(self,
			name						= 'Pirateiro',
			description					= '{name} is a less-known {container} site. The site contains results in various languages, but most of them are in English. {name} has many and high-quality results with good metadata, but also has strong Cloudflare protection that might not be bypassable and cause scraping to fail.',
			rank						= 4,
			performance					= ProviderHtml.PerformanceGood,
			status						= ProviderHtml.StatusImpaired,

			link						= Provider._Link,
			mirror						= Provider._Mirror,
			unblock						= Provider._Unblock,

			customVerified				= True,

			supportMovie				= True,
			supportShow					= True,
			supportPack					= True,

			offsetStart					= 1,
			offsetIncrease				= 1,

			formatEncode				= ProviderHtml.FormatEncodePlus,

			queryMovie					= '%s %s' % (ProviderHtml.TermYear, ProviderHtml.TermTitleMovie), # For some reason more titles are found if the year is placed first. Eg: "avatar 2009" vs "2009 avatar".

			searchQuery					= {
											ProviderHtml.RequestMethod : ProviderHtml.RequestMethodGet,
											ProviderHtml.RequestPath : Provider._Path,
											ProviderHtml.RequestData : {
												Provider._ParameterSearch	: ProviderHtml.TermQuery,
												Provider._ParameterPage		: ProviderHtml.TermOffset,
												Provider._ParameterSort		: Provider._ParameterSeeds,
												ProviderHtml.TermCategory	: Provider._ParameterYes,
												Provider._CategoryAnime		: Provider._ParameterYes,
											},
										},
			searchCategoryMovie			= Provider._CategoryMovie,
			searchCategoryShow			= Provider._CategoryShow,

			extractParser				= ProviderHtml.ParserHtml5,
			extractList					= [HtmlResults(class_ = Provider._AttributeTable, start = 1)],
			extractLink					= [HtmlResult(index = 1), HtmlLink(href_ = ProviderHtml.ExpressionMagnet, extract = Html.AttributeHref)],
			extractFileName				= [HtmlResult(index = 0), HtmlLink(index = 1)],
			extractFileSize				= [HtmlResult(index = 3)],
			extractReleaseUploader		= [HtmlResult(index = 0), HtmlSmall(), HtmlLink()],
			extractSourceTime			= [HtmlResult(index = 2), HtmlSpan(extract = Html.AttributeTitle)],
			extractSourceSeeds			= [HtmlResult(index = 4)],
			extractSourceLeeches		= [HtmlResult(index = 5)],
		)

	##############################################################################
	# PROCESS
	##############################################################################

	def processOffset(self, data, items):
		try:
			last = self.extractHtml(data, [HtmlTable(class_ = Provider._AttributeContainer), HtmlTable(index = -1), HtmlLink(index = -1, extract = Html.AttributeClass)])
			if last and Provider._AttributePage in last: return ProviderHtml.Skip
		except: self.logError()

	def processBefore(self, item):
		if self.customVerified():
			verified = self.extractHtml(item, [HtmlResult(index = 1), HtmlLink(class_ = Provider._ExpressionVerified)])
			if not verified: return ProviderHtml.Skip
