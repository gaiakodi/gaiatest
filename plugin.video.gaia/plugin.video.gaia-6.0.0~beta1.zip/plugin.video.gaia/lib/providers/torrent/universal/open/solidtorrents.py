# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.providers.core.json import ProviderJson

class Provider(ProviderJson):

	_Link					= ['https://solidtorrents.net']
	_Path					= 'api/v1/search'

	_LimitOffset			= 20
	_LimitApproval			= 2000

	_CategoryVideo			= 'Video'
	_CategoryUnknown		= 'Unknown'

	_ParameterQuery			= 'q'
	_ParameterOffset		= 'skip'
	_ParameterCategory		= 'category'
	_ParameterSort			= 'sort'
	_ParameterSeeds			= 'seeders'
	_ParameterSpam			= 'fuv'
	_ParameterYes			= 'yes'
	_ParameterNo			= 'no'

	_AttributList			= 'results'
	_AttributId				= '_id'
	_AttributeLink			= 'magnet'
	_AttributeName			= 'title'
	_AttributeSize			= 'size'
	_AttributeTime			= 'imported'
	_AttributeSwarm			= 'swarm'
	_AttributeSeeds			= 'seeders'
	_AttributeLeeches		= 'leechers'
	_AttributeVerified		= 'verified'
	_AttributeDownloads		= 'downloads'

	##############################################################################
	# INITIALIZE
	##############################################################################

	def initialize(self):
		category = ','.join([Provider._CategoryVideo, Provider._CategoryUnknown])
		ProviderJson.initialize(self,
			name					= 'SolidTorrents',
			description				= '{name} is a less-known {container} site and API. The site contains results in various languages, but most of them are in English. {name} is fast and has many {containers} with good metadata.',
			rank					= 5,

			link					= Provider._Link,

			customSpam				= True,
			customVerified			= True,

			supportMovie			= True,
			supportShow				= True,
			supportPack				= True,

			offsetStart				= 0,
			offsetIncrease			= Provider._LimitOffset,

			formatEncode			= ProviderJson.FormatEncodePlus,

			searchQuery				= {
										ProviderJson.RequestMethod : ProviderJson.RequestMethodGet,
										ProviderJson.RequestPath : Provider._Path,
										ProviderJson.RequestData : {
											Provider._ParameterQuery	: ProviderJson.TermQuery,
											Provider._ParameterCategory	: ProviderJson.TermCategory,
											Provider._ParameterOffset	: ProviderJson.TermOffset,
											Provider._ParameterSort		: Provider._ParameterSeeds,
											Provider._ParameterSpam		: Provider._ParameterYes if self.customSpam() else Provider._ParameterNo,
										},
									},
			searchCategoryMovie		= category,
			searchCategoryShow		= category,

			extractList				= Provider._AttributList,
			extractLink				= Provider._AttributeLink,
			extractIdLocal			= Provider._AttributId,
			extractFileName			= Provider._AttributeName,
			extractFileSize			= Provider._AttributeSize,
			extractSourceTime		= Provider._AttributeTime,
			extractSourceApproval	= [Provider._AttributeSwarm, Provider._AttributeDownloads],
			extractSourceSeeds		= [Provider._AttributeSwarm, Provider._AttributeSeeds],
			extractSourceLeeches	= [Provider._AttributeSwarm, Provider._AttributeLeeches],
		)

	##############################################################################
	# PROCESS
	##############################################################################

	def processBefore(self, item):
		if self.customVerified():
			if not item[Provider._AttributeSwarm][Provider._AttributeVerified]: return ProviderJson.Skip

	def processSourceApproval(self, value, item, details = None, entry = None):
		result = ProviderJson.ApprovalDefault
		try: result += (1 - result) * (float(value) / Provider._LimitApproval)
		except: pass
		return result
