# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.informers import Informer as InformerBase
from lib.modules.tools import Time, System
from lib.modules.interface import Loader

class Informer(InformerBase):

	Name	= 'Kodi'

	##############################################################################
	# CONSTRUCTOR
	##############################################################################

	def __init__(self):
		InformerBase.__init__(self, name = Informer.Name)

	##############################################################################
	# PARAMETERS
	##############################################################################

	def parameters(self, type, imdb = None, tmdb = None, tvdb = None, title = None, year = None, season = None, episode = None):
		parameters = {}

		if type == InformerBase.TypeMovie: parameters['call'] = 'movie'
		elif type == InformerBase.TypeShow or type == InformerBase.TypeSeason: parameters['call'] = 'tv'
		elif type == InformerBase.TypePerson: parameters['call'] = 'person'
		else: return None # Not supported.

		if tmdb: parameters['tmdb_id'] = tmdb
		elif imdb: parameters['external_id'] = imdb
		elif tvdb: parameters['external_id'] = tvdb
		elif title: parameters['query'] = title

		if not year is None: parameters['year'] = year
		if not season is None: parameters['season'] = season

		return parameters

	##############################################################################
	# DIALOG
	##############################################################################

	def _dialog(self, type = None, imdb = None, tmdb = None, tvdb = None, title = None, year = None, season = None, episode = None, wait = True):
		if type in [InformerBase.TypeMovie, InformerBase.TypeShow, InformerBase.TypeSeason, InformerBase.TypeEpisode]:
			Loader.hide()

			 # The item must be selected in the Kodi GUI for the info dialog to work.
			 # If the context menu is still open, Kodi will not be able to get the selected movie/show.
			Time.sleep(0.5) # 0.1 is often too little waiting time.

			System.execute('Action(Info)')
			return True
		else:
			return None # Not supported.
