# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.modules.tools import File

class Debrid(object):

	TypeCore		= 'core'
	TypeInterface	= 'interface'
	TypeHandle		= 'handle'

	Instances = {}

	@classmethod
	def _path(self):
		return File.directory(__file__)

	@classmethod
	def _import(self):
		import importlib
		directories, files = File.listDirectory(self._path(), absolute = False)
		for directory in directories:
			if not directory.startswith('_'):
				# Only import if not already imported.
				# Otherwise import_module(...) can end up in deadlock if this functions is called in parallel.
				# Eg: _frozen_importlib._DeadlockError: deadlock detected by _ModuleLock('lib.debrid.easynews')
				module = 'lib.debrid.' + directory
				if not importlib.find_loader(module): importlib.import_module(module)

	@classmethod
	def _instances(self, type = TypeCore):
		if not type in Debrid.Instances:
			import importlib
			instances = []
			directories, files = File.listDirectory(self._path(), absolute = False)
			for directory in directories:
				if not directory.startswith('_'):
					module = importlib.import_module('lib.debrid.' + directory + '.' + type.lower())
					try: module = getattr(module, type.capitalize())()
					except: continue # If does not have the class (eg: EasyNews Handle).
					instances.append(module)
			Debrid.Instances[type] = instances
		return Debrid.Instances[type]

	@classmethod
	def _instance(self, id, type = TypeCore):
		import importlib
		module = importlib.import_module('lib.debrid.%s.%s' % (id, type))
		try: return getattr(module, type.capitalize())()
		except: return None

	@classmethod
	def enabled(self):
		for instance in self._instances():
			if instance.accountEnabled() and instance.accountValid(): return True
		return False

	@classmethod
	def services(self):
		result = {}
		for instance in self._instances():
			if instance.accountEnabled() and instance.accountValid():
				result[instance.id()] = instance.servicesList(onlyEnabled = True)
		return result

	@classmethod
	def cached(self, items):
		for value in items.values():
			if value: return True
		return False

	@classmethod
	def deletePlayback(self, link, source):
		id = source['stream'].streamId()
		if not id: id = link
		handle = source['stream'].streamHandle()
		category = source['stream'].streamCategory()
		pack = source['stream'].filePack(boolean = True)

		for instance in self._instances():
			if instance.id() == handle:
				if instance.deletePossible(source['stream'].sourceType()):
					instance.deletePlayback(id = id, pack = pack, category = category)
				break

	@classmethod
	def handles(self, data = False, priority = False):
		instances = self._instances(type = Debrid.TypeHandle)
		if priority:
			highest = 0
			for instance in instances:
				if instance.priority() > highest:
					highest = instance.priority()
			temp = [None] * (max(highest, len(instances)) + 1)
			for instance in instances:
				temp[instance.priority() - 1] = instance
			instances = [i for i in temp if i]
		if data:
			for i in range(len(instances)):
				instances[i] = instances[i].data()
		return instances
