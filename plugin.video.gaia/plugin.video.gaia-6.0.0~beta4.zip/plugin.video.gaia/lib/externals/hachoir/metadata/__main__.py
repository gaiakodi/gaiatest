from lib.externals.hachoir.metadata.main import main
main()
