from lib.externals.hachoir.parser.game.zsnes import ZSNESFile  # noqa
from lib.externals.hachoir.parser.game.spider_man_video import SpiderManVideoFile  # noqa
from lib.externals.hachoir.parser.game.laf import LafFile  # noqa
from lib.externals.hachoir.parser.game.blp import BLP1File, BLP2File  # noqa
