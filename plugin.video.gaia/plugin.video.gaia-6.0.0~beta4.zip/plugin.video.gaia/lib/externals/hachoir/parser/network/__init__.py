from lib.externals.hachoir.parser.network.tcpdump import TcpdumpFile  # noqa
