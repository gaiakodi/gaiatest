# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os,re,imp,json,time,xbmc

from lib.modules import tools
from lib.modules import cache
from lib.modules import network
from lib.modules import interface
from lib.modules import database
from lib.modules import clipboard
from lib.modules.concurrency import Pool
from lib.modules.account import Trakt as Account

TraktId = None
TraktClient = None
TraktAccount = None

def getTraktAccount():
	global TraktAccount
	if TraktAccount is None: TraktAccount = Account()
	return TraktAccount

def getTraktId():
	global TraktId
	if TraktId is None: TraktId = tools.System.obfuscate(tools.Settings.getString('internal.key.trakt.id', raw = True))
	return TraktId

def getTraktClient():
	global TraktClient
	if TraktClient is None: TraktClient = tools.System.obfuscate(tools.Settings.getString('internal.key.trakt.client', raw = True))
	return TraktClient

def getTraktToken():
	return getTraktAccount().dataToken()

def getTraktRefresh():
	return getTraktAccount().dataRefresh()

def getTrakt(url, post = None, cache = True, check = True, timestamp = None, extended = False, direct = False, authentication = None, timeout = network.Networker.TimeoutLong):
	try:
		if not url.startswith('https://api.trakt.tv'):
			url = network.Networker.linkJoin('https://api.trakt.tv', url)

		token = None
		refresh = None
		if authentication:
			valid = True
			token = authentication['token']
			refresh = authentication['refresh']
		else:
			valid = getTraktCredentialsInfo()
			if valid:
				token = getTraktToken()
				refresh = getTraktRefresh()

		headers = {'Content-Type': 'application/json', 'trakt-api-key': getTraktId(), 'trakt-api-version': '2'}

		if not post == None: post = json.dumps(post)

		if direct or not valid:
			# Some features, like searching, can be done without user authentication.
			result = network.Networker().requestText(link = url, data = post, headers = headers, timeout = timeout)
			return result

		headers['Authorization'] = 'Bearer %s' % token
		networker = network.Networker()
		result = networker.request(link = url, data = post, headers = headers, timeout = timeout)
		if result and not (result['error']['code'] == 401 or result['error']['code'] == 405):
			if check: _cacheCheck()
			if extended: return networker.responseDataText(), result['headers']
			else: return networker.responseDataText()

		try: code = str(result[1])
		except: code = ''

		if code.startswith('5') or (result and tools.Tools.isString(result) and '<html' in result) or not result:
			return _error(url = url, post = post, timestamp = timestamp, message = 33676)

		oauth = 'https://api.trakt.tv/oauth/token'
		opost = {'client_id': getTraktId(), 'client_secret': getTraktClient(), 'redirect_uri': 'urn:ietf:wg:oauth:2.0:oob', 'grant_type': 'refresh_token', 'refresh_token': refresh}

		result = network.Networker().requestText(link = oauth, type = network.Networker.DataJson, data = opost, headers = headers, timeout = timeout)
		try: code = str(result[1])
		except: code = ''

		if code.startswith('5') or not result or (result and tools.Tools.isString(result) and '<html' in result):
			return _error(url = url, post = post, timestamp = timestamp, message = 33676)
		elif result and code in ['404']:
			return _error(url = url, post = post, timestamp = timestamp, message = 33786)
		elif result and code in ['401', '405']:
			return _error(url = url, post = post, timestamp = timestamp, message = 33677)

		result = json.loads(result)

		getTraktAccount().update(token = result['access_token'], refresh = result['refresh_token'])
		valid = getTraktCredentialsInfo()
		token = getTraktToken()

		headers['Authorization'] = 'Bearer %s' % token

		networker = network.Networker()
		result = networker.request(link = url, data = post, headers = headers, timeout = timeout)

		if check: _cacheCheck()

		if extended: return networker.responseDataText(), result['headers']
		else: return networker.responseDataText()
	except:
		tools.Logger.error()

	return None


def _error(url, post, timestamp, message):
	_cache(url = url, post = post, timestamp = timestamp)
	if tools.Settings.getBoolean('account.trakt.notifications'):
		interface.Dialog.notification(title = 32315, message = message, icon = interface.Dialog.IconError)
	interface.Loader.hide()
	return None

def _cache(url, post = None, timestamp = None):
	return cache.Cache.instance().traktCache(link = url, data = post, timestamp = timestamp)

def _cacheCheck():
	thread = Pool.thread(target = _cacheProcess)
	thread.start()

def _cacheProcess():
	while True:
		item = cache.Cache.instance().traktRetrieve()
		if not item: break
		getTrakt(url = item['link'], post = json.loads(item['data']) if item['data'] else None, cache = True, check = False, timestamp = item['time'])

def authentication(settings = True):
	def _authenticationInitiate():
		try:
			result = getTraktAsJson('/oauth/device/code', {'client_id': getTraktId()}, direct = True)
			return {
				Account.AttributeExpiration : int(result['expires_in']),
				Account.AttributeInterval : int(result['interval']),
				Account.AttributeCode : result['user_code'],
				Account.AttributeDevice : result['device_code'],
				Account.AttributeLink : result['verification_url'],
			}
		except:
			tools.Logger.error()
			return False

	def _authenticationVerify(data):
		try:
			result = getTraktAsJson('/oauth/device/token', {'client_id': getTraktId(), 'client_secret': getTraktClient(), 'code': data['device']}, direct = True)
			if result and 'access_token' in result:
				result = {
					Account.AttributeToken : result['access_token'],
					Account.AttributeRefresh : result['refresh_token'],
				}
				profile = getTraktAsJson('/users/me', authentication = result)
				result[Account.AttributeUsername] = profile['username']
				return result
			return None
		except:
			tools.Logger.error()
			return False

	return getTraktAccount()._authenticate(functionInitiate = _authenticationInitiate, functionVerify = _authenticationVerify, settings = settings)

def getTraktCredentialsInfo():
	return getTraktAccount().authenticated()


def getTraktIndicatorsInfo():
	if tools.Settings.getBoolean('playback.track.enabled'):
		indicator = tools.Settings.getInteger('playback.track.status.alternative') if getTraktCredentialsInfo() else tools.Settings.getInteger('playback.track.status')
		return indicator == 1
	return None


def getTraktAddonMovieInfo():
	try: addon = tools.System.addon(id = 'script.trakt')
	except: pass
	try: scrobble = addon.getSetting('scrobble_movie')
	except: scrobble = ''
	try: ExcludeHTTP = addon.getSetting('ExcludeHTTP')
	except: ExcludeHTTP = ''
	try: authorization = addon.getSetting('authorization')
	except: authorization = ''
	if scrobble == 'true' and ExcludeHTTP == 'false' and not authorization == '': return True
	else: return False


def getTraktAddonEpisodeInfo():
	try: addon = tools.System.addon(id = 'script.trakt')
	except: pass
	try: scrobble = addon.getSetting('scrobble_episode')
	except: scrobble = ''
	try: ExcludeHTTP = addon.getSetting('ExcludeHTTP')
	except: ExcludeHTTP = ''
	try: authorization = addon.getSetting('authorization')
	except: authorization = ''
	if scrobble == 'true' and ExcludeHTTP == 'false' and not authorization == '': return True
	else: return False

def watch(type = None, imdb = None, tmdb = None, tvdb = None, season = None, episode = None, refresh = True, notification = False):
	if type is None: type = tools.Media.TypeMovie if season is None else tools.Media.TypeEpisode
	if tools.Media.typeTelevision(type):
		if not episode == None:
			markEpisodeAsWatched(imdb = imdb, tvdb = tvdb, season = season, episode = episode)
			syncShowCache(imdb = imdb, cached = False)
		elif not season == None:
			markSeasonAsWatched(imdb = imdb, tvdb = tvdb, season = season)
			syncShowCache(imdb = imdb, cached = False)
		elif not tvdb == None:
			markTVShowAsWatched(imdb = imdb, tvdb = tvdb)
			syncShowCache(imdb = imdb, cached = False)
	else:
		markMovieAsWatched(imdb = imdb, tmdb = tmdb)
		syncMoviesCache(cached = False)

	if refresh: interface.Directory.refresh(position = True)
	if notification: interface.Dialog.notification(title = 32315, message = 35502, icon = interface.Dialog.IconSuccess)

	try:
		from lib.modules import video
		video.Trailer().watch(imdb = imdb)
	except:
		tools.Logger.error()

def unwatch(type = None, imdb = None, tmdb = None, tvdb = None, season = None, episode = None, refresh = True, notification = False):
	if type is None: type = tools.Media.TypeMovie if season is None else tools.Media.TypeEpisode
	if tools.Media.typeTelevision(type):
		if not episode == None:
			markEpisodeAsNotWatched(imdb = imdb, tvdb = tvdb, season = season, episode = episode)
			syncShowCache(imdb = imdb, cached = False)
		elif not season == None:
			markSeasonAsNotWatched(imdb = imdb, tvdb = tvdb, season = season)
			syncShowCache(imdb = imdb, cached = False)
		elif not tvdb == None:
			markTVShowAsNotWatched(imdb = imdb, tvdb = tvdb)
			syncShowCache(imdb = imdb, cached = False)
	else:
		markMovieAsNotWatched(imdb = imdb, tmdb = tmdb)
		syncMoviesCache(cached = False)

	if refresh: interface.Directory.refresh(position = True)
	if notification: interface.Dialog.notification(title = 32315, message = 35503, icon = interface.Dialog.IconSuccess)

	try:
		from lib.modules import video
		video.Trailer().unwatch(imdb = imdb)
	except:
		tools.Logger.error()

def manager(imdb = None, tvdb = None, season = None, episode = None, refresh = True):
	try:
		interface.Loader.show()
		if not season == None: season = int(season)
		if not episode == None: episode = int(episode)

		lists = []
		try:
			result = getTrakt('/users/me/lists')
			result = tools.Converter.jsonFrom(result)
			result = [(i['name'], i['ids']['slug']) for i in result]
			for i in result:
				lists.append({
					'title' : i[0],
					'items' : [
						{'title' : interface.Translation.string(32521) % i[0], 'value' : interface.Translation.string(33580) % i[0], 'return' : '/users/me/lists/%s/items' % i[1]},
						{'title' : interface.Translation.string(32522) % i[0], 'value' : interface.Translation.string(33581) % i[0], 'return' : '/users/me/lists/%s/items/remove' % i[1]},
					],
				})
		except:
			tools.Logger.error()

		items = [
			{'title' : interface.Dialog.prefixBack(33486), 'close' : True},
			{
				'title' : 35500,
				'items' : [
					{'title' : 33651, 'value' : 33655, 'return' : 'watch'},
					{'title' : 33652, 'value' : 33656, 'return' : 'unwatch'},
				],
			},
			{
				'title' : 35501,
				'items' : [
					{'title' : 33653, 'value' : 33657, 'return' : 'rate'},
					{'title' : 33654, 'value' : 33658, 'return' : 'unrate'},
				],
			},
			{
				'title' : 32032,
				'items' : [
					{'title' : 32516, 'value' : 33575, 'return' : '/sync/collection'},
					{'title' : 32517, 'value' : 33576, 'return' : '/sync/collection/remove'},
				],
			},
			{
				'title' : 32033,
				'items' : [
					{'title' : 32518, 'value' : 33577, 'return' : '/sync/watchlist'},
					{'title' : 32519, 'value' : 33578, 'return' : '/sync/watchlist/remove'},
				],
			},
		]
		items += lists
		items += [{
			'title' : 33002,
			'items' : [
				{'title' : 32520, 'value' : 33579, 'return' : '/users/me/lists/%s/items'},
			],
		}]

		interface.Loader.hide()
		select = interface.Dialog.information(title = 32070, items = items)

		if select:
			if select in ['watch', 'unwatch']:
				interface.Loader.show()
				globals()[select](imdb = imdb, tvdb = tvdb, season = season, episode = episode, refresh = refresh, notification = True)
				interface.Loader.hide()
			elif select in ['rate', 'unrate']:
				interface.Loader.show()
				globals()[select](imdb = imdb, tvdb = tvdb, season = season, episode = episode)
				interface.Loader.hide()
			else:
				interface.Loader.show()
				if tvdb == None:
					post = {"movies": [{"ids": {"imdb": imdb}}]}
				else:
					if not episode == None:
						post = {"shows": [{"ids": {"imdb": imdb, "tvdb": tvdb}, "seasons": [{"number": season, "episodes": [{"number": episode}]}]}]}
					elif not season == None:
						post = {"shows": [{"ids": {"imdb": imdb, "tvdb": tvdb}, "seasons": [{"number": season}]}]}
					else:
						post = {"shows": [{"ids": {"imdb": imdb, "tvdb": tvdb}}]}

				if select == '/users/me/lists/%s/items':
					slug = listAdd(successNotification = False)
					if not slug == None: getTrakt(select % slug, post = post)
				else:
					getTrakt(select, post = post)

				interface.Loader.hide()
				interface.Dialog.notification(title = 32315, message = 33583 if '/remove' in select else 33582, icon = interface.Dialog.IconSuccess)
	except:
		tools.Logger.error()
		interface.Loader.hide()


def listAdd(successNotification = True):
	new = interface.Dialog.keyboard(title = 32520)
	if (new == None or new == ''): return
	result = getTrakt('/users/me/lists', post = {"name" : new, "privacy" : "private"})

	try:
		slug = json.loads(result)['ids']['slug']
		if successNotification:
			interface.Dialog.notification(title = 32070, message = 33661, icon = interface.Dialog.IconSuccess)
		return slug
	except:
		interface.Dialog.notification(title = 32070, message = 33584, icon = interface.Dialog.IconError)
		return None


def lists(id = None):
	return cache.Cache.instance().cacheMedium(getTraktAsJson, 'https://api.trakt.tv/users/me/lists' + ('' if id == None else ('/' + str(id))))


def list(id):
	return lists(id = id)


def slug(name):
	name = name.strip()
	name = name.lower()
	name = re.sub('[^a-z0-9_]', '-', name)
	name = re.sub('--+', '-', name)
	return name


def verify(authentication = None):
	try:
		if getTraktAsJson('/sync/last_activities', authentication = authentication):
			return True
	except: pass
	return False


def getActivity():
	try:
		i = getTraktAsJson('/sync/last_activities')

		activity = []
		activity.append(i['movies']['collected_at'])
		activity.append(i['episodes']['collected_at'])
		activity.append(i['movies']['watchlisted_at'])
		activity.append(i['shows']['watchlisted_at'])
		activity.append(i['seasons']['watchlisted_at'])
		activity.append(i['episodes']['watchlisted_at'])
		activity.append(i['lists']['updated_at'])
		activity.append(i['lists']['liked_at'])
		activity = [tools.Time.timestamp(i, iso = True) for i in activity]
		activity = sorted(activity, key=int)[-1]

		return activity
	except:
		pass


def getWatchedActivity():
	try:
		i = getTraktAsJson('/sync/last_activities')

		activity = []
		activity.append(i['movies']['watched_at'])
		activity.append(i['episodes']['watched_at'])
		activity = [tools.Time.timestamp(i, iso = True) for i in activity]
		activity = sorted(activity, key=int)[-1]

		return activity
	except:
		pass


def syncMoviesCache(cached = True):
	if cached: return cache.Cache.instance().cacheShort(syncMovies) # Do not cacheRefresh() here, since it will always make a request to Trakt if the same menu is reloaded seconds appart.
	else: return cache.Cache.instance().cacheClear(syncMovies)


def syncMovies():
	try:
		if getTraktCredentialsInfo():
			indicators = getTraktAsJson('/users/me/watched/movies')
			indicators = [i['movie']['ids'] for i in indicators]
			indicators = [str(i['imdb']) for i in indicators if 'imdb' in i]
			return indicators
	except:
		pass


# Gaia
def watchedMovies():
	try:
		if getTraktCredentialsInfo():
			return getTraktAsJson('/users/me/watched/movies?extended=full')
	except:
		pass


# Gaia
def watchedMoviesTime(imdb):
	try:
		imdb = str(imdb)
		items = watchedMovies()
		for item in items:
			if str(item['movie']['ids']['imdb']) == imdb:
				return item['last_watched_at']
	except:
		pass


def syncShowCache(imdb, cached = True):
	threads = [Pool.thread(target = syncShowsCache, args = (cached,)), Pool.thread(target = syncSeasonsCache, args = (imdb, cached))]
	[i.start() for i in threads]
	[i.join() for i in threads]


def syncShowsCache(cached = True):
	if cached: return cache.Cache.instance().cacheShort(syncShows) # Do not cacheRefresh() here, since it will always make a request to Trakt if the same menu is reloaded seconds appart.
	else: return cache.Cache.instance().cacheClear(syncShows)


def syncSeasonsCache(imdb, cached = True):
	if cached: return cache.Cache.instance().cacheRefresh(syncSeasons, imdb)
	else: return cache.Cache.instance().cacheClear(syncSeasons, imdb)


def syncShows():
	try:
		if getTraktCredentialsInfo():
			indicators = getTraktAsJson('/users/me/watched/shows?extended=full')
			indicators = [(i['show']['ids']['tvdb'], i['show']['aired_episodes'], sum([[(s['number'], e['number']) for e in s['episodes']] for s in i['seasons']], [])) for i in indicators]
			indicators = [(str(i[0]), int(i[1]), i[2]) for i in indicators]
			return indicators
	except:
		pass


def syncSeasons(imdb):
	try:
		if getTraktCredentialsInfo():
			indicators = getTraktAsJson('/shows/%s/progress/watched?specials=true&hidden=false' % imdb)
			indicators = indicators['seasons']
			indicators = [(i['number'], [x['completed'] for x in i['episodes']]) for i in indicators]
			indicators = ['%01d' % int(i[0]) for i in indicators if not False in i[1]]
			return indicators
	except:
		pass


# Gaia
def watchedShows():
	try:
		if getTraktCredentialsInfo():
			return getTraktAsJson('/users/me/watched/shows?extended=full')
	except:
		pass


# Gaia
def watchedShowsTime(tvdb, season, episode):
	try:
		tvdb = str(tvdb)
		season = int(season)
		episode = int(episode)
		items = watchedShows()
		for item in items:
			if str(item['show']['ids']['tvdb']) == tvdb:
				seasons = item['seasons']
				for s in seasons:
					if s['number'] == season:
						episodes = s['episodes']
						for e in episodes:
							if e['number'] == episode:
								return e['last_watched_at']
	except:
		pass


# Gaia
def showCount(imdb, refresh = True, wait = False):
	try:
		if not imdb: return None
		result = {'total' : 0, 'watched' : 0, 'unwatched' : 0}
		indicators = seasonCount(imdb = imdb, refresh = refresh, wait = wait)
		for key, value in indicators.items():
			result['total'] += value['total']
			result['watched'] += value['watched']
			result['unwatched'] += value['unwatched']
		return result
	except:
		return None

def seasonCount(imdb = None, items = None, refresh = True, wait = False):
	try:
		single = items == None
		if single: items = [imdb]
		items = [('tt' + i.replace('tt', '')) for i in items if i]
		if len(items) == 0: return None

		indicators = [cache.Cache.instance().cacheRetrieve(_seasonCountRetrieve, i) for i in items]
		if refresh:
			# NB: Do not retrieve a fresh count, otherwise loading show/season menus are slow.
			threads = [Pool.thread(target = _seasonCountCache, args = (i,)) for i in items]
			[i.start() for i in threads]
			if wait:
				[i.join() for i in threads]
				indicators = [cache.Cache.instance().cacheRetrieve(_seasonCountRetrieve, i) for i in items]

		return indicators[0] if single else indicators
	except:
		return None

def _seasonCountCache(imdb):
	return cache.Cache.instance().cacheRefresh(_seasonCountRetrieve, imdb)

def _seasonCountRetrieve(imdb):
	try:
		if getTraktCredentialsInfo():
			special = tools.Settings.getBoolean('navigation.show.special') and (tools.Settings.getBoolean('navigation.show.special.season') or tools.Settings.getBoolean('navigation.show.special.episode'))
			indicators = getTraktAsJson('/shows/%s/progress/watched?specials=%s&hidden=false' % (imdb, 'true' if special else 'false'))
			seasons = indicators['seasons']
			return {season['number'] : {'total' : season['aired'], 'watched' : season['completed'], 'unwatched' : season['aired'] - season['completed']} for season in seasons}
	except:
		return None


def request(imdb = None, tmdb = None, tvdb = None, season = None, episode = None, rating = None, items = None):
	result = []
	if items == None: items = [{'imdb' : imdb, 'tmdb' : tmdb, 'tvdb' : tvdb, 'season' : season, 'episode' : episode, 'rating' : rating}]
	for item in items:
		value = {'ids' : {}}
		if 'imdb' in item and item['imdb']: value['ids']['imdb'] = 'tt' + item['imdb'].replace('tt', '')
		if 'tmdb' in item and item['tmdb']: value['ids']['tmdb'] = int(item['tmdb'])
		if 'tvdb' in item and item['tvdb']: value['ids']['tvdb'] = int(item['tvdb'])
		if 'season' in item and item['season']:
			value['seasons'] = [{'number' : int(item['season'])}]
			if 'episode' in item and item['episode']:
				value['seasons'][0]['episodes'] = [{'number' : int(item['episode'])}]
				if 'rating' in item and not item['rating'] is None: value['seasons'][0]['episodes'][0]['rating'] = int(item['rating'])
			elif 'rating' in item and not item['rating'] is None:
				value['seasons'][0]['rating'] = int(item['rating'])
		elif 'rating' in item and not item['rating'] is None:
			value['rating'] = int(item['rating'])
		result.append(value)
	return result

def timeout(items):
	return max(network.Networker.TimeoutLong, len(items) * 2)

def markMovieAsWatched(imdb = None, tmdb = None, items = None):
	items = request(imdb = imdb, tmdb = tmdb, items = items)
	return getTrakt('/sync/history', {"movies": items}, timeout = timeout(items))

def markMovieAsNotWatched(imdb = None, tmdb = None, items = None):
	items = request(imdb = imdb, tmdb = tmdb, items = items)
	return getTrakt('/sync/history/remove', {"movies": items}, timeout = timeout(items))

def markTVShowAsWatched(imdb = None, tvdb = None, items = None):
	items = request(imdb = imdb, tvdb = tvdb, items = items)
	result = getTrakt('/sync/history', {"shows": items}, timeout = timeout(items))
	seasonCount(imdb = imdb, items = items)
	return result

def markTVShowAsNotWatched(imdb = None, tvdb = None, items = None):
	items = request(imdb = imdb, tvdb = tvdb, items = items)
	result = getTrakt('/sync/history/remove', {"shows": items}, timeout = timeout(items))
	seasonCount(imdb = imdb, items = items)
	return result

def markSeasonAsWatched(imdb = None, tvdb = None, season = None, items = None):
	items = request(imdb = imdb, tvdb = tvdb, season = season, items = items)
	result = getTrakt('/sync/history', {"shows": items}, timeout = timeout(items))
	seasonCount(imdb = imdb, items = items)
	return result

def markSeasonAsNotWatched(imdb = None, tvdb = None, season = None, items = None):
	items = request(imdb = imdb, tvdb = tvdb, season = season, items = items)
	result = getTrakt('/sync/history/remove', {"shows": items}, timeout = timeout(items))
	seasonCount(imdb = imdb, items = items)
	return result

def markEpisodeAsWatched(imdb = None, tvdb = None, season = None, episode = None, items = None):
	items = request(imdb = imdb, tvdb = tvdb, season = season, episode = episode, items = items)
	result = getTrakt('/sync/history', {"shows": items}, timeout = timeout(items))
	seasonCount(imdb = imdb, items = items)
	return result

def markEpisodeAsNotWatched(imdb = None, tvdb = None, season = None, episode = None, items = None):
	items = request(imdb = imdb, tvdb = tvdb, season = season, episode = episode, items = items)
	result = getTrakt('/sync/history/remove', {"shows": items}, timeout = timeout(items))
	seasonCount(imdb = imdb, items = items)
	return result

def rateMovie(imdb = None, tmdb = None, rating = None, items = None):
	items = request(imdb = imdb, tmdb = tmdb, rating = rating, items = items)
	return getTrakt('/sync/ratings', {"movies": items}, timeout = timeout(items))

def rateShow(imdb = None, tvdb = None, rating = None, items = None):
	items = request(imdb = imdb, tvdb = tvdb, rating = rating, items = items)
	return getTrakt('/sync/ratings', {"shows": items}, timeout = timeout(items))

def rateSeason(imdb = None, tvdb = None, season = None, rating = None, items = None):
	items = request(imdb = imdb, tvdb = tvdb, season = season, rating = rating, items = items)
	return getTrakt('/sync/ratings', {"shows": items}, timeout = timeout(items))

def rateEpisode(imdb = None, tvdb = None, season = None, episode = None, rating = None, items = None):
	items = request(imdb = imdb, tvdb = tvdb, season = season, episode = episode, rating = rating, items = items)
	return getTrakt('/sync/ratings', {"shows": items}, timeout = timeout(items))

def rate(imdb = None, tvdb = None, season = None, episode = None):
	return _rate(action = 'rate', imdb = imdb, tvdb = tvdb, season = season, episode = episode)

def unrate(imdb = None, tvdb = None, season = None, episode = None):
	return _rate(action = 'unrate', imdb = imdb, tvdb = tvdb, season = season, episode = episode)

def rateManual(imdb = None, tvdb = None, season = None, episode = None):
	if tools.Settings.getInteger('account.trakt.rating') == 1:
		rate(imdb = imdb, tvdb = tvdb, season = season, episode = episode)

def _rate(action, imdb = None, tvdb = None, season = None, episode = None):
	try:
		if tools.Trakt.installed():
			data = {}
			data['action'] = action
			if not tvdb == None:
				data['video_id'] = tvdb
				if not episode == None:
					data['media_type'] = 'episode'
					data['dbid'] = 1
					data['season'] = int(season)
					data['episode'] = int(episode)
				elif not season == None:
					data['media_type'] = 'season'
					data['dbid'] = 5
					data['season'] = int(season)
				else:
					data['media_type'] = 'show'
					data['dbid'] = 2
			else:
				data['video_id'] = imdb
				data['media_type'] = 'movie'
				data['dbid'] = 4

			script = os.path.join(tools.System.path(tools.Trakt.Id), 'resources', 'lib', 'sqlitequeue.py')
			sqlitequeue = imp.load_source('sqlitequeue', script)
			data = {'action' : 'manualRating', 'ratingData' : data}
			sqlitequeue.SqliteQueue().append(data)
		else:
			interface.Dialog.notification(title = 32315, message = 33659)
	except:
		tools.Logger.error()

def getMovieTranslation(id, lang = None, full = False):
	url = '/movies/%s/translations' % id
	return getTranslation(url = url, lang = lang, full = full)

def getTVShowTranslation(id, lang = None, season = None, episode = None, full = False):
	if season and episode: url = '/shows/%s/seasons/%s/episodes/%s/translations' % (id, season, episode)
	else: url = '/shows/%s/translations' % id
	return getTranslation(url = url, lang = lang, full = full)

def getTranslation(url, lang = None, full = False):
	try:
		all = False
		single = False
		multi = False
		if not lang: all = True
		elif tools.Tools.isString(lang): single = True
		elif tools.Tools.isArray(lang): multi = True

		if single: url += '/%s' % lang
		item = processTitles(cache.Cache.instance().cacheLong(getTraktAsJson, url))

		if item:
			if multi: item = [i for i in item if i['language'] in lang]
			if not full: item = [i['title'] for i in item if 'title' in i and i['title']]
			if single: item = item[0]
			return item
	except: tools.Logger.error()
	return None


def getMovieSummary(id, full = True):
	try:
		url = '/movies/%s' % id
		if full: url += '?extended=full'
		return cache.Cache.instance().cacheLong(getTraktAsJson, url)
	except:
		return


def getTVShowSummary(id, full = True):
	try:
		url = '/shows/%s' % id
		if full: url += '?extended=full'
		return cache.Cache.instance().cacheLong(getTraktAsJson, url)
	except:
		return


def sort_list(sort_key, sort_direction, list_data):
	reverse = False if sort_direction == 'asc' else True
	if sort_key == 'rank':
		return sorted(list_data, key=lambda x: x['rank'], reverse=reverse)
	elif sort_key == 'added':
		return sorted(list_data, key=lambda x: x['listed_at'], reverse=reverse)
	elif sort_key == 'title':
		return sorted(list_data, key=lambda x: title_key(x[x['type']].get('title')), reverse=reverse)
	elif sort_key == 'released':
		return sorted(list_data, key=lambda x: x[x['type']].get('first_aired', ''), reverse=reverse)
	elif sort_key == 'runtime':
		return sorted(list_data, key=lambda x: x[x['type']].get('runtime', 0), reverse=reverse)
	elif sort_key == 'popularity':
		return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
	elif sort_key == 'percentage':
		return sorted(list_data, key=lambda x: x[x['type']].get('rating', 0), reverse=reverse)
	elif sort_key == 'votes':
		return sorted(list_data, key=lambda x: x[x['type']].get('votes', 0), reverse=reverse)
	else:
		return list_data


def title_key(title):
	try:
		if title is None: title = ''
		articles_en = ['the', 'a', 'an']
		articles_de = ['der', 'die', 'das']
		articles = articles_en + articles_de

		match = re.match('^(\w+\s+)', title.lower())
		if match and match.group(1) in articles: offset = len(match.group(1))
		else: offset = 0

		return title[offset:]
	except:
		return title


def getTraktAsJson(url, post = None, direct = False, authentication = None):
	try:
		res_headers = {}
		r = getTrakt(url = url, post = post, extended = True, direct = direct, authentication = authentication)
		if tools.Tools.isTuple(r) and len(r) == 2:
			res_headers = r[1]
			r = r[0]
		r = tools.Converter.jsonFrom(r)
		res_headers = dict((k.lower(), v) for k, v in res_headers.items())
		if 'x-sort-by' in res_headers and 'x-sort-how' in res_headers:
			r = sort_list(res_headers['x-sort-by'], res_headers['x-sort-how'], r)
		return r
	except:
		pass

def processTitles(data):
	if data:
		try:
			result = []
			for item in data:
				# Filter out titles that are URLs.
				# Trakt sometimes returns a URL as an alias.
				# Eg: Cruella (2001): https://world.snagfilms.cc/en/movie/337404/cruella
				if network.Networker.linkIs(item['title']): continue

				result.append(item)
			return result
		except: tools.Logger.error()
	return data

def getMovieAliases(id):
	try: return processTitles(cache.Cache.instance().cacheLong(getTraktAsJson, '/movies/%s/aliases' % id))
	except: return []

def getTVShowAliases(id):
	try: return processTitles(cache.Cache.instance().cacheLong(getTraktAsJson, '/shows/%s/aliases' % id))
	except: return []

def getPeople(id, content_type, full=True):
	try:
		url = '/%s/%s/people' % (content_type, id)
		if full: url += '?extended=full'
		return cache.Cache.instance().cacheLong(getTraktAsJson, url)
	except:
		return

def SearchAll(title = None, year = None, imdb = None, tmdb = None, tvdb = None, trakt = None, full = True):
	try:
		result = []
		movies = SearchMovie(title = title, year = year, imdb = imdb, tmdb = tmdb, tvdb = tvdb, trakt = trakt, full = full)
		if movies: result.extend(movies)
		shows = SearchTVShow(title = title, year = year, imdb = imdb, tmdb = tmdb, tvdb = tvdb, trakt = trakt, full = full)
		if shows: result.extend(shows)
		returnresult if result else None
	except:
		return

def SearchMovie(title = None, year = None, imdb = None, tmdb = None, tvdb = None, trakt = None, full = True):
	try:
		if trakt: url = '/search/trakt/%s?type=movie' % str(trakt)
		elif imdb: url = '/search/imdb/%s' % str(imdb)
		elif tmdb: url = '/search/tmdb/%s?type=movie' % str(tmdb)
		elif title:
			url = '/search/movie?query=%s' % network.Networker.linkQuote(title, plus = True)
			if year: url += '&years=%s' % str(year)
		if full: url += '&extended=full'
		return getTraktAsJson(url)
	except:
		return

def SearchTVShow(title = None, year = None, imdb = None, tmdb = None, tvdb = None, trakt = None, full = True):
	try:
		if trakt: url = '/search/trakt/%s?type=show' % str(trakt)
		elif tvdb: url = '/search/tvdb/%s?type=show' % str(tvdb)
		elif imdb: url = '/search/imdb/%s' % str(imdb)
		elif tmdb: url = '/search/tmdb/%s?type=show' % str(tmdb)
		elif title:
			url = '/search/show?query=%s' % network.Networker.linkQuote(title, plus = True)
			if year: url += '&years=%s' % str(year)
		if full: url += '&extended=full'
		result = getTraktAsJson(url)
		if result: result = [i for i in result if i['type'] == 'show'] # Filter out movie results that might be returned by imdb lookups which do not support a type parameter.
		return result
	except:
		return


def getGenre(content, type, type_id):
	try:
		r = '/search/%s/%s?type=%s&extended=full' % (type, type_id, content)
		r = cache.Cache.instance().cacheLong(getTraktAsJson, r)
		r = r[0].get(content, {}).get('genres', [])
		return r
	except:
		return []

# GAIA

def _scrobbleType(type):
	if tools.Media.typeTelevision(type):
		return 'episode'
	else:
		return 'movie'

def scrobbleProgress(type, imdb = None, tvdb = None, season = None, episode = None):
	try:
		type = _scrobbleType(type)
		if not imdb == None: imdb = str(imdb)
		if not tvdb == None: tvdb = int(tvdb)
		if not episode == None: episode = int(episode)
		if not episode == None: episode = int(episode)
		link = '/sync/playback/type'
		items = getTraktAsJson(link)

		if type == 'episode':
			if imdb and items:
				for item in items:
					if 'show' in item and 'imdb' in item['show']['ids'] and item['show']['ids']['imdb'] == imdb:
						if item['episode']['season'] == season and item['episode']['number'] == episode:
							return item['progress']
			if tvdb:
				for item in items:
					if 'show' in item and 'tvdb' in item['show']['ids'] and item['show']['ids']['tvdb'] == tvdb:
						if item['episode']['season'] == season and item['episode']['number'] == episode:
		 					return item['progress']
		else:
			if imdb and items:
				for item in items:
					if 'movie' in item and 'imdb' in item['movie']['ids'] and item['movie']['ids']['imdb'] == imdb:
						return item['progress']
	except:
		tools.Logger.error()
	return 0

# action = start, pause, stop
# type = tools.Media.Type
# progress = float in [0, 100]
def scrobbleUpdate(action, type, imdb = None, tvdb = None, season = None, episode = None, progress = 0):
	try:
		if action:
			type = _scrobbleType(type)
			if not imdb == None: imdb = str(imdb)
			if not tvdb == None: tvdb = int(tvdb)
			if not season == None: season = int(season)
			if not episode == None: episode = int(episode)

			if imdb: link = '/search/imdb/' + str(imdb)
			elif tvdb: link = '/search/tvdb/' + str(tvdb)
			if type == 'episode': link += '?type=show'
			else: link += '?type=movie'
			items = cache.Cache.instance().cacheLong(getTraktAsJson, link)

			if len(items) > 0:
				item = items[0]
				if type == 'episode':
					slug = item['show']['ids']['slug']
					link = '/shows/%s/seasons/%d/episodes/%d' % (slug, season, episode)
					item = cache.Cache.instance().cacheLong(getTraktAsJson, link)
				else:
					item = item['movie']

				if item:
					link = '/scrobble/' + action
					data = {
						type : item,
						'progress' : progress,
						'app_version' : tools.System.version(),
					}
					result = getTrakt(url = link, post = data)
					return 'progress' in result
	except:
		pass
	return False

def imdbImportCheck(importWatched, importRatings):
	from lib.indexers import movies

	def check(method, result, index):
		indexer = movies.movies(type = tools.Media.TypeMovie)
		getattr(indexer, method)()
		result[index] = indexer.imdb_public

	threads = []
	values = [None, None]
	if any(importWatched):
		values[0] = False
		threads.append(Pool.thread(target = check, args = ('imdb_watched', values, 0)))
	if any(importRatings):
		values[1] = False
		threads.append(Pool.thread(target = check, args = ('imdb_ratings', values, 1)))

	[i.start() for i in threads]
	[i.join() for i in threads]
	return values[0], values[1]

def imdbImportRetrieve(importWatched, importRatings, ratings):
	from lib.indexers import movies
	from lib.indexers import shows

	def retrieve(type, method, result, index):
		if tools.Media.typeTelevision(type): result[index] = getattr(shows.shows(), method)()
		else: result[index] = getattr(movies.movies(type = type), method)()

	threads = []
	valuesWatched = [None, None, None, None]
	valuesRatings = [None, None, None, None]

	if importWatched[0]: threads.append(Pool.thread(target = retrieve, args = (tools.Media.TypeMovie, 'imdb_watched', valuesWatched, 0)))
	if importWatched[1]: threads.append(Pool.thread(target = retrieve, args = (tools.Media.TypeDocumentary, 'imdb_watched', valuesWatched, 1)))
	if importWatched[2]: threads.append(Pool.thread(target = retrieve, args = (tools.Media.TypeShort, 'imdb_watched', valuesWatched, 2)))
	if importWatched[3]: threads.append(Pool.thread(target = retrieve, args = (tools.Media.TypeShow, 'imdb_watched', valuesWatched, 3)))

	if importRatings[0]: threads.append(Pool.thread(target = retrieve, args = (tools.Media.TypeMovie, 'imdb_ratings', valuesRatings, 0)))
	if importRatings[1]: threads.append(Pool.thread(target = retrieve, args = (tools.Media.TypeDocumentary, 'imdb_ratings', valuesRatings, 1)))
	if importRatings[2]: threads.append(Pool.thread(target = retrieve, args = (tools.Media.TypeShort, 'imdb_ratings', valuesRatings, 2)))
	if importRatings[3]: threads.append(Pool.thread(target = retrieve, args = (tools.Media.TypeShow, 'imdb_ratings', valuesRatings, 3)))

	[i.start() for i in threads]
	[i.join() for i in threads]

	if ratings:
		if importWatched[0] and importRatings[0]: valuesWatched[0] = movies.movies(type = tools.Media.TypeMovie).imdb_account(ratings = valuesRatings[0], watched = valuesWatched[0])
		if importWatched[1] and importRatings[1]: valuesWatched[1] = movies.movies(type = tools.Media.TypeDocumentary).imdb_account(ratings = valuesRatings[1], watched = valuesWatched[1])
		if importWatched[2] and importRatings[2]: valuesWatched[2] = movies.movies(type = tools.Media.TypeShort).imdb_account(ratings = valuesRatings[2], watched = valuesWatched[2])
		if importWatched[3] and importRatings[3]: valuesWatched[3] = shows.shows().imdb_account(ratings = valuesRatings[3], watched = valuesWatched[3])

	return valuesWatched, valuesRatings

def imdbImportSync(itemsWatched, itemsRatings):
	def syncWatched(type, items):
		if tools.Media.typeTelevision(type): markTVShowAsWatched(items = items)
		else: markMovieAsWatched(items = items)

	def syncRatings(type, items):
		if tools.Media.typeTelevision(type): rateShow(items = items)
		else: rateMovie(items = items)

	threads = []

	if itemsWatched[0]: threads.append(Pool.thread(target = syncWatched, args = (tools.Media.TypeMovie, itemsWatched[0])))
	if itemsWatched[1]: threads.append(Pool.thread(target = syncWatched, args = (tools.Media.TypeDocumentary, itemsWatched[1])))
	if itemsWatched[2]: threads.append(Pool.thread(target = syncWatched, args = (tools.Media.TypeShort, itemsWatched[2])))
	if itemsWatched[3]: threads.append(Pool.thread(target = syncWatched, args = (tools.Media.TypeShow, itemsWatched[3])))

	if itemsRatings[0]: threads.append(Pool.thread(target = syncRatings, args = (tools.Media.TypeMovie, itemsRatings[0])))
	if itemsRatings[1]: threads.append(Pool.thread(target = syncRatings, args = (tools.Media.TypeDocumentary, itemsRatings[1])))
	if itemsRatings[2]: threads.append(Pool.thread(target = syncRatings, args = (tools.Media.TypeShort, itemsRatings[2])))
	if itemsRatings[3]: threads.append(Pool.thread(target = syncRatings, args = (tools.Media.TypeShow, itemsRatings[3])))

	[i.start() for i in threads]
	[i.join() for i in threads]

def imdbImport():
	if interface.Dialog.option(title = 32034, message = 35610):
		yes = interface.Format.fontBold(interface.Format.fontColor(interface.Translation.string(33341), interface.Format.colorExcellent()))
		no = interface.Format.fontBold(interface.Format.fontColor(interface.Translation.string(33342), interface.Format.colorBad()))

		importWatched = [True, True, True, True]
		importRatings = [True, True, True, True]

		initial = True
		while initial:
			choice = 1
			while choice > 0:
				items = [
					interface.Format.fontBold(interface.Translation.string(33821)),

					interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(35212), interface.Translation.string(32001), interface.Translation.string(32033))) + (yes if importWatched[0] else no),
					interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(35212), interface.Translation.string(33470), interface.Translation.string(32033))) + (yes if importWatched[1] else no),
					interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(35212), interface.Translation.string(33471), interface.Translation.string(32033))) + (yes if importWatched[2] else no),
					interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(35212), interface.Translation.string(32002), interface.Translation.string(32033))) + (yes if importWatched[3] else no),

					interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(35212), interface.Translation.string(32001), interface.Translation.string(35602))) + (yes if importRatings[0] else no),
					interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(35212), interface.Translation.string(33470), interface.Translation.string(35602))) + (yes if importRatings[1] else no),
					interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(35212), interface.Translation.string(33471), interface.Translation.string(35602))) + (yes if importRatings[2] else no),
					interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(35212), interface.Translation.string(32002), interface.Translation.string(35602))) + (yes if importRatings[3] else no),
				]
				choice = interface.Dialog.select(title = 32034, items = items)
				if choice < 0: return False
				elif choice == 0: break
				elif choice < 5: importWatched[choice - 1] = not importWatched[choice - 1]
				else: importRatings[choice - 5] = not importRatings[choice - 5]

			while True:
				publicWatched, publicRatings = imdbImportCheck(importWatched, importRatings)
				if publicWatched is False:
					if interface.Dialog.option(title = 32034, message = 35608, labelConfirm = 35606, labelDeny = 35374): continue
				elif publicRatings is False:
					if interface.Dialog.option(title = 32034, message = 35609, labelConfirm = 35606, labelDeny = 35374): continue
				else:
					initial = False
				break

		ratings = interface.Dialog.option(title = 32034, message = 35611) if any(importRatings) else False
		itemsWatched, itemsRatings = imdbImportRetrieve(importWatched, importRatings, ratings)

		items = [interface.Format.fontBold(interface.Translation.string(33821))]
		if not itemsWatched[0] is None: items.append(interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(32001), interface.Translation.string(32033), interface.Translation.string(35607))) + str(len(itemsWatched[0])))
		if not itemsWatched[1] is None: items.append(interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(33470), interface.Translation.string(32033), interface.Translation.string(35607))) + str(len(itemsWatched[1])))
		if not itemsWatched[2] is None: items.append(interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(33471), interface.Translation.string(32033), interface.Translation.string(35607))) + str(len(itemsWatched[2])))
		if not itemsWatched[3] is None: items.append(interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(32002), interface.Translation.string(32033), interface.Translation.string(35607))) + str(len(itemsWatched[3])))
		if not itemsRatings[0] is None: items.append(interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(32001), interface.Translation.string(35602), interface.Translation.string(35607))) + str(len(itemsRatings[0])))
		if not itemsRatings[1] is None: items.append(interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(33470), interface.Translation.string(35602), interface.Translation.string(35607))) + str(len(itemsRatings[1])))
		if not itemsRatings[2] is None: items.append(interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(33471), interface.Translation.string(35602), interface.Translation.string(35607))) + str(len(itemsRatings[2])))
		if not itemsRatings[3] is None: items.append(interface.Format.fontBold('%s %s %s: ' % (interface.Translation.string(32002), interface.Translation.string(35602), interface.Translation.string(35607))) + str(len(itemsRatings[3])))
		choice = interface.Dialog.select(title = 32034, items = items)
		if choice < 0: return False

		if interface.Dialog.option(title = 32034, message = 35612):
			interface.Loader.show()
			imdbImportSync(itemsWatched, itemsRatings)
			interface.Loader.hide()
			interface.Dialog.confirm(title = 32034, message = 35613)
			return True

	interface.Loader.hide()
	return False
