# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import xbmcgui
import re

from lib.modules import tools
from lib.modules import interface
from lib.modules.theme import Theme
from lib.modules.concurrency import Pool, Lock

class WindowBase(object):

	# Actions
	ActionAny = -1
	ActionMoveLeft = 1
	ActionMoveRight = 2
	ActionMoveUp = 3
	ActionMoveDown = 4
	ActionSelectItem = 7
	ActionBackSpace = 110
	ActionContextMenu = 117
	ActionPreviousMenu = 10
	ActionNavigationBack = 92
	ActionShowInfo = 11
	ActionItemNext = 14
	ActionItemPrevious = 15
	ActionsCancel = [ActionPreviousMenu, ActionNavigationBack, ActionBackSpace]

	def __init__(self, **arguments):
		self.mActions = []
		self.mControls = []
		self.mClicks = []
		self.mVisible = False

	def __del__(self):
		self.mVisible = False

	def show(self):
		self.mVisible = True
		xbmcgui.WindowDialog.show(self)

	def doModal(self):
		self.mVisible = True
		xbmcgui.WindowDialog.doModal(self)

	def close(self):
		self.mVisible = False
		xbmcgui.WindowDialog.close(self)

	def visible(self):
		return self.mVisible

	def _onAction(self, action, callback):
		self.mActions.append((action, callback))

	def _onControl(self, x, y, callback):
		self.mControls.append((x, y, callback))

	def _onClick(self, control, callback):
		try: control = control.getId()
		except: pass
		self.mClicks.append((control, callback))

	def onAction(self, action):
		id = action.getId()
		if id in WindowBase.ActionsCancel: self.mVisible = False
		xbmcgui.WindowDialog.onAction(self, action)
		for i in self.mActions:
			if i[0] == WindowBase.ActionAny or i[0] == id:
				try: i[1](action = id)
				except: i[1]()

	def onControl(self, control):
		distances = []
		actions = []
		x = control.getX()
		y = control.getY()

		for i in self.mControls:
			distances.append(abs(x - i[0]) + abs(y - i[1]))
			actions.append(i[2])

		smallestIndex = -1
		smallestDistance = 999999
		for i in range(len(distances)):
			if distances[i] < smallestDistance:
				smallestDistance = distances[i]
				smallestIndex = i

		if smallestIndex >= 0:
			try: actions[smallestIndex](control = control)
			except: actions[smallestIndex]()

	def onClick(self, controlId):
		for i in self.mClicks:
			if i[0] == controlId: i[1]()

class WindowCore(WindowBase, xbmcgui.WindowDialog):

	def __init__(self):
		super(WindowCore, self).__init__()

	def __del__(self):
		try: super(WindowCore, self).__del__()
		except: pass

class WindowXml(WindowBase, xbmcgui.WindowXMLDialog):

	def __init__(self, file, path, skin, resolution):
		# Using super() here with multiple inheritance does not work.
		WindowBase.__init__(self)
		xbmcgui.WindowXMLDialog.__init__(self, xmlFilename = file, scriptPath = path, defaultSkin = skin, defaultRes = resolution)

	def __del__(self):
		try: super(WindowXml, self).__del__()
		except: pass

class Window(object):

	Instance = None

	InitializeIterations = 100
	InitializeSleep = 0.1

	IdMinimum = 10000
	IdMaximum = 13000
	IdWindowHome = 10000
	IdWindowVideo = 10025
	IdWindowPlayer = 12901
	IdWindowPlayerFull = 12005
	IdWindowPlaylist = 10028
	IdWindowOk = 12002
	IdWindowInformation = 12003
	IdListControl = 52000

	PropertyType = 'GaiaType'

	# All Kodi windows have this fixed dimension.
	SizeWidth = 1280
	SizeHeight = 720

	# Size
	SizeLarge = 'large'
	SizeMedium = 'medium'
	SizeSmall = 'small'
	SizeMini = 'mini'

	# Replacements
	Replacements = {
		tools.Screen.Ratio4x3 : {
			'[GAIAPANELLEFT]' : '40',
			'[GAIAPOSTERTOP]' : '130',
			'[GAIAPOSTERWIDTH]' : '360',
			'[GAIAPOSTERHEIGHT]' : '400',
		},
		tools.Screen.Ratio16x9 : {
			'[GAIAPANELLEFT]' : '40',
			'[GAIAPOSTERTOP]' : '0',
			'[GAIAPOSTERWIDTH]' : '360',
			'[GAIAPOSTERHEIGHT]' : '530',
		},
		tools.Screen.Ratio20x9 : {
			'[GAIAPANELLEFT]' : '70',
			'[GAIAPOSTERTOP]' : '0',
			'[GAIAPOSTERWIDTH]' : '300',
			'[GAIAPOSTERHEIGHT]' : '530',
		},
	}

	# Type
	TypePlain = 'plain'
	TypeBasic = 'basic'
	TypeIcons = 'icons'
	TypeDefault = TypeIcons
	Types = [TypePlain, TypeBasic, TypeIcons]

	# Background
	BackgroundColorOpaque = 'FFFFFFFF'
	BackgroundColor1 = 'DD222222'
	BackgroundColor2 = 'AA111111'
	BackgroundNone = 0
	BackgroundCombined = 1
	BackgroundSkin = 2
	BackgroundFanart = 3

	# Separator
	SeparatorLineWidth = 850
	SeparatorLineHeight = 3
	SeparatorLineNarrow = 650
	SeparatorLineWide = 1100
	SeparatorLinePadding = 25

	# Alignment
	AlignmentLeft = 0x00000000
	AlignmentRight = 0x00000001
	AlignmentTruncated = 0x00000008
	AlignmentJustified = 0x00000010
	AlignmentCenterX = 0x00000002
	AlignmentCenterY = 0x00000004
	AlignmentCenter = AlignmentCenterX | AlignmentCenterY
	AlignmentLeftCenter = AlignmentLeft | AlignmentCenterY
	AlignmentRightCenter = AlignmentRight | AlignmentCenterY
	AlignmentTruncatedCenter = AlignmentTruncated | AlignmentCenterY
	AlignmentJustifiedCenter = AlignmentJustified | AlignmentCenterY

	# Ratio
	RatioStretch = 0
	RatioScaleUp = 1
	RatioScaleDown = 2
	RatioDefault = RatioStretch

	# Select
	SelectNone = None
	SelectYes = True
	SelectNo = False
	SelectHide = 'hide'

	def __init__(self, backgroundType, backgroundPath, xml = None, xmlScale = False, xmlType = TypeDefault, width = None, height = None):
		self.mId = 0
		self.mLock = Lock()
		self.mClose = False

		if xml:
			if xmlScale:
				ratio = tools.Screen.ratio(closest = True)[0]
				xmlRatio = xml.replace('.xml', '') + xmlType + ratio + '.xml'
				if not '.' in xml: xml += '.xml'
				pathTemplate = self._pathTemplate()
				pathWindow = self._pathWindow(True)
				pathXml = tools.File.joinPath(pathTemplate, xml)
				pathRatio = tools.File.joinPath(pathWindow, xmlRatio)
				xml = xmlRatio

				if not tools.File.exists(pathRatio):
					tools.File.makeDirectory(pathWindow)
					data = tools.File.readNow(pathXml)

					for key, value in Window.Replacements[ratio].items():
						data = data.replace(key, value)

					types = Window.Types
					try: types.remove(xmlType)
					except: pass
					types = ['<!-- \[GAIATYPE%s/\] -->.*?<!-- \[/GAIATYPE%s\] -->' % (type.upper(), type.upper()) for type in types]
					for type in types:
						data = re.sub(type, '', data, flags = re.DOTALL)

					tools.File.writeNow(pathRatio, data)
			if not '.' in xml: xml += '.xml'
			self.mWindow = WindowXml(xml, self._pathWindow(False), 'default', '720p')
		else:
			self.mWindow = WindowCore()

		self.mEnd = False
		self.mControls = []
		self.mLabels = []
		self.mContexts = []

		self.mBackgroundType = backgroundType
		self.mBackgroundPath = backgroundPath

		self.mScaleWidth = (Window.SizeWidth / float(Window.SizeHeight)) / (tools.Screen.width() / float(tools.Screen.height()))
		self.mScaleHeight = 1

		self.mWidth = Window.SizeWidth if width is None else width
		self.mHeight = Window.SizeHeight if height is None else height

	def __del__(self):
		self._remove()

	@classmethod
	def instance(self):
		return self._instance()

	@classmethod
	def _instance(self, instance = None):
		# One instance per class.
		if not instance is None: globals()[self.__name__].Instance = instance
		return globals()[self.__name__].Instance

	@classmethod
	def _instanceHas(self):
		return not globals()[self.__name__].Instance is None

	@classmethod
	def _instanceId(self):
		try: return globals()[self.__name__].Instance.mId
		except: return None

	@classmethod
	def _instanceDelete(self):
		try:
			del globals()[self.__name__].Instance
			globals()[self.__name__].Instance = None
		except: pass

	def _lock(self):
		self.mLock.acquire()

	def _unlock(self):
		self.mLock.release()

	def _locked(self):
		self.mLock.locked()

	def _initializeStart1(self):
		pass

	def _initializeStart2(self):
		self._addBackground(type = self.mBackgroundType, path = self.mBackgroundPath)

	def _initializeStart3(self):
		pass

	def _initializeEnd1(self):
		self.mEnd = True

	def _initializeEnd2(self):
		pass

	def _onAction(self, action, callback):
		if self.mWindow: self.mWindow._onAction(action, callback)

	def _onControl(self, x, y, callback):
		if self.mWindow: self.mWindow._onControl(x, y, callback)

	def _onClick(self, control, callback):
		if self.mWindow: self.mWindow._onClick(control, callback)

	@classmethod
	def _colorDefault(self):
		return interface.Format.colorWhite()

	@classmethod
	def _colorHighlight(self):
		return interface.Format.colorPrimary()

	@classmethod
	def _colorDiffuse(self):
		return interface.Format.colorDisabled()

	@classmethod
	def _colorSeparator(self):
		return interface.Format.colorSecondary()

	@classmethod
	def _end(self):
		try: return self._instance().mEnd
		except: pass

	@classmethod
	def _idPropertyName(self):
		return tools.System.name() + self.__name__

	@classmethod
	def _idProperty(self):
		id = self.propertyGlobal(self._idPropertyName())
		if id is None or id == '': return None
		else: return int(id)

	@classmethod
	def _idPropertySet(self, id):
		return self.propertyGlobalSet(self._idPropertyName(), id)

	@classmethod
	def _idPropertyClear(self):
		return self.propertyGlobalClear(self._idPropertyName())

	@classmethod
	def _initialize1(self, **arguments):
		try:
			window = self._instance(self(**arguments))
		except:
			try:
				try: del arguments['retry']
				except: pass
				window = self._instance(self(**arguments))
			except:
				tools.Logger.error()
				return None
		window.propertySet(Window.PropertyType, self.__name__)
		window._initializeStart1()
		window._initializeStart2()
		window._initializeControls(labels = False) # Initialize controls needed from the start (important for WindowStreams).
		window._initializeStart3()
		window.mWindow.doModal()
		window.close()

	@classmethod
	def _initialize2(self):
		try:
			count = 0
			instance = self._instance()
			while instance is None and count < Window.InitializeIterations:
				tools.Time.sleep(Window.InitializeSleep)
				count += 1
				instance = self._instance()
			if not instance is None:
				while not instance.visible() and count < Window.InitializeIterations:
					tools.Time.sleep(Window.InitializeSleep)
					count += 1
				id = self.current()
				instance.mId = id
				self._idPropertySet(instance.mId)
				instance._initializeEnd1()
				instance._initializeControls(labels = True) # Initialize remaining controls.
				instance._initializeEnd2()
		except: pass

	def _initializeControls(self, labels = True, lock = False):
		if lock: self._lock()

		# Add controls that were not added before.
		controls = []
		hidden = []
		animations = []
		for i in range(len(self.mControls)):
			if not self.mControls[i]['initialized']:
				self.mControls[i]['initialized'] = True
				controls.append(self.mControls[i]['control'])
				if not self.mControls[i]['visible']: hidden.append(self.mControls[i]['control'])
				if self.mControls[i]['animation']: animations.append((self.mControls[i]['control'], self.mControls[i]['animation']))
		self.mWindow.addControls(controls)

		# Hide non-visible controls.
		# Cannot call setVisible(...) BEFORE the controls was added to the window.
		for control in hidden:
			control.setVisible(False)

		# Add animations.
		for control in animations:
			control[0].setAnimations(control[1])

		# Initialize the label text.
		if labels:
			for label in self.mLabels:
				self._setLabel(control = label['control'], text = label['text'], color = label['color'], size = label['size'], bold = label['bold'], italic = label['italic'], light = label['light'], uppercase = label['uppercase'], lowercase = label['lowercase'], capitalcase = label['capitalcase'])

		if lock: self._unlock()

	@classmethod
	def _show(self, **arguments):
		try:
			close = arguments['close']
			del arguments['close']
		except:
			close = False
		if self.visible() and not close:
			return False
		elif close:
			self.close()
			tools.Time.sleep(0.1)

		wait = arguments['wait']
		del arguments['wait']
		initialize = arguments['initialize']
		del arguments['initialize']
		thread1 = Pool.thread(target = self._initialize1, kwargs = arguments)
		thread1.start()
		thread2 = Pool.thread(target = self._initialize2)
		thread2.start()
		if wait:
			thread1.join()
		elif initialize: # Wait until launched.
			count = 0
			while not self.visible() and count < Window.InitializeIterations:
				tools.Time.sleep(Window.InitializeSleep)
				count += 1
			while not self._end() and count < Window.InitializeIterations:
				tools.Time.sleep(Window.InitializeSleep)
				count += 1
		return True

	@classmethod
	def clean(self):
		tools.File.deleteDirectory(self._pathWindow())

	@classmethod
	def close(self, id = None, loader = False):
		try:
			# Instance might be lost if accessed in a subsequent execution (eg: applying filters).
			if id is None and not self._instanceHas(): id = self._idProperty()
			if id is None:
				instance = self._instance()
				if not instance.mClose: # In case this function is called multiple times.
					instance.mClose = True
					# Close the window BEFORE calling _remove().
					# This seems to solve the issue of Gaia labels remaining in the Kodi UI when the cancel button in scraping window is clicked.
					instance.mWindow.close()
					instance._remove()
					#instance.mWindow.close()
					if loader: interface.Loader.hide() # Sometimes is visible if canceling playback window.
					try: del instance.mWindow
					except: pass
					try: instance.mWindow = None
					except: pass
					self._instanceDelete()
			else:
				interface.Dialog.close(id)
			self._idPropertyClear()
			return True
		except:
			self._idPropertyClear()
			return False

	@classmethod
	def show(self, id):
		return tools.System.execute('ActivateWindow(%s)' % str(id))

	@classmethod
	def id(self):
		try: return self._instance().mId
		except: return None

	@classmethod
	def current(self, id = None):
		return self.currentDialog(id = id)

	@classmethod
	def currentWindow(self, id = None):
		result = xbmcgui.getCurrentWindowId()
		if id is None: return result
		else: return result == id

	@classmethod
	def currentDialog(self, id = None):
		result = xbmcgui.getCurrentWindowDialogId()
		if id is None: return result
		else: return result == id

	@classmethod
	def currentType(self):
		try:
			result = xbmcgui.Window(self.currentDialog()).getProperty(Window.PropertyType)
			if result == '': return None
			else: return result
		except: return None

	@classmethod
	def currentGaia(self):
		return not self.currentType() is None

	@classmethod
	def visible(self, id = None):
		try:
			if id is None: return self._instance().mWindow.visible()
			else: return self.visibleWindow(id) or self.visibleDialog(id)
		except: return False

	@classmethod
	def visibleWindow(self, id):
		return self.currentWindow() == id

	@classmethod
	def visibleDialog(self, id):
		return self.currentDialog() == id

	@classmethod
	def visibleCustom(self, id = None):
		return self.currentWindow() >= Window.IdMaximum or self.currentDialog() >= Window.IdMaximum

	@classmethod
	def _separator(self, values):
		return self.separator(values, color = self._colorSeparator(), bold = False)

	@classmethod
	def _highlight(self, value):
		return interface.Format.fontColor(str(value), self._colorHighlight())

	@classmethod
	def separator(self, items = None, bold = True, color = None):
		separator = interface.Format.iconSeparator(pad = '  ')
		if bold:
			separator = interface.Format.font(separator, bold = True, translate = False)
		if color:
			if color == True: color = self._colorDiffuse()
			separator = interface.Format.font(separator, color = color, translate = False)
		if items: return separator.join([i for i in items if not i is None and not i == ''])
		else: return separator

	@classmethod
	def focus(self, control = IdListControl, sleep = True):
		try:
			if tools.Tools.isInteger(control): result = self._instance().mWindow.setFocusId(control)
			else: result = self._instance().mWindow.setFocus(control)
			if sleep: tools.Time.sleep(0.01) # Otherwise the control is not yet focused when later code requires the focus somehow (eg: opening the context menu).
			return result
		except: pass

	@classmethod
	def itemClear(self, control = IdListControl):
		try: return self._instance().control(control).reset()
		except: pass

	@classmethod
	def itemAdd(self, item, context = None, control = IdListControl):
		try:
			instance = self._instance()
			if tools.Tools.isArray(item):
				instance.mContexts.extend(context)
				return instance.control(control).addItems(item)
			else:
				instance.mContexts.append(context)
				return instance.control(control).addItem(item)
		except: pass

	@classmethod
	def itemSelect(self, index, control = IdListControl):
		try: return self._instance().control(control).selectItem(index)
		except: pass

	@classmethod
	def itemSelected(self, control = IdListControl, index = True):
		if index:
			try: return self._instance().control(control).getSelectedPosition()
			except: pass
		else:
			try: return self._instance().control(control).getSelectedItem()
			except: pass

	@classmethod
	def property(self, property, id = None):
		try:
			if id is None: return self._instance().mWindow.getProperty(property)
			else: return xbmcgui.Window(id).getProperty(property)
		except: pass

	@classmethod
	def propertyClear(self, property, id = None):
		try:
			if id is None: return self._instance().mWindow.clearProperty(property)
			else: return xbmcgui.Window(id).clearProperty(property)
		except: pass

	@classmethod
	def propertySet(self, property, value, id = None):
		try:
			if tools.Tools.isStructure(value):
				value = tools.Converter.jsonTo(value)
			else:
				if value is None: value = ''
				elif tools.Tools.isBoolean(value): value = int(value)
				value = str(value)
			if id is None: return self._instance().mWindow.setProperty(property, value)
			else: return xbmcgui.Window(id).setProperty(property, value)
		except: pass

	@classmethod
	def propertyGlobal(self, property):
		return self.property(property = property, id = Window.IdWindowHome)

	@classmethod
	def propertyGlobalClear(self, property):
		return self.propertyClear(property = property, id = Window.IdWindowHome)

	@classmethod
	def propertyGlobalSet(self, property, value):
		return self.propertySet(property = property, value = value, id = Window.IdWindowHome)

	def control(self, id):
		try: return self.mWindow.getControl(id)
		except: return None

	def _window(self):
		return self.mWindow

	@classmethod
	def _theme(self):
		theme = Theme.skin()
		theme = theme.replace(' ', '').lower()
		index = theme.find('(')
		if index >= 0: theme = theme[:index]
		return theme

	@classmethod
	def _pathTemplate(self):
		return tools.File.joinPath(tools.System.pathResources(), 'resources', 'skins', 'default', '720p')

	@classmethod
	def _pathWindow(self, kodi = False):
		path = tools.File.joinPath(tools.System.profile(), 'Windows')
		if kodi: path = tools.File.joinPath(path, 'resources', 'skins', 'default', '720p')
		return path

	@classmethod
	def _pathInterface(self):
		return tools.File.joinPath(tools.System.pathResources(), 'resources', 'media', 'interface')

	@classmethod
	def _pathSkin(self):
		theme = self._theme()
		addon = tools.System.pathResources() if theme == 'default' or 'gaia1' in theme else tools.System.pathSkins()
		return tools.File.joinPath(addon, 'resources', 'media', 'skins', theme)

	@classmethod
	def _pathImage(self, image, interface = True):
		if not '.' in image: image += '.png'
		path = tools.File.joinPath(self._pathSkin(), 'interface' if interface else '', image)
		if not tools.File.exists(path): path = tools.File.joinPath(self._pathInterface(), image)
		return path

	def _pathIcon(self, icon, quality = None):
		if not '.' in icon: icon += '.png'
		return interface.Icon.path(icon, type = interface.Icon.themeIcon(), quality = quality)

	def _pathLogo(self, size = SizeLarge):
		return tools.File.joinPath(tools.System.pathResources(), 'resources', 'media', 'logo', size)

	@classmethod
	def _background(self, type = None, path = None):
		result = []
		if type == Window.BackgroundFanart or type == Window.BackgroundCombined:
			result.append({'path' : path if path else self._pathImage('background.jpg', interface = False), 'color' : Window.BackgroundColorOpaque})
		elif type == Window.BackgroundSkin :
			result.append({'path' : self._pathImage('background.jpg', interface = False), 'color' : Window.BackgroundColorOpaque})
		if type == Window.BackgroundCombined:
			result.append({'path' : self._pathImage('background.jpg', interface = False), 'color' : Window.BackgroundColor1})
		else:
			result.append({'path' : self._pathImage('pixel.png'), 'color' : Window.BackgroundColor2})
		return result

	def _scaleWidth(self, value):
		return int(self.mScaleWidth * value)

	def _scaleHeight(self, value):
		return int(self.mScaleHeight * value)

	def _centerX(self, width):
		return int((self.mWidth - width) / 2.0)

	def _centerY(self, height):
		return int((self.mHeight - height) / 2.0)

	def _offsetX(self):
		return self.mDimensionX + self.mDimensionWidth

	def _offsetY(self):
		return self.mDimensionY + self.mDimensionHeight

	def _dimensionSeparator(self, width = None):
		if width is None: width = Window.SeparatorLineWidth
		elif width is True: width = Window.SeparatorLineWide
		return [width, Window.SeparatorLineHeight + Window.SeparatorLinePadding]

	def _dimensionButton(self, text = None, icon = None):
		return [(len(self._buttonText(text = text, icon = icon)) * 14) if text else self._scaleWidth(250), self._scaleHeight(50)]

	def _buttonText(self, text, icon = None):
		text = interface.Translation.string(text)
		if not icon is None: text = '       ' + text
		return text

	def _remove(self, controls = None, force = False):
		try:
			if controls is None:
				result = []
				remove = []
				for control in self.mControls[::-1]: # Iterate reverse, because there is a delay.
					if force or not control['fixed']: control['control'].setVisible(False)
				for control in self.mControls[::-1]: # Iterate reverse, because there is a delay.
					if not force and control['fixed']: result.append(control)
					else: remove.append(control['control'])
				self.mWindow.removeControls(remove)
				for control in remove: del control

				# Calling "del" on the controls above only reduces the reference counter, but does not delete it if there are still other refrences.
				# This causes Kodi to show error messages: "... has left several classes in memory that we couldn't clean up".
				# Remove to individual instance member variables (eg: mStatusControl), dictionaries (eg: mLabels), and lists (eg: mProgressInner).
				for i in range(len(self.mLabels)):
					if self.mLabels[i]['control'] in remove:
						self.mLabels[i]['control'] = None
				for name in vars(self).keys():
					variable = self.__dict__[name]
					if tools.Tools.isDictionary(variable):
						for key, value in variable.items():
							if value in remove:
								variable[key] = None
					elif tools.Tools.isArray(variable):

						for i in range(len(variable)):
							if variable[i] in remove:
								variable[i] = None
					elif variable in remove:
						self.__dict__[name] = None

				self.mControls = result
			else:
				if tools.Tools.isArray(controls): self.mWindow.removeControls(controls)
				else: self.mWindow.removeControl(controls)
				for control in controls: del control
		except:
			pass

	def _add(self, control, fixed = False, visible = True, animation = None, lock = False, initialize = False):
		# Adding controls individually to the window is slow, especially the progress bar icons.
		# Instead of adding each control individually, we queue them and add them all at once in _initializeControls() using window.addControls(...) which is a lot faster.
		# We also do not need locking here, which would also makes things slower, sincee append/extend on lists is thread safe.

		if lock: self._lock()
		if tools.Tools.isArray(control):
			self.mControls.extend([{
				'control' : c,
				'fixed' : fixed,
				'initialized' : initialize,
				'visible' : visible,
				'animation' : animation,
			} for c in control])
			if initialize: self.mWindow.addControls(control)
		else:
			self.mControls.append({
				'control' : control,
				'fixed' : fixed,
				'initialized' : initialize,
				'visible' : visible,
				'animation' : animation,
			})
			if initialize: self.mWindow.addControl(control)
		if lock: self._unlock()
		return control

	def _get(self, control):
		try: control = control[0].getId()
		except:
			try: control = control.getId()
			except: pass

		for i in self.mControls:
			if i['control'].getId() == control:
				return i

		return None

	def _components(self, control, components):
		for i in self.mControls:
			if i['control'] == control:
				i['components'] = components
				break

	@classmethod
	def _visible(self, control):
		if tools.Tools.isArray(control):
			for i in control:
				try:
					if i.isVisible(): return True
				except: pass
		else:
			if control.isVisible(): return True
		return False

	@classmethod
	def _visibleSet(self, control, visible = True):
		if tools.Tools.isDictionary(control):
			for i in control.items():
				self._visibleSet(control = i, visible = visible)
		elif tools.Tools.isArray(control):
			for i in control:
				self._visibleSet(control = i, visible = visible)
		else:
			try: control.setVisible(visible)
			except: pass

	def _addImage(self, path, x, y, width, height, ratio = RatioDefault, color = None, fixed = False, visible = True, animation = None):
		image = xbmcgui.ControlImage(x, y, width, height, path, ratio)
		if color: image.setColorDiffuse(color)
		self._add(control = image, fixed = fixed, visible = visible, animation = animation)
		return image

	def _addBackground(self, type = BackgroundCombined, path = None, fixed = False):
		images = self._background(type = type, path = path)
		ratio = Window.RatioDefault if self.mWidth == Window.SizeWidth and self.mHeight == Window.SizeHeight else Window.RatioScaleUp
		for image in images:
			self._addImage(path = image['path'], color = image['color'], x = 0, y = 0, width = self.mWidth, height = self.mHeight, ratio = ratio, fixed = fixed)

	def _addCurtains(self):
		if tools.Settings.getInteger('interface.scrape.interface') == 3 and tools.Settings.getBoolean('interface.scrape.interface.curtains'):
			path = tools.File.joinPath(tools.System.pathResources(), 'resources', 'media', 'cinema', 'curtains.png')
			return self._addImage(path = path, x = 0, y = 0, width = self.mWidth, height = self.mHeight)
		return None

	def _addButton(self, text, x, y, width = None, height = None, callback = None, icon = None, select = SelectNone, bold = True, uppercase = True, alignment = AlignmentCenter, size = None, visible = True):
		dimension = self._dimensionButton(text = text, icon = icon)
		if width is None: width = dimension[0]
		if height is None: height = dimension[1]

		if size is None: size = interface.Skin.fontLarge()

		text = self._buttonText(text = text, icon = icon)
		if alignment in [Window.AlignmentLeftCenter, Window.AlignmentLeft]: text = '  ' + text

		components = {}
		pathNormal = self._pathImage('buttonnormal')
		pathFocus = self._pathImage('buttonfocus')
		control = self._add(xbmcgui.ControlButton(x, y, width, height, interface.Format.font(text, bold = bold, uppercase = uppercase), focusTexture = pathFocus, noFocusTexture = pathNormal, alignment = alignment, textColor = Window._colorDefault(), font = size), visible = visible)

		if not icon is None:
			sizeIcon = int(height * 0.8)
			iconX = int(x + (width * 0.1))
			iconY = int(y + ((height - sizeIcon) / 2.0))
			controlIcon = self._addImage(path = self._pathIcon(icon = icon, quality = interface.Icon.QualityMini), x = iconX, y = iconY, width = sizeIcon, height = sizeIcon, visible = visible)
			components['icon'] = controlIcon
		else:
			controlIcon = None

		if not select is Window.SelectNone:
			sizeIcon = int(height * 0.6)
			iconX = int(x - (sizeIcon / 3))
			iconY = int(y - (sizeIcon / 3))
			controlSelect = self._addImage(path = self._pathImage('buttonselect' if select == Window.SelectYes else 'buttonunselect' if select == Window.SelectNo else ''), x = iconX, y = iconY, width = sizeIcon, height = sizeIcon, visible = visible)
			components['select'] = controlSelect
		else:
			controlSelect = None

		if components: self._components(control = control, components = components)

		if callback:
			def wrapper(control):
				try: callback(control = self._get(control = control))
				except: callback()
			self.mWindow._onControl(x, y, wrapper)

		return [control, controlIcon, controlSelect]

	def _setButton(self, control, text = None, icon = None, bold = True, uppercase = True, size = None):
		if text:
			if size is None: size = interface.Skin.fontLarge()
			control[0].setLabel(interface.Format.font(self._buttonText(text = text, icon = icon), bold = bold, uppercase = uppercase), font = size)
			dimension = self._dimensionButton(text = text, icon = icon)
			control[0].setWidth(dimension[0])
		if icon:
			control[1].setImage(self._pathIcon(icon = icon, quality = interface.Icon.QualityMini))

	def _selectButton(self, control, select = SelectYes):
		if tools.Tools.isArray(control): control = control[2]
		control.setImage(self._pathImage('buttonselect' if select == Window.SelectYes else 'buttonunselect' if select == Window.SelectNo else ''))

	def _addSeparator(self, x = None, y = None, width = None, control = False):
		dimension = self._dimensionSeparator(width = width)
		height = self._scaleHeight(Window.SeparatorLineHeight)
		if x is None: x = self._centerX(dimension[0])
		if y is None: y = self._offsetY() + int((dimension[1] - height) / 2.0)
		image = self._addImage(self._pathImage('separator'), x = x, y = y, width = dimension[0], height = height)
		if control: return (image, dimension)
		else: return dimension

	def _addLabel(self, text, x, y, width, height, color = None, size = None, alignment = AlignmentLeft, bold = False, italic = False, light = False, uppercase = False, lowercase = False, capitalcase = False, animation = None):
		# NB: Fix suggested by NG.
		# Sometimes when the special window is closed, the text of the lables remain afterwards. The text is then shown in various places of the current Kodi native window and remain there until Kodi is restarted.
		# Create the label control, but only set the label text AFTER the window has been created.
		if color is None: color = self._colorDefault()
		if size is None: size = interface.Skin.fontDefault()
		control = self._add(xbmcgui.ControlLabel(x, y, width, height, '', font = size, textColor = color, alignment = alignment), animation = animation)
		self.mLabels.append({'control' : control, 'text' : text, 'color' : color, 'size' : size, 'bold' : bold, 'italic' : italic, 'light' : light, 'uppercase' : uppercase, 'lowercase' : lowercase, 'capitalcase' : capitalcase})
		return control

	def _setLabel(self, control, text, color = None, size = None, bold = False, italic = False, light = False, uppercase = False, lowercase = False, capitalcase = False, translate = False):
		if color is None: color = self._colorDefault()
		if size is None: size = interface.Skin.fontDefault()
		control.setLabel(interface.Format.font(text, bold = bold, italic = italic, light = light, uppercase = uppercase, lowercase = lowercase, capitalcase = capitalcase, translate = translate), font = size, textColor = color)

class WindowCinema(Window):

	LogoWidth = 300
	LogoHeight = 218

	def __init__(self, backgroundType, backgroundPath):
		super(WindowCinema, self).__init__(backgroundType = backgroundType, backgroundPath = backgroundPath)

	@classmethod
	def show(self, background = None, wait = False, initialize = True, close = False):
		return super(WindowCinema, self)._show(backgroundType = tools.Settings.getInteger('interface.scrape.interface.background'), backgroundPath = background, wait = wait, initialize = initialize, close = close)

	def _initializeStart1(self):
		super(WindowCinema, self)._initializeStart1()

	def _initializeStart2(self):
		super(WindowCinema, self)._initializeStart2()
		self._addCurtains()
		if tools.Settings.getInteger('interface.scrape.interface.loader') == 2: self._addLogo()

	def _addLogo(self):
		width = self._scaleWidth(WindowCinema.LogoWidth)
		height = self._scaleHeight(WindowCinema.LogoHeight)
		path = tools.File.joinPath(tools.System.pathResources(), 'resources', 'media', 'cinema', 'logo.png')
		self._addImage(path = path, x = self._centerX(width), y = self._centerY(height), width = width, height = height)

class WindowProgress(Window):

	# Logo
	LogoNone = None
	LogoIcon = 'icon'
	LogoName = 'name'

	LogoIconWidth = 128
	LogoIconHeight = 128
	LogoNameWidth = 197
	LogoNameHeight = 100
	LogoOffsetY = 0.24

	ProgressPercentage = 'GaiaProgressPercentage'
	ProgressFinished = 'GaiaProgressFinished'
	ProgressCount = 10
	ProgressSize = 24
	ProgressPaddingX = 8
	ProgressPaddingY = 20
	ProgressInterval = 1

	def __init__(self, backgroundType, backgroundPath, logo = None, status = None, statusUpper = True, xml = None, xmlScale = False, xmlType = Window.TypeDefault, width = None, height = None):
		super(WindowProgress, self).__init__(backgroundType = backgroundType, backgroundPath = backgroundPath, xml = xml, xmlScale = xmlScale, xmlType = xmlType, width = width, height = height)

		self.mLogo = logo

		self.mProgress = 0
		self.mProgressFinished = False
		self.mProgressInner = []
		self.mProgressOuter = []
		self.mProgressFill = []
		self.mProgressUpdate = None
		self.mProgressPrevious = [None, None, None]
		self.mProgressColors = interface.Format.colorGradient(self._colorProgressEmpty(), self._colorProgressFull(), int(100 / WindowProgress.ProgressCount))
		self.propertySet(WindowProgress.ProgressPercentage, self.mProgress)
		self.propertySet(WindowProgress.ProgressFinished, False)

		self.mStatus = status
		self.mStatusUpper = statusUpper
		self.mStatusControl = None

	# For some reason WindowIntro throws the following error on destrucution:
	#	ERROR: Exception
	#	ERROR: TypeError
	#	ERROR: :
	#	ERROR: "'NoneType' object is not callable"
	#	ERROR:  in
	#	ERROR: <bound method WindowIntro.__del__ of <lib.modules.window.WindowIntro object at 0x7f2c3861add0>>
	#	ERROR:  ignored
	# If the desctructors are removed, this error disappears.
	# Since the desctructors don't do anything but call the pareent desctructor, this should not be a problem.
	# All desctructors of other Window classes were aslo removed.
	#def __del__(self):
	#	super(WindowProgress, self).__del__()

	def _initializeStart1(self, progress = True, status = True):
		super(WindowProgress, self)._initializeStart1()

		self.mDimensionWidth = 0
		self.mDimensionHeight = 0

		if self.mLogo: self._dimensionUpdate(self._dimensionLogo(self.mLogo))
		if progress: self._dimensionUpdate(self._dimensionProgress())
		if status and not self.mStatus is False and not self.mStatus is None:
			self._dimensionUpdate(self._dimensionSpace())
			self._dimensionUpdate(self._dimensionLine())
			self._dimensionUpdate(self._dimensionSpace())

	def _initializeStart2(self, progress = True, status = True):
		super(WindowProgress, self)._initializeStart2()

		if self.mLogo: self.mDimensionHeight += self._offsetLogo(self._dimensionLogo(self.mLogo)[1])

		self.mDimensionX = self._centerX(self.mDimensionWidth)
		self.mDimensionY = self._centerY(self.mDimensionHeight)

		self.mDimensionWidth = 0
		self.mDimensionHeight = 0
		if self.mLogo: self._dimensionUpdate(self._addLogo(self.mLogo))
		if progress: self._dimensionUpdate(self._addProgress())
		if status and not self.mStatus is False and not self.mStatus is None:
			self._dimensionUpdate(self._dimensionSpace())
			self._dimensionUpdate(self._addStatus())
			self._dimensionUpdate(self._dimensionSpace())

	@classmethod
	def show(self, backgroundType = None, backgroundPath = None, logo = LogoIcon, status = None, wait = False, initialize = True, close = False, retry = False, **kwargs):
		if tools.Tools.isInteger(wait):
			thread = Pool.thread(target = self._refresh, args = (wait,))
			thread.start()
			wait = True
		return super(WindowProgress, self)._show(backgroundType = backgroundType, backgroundPath = backgroundPath, logo = logo, status = status, wait = wait, initialize = initialize, close = close, retry = retry, **kwargs)

	@classmethod
	def _refresh(self, duration):
		steps = int(duration / WindowProgress.ProgressInterval)

		for i in range(steps):
			if self.visible(): break
			tools.Time.sleep(WindowProgress.ProgressInterval)

		progress = 0
		increase = 100 / steps
		for i in range(steps):
			if not self.visible(): break
			progress += increase
			self.update(progress = progress)
			tools.Time.sleep(WindowProgress.ProgressInterval)

		self.close()

	@classmethod
	def update(self, progress = None, finished = None, status = None):
		instance = self._instance()
		if not instance or not instance.visible(): return None

		current = (progress, finished, status)

		# Updating the visible GUI is an expensive task, probably due to Kodi's GUI lock.
		# Try to update the progress as seldom as possible, to reduce overhead.
		# Also update the progress in a thread, to not make it block the actual tasks we keep track of.
		# Add progress update values to a queue and only pick the last value in the thread.
		# This reduces the number of times the GUI is updated, if multiple updaates come in while the thread is still busy with a previous update.
		if not progress is None:
			if progress < 1: progress *= 100
			progress = int(progress)

			# NB: Do not update the progress too often.
			# In some situations the progress increment can be fractionally small, causing the progress bar to update too often.
			# Eg: 2000 streams have been found, and now the progress is incremented by 0.05, each time calling the WindowProgress.update() function.
			# The actions below are processing-intensive (eg: setColorDiffuse) which can take very long when called 2000 times.
			if instance.mProgressPrevious[0] == progress: progress = None

			# Reduce even further. Only update the semi-opaque progress block every 5% instead of every 1%.
			# Only do this if the new progress is less than 5% from the previous progress, otherwise huge progress jumps are not immediatly shown.
			elif not progress % 5 == 0 and (instance.mProgressPrevious[0] is None or (progress - instance.mProgressPrevious[0]) < 5): progress = None

		if not status is None and instance.mProgressPrevious[2] == status:
			status = None

		instance.mProgressPrevious = current

		if not progress is None or not finished is None or not status is None:
			instance.mProgressUpdate = (progress, finished, status)
			if not instance._locked():
				thread = Pool.thread(target = instance._update)
				thread.start()

		return instance

	def _update(self):
		self._lock()

		while self.mProgressUpdate:
			if not self.visible() or self.mProgressFinished: break # Closed.

			progress, finished, status = self.mProgressUpdate
			self.mProgressUpdate = None
			if finished is True: progress = 100

			self._progressUpdate(progressNew = progress, progressCurrent = self.mProgress, controlFill = self.mProgressFill, controlIcon = self.mProgressInner)

			if not finished is None:
				self.mProgressFinished = finished
				self.propertySet(WindowProgress.ProgressFinished, finished)

			if not status is None:
				self.mStatus = status
				self._setLabel(control = self.mStatusControl, text = interface.Format.fontColor(self.mStatus, self._colorHighlight()), size = interface.Skin.fontLarge(), bold = True, uppercase = self.mStatusUpper)

		self._unlock()

	@classmethod
	def _colorProgressEmpty(self):
		return interface.Format.colorSecondary()

	@classmethod
	def _colorProgressFull(self):
		return interface.Format.colorPrimary()

	def _logoSize(self, dimension):
		width = dimension[0]
		height = dimension[1]
		# Use < and not <=. If the logo is 128px, it will use the 256px image.
		# Due to dynamic resizing, the image with the actual size looks poor, rather use the larger image.
		if width < 64 and height < 64: return Window.SizeMini
		elif width < 128 and height < 128: return Window.SizeSmall
		elif width < 256 and height < 256: return Window.SizeMedium
		else: return Window.SizeLarge

	def _logoName(self, force = False, dimension = None):
		theme = self._theme()
		size = self._logoSize(dimension)
		return tools.File.joinPath(self._pathLogo(size), 'namecolor.png' if force or theme == 'default' or 'gaia' in theme  else 'nameglass.png')

	def _logoIcon(self, force = False, dimension = None):
		theme = self._theme()
		size = self._logoSize(dimension)
		return tools.File.joinPath(self._pathLogo(size), 'iconcolor.png' if force or theme == 'default' or 'gaia' in theme else 'iconglass.png')

	def _progress(self, progress):
		return int(tools.Math.roundDown(progress / float(WindowProgress.ProgressCount)))

	def _progressSub(self, progress):
		return int(progress % float(WindowProgress.ProgressCount))

	def _progressUpdate(self, progressNew, progressCurrent, controlFill, controlIcon):
		if not progressNew is None:
			reduced = progressNew < progressCurrent
			progress = self._progress(progressNew)

			# setColorDiffuse is an expensive task. Only set if not set before.
			# Probably due to GUI locks that Kodi uses for updating items in the visible GUI.
			try:
				for i in range(progress):
					if not controlFill[i] is True:
						controlFill[i] = True
						controlIcon[i].setColorDiffuse(self._colorProgressFull())
				try:
					controlFill[i] = None
					controlIcon[progress].setColorDiffuse(self.mProgressColors[self._progressSub(progress)])
				except: pass
				if reduced:
					for i in range(progress, WindowProgress.ProgressCount):
						if not controlFill[i] is False:
							controlFill[i] = False
							controlIcon[i].setColorDiffuse(self._colorProgressEmpty())
			except:
				# Sometimes the icons are None and setColorDiffuse() fails.
				tools.Logger.error()

	def _progressClear(self, controlFill, controlIcon):
		self._progressUpdate(progressNew = -1, progressCurrent = 0, controlFill = controlFill, controlIcon = controlIcon)

	def _offsetLogo(self, y):
		return int(y * WindowProgress.LogoOffsetY)

	def _dimensionUpdate(self, size):
		self.mDimensionWidth = max(self.mDimensionWidth, size[0])
		self.mDimensionHeight += size[1]

	def _dimensionLine(self):
		return [self._scaleWidth(1200), self._scaleHeight(30)]

	def _dimensionSpace(self):
		return [1, self._scaleHeight(10)]

	def _dimensionLogo(self, logo):
		if logo == WindowProgress.LogoIcon: return [self._scaleWidth(WindowProgress.LogoIconWidth), self._scaleHeight(WindowProgress.LogoIconHeight)]
		elif logo == WindowProgress.LogoName: return [self._scaleWidth(WindowProgress.LogoNameWidth), self._scaleHeight(WindowProgress.LogoNameHeight)]
		else: return [0, 0]

	def _dimensionProgress(self):
		width = (WindowProgress.ProgressCount * self._scaleWidth(WindowProgress.ProgressSize)) + ((WindowProgress.ProgressCount - 1) * self._scaleWidth(WindowProgress.ProgressPaddingX))
		height = self._scaleHeight(WindowProgress.ProgressSize + (0 if self.mStatus is False or self.mStatus is None else WindowProgress.ProgressPaddingY))
		return [width, height]

	def _addLogo(self, logo):
		dimension = self._dimensionLogo(logo)
		if logo == WindowProgress.LogoIcon: path = self._logoIcon(force = True, dimension = dimension)
		elif logo == WindowProgress.LogoName: path = self._logoName(force = True, dimension = dimension)
		self._addImage(path = path, x = self._centerX(dimension[0]), y = self._offsetY(), width = dimension[0], height = dimension[1])
		if logo == WindowProgress.LogoName: dimension[1] += self._offsetLogo(dimension[1]) # Add padding below.
		return dimension

	def _addProgress(self, animation = None):
		dimension, self.mProgressInner, self.mProgressOuter, self.mProgressFill = self._addProgressBar(animation = animation)
		return dimension

	def _addProgressBar(self, x = None, y = None, animation = None):
		pathInner = self._pathImage('progressinner')
		pathOuter = self._pathImage('progressouter')
		padding = self._scaleWidth(WindowProgress.ProgressPaddingX)
		dimension = self._dimensionProgress()
		width = self._scaleWidth(WindowProgress.ProgressSize)
		height = self._scaleHeight(WindowProgress.ProgressSize)
		if x is None: x = self._centerX(dimension[0])
		if y is None: y = self._offsetY()

		inner = [None] * WindowProgress.ProgressCount
		outer = [None] * WindowProgress.ProgressCount
		fill = [False] * WindowProgress.ProgressCount
		for i in range(WindowProgress.ProgressCount):
			self._addProgressIcon(inner = inner, outer = outer, index = i, pathInner = pathInner, pathOuter = pathOuter, x = x, y = y, width = width, height = height, animation = animation)
			x += width + padding

		return dimension, inner, outer, fill

	def _addProgressIcon(self, inner, outer, index, pathInner, pathOuter, x, y, width, height, animation = None):
		inner[index] = self._addImage(path = pathInner, x = x, y = y, width = width, height = height, color = self._colorProgressEmpty(), animation = animation)
		outer[index] = self._addImage(path = pathOuter, x = x, y = y, width = width, height = height, animation = animation)

	def _addLine(self, text = '', color = None, size = None, alignment = Window.AlignmentCenter, bold = True, uppercase = True, animation = None, dimension = None):
		if color is None: color = self._colorDefault()
		if size is None: size = interface.Skin.fontLarge()
		if dimension is None: dimension = self._dimensionLine()
		control = self._addLabel(text = text, x = self._centerX(dimension[0]), y = self._offsetY(), width = dimension[0], height = dimension[1], color = color, size = size, alignment = alignment, bold = bold, uppercase = uppercase, animation = animation)
		return control, dimension

	def _addStatus(self, text = None, animation = None):
		if text is None: text = self.mStatus
		if tools.Tools.isBoolean(text): text = ''
		self.mStatusControl, dimension = self._addLine(text = text, color = self._colorHighlight(), animation = animation, uppercase = self.mStatusUpper)
		return dimension


class WindowIntro(WindowProgress):

	Parts = 7

	TimeAnimation = 1000
	TimeDelay = 200

	LogoWidth = 700
	LogoHeight = 303

	AnimationType = 'WindowOpen'
	AnimationValues = 'effect=fade start=0 end=100 time=%d delay=%d'

	def __init__(self, backgroundType, backgroundPath, progress = False, status = True):
		super(WindowIntro, self).__init__(backgroundType = backgroundType, backgroundPath = backgroundPath, status = status)
		self.mTime = tools.Time.timestamp()
		self.mProgressEnabled = progress

	def _initializeStart1(self):
		super(WindowIntro, self)._initializeStart1(progress = False, status = False)
		self._dimensionUpdate(self._dimensionLogo())
		if self.mProgressEnabled:
			self._dimensionUpdate(self._dimensionSpace())
			self._dimensionUpdate(self._dimensionSpace())
			self._dimensionUpdate(self._dimensionProgress())
		if not self.mStatus is False and not self.mStatus is None:
			self._dimensionUpdate(self._dimensionLine())
			self._dimensionUpdate(self._dimensionSpace())

	def _initializeStart2(self):
		super(WindowIntro, self)._initializeStart2(progress = False, status = False)
		self._dimensionUpdate(self._addLogo())
		delay = (WindowIntro.Parts - 1) * WindowIntro.TimeDelay
		if self.mProgressEnabled:
			self._dimensionUpdate(self._dimensionSpace())
			self._dimensionUpdate(self._dimensionSpace())
			self._dimensionUpdate(self._addProgress(animation = self._animation(delay = delay)))
		if not self.mStatus is False and not self.mStatus is None:
			self._dimensionUpdate(self._addStatus(animation = self._animation(delay = delay)))
			self._dimensionUpdate(self._dimensionSpace())

	def _initializeEnd1(self):
		super(WindowIntro, self)._initializeEnd1()
		if not self.mProgressEnabled: self.close(wait = True)

	@classmethod
	def show(self, status = True, wait = False, initialize = True, close = False, progress = True):
		return super(WindowIntro, self)._show(backgroundType = self.BackgroundCombined, backgroundPath = None, status = status, wait = wait, initialize = initialize, close = close, progress = progress)

	@classmethod
	def close(self, id = None, loader = True, wait = False):
		if wait:
			start = self.instance().mTime
			total = ((2 * WindowIntro.TimeAnimation) + ((WindowIntro.Parts + 1) * WindowIntro.TimeDelay)) / 1000.0
			current = tools.Time.timestamp()
			while current - start < total:
				tools.Time.sleep(0.5)
				current += 0.5
		return super(WindowIntro, self).close(id = id, loader = loader)

	@classmethod
	def duration(self, seconds = True):
		result = WindowIntro.TimeAnimation + WindowIntro.TimeDelay
		if seconds: result = result / 1000.0
		return result

	@classmethod
	def _animation(self, duration = None, delay = None):
		return [(WindowIntro.AnimationType, WindowIntro.AnimationValues % (duration if duration else WindowIntro.TimeAnimation, delay if delay else WindowIntro.TimeDelay))]

	def _logoPath(self, part):
		return tools.File.joinPath(tools.System.pathResources(), 'resources', 'media', 'logo', 'splash', 'gaia%d.png' % part)

	def _dimensionLogo(self):
		return [self._scaleWidth(WindowIntro.LogoWidth), self._scaleHeight(WindowIntro.LogoHeight)]

	def _addLogo(self):
		dimension = self._dimensionLogo()
		width = dimension[0]
		height = dimension[1]
		x = self._centerX(width)
		y = self._offsetY()

		delay = WindowIntro.TimeDelay
		for i in range(1, WindowIntro.Parts + 1):
			logo = self._addImage(path = self._logoPath(i), x = x, y = y, width = width, height = height, animation = self._animation(delay = delay))
			if i < WindowIntro.Parts - 1: delay += WindowIntro.TimeDelay

		return dimension


class WindowAttribution(WindowProgress):

	Duration = 10

	def __init__(self, backgroundType, backgroundPath, status, progress, logo = None, width = None, height = None, inverse = False):
		super(WindowAttribution, self).__init__(backgroundType = backgroundType, backgroundPath = backgroundPath, status = status, logo = logo, width = width, height = height)

		self.mTime = tools.Time.timestamp()
		self.mProgressEnabled = progress

		self.mControlRow = -1
		self.mControlIndex = -1
		self.mControlButtons = [[], [], []]

		self._onAction(WindowBase.ActionPreviousMenu, self.close)
		self._onAction(WindowBase.ActionNavigationBack, self.close)
		self._onAction(WindowBase.ActionBackSpace, self.close)
		self._onAction(WindowBase.ActionMoveLeft, self._actionFocus)
		self._onAction(WindowBase.ActionMoveRight, self._actionFocus)
		self._onAction(WindowBase.ActionMoveUp, self._actionFocus)
		self._onAction(WindowBase.ActionMoveDown, self._actionFocus)
		self._onAction(WindowBase.ActionItemNext, lambda: self._actionFocus(action = WindowBase.ActionMoveRight))
		self._onAction(WindowBase.ActionItemPrevious, lambda: self._actionFocus(action = WindowBase.ActionMoveLeft))

	def _initializeStart1(self):
		super(WindowAttribution, self)._initializeStart1(progress = False, status = False)
		if self.mProgressEnabled:
			self._dimensionUpdate(self._dimensionProgress())
		else:
			self._dimensionUpdate(self._dimensionSpace())
			self._dimensionUpdate(self._dimensionButton())
			self._dimensionUpdate(self._dimensionSpace())
			self._dimensionUpdate(self._dimensionSpace())
		if not self.mStatus is False and not self.mStatus is None:
			self._dimensionUpdate(self._dimensionDescription())
			self._dimensionUpdate(self._dimensionSpace())
		self._dimensionUpdate(self._dimensionProviderLine())
		self._dimensionUpdate(self._dimensionProviderLine())

	def _initializeStart2(self):
		super(WindowAttribution, self)._initializeStart2(progress = False, status = False)
		if self.mProgressEnabled:
			self._dimensionUpdate(self._addProgress())
		else:
			self._dimensionUpdate(self._dimensionSpace())
			self._dimensionUpdate(self._addClose())
			self._dimensionUpdate(self._dimensionSpace())
			self._dimensionUpdate(self._dimensionSpace())
		if not self.mStatus is False and not self.mStatus is None:
			self._dimensionUpdate(self._addDescription())
			self._dimensionUpdate(self._dimensionSpace())
		self._addProvider(id = 'tvdb', row = 1, offset = 0, link = 'thetvdb.com')
		self._addProvider(id = 'tmdb', row = 1, offset = 1, link = 'themoviedb.org')
		self._addProvider(id = 'imdb', row = 1, offset = 2, link = 'imdb.com')
		self._dimensionUpdate(self._dimensionProviderLine())
		self._addProvider(id = 'trakt', row = 2, offset = 0, link = 'trakt.tv')
		self._addProvider(id = 'fanart', row = 2, offset = 1, link = 'fanart.tv')
		self._addProvider(id = 'opensubtitles', row = 2, offset = 2, link = 'opensubtitles.org')
		self._dimensionUpdate(self._dimensionProviderLine())

	@classmethod
	def show(self, status = True, initialize = True, close = False, progress = True):
		return super(WindowAttribution, self).show(backgroundType = self.BackgroundCombined, backgroundPath = None, status = status, logo = self.LogoName, wait = WindowAttribution.Duration if progress else False, initialize = initialize, close = close, progress = progress)

	@classmethod
	def close(self, id = None, loader = True):
		return super(WindowAttribution, self).close(id = id, loader = loader)

	@classmethod
	def _visit(self, link):
		tools.System.openLink(link = link)

	def _actionFocus(self, action = None):
		rowBefore = self.mControlRow

		if self.mControlRow < 0: self.mControlRow = 0
		elif action == WindowBase.ActionMoveUp: self.mControlRow -= 1
		elif action == WindowBase.ActionMoveDown: self.mControlRow += 1
		count = len(self.mControlButtons) - 1
		if self.mControlRow > count: self.mControlRow = 0
		elif self.mControlRow < 0: self.mControlRow = count

		if self.mControlIndex < 0: self.mControlIndex = 0
		elif action == WindowBase.ActionMoveLeft: self.mControlIndex -= 1
		elif action == WindowBase.ActionMoveRight: self.mControlIndex += 1
		count = len(self.mControlButtons[self.mControlRow]) - 1
		if self.mControlIndex > count: self.mControlIndex = 0
		elif self.mControlIndex < 0: self.mControlIndex = count

		# Move to center button.
		if rowBefore == 0 and self.mControlIndex == 0: self.mControlIndex = 1

		self.focus(self.mControlButtons[self.mControlRow][self.mControlIndex])

	def _logoPath(self, id = None):
		path = tools.File.joinPath(tools.System.pathResources(), 'resources', 'media')
		if id: return tools.File.joinPath(path, 'attribution', id + '.png')
		else: return tools.File.joinPath(path, 'logo', 'small', 'namecolor.png')

	def _dimensionDescription(self):
		return [self._scaleWidth(1000), self._scaleHeight(60)]

	def _dimensionProviderLine(self):
		return [self._scaleWidth(650), self._scaleHeight(210)]

	def _dimensionProviderBox(self):
		return [self._scaleWidth(150), self._scaleHeight(150)]

	def _dimensionProviderLink(self):
		return [self._scaleWidth(150), self._scaleHeight(30)]

	def _dimensionProviderLogo(self):
		return [self._scaleWidth(100), self._scaleHeight(100)]

	def _addDescription(self):
		dimension = self._dimensionDescription()
		control, dimension = self._addLine(text = interface.Translation.string(33986), color = self._colorDefault(), uppercase = False, dimension = dimension)
		return dimension

	def _addClose(self):
		dimension = self._dimensionButton(text = 33486, icon = 'error')
		x = self._centerX(dimension[0])
		y = self._offsetY()
		control = self._addButton(text = 33486, x = x, y = y, callback = self.close, icon = 'error')
		self.mControlButtons[0].append(control[0])
		return dimension

	def _addProvider(self, id, link, row, offset = 0):
		dimension = self._dimensionProviderBox()
		offset = self._scaleWidth(257 + (offset * 300))
		self._addProviderLogo(id = id, offset = offset)
		self._addProviderLink(link = link, offset = offset)
		self._addProviderButton(link = tools.Settings.raw('internal.link.' + id), row = row, offset = offset)
		return dimension

	def _addProviderLogo(self, id, offset):
		dimensionBox = self._dimensionProviderBox()
		dimension = self._dimensionProviderLogo()
		x = offset + int((dimensionBox[0] - dimension[0]) / 2)
		y = self._offsetY()
		logo = self._addImage(path = self._logoPath(id = id), x = x, y = y, width = dimension[0], height = dimension[1])
		return dimension

	def _addProviderLink(self, link, offset):
		dimensionBox = self._dimensionProviderBox()
		dimensionLogo = self._dimensionProviderLogo()
		dimension = self._dimensionProviderLink()
		x = offset + int((dimensionBox[0] - dimension[0]) / 2)
		y = self._offsetY() + dimensionLogo[1]
		self._addLabel(text = link, x = x, y = y, width = dimension[0], height = dimension[1], color = self._colorDefault(), alignment = Window.AlignmentCenter, bold = True)
		return dimension

	def _addProviderButton(self, link, row, offset):
		dimensionBox = self._dimensionProviderBox()
		dimensionLogo = self._dimensionProviderLogo()
		dimensionLink = self._dimensionProviderLink()
		dimension = self._dimensionButton(text = 33921, icon = 'attribution')
		x = offset + int((dimensionBox[0] - dimension[0]) / 2)
		y = self._offsetY() + dimensionLogo[1] + dimensionLink[1]
		control = self._addButton(text = 33921, x = x, y = y, callback = (lambda: self._visit(link = link)), icon = 'attribution')
		self.mControlButtons[row].append(control[0])


class WindowScrape(WindowProgress):

	StatisticsEssential	= 0
	StatisticsStandard	= 1
	StatisticsAdvanced	= 2
	StatisticsExtended	= 3

	def __init__(self, backgroundType, backgroundPath, logo, status):
		super(WindowScrape, self).__init__(backgroundType = backgroundType, backgroundPath = backgroundPath, logo = logo, status = status)

		self.mSkip = False
		self.mTime = None
		self.mStreamsTotal = 0
		self.mStreamsHdUltra = 0
		self.mStreamsHd1080 = 0
		self.mStreamsHd720 = 0
		self.mStreamsSd = 0
		self.mStreamsLd = 0
		self.mStreamsTorrent = 0
		self.mStreamsUsenet = 0
		self.mStreamsHoster = 0
		self.mStreamsCached = 0
		self.mStreamsDebrid = 0
		self.mStreamsDirect = 0
		self.mStreamsPremium = 0
		self.mStreamsLocal = 0
		self.mStreamsFinished = 0
		self.mStreamsBusy = 0
		self.mProvidersFinished = 0
		self.mProvidersBusy = 0
		self.mProvidersLabels = None
		self.mProvidersStarted = None

		self.mControlDetails = None
		self.mControlStreams1 = None
		self.mControlStreams2 = None
		self.mControlStreams3 = None
		self.mControlStreams4 = None
		self.mControlProcessed = None
		self.mControlProviders = None
		self.mControlSkip = None
		self.mControlCancel = None

		self.mStatistics = tools.Settings.getInteger('interface.scrape.interface.statistics')

		self._onAction(WindowBase.ActionMoveLeft, self._actionFocus)
		self._onAction(WindowBase.ActionMoveRight, self._actionFocus)
		self._onAction(WindowBase.ActionMoveUp, self._actionFocus)
		self._onAction(WindowBase.ActionMoveDown, self._actionFocus)
		self._onAction(WindowBase.ActionItemNext, self._actionFocus)
		self._onAction(WindowBase.ActionItemPrevious, self._actionFocus)
		self._onAction(WindowBase.ActionSelectItem, self._actionFocus)

	def _initializeStart1(self):
		super(WindowScrape, self)._initializeStart1()
		self._dimensionUpdate(self._dimensionSeparator())
		self._dimensionUpdate(self._dimensionLine())
		if self.mStatistics >= WindowScrape.StatisticsStandard:
			self._dimensionUpdate(self._dimensionSeparator())
			self._dimensionUpdate(self._dimensionLine())
			self._dimensionUpdate(self._dimensionLine())
		if self.mStatistics >= WindowScrape.StatisticsAdvanced:
			self._dimensionUpdate(self._dimensionLine())
		if self.mStatistics >= WindowScrape.StatisticsExtended:
			self._dimensionUpdate(self._dimensionLine())
		if self.mStatistics >= WindowScrape.StatisticsAdvanced:
			self._dimensionUpdate(self._dimensionSeparator())
			self._dimensionUpdate(self._dimensionLine())
			if tools.Settings.getBoolean('interface.scrape.interface.providers'): self._dimensionUpdate(self._dimensionLine())
		self._dimensionUpdate(self._dimensionSeparator())
		self._dimensionUpdate(self._dimensionButtons())

	def _initializeStart2(self):
		super(WindowScrape, self)._initializeStart2()
		width = Window.SeparatorLineNarrow if self.mStatistics <= WindowScrape.StatisticsStandard else None
		self._dimensionUpdate(self._addSeparator(width = width))
		self._dimensionUpdate(self._addDetails())
		if self.mStatistics >= WindowScrape.StatisticsStandard:
			self._dimensionUpdate(self._addSeparator(width = width))
			self._dimensionUpdate(self._addStreams1())
			self._dimensionUpdate(self._addStreams2())
		if self.mStatistics >= WindowScrape.StatisticsAdvanced:
			self._dimensionUpdate(self._addStreams3())
		if self.mStatistics >= WindowScrape.StatisticsExtended:
			self._dimensionUpdate(self._addStreams4())
		if self.mStatistics >= WindowScrape.StatisticsAdvanced:
			self._dimensionUpdate(self._addSeparator(width = width))
			self._dimensionUpdate(self._addProcessed())
			if tools.Settings.getBoolean('interface.scrape.interface.providers'): self._dimensionUpdate(self._addProviders())
		self._dimensionUpdate(self._addSeparator(width = width))
		self._dimensionUpdate(self._addButtons())
		self._addCurtains()

	@classmethod
	def show(self, background = None, status = True, wait = False, initialize = True, close = False):
		return super(WindowScrape, self).show(backgroundType = tools.Settings.getInteger('interface.scrape.interface.background'), backgroundPath = background, logo = WindowProgress.LogoIcon, status = status, wait = wait, initialize = initialize, close = close)

	@classmethod
	def update(self, progress = None, finished = None, status = None, time = None, streamsTotal = None, streamsHdUltra = None, streamsHd1080 = None, streamsHd720 = None, streamsSd = None, streamsLd = None, streamsTorrent = None, streamsUsenet = None, streamsHoster = None, streamsCached = None, streamsDebrid = None, streamsDirect = None, streamsPremium = None, streamsLocal = None, streamsFinished = None, streamsBusy = None, providersFinished = None, providersBusy = None, providersLabels = None, skip = False):
		instance = super(WindowScrape, self).update(progress = progress, finished = finished, status = status)
		if instance is None: return instance
		instance._lock()

		if not time is None: instance.mTime = time
		if not streamsTotal is None: instance.mStreamsTotal = streamsTotal
		if not streamsHdUltra is None: instance.mStreamsHdUltra = streamsHdUltra
		if not streamsHd1080 is None: instance.mStreamsHd1080 = streamsHd1080
		if not streamsHd720 is None: instance.mStreamsHd720 = streamsHd720
		if not streamsSd is None: instance.mStreamsSd = streamsSd
		if not streamsLd is None: instance.mStreamsLd = streamsLd
		if not streamsTorrent is None: instance.mStreamsTorrent = streamsTorrent
		if not streamsUsenet is None: instance.mStreamsUsenet = streamsUsenet
		if not streamsHoster is None: instance.mStreamsHoster = streamsHoster
		if not streamsCached is None: instance.mStreamsCached = streamsCached
		if not streamsDebrid is None: instance.mStreamsDebrid = streamsDebrid
		if not streamsDirect is None: instance.mStreamsDirect = streamsDirect
		if not streamsPremium is None: instance.mStreamsPremium = streamsPremium
		if not streamsLocal is None: instance.mStreamsLocal = streamsLocal
		if not streamsFinished is None: instance.mStreamsFinished = streamsFinished
		if not streamsBusy is None: instance.mStreamsBusy = streamsBusy
		if not providersFinished is None: instance.mProvidersFinished = providersFinished
		if not providersBusy is None: instance.mProvidersBusy = providersBusy
		try: instance.mProvidersLabels = providersLabels[:3]
		except: instance.mProvidersLabels = providersLabels

		if not instance.mSkip == skip:
			if skip:
				[i.setVisible(not skip) for i in instance.mControlCancel if i]
				[i.setVisible(skip) for i in instance.mControlSkip if i]
			else:
				[i.setVisible(skip) for i in instance.mControlSkip if i]
				[i.setVisible(not skip) for i in instance.mControlCancel if i]
			instance.mSkip = skip

		size = interface.Skin.fontLarge()

		if not progress is None or not time is None:
			labels = []
			labels.append('%s: %s %%' % (interface.Translation.string(32037), instance._highlight(instance.mProgress)))
			labels.append('%s: %s %s' % (interface.Translation.string(35029), instance._highlight(instance.mTime), interface.Translation.string(32405)))
			if instance.mStatistics == WindowScrape.StatisticsEssential:
				labels.append('%s: %s' % (interface.Translation.string(33481), instance._highlight(instance.mStreamsTotal)))
			instance._setLabel(control = instance.mControlDetails, text = self._separator(labels), size = size, bold = True, uppercase = True)

		if instance.mStatistics == WindowScrape.StatisticsStandard:
			if not streamsTotal is None:
				labels = []
				labels.append('TOTAL: ' + instance._highlight(instance.mStreamsTotal))
				labels.append('INSTANT: ' + instance._highlight(instance.mStreamsCached + instance.mStreamsPremium + instance.mStreamsLocal + instance.mStreamsDirect))
				instance._setLabel(control = instance.mControlStreams1, text = self._separator(labels), size = size, bold = True, uppercase = True)

			if not streamsHdUltra is None or not streamsHd1080 is None or not streamsHd720 is None or not streamsSd is None or not streamsLd is None:
				labels = []
				labels.append('ULTRA: ' + instance._highlight(instance.mStreamsHdUltra))
				labels.append('HD: ' + instance._highlight(instance.mStreamsHd1080 + instance.mStreamsHd720))
				labels.append('SD: ' + instance._highlight(instance.mStreamsSd + instance.mStreamsLd))
				instance._setLabel(control = instance.mControlStreams2, text = self._separator(labels), size = size, bold = True, uppercase = True)
		elif instance.mStatistics == WindowScrape.StatisticsAdvanced:
			if not streamsTotal is None:
				label = 'TOTAL: ' + instance._highlight(instance.mStreamsTotal)
				instance._setLabel(control = instance.mControlStreams1, text = label, size = size, bold = True, uppercase = True)

			if not streamsHdUltra is None or not streamsHd1080 is None or not streamsHd720 is None or not streamsSd is None or not streamsLd is None:
				labels = []
				labels.append('ULTRA: ' + instance._highlight(instance.mStreamsHdUltra))
				labels.append('HD: ' + instance._highlight(instance.mStreamsHd1080 + instance.mStreamsHd720))
				labels.append('SD: ' + instance._highlight(instance.mStreamsSd + instance.mStreamsLd))
				instance._setLabel(control = instance.mControlStreams2, text = self._separator(labels), size = size, bold = True, uppercase = True)

			if not streamsCached is None or not streamsDebrid is None or not streamsDirect is None or not streamsPremium is None or not streamsLocal is None:
				labels = []
				labels.append('CACHED: ' + instance._highlight(instance.mStreamsCached))
				labels.append('INSTANT: ' + instance._highlight(instance.mStreamsPremium + instance.mStreamsDirect + instance.mStreamsLocal))
				labels.append('DEBRID: ' + instance._highlight(instance.mStreamsDebrid))
				instance._setLabel(control = instance.mControlStreams3, text = self._separator(labels), size = size, bold = True, uppercase = True)
		elif instance.mStatistics == WindowScrape.StatisticsExtended:
			if not streamsTotal is None:
				label = 'STREAMS FOUND: ' + instance._highlight(instance.mStreamsTotal)
				instance._setLabel(control = instance.mControlStreams1, text = label, size = size, bold = True, uppercase = True)

			if not streamsTorrent is None or not streamsUsenet is None or not streamsHoster is None:
				labels = []
				labels.append('TORRENT: ' + instance._highlight(instance.mStreamsTorrent))
				labels.append('USENET: ' + instance._highlight(instance.mStreamsUsenet))
				labels.append('HOSTER: ' + instance._highlight(instance.mStreamsHoster))
				instance._setLabel(control = instance.mControlStreams2, text = self._separator(labels), size = size, bold = True, uppercase = True)

			if not streamsHdUltra is None or not streamsHd1080 is None or not streamsHd720 is None or not streamsSd is None or not streamsLd is None:
				labels = []
				labels.append('HDULTRA: ' + instance._highlight(instance.mStreamsHdUltra))
				labels.append('HD1080: ' + instance._highlight(instance.mStreamsHd1080))
				labels.append('HD720: ' + instance._highlight(instance.mStreamsHd720))
				labels.append('SD: ' + instance._highlight(instance.mStreamsSd))
				labels.append('LD: ' + instance._highlight(instance.mStreamsLd))
				instance._setLabel(control = instance.mControlStreams3, text = self._separator(labels), size = size, bold = True, uppercase = True)

			if not streamsCached is None or not streamsDebrid is None or not streamsDirect is None or not streamsPremium is None or not streamsLocal is None:
				labels = []
				labels.append('CACHED: ' + instance._highlight(instance.mStreamsCached))
				labels.append('DEBRID: ' + instance._highlight(instance.mStreamsDebrid))
				labels.append('DIRECT: ' + instance._highlight(instance.mStreamsDirect))
				labels.append('PREMIUM: ' + instance._highlight(instance.mStreamsPremium))
				labels.append('LOCAL: ' + instance._highlight(instance.mStreamsLocal))
				instance._setLabel(control = instance.mControlStreams4, text = self._separator(labels), size = size, bold = True, uppercase = True)

		if instance.mStatistics >= WindowScrape.StatisticsAdvanced:
			if instance.mStreamsFinished > 0 or instance.mStreamsBusy > 0:
				labels = []
				labels.append('FINISHED STREAMS: ' + instance._highlight(instance.mStreamsFinished))
				labels.append('BUSY STREAMS: ' + instance._highlight(instance.mStreamsBusy))
				instance._setLabel(control = instance.mControlProcessed, text = self._separator(labels), size = size, bold = True, uppercase = True)
			elif not providersFinished is None or not providersBusy is None:
				labels = []
				labels.append('BUSY PROVIDERS: ' + instance._highlight(instance.mProvidersBusy))
				labels.append('FINISHED PROVIDERS: ' + instance._highlight(instance.mProvidersFinished))
				instance._setLabel(control = instance.mControlProcessed, text = self._separator(labels), size = size, bold = True, uppercase = True)

			if not instance.mControlProviders is None:
				try:
					if not instance.mProvidersStarted and instance.mProvidersLabels is None: label = 'PROVIDERS STARTED'
					elif not instance.mProvidersLabels or len(instance.mProvidersLabels) == 0: label = 'PROVIDERS FINISHED'
					else:
						instance.mProvidersStarted = True
						label = self._separator(instance.mProvidersLabels)
					instance._setLabel(control = instance.mControlProviders, text = label, size = size, bold = True, uppercase = True)
				except:
					tools.Logger.error()

		instance._unlock()
		return instance

	@classmethod
	def enabled(self):
		return tools.Settings.getInteger('interface.scrape.interface') == 0

	@classmethod
	def skip(self):
		interface.Loader.show()
		self.close()

	def _actionFocus(self):
		try:
			if self.mControlSkip[0].isVisible():
				self.focus(self.mControlSkip[0])
			else:
				self.focus(self.mControlCancel[0])
		except:
			# For Kodi 17 that does not have the isVisible() function.
			try:
				if self.mSkip: self.focus(self.mControlSkip[0])
				else: self.focus(self.mControlCancel[0])
			except: pass

	def _dimensionButtons(self, text = None):
		return self._dimensionButton(text = text, icon = True)

	def _addDetails(self):
		self.mControlDetails, dimension = self._addLine()
		return dimension

	def _addStreams1(self):
		self.mControlStreams1, dimension = self._addLine()
		return dimension

	def _addStreams2(self):
		self.mControlStreams2, dimension = self._addLine()
		return dimension

	def _addStreams3(self):
		self.mControlStreams3, dimension = self._addLine()
		return dimension

	def _addStreams4(self):
		self.mControlStreams4, dimension = self._addLine()
		return dimension

	def _addProcessed(self):
		self.mControlProcessed, dimension = self._addLine()
		return dimension

	def _addProviders(self):
		self.mControlProviders, dimension = self._addLine()
		return dimension

	def _addButtons(self):
		dimension = self._dimensionButtons(text = 33897)
		x = self._centerX(dimension[0])
		y = self._offsetY() + self._scaleHeight(20)
		self.mControlSkip = self._addButton(text = 33897, x = x, y = y, callback = self.skip, icon = 'change', visible = False)

		dimension = self._dimensionButtons(text = 33743)
		x = self._centerX(dimension[0])
		y = self._offsetY() + self._scaleHeight(20)
		self.mControlCancel = self._addButton(text = 33743, x = x, y = y, callback = self.close, icon = 'error')

		return dimension

class WindowPlayback(WindowProgress):

	def __init__(self, backgroundType, backgroundPath, logo, status, retry):
		super(WindowPlayback, self).__init__(backgroundType = backgroundType, backgroundPath = backgroundPath, logo = logo, status = status)
		self.mRetry = retry
		self.mRetryCount = None
		self.mControlSeparator1 = None
		self.mControlSeparator2 = None
		self.mControlSubstatus = None
		self.mControlRetries = None
		self.mControlCancel = None

		self._onAction(WindowBase.ActionMoveLeft, self._actionFocus)
		self._onAction(WindowBase.ActionMoveRight, self._actionFocus)
		self._onAction(WindowBase.ActionMoveUp, self._actionFocus)
		self._onAction(WindowBase.ActionMoveDown, self._actionFocus)
		self._onAction(WindowBase.ActionItemNext, self._actionFocus)
		self._onAction(WindowBase.ActionItemPrevious, self._actionFocus)
		self._onAction(WindowBase.ActionSelectItem, self._actionFocus)

	def _initializeStart1(self, retry = False):
		super(WindowPlayback, self)._initializeStart1()
		if self.mRetry:
			self._dimensionUpdate(self._dimensionSeparator())
			self._dimensionUpdate(self._dimensionLine())
			self._dimensionUpdate(self._dimensionLine())
			self._dimensionUpdate(self._dimensionSeparator())
		self._dimensionUpdate(self._dimensionCancel())

	def _initializeStart2(self, retry = False):
		super(WindowPlayback, self)._initializeStart2()
		if self.mRetry:
			self._dimensionUpdate(self._addSeparator1())
			self._dimensionUpdate(self._addSubstatus())
			self._dimensionUpdate(self._addRetries())
			self._dimensionUpdate(self._addSeparator2())
		self._dimensionUpdate(self._addCancel())
		self._addCurtains()

	@classmethod
	def show(self, background = None, status = True, wait = False, initialize = True, close = False, retry = False):
		return super(WindowPlayback, self).show(backgroundType = tools.Settings.getInteger('interface.playback.interface.background'), backgroundPath = background, logo = WindowProgress.LogoIcon, status = status, wait = wait, initialize = initialize, close = close, retry = retry)

	@classmethod
	def close(self, id = None, loader = True):
		# If the playback has started but Kodi cannot connect and/or start streaming (stuck at "Establishing Stream Connection").
		from lib.modules.interface import Player
		Player().stop()

		# Sometimes is visible if canceling playback window. Loader parameter True by default.
		return super(WindowPlayback, self).close(id = id, loader = loader)

	@classmethod
	def update(self, progress = None, finished = None, status = None, substatus1 = None, substatus2 = None, total = None, remaining = None):
		instance = super(WindowPlayback, self).update(progress = progress, finished = finished, status = status)
		if instance is None: return instance
		instance._lock()

		try:
			remaining += 1 # Otherwise it shows "0 of 2" after the first retry. Just looks better as "1 of 2".
			retry = not((total - remaining) == 0)
		except: retry = False

		if retry and not remaining == instance.mRetryCount:
			background = instance.mBackgroundPath
			instance._unlock()
			interface.Loader.show()
			instance.close(loader = False)
			self.show(background = background, status = True, retry = True)
			instance = super(WindowPlayback, self).update(progress = progress, finished = finished, status = status)
			interface.Loader.hide()
			if instance is None: return instance
			instance._lock()
			instance.mRetryCount = remaining

		if retry:
			size = interface.Skin.fontLarge()

			if not substatus1 is None or not substatus2 is None:
				labels = []
				labels.append(substatus1)
				labels.append(substatus2)
				instance._setLabel(control = instance.mControlSubstatus, text = self._separator(labels), size = size, bold = True, uppercase = True)

			if not total is None or not remaining is None:
				labels = []
				labels.append('%s: %s' % (interface.Translation.string(35475), instance._highlight(remaining)))
				labels.append('%s: %s' % (interface.Translation.string(35476), instance._highlight(total)))
				instance._setLabel(control = instance.mControlRetries, text = self._separator(labels), size = size, bold = True, uppercase = True)

		instance._unlock()
		return instance

	@classmethod
	def enabled(self):
		return tools.Settings.getInteger('interface.playback.interface') == 0

	def _actionFocus(self):
		try: self.focus(self.mControlCancel[0])
		except: pass

	def _dimensionCancel(self):
		return self._dimensionButton(text = 33743, icon = True)

	def _addSeparator1(self):
		self.mControlSeparator1, dimension = self._addSeparator(control = True)
		return dimension

	def _addSeparator2(self):
		self.mControlSeparator2, dimension = self._addSeparator(control = True)
		return dimension

	def _addSubstatus(self):
		self.mControlSubstatus, dimension = self._addLine()
		return dimension

	def _addRetries(self):
		self.mControlRetries, dimension = self._addLine()
		return dimension

	def _addCancel(self):
		dimension = self._dimensionCancel()
		x = self._centerX(dimension[0])
		y = self._offsetY() + self._scaleHeight(20)
		self.mControlCancel = self._addButton(text = 33743, x = x, y = y, callback = self.close, icon = 'error')
		return dimension

class WindowStreams(WindowProgress):

	def __init__(self, backgroundType, backgroundPath, logo, status, metadata, xmlType):
		super(WindowStreams, self).__init__(backgroundType = backgroundType, backgroundPath = backgroundPath, logo = logo, status = status, xml = 'streams', xmlScale = True, xmlType = xmlType)

		self.mMetadata = metadata

		self._onAction(WindowBase.ActionContextMenu, self._actionContext)
		self._onAction(WindowBase.ActionShowInfo, self._actionInformation)
		self._onAction(WindowBase.ActionAny, self._actionList)
		self._onClick(self.IdListControl, self._actionSelect)

	@classmethod
	def show(self, background = None, status = True, metadata = None, wait = False, initialize = True, close = False):
		backgroundType = tools.Settings.getInteger('interface.stream.interface.background')
		decorations = tools.Settings.getInteger('interface.stream.interface.decorations')
		if decorations == 0: decorations = self.TypePlain
		elif decorations == 1: decorations = self.TypeBasic
		elif decorations == 2: decorations = self.TypeIcons
		else: decorations = self.TypePlain
		return super(WindowStreams, self)._show(xmlType = decorations, backgroundType = backgroundType, backgroundPath = background, logo = WindowProgress.LogoIcon, status = status, metadata = metadata, wait = wait, initialize = initialize, close = close)

	@classmethod
	def update(self, progress = None, finished = None, status = None):
		instance = super(WindowStreams, self).update(progress = progress, finished = finished, status = status)
		try:
			if finished: instance._remove()
		except: pass

	@classmethod
	def enabled(self):
		return tools.Settings.getInteger('interface.stream.interface') == 0

	@classmethod
	def itemReselect(self):
		id = self.propertyGlobal('GaiaIndexId')
		position = self.propertyGlobal('GaiaIndex' + id)
		if position: self.itemSelect(int(position))

	def _initializeStart2(self):
		# Create the main background.
		self._addBackground(type = self.mBackgroundType, path = self.mBackgroundPath, fixed = True)

	def _initializeEnd1(self):
		# The XML interface is only created during doModal().
		# In order to create the loader on top of the XML, it must be added AFTER the window has been shown.
		super(WindowStreams, self)._initializeStart2()
		super(WindowStreams, self)._initializeEnd1()

	def _actionSelect(self):
		path = self.control(self.IdListControl).getSelectedItem().getProperty('GaiaAction')
		tools.System.executePlugin(command = path)

	def _actionInformation(self):
		# This only works if the user has opened the information dialog on the normal movie/episode menu before.
		# This adds the metadata to memory and when the window is opened from here, it will correctly display the metadata.
		# But if the information was not displayed before, this window stays empty.
		# Use the ExtendedInfo dialog instead.
		#Window.show(self.IdWindowInformation)

		from lib.informers import Informer
		Informer.show(metadata = self.mMetadata)

	def _actionContext(self):
		index = self.control(self.IdListControl).getSelectedPosition()
		if index >= 0:
			self.focus(50000)
			self.mContexts[index].show()

	def _actionList(self):
		try:
			id = self.propertyGlobal('GaiaIndexId')
			if id: self.propertyGlobalSet('GaiaIndex' + id, self.control(self.IdListControl).getSelectedPosition())
		except: pass


class WindowBinge(WindowProgress):

	ModeFull = True
	ModeOverlay = False

	def __init__(self, mode, backgroundType, backgroundPath, poster, logo, status, width = None, height = None, inverse = False):
		super(WindowBinge, self).__init__(backgroundType = backgroundType, backgroundPath = backgroundPath, logo = logo, status = status, width = width, height = height)

		self.mMode = mode

		self.mControlTitle = None
		self.mControlEpisode = None
		self.mControlTime = None
		self.mControlCancel = None
		self.mControlContinue = None

		self.mPoster = poster
		self.mTime = None
		self.mFocus = None
		self.mAction = tools.Binge.actionNone()
		self.mContinue = self.mAction == tools.Binge.ActionContinue
		self.mFontSize = interface.Skin.fontMedium() if self.mMode == WindowBinge.ModeOverlay else interface.Skin.fontLarge()

		for action in [WindowBase.ActionMoveLeft, WindowBase.ActionMoveRight, WindowBase.ActionMoveUp, WindowBase.ActionMoveDown, WindowBase.ActionItemNext, WindowBase.ActionItemPrevious, WindowBase.ActionSelectItem]:
			self._onAction(action, self._actionFocus)

	@classmethod
	def show(self, background = None, poster = None, wait = False, initialize = True, close = False, title = None, season = None, episode = None, duration = None, delay = None):
		next = False
		result = super(WindowBinge, self)._show(backgroundType = tools.Settings.getInteger('interface.playback.interface.background'), backgroundPath = background, poster = poster, logo = WindowProgress.LogoIcon, status = interface.Translation.string(35582), wait = wait, initialize = initialize, close = close)
		if result:
			instance = self._instance()

			instance._setLabel(control = instance.mControlTitle, text = title, size = instance.mFontSize, bold = True, uppercase = True)
			instance._setLabel(control = instance.mControlEpisode, text = self._separator(['%s %s' % (interface.Translation.string(32055), self._highlight(season)), '%s %s' % (interface.Translation.string(33028), self._highlight(episode))]), size = instance.mFontSize, bold = True, uppercase = True)

			if duration:
				end = interface.Translation.string(33331) + ' ' + self._highlight(tools.Time.future(seconds = duration, format = tools.Time.FormatTimeShort, local = True).replace(':', interface.Format.fontColor(':', color = self._colorDefault())))
				duration = int(tools.Math.roundDown(float(duration) / 60.0))
				hours = int(tools.Math.roundDown(duration / 60.0))
				minutes = duration % 60
				duration = []
				if hours > 0: duration.append('%s %s' % (self._highlight(hours), interface.Translation.string(35617 if hours == 1 else 35618)))
				if minutes > 0: duration.append('%s %s' % (self._highlight(minutes), interface.Translation.string(35619 if minutes == 1 else 35620)))
				duration = ' '.join(duration)
				duration = self._separator([duration, end])
			else:
				duration = interface.Translation.string(33237)
			instance._setLabel(control = instance.mControlTime, text = duration, size = instance.mFontSize, bold = True, uppercase = True)

			if delay:
				delay = (delay * 1000) - 1000 # Subtract a little bit, since the window takes some time to show.
				self.update(progress = 0, time = int(delay / 1000.0))
				timer = tools.Time()
				timer.start()
				elapsed = 0
				while (delay - elapsed) > 1000 and instance.visible():
					elapsed = timer.elapsed(milliseconds = True)
					self.update(progress = int((elapsed + 1000) / float(delay) * 100), time = int((delay - elapsed) / 1000.0))
					tools.Time.sleep(0.2)
				self.update(progress = 100, time = 0, finished = True)
				next = instance.mContinue
				instance.close()
		return result and next

	@classmethod
	def update(self, progress = None, finished = None, time = None):
		instance = super(WindowBinge, self).update(progress = progress, finished = finished)
		if instance is None: return instance
		instance._lock()

		if not time is None: instance.mTime = time

		label = 35582 if instance.mAction == tools.Binge.ActionContinue else 35629
		unit = 35630 if instance.mTime == 1 else 32405
		instance.mStatus = '%s %s %s' % (interface.Translation.string(label), self._highlight(instance.mTime), interface.Translation.string(unit))
		instance._setLabel(control = instance.mStatusControl, text = instance.mStatus, size = instance.mFontSize, bold = True, uppercase = True)

		instance._unlock()
		return instance

	def _actionFocus(self):
		if self.mMode == WindowBinge.ModeOverlay:
			if self.mFocus is True: self._actionFocusCancel()
			else: self._actionFocusContinue()
		else:
			if self.mFocus is False: self._actionFocusContinue()
			else: self._actionFocusCancel()

	def _actionFocusCancel(self):
		self.mFocus = False
		try: self.focus(self.mControlCancel[0])
		except: pass

	def _actionFocusContinue(self):
		self.mFocus = True
		try: self.focus(self.mControlContinue[0])
		except: pass

	def _actionCancel(self):
		self.mContinue = False
		self.close()

	def _actionContinue(self):
		self.mContinue = True
		self.close()

	def _addStatus(self, text = None):
		if text is None: text = self.mStatus
		if tools.Tools.isBoolean(text): text = ''
		self.mStatusControl, dimension = self._addLine(text = text, size = self.mFontSize)
		return dimension

class WindowBingeFull(WindowBinge):

	Padding = 30

	def __init__(self, backgroundType, backgroundPath, poster, logo, status):
		super(WindowBingeFull, self).__init__(mode = WindowBinge.ModeFull, backgroundType = backgroundType, backgroundPath = backgroundPath, poster = poster, logo = logo, status = status)

	def _initializeStart1(self):
		super(WindowBingeFull, self)._initializeStart1()
		self._dimensionUpdate(self._dimensionSeparator())
		self._dimensionUpdate(self._dimensionLine())
		self._dimensionUpdate(self._dimensionLine())
		self._dimensionUpdate(self._dimensionLine())
		self._dimensionUpdate(self._dimensionSeparator())
		self._dimensionUpdate(self._dimensionControls())

	def _initializeStart2(self):
		super(WindowBingeFull, self)._initializeStart2()
		self._dimensionUpdate(self._addSeparator1())
		self._dimensionUpdate(self._addTitle())
		self._dimensionUpdate(self._addEpisode())
		self._dimensionUpdate(self._addTime())
		self._dimensionUpdate(self._addSeparator2())
		self._dimensionUpdate(self._addControls())
		self._addCurtains()

	def _dimensionControls(self):
		dimensionCancel = self._dimensionCancel()
		dimensionContinue = self._dimensionContinue()
		return (self._scaleWidth(WindowBingeFull.Padding) + dimensionCancel[0] + dimensionContinue[0], max(dimensionCancel[1], dimensionContinue[1]))

	def _dimensionCancel(self):
		return self._dimensionButton(text = 33743, icon = True)

	def _dimensionContinue(self):
		return self._dimensionButton(text = 33821, icon = True)

	def _addSeparator1(self):
		control, dimension = self._addSeparator(control = True)
		return dimension

	def _addSeparator2(self):
		control, dimension = self._addSeparator(control = True)
		return dimension

	def _addTitle(self):
		self.mControlTitle, dimension = self._addLine()
		return dimension

	def _addEpisode(self):
		self.mControlEpisode, dimension = self._addLine()
		return dimension

	def _addTime(self):
		self.mControlTime, dimension = self._addLine()
		return dimension

	def _addControls(self):
		dimension = self._dimensionControls()
		y = self._offsetY() + self._scaleHeight(20)
		x = self._centerX(dimension[0])
		self.mControlCancel = self._addButton(text = 33743, x = x, y = y, callback = self._actionCancel, icon = 'error')
		x += self._dimensionCancel()[0] + self._scaleWidth(WindowBingeFull.Padding)
		self.mControlContinue = self._addButton(text = 33821, x = x, y = y, callback = self._actionContinue, icon = 'play')
		return dimension

class WindowBingeOverlay(WindowBinge):

	SizeHeight = 110

	ButtonWidth = 150
	ButtonHeight = 40

	LogoIconWidth = 48
	LogoIconHeight = 48

	PosterWidth = 61
	PosterHeight = 90

	Padding = 10

	def __init__(self, backgroundType, backgroundPath, poster, logo, status):
		super(WindowBingeOverlay, self).__init__(mode = WindowBinge.ModeOverlay, backgroundType = backgroundType, backgroundPath = backgroundPath, poster = poster, logo = logo, status = status, height = WindowBingeOverlay.SizeHeight, inverse = True)

	def _initializeStart1(self):
		super(WindowBingeOverlay, self)._initializeStart1()
		self.mDimensionHeight += WindowBingeOverlay.Padding

	def _initializeStart2(self):
		super(WindowBingeOverlay, self)._initializeStart2()
		self._addSeparator()
		self._addPoster()
		self._addDetails()
		self._addControls()

	def _dimensionSpace(self):
		return [0, 0]

	def _dimensionLine(self):
		return [self._scaleWidth(1200), self._scaleHeight(1)]

	def _dimensionLogo(self, logo):
		if logo == WindowProgress.LogoIcon: return [self._scaleWidth(WindowBingeOverlay.LogoIconWidth), self._scaleHeight(WindowBingeOverlay.LogoIconHeight)]
		else: return [0, 0]

	def _dimensionButton(self, text = None, icon = None):
		width = len(self._buttonText(text = text, icon = icon)) * 10
		return [max(width, self._scaleWidth(WindowBingeOverlay.ButtonWidth)), self._scaleHeight(WindowBingeOverlay.ButtonHeight)]

	def _dimensionPoster(self, text = None, icon = None):
		return [self._scaleWidth(WindowBingeOverlay.PosterWidth), self._scaleHeight(WindowBingeOverlay.PosterHeight)]

	def _dimensionDetail(self):
		return [self._scaleWidth((self.mWidth / 2) - (3 * WindowBingeOverlay.Padding) - WindowBingeOverlay.PosterWidth), self._scaleHeight(20)]

	def _addSeparator(self):
		return self._addImage(self._pathImage('separator'), x = -5, y = self.mHeight, width = self.mWidth + 10, height = Window.SeparatorLineHeight)

	def _addPoster(self):
		if self.mPoster:
			dimension = self._dimensionPoster()
			self._addImage(path = self.mPoster, x = WindowBingeOverlay.Padding, y = WindowBingeOverlay.Padding, width = dimension[0], height = dimension[1])

	def _addDetails(self):
		x = (self._dimensionPoster()[0] + (2 * WindowBingeOverlay.Padding)) if self.mPoster else WindowBingeOverlay.Padding
		y = int(1.5 * WindowBingeOverlay.Padding)
		self.mControlTitle, dimension = self._addDetail(x = x, y = y)
		y += WindowBingeOverlay.Padding + dimension[1]
		self.mControlEpisode, dimension = self._addDetail(x = x, y = y)
		y += WindowBingeOverlay.Padding + dimension[1]
		self.mControlTime, dimension = self._addDetail(x = x, y = y)

	def _addDetail(self, x, y, text = ''):
		dimension = self._dimensionDetail()
		control = self._addLabel(text = text, x = x, y = y, width = dimension[0], height = dimension[1], color = self._colorDefault(), alignment = Window.AlignmentLeftCenter, bold = True, uppercase = True)
		return control, dimension

	def _addControls(self):
		dimensionContinue = self._dimensionButton(text = 33821, icon = 'play')
		dimensionCancel = self._dimensionButton(text = 33821, icon = 'play')
		width = max(dimensionContinue[0], dimensionCancel[0])
		height = max(dimensionContinue[1], dimensionCancel[1])
		x = self.mWidth - width - WindowBingeOverlay.Padding
		y = WindowBingeOverlay.Padding
		self.mControlContinue = self._addButton(text = 33821, x = x, y = y, width = width, height = height, callback = self._actionContinue, icon = 'play', size = interface.Skin.fontMedium())
		y += height + WindowBingeOverlay.Padding
		self.mControlCancel = self._addButton(text = 33743, x = x, y = y, width = width, height = height, callback = self._actionCancel, icon = 'error', size = interface.Skin.fontMedium())


class WindowStep(WindowProgress):

	def __init__(self, backgroundType, backgroundPath, logo, stepper = True, navigationCancel = True, navigationHelp = True, navigationBack = True, navigationNext = True, callbackCancel = None, callbackHelp = None, callbackBack = None, callbackNext = None, **kwargs):
		super(WindowStep, self).__init__(backgroundType = backgroundType, backgroundPath = backgroundPath, logo = logo, **kwargs)

		self.mStepper = stepper

		self.mSeparator1 = None
		self.mSeparator2 = None

		self.mNavigation = None
		self.mNavigationIndex = None
		self.mNavigationCount = None

		self.mNavigationCancel = navigationCancel
		self.mNavigationHelp = navigationHelp
		self.mNavigationBack = navigationBack
		self.mNavigationNext = navigationNext

		self.mCallbackCancel = callbackCancel
		self.mCallbackHelp = callbackHelp
		self.mCallbackBack = callbackBack
		self.mCallbackNext = callbackNext

		self._onAction(WindowBase.ActionMoveLeft, self._actionFocus)
		self._onAction(WindowBase.ActionMoveRight, self._actionFocus)
		self._onAction(WindowBase.ActionMoveUp, self._actionFocus)
		self._onAction(WindowBase.ActionMoveDown, self._actionFocus)

		self._onAction(WindowBase.ActionContextMenu, self._actionHelp)
		self._onAction(WindowBase.ActionShowInfo, self._actionHelp)

		self._onAction(WindowBase.ActionNavigationBack, self._actionBack)
		self._onAction(WindowBase.ActionBackSpace, self._actionBack)
		self._onAction(WindowBase.ActionPreviousMenu, self._actionBack)

	def _initializeStart1(self, retry = False):
		super(WindowStep, self)._initializeStart1(progress = self.mStepper, status = self.mStepper)
		self._dimensionUpdate(self._dimensionSeparator(width = True))
		self._dimensionUpdate(self._dimensionContent())
		self._dimensionUpdate(self._dimensionSeparator(width = True))
		self._dimensionUpdate(self._dimensionNavigation())

	def _initializeStart2(self, retry = False):
		super(WindowStep, self)._initializeStart2(progress = self.mStepper, status = self.mStepper)
		self._dimensionUpdate(self._addSeparator1())
		self._dimensionUpdate(self._addContent())
		self._dimensionUpdate(self._addSeparator2())
		self._dimensionUpdate(self._addNavigation())

	def _initializeEnd2(self):
		super(WindowStep, self)._initializeEnd2()
		self._actionDefault()

	@classmethod
	def show(self, stepper = True, navigationCancel = True, navigationHelp = True, navigationBack = True, navigationNext = True, callbackCancel = None, callbackHelp = None, callbackBack = None, callbackNext = None, **kwargs):
		return super(WindowStep, self).show(backgroundType = tools.Settings.getInteger('interface.playback.interface.background'), logo = WindowProgress.LogoIcon, stepper = stepper, navigationCancel = navigationCancel, navigationHelp = navigationHelp, navigationBack = navigationBack, navigationNext = navigationNext, callbackCancel = callbackCancel, callbackHelp = callbackHelp, callbackBack = callbackBack, callbackNext = callbackNext, **kwargs)

	def _actionDefault(self):
		self.mNavigation = []
		if self.mNavigationCancel: self.mNavigation.append(self.mNavigationCancel)
		if self.mNavigationHelp: self.mNavigation.append(self.mNavigationHelp)
		if self.mNavigationBack: self.mNavigation.append(self.mNavigationBack)
		if self.mNavigationNext: self.mNavigation.append(self.mNavigationNext)
		self._actionFocus()

	def _actionFocus(self, action = None, multiple = False):
		count = self.mNavigationCount
		if not count: count = 0

		navigation = [i for i in self.mNavigation if self._visible(i)]
		self.mNavigationCount = len(navigation)
		maximum = self.mNavigationCount - 1

		if self.mNavigationIndex is None: self.mNavigationIndex = maximum
		else:
			self.mNavigationIndex += (self.mNavigationCount - count)
			if action == WindowBase.ActionMoveLeft: self.mNavigationIndex -= 1
			elif action == WindowBase.ActionMoveRight: self.mNavigationIndex += 1
			elif not multiple:
				if action == WindowBase.ActionMoveUp: self.mNavigationIndex -= 1
				elif action == WindowBase.ActionMoveDown: self.mNavigationIndex += 1

		if self.mNavigationIndex < 0: self.mNavigationIndex = maximum
		if self.mNavigationIndex > maximum: self.mNavigationIndex = 0

		self.focus(navigation[self.mNavigationIndex][0])

	def _actionRefocus(self):
		self.mNavigationIndex = None
		self._actionFocus()

	# Virtual
	def _actionClose(self):
		self.close()

	# Virtual
	def _actionHelp(self):
		pass

	# Virtual
	def _actionBack(self):
		pass

	# Virtual
	def _actionNext(self):
		pass

	def actionClose(self):
		if self.mCallbackCancel: self.mCallbackCancel()
		self._actionClose()

	def actionHelp(self):
		if self.mCallbackHelp: self.mCallbackHelp()
		self._actionHelp()

	def actionBack(self):
		if self.mCallbackBack: self.mCallbackBack()
		self._actionBack()
		self._actionRefocus()

	def actionNext(self):
		if self.mCallbackNext: self.mCallbackNext()
		self._actionNext()
		self._actionRefocus()

	def _dimensionContent(self):
		return [self._scaleWidth(1200), self._scaleHeight(400)]

	def _dimensionNavigation(self):
		return [self._scaleWidth(1200), self._scaleHeight(80)]

	def _addSeparator1(self):
		self.mSeparator1, dimension = self._addSeparator(control = True, width = True, y = self._offsetY() + self._scaleHeight(25 if self.mStepper else 10))
		return dimension

	def _addSeparator2(self):
		self.mSeparator2, dimension = self._addSeparator(control = True, width = True, y = self._scaleHeight(Window.SizeHeight) - self._dimensionNavigation()[1] - self._dimensionSeparator()[1])
		return dimension

	def _addContent(self):
		return self._dimensionContent()

	def _addNavigation(self):
		dimension = self._dimensionNavigation()
		y = self._scaleHeight(Window.SizeHeight - dimension[1])
		window = self._scaleWidth(Window.SizeWidth)
		offset = window - dimension[0] + self._scaleWidth(40)

		if self.mNavigationCancel: self.mNavigationCancel = self._addButton(text = 33743, x = offset, y = y, callback = self.actionClose, icon = 'error')
		else: self.mNavigationCancel = None

		if self.mNavigationHelp: self.mNavigationHelp = self._addButton(text = 33239, x = offset + self._scaleWidth(20) + self.mNavigationCancel[0].getWidth(), y = y, callback = self.actionHelp, icon = 'help')
		else: self.mNavigationHelp = None

		if self.mNavigationNext:
			label = 33821
			icon = 'next'
			if tools.Tools.isDictionary(self.mNavigationNext):
				if 'label' in self.mNavigationNext: label = self.mNavigationNext['label']
				if 'icon' in self.mNavigationNext: icon = self.mNavigationNext['icon']
			elif tools.Tools.isInteger(self.mNavigationNext):
				label = self.mNavigationNext
			dimensionNext = self._dimensionButton(text = label, icon = icon)
			self.mNavigationNext = self._addButton(text = label, x = window - offset - dimensionNext[0], y = y, callback = self.actionNext, icon = icon)
		else:
			self.mNavigationNext = None
			dimensionNext = [0, 0]

		if self.mNavigationBack:
			label = 36051
			icon = 'previous'
			if tools.Tools.isDictionary(self.mNavigationBack):
				if 'label' in self.mNavigationBack: label = self.mNavigationBack['label']
				if 'icon' in self.mNavigationBack: icon = self.mNavigationBack['icon']
			elif tools.Tools.isInteger(self.mNavigationBack):
				label = self.mNavigationBack
			dimensionBack = self._dimensionButton(text = label, icon = icon)
			self.mNavigationBack = self._addButton(text = label, x = window - offset - self._scaleWidth(20) - dimensionNext[0] - dimensionBack[0], y = y, callback = self.actionBack, icon = icon)
		else:
			self.mNavigationBack = None

		return dimension


class WindowOptimization(WindowStep):

	SizeIcon = 128
	SizeRating = 200

	CategoryScrape = 'scrape'
	CategoryProvider = 'provider'

	# Must be thew same as manager.py.
	TradeoffSpeed = 'speed'
	TradeoffResult = 'result'
	TradeoffMixed = 'mixed'

	StepIntroduction = 'introduction'
	StepDiagnostics = 'diagnostics'
	StepRating = 'rating'
	StepPreferences = 'preferences'

	def __init__(self, navigationCategory, callbackDiagnose, callbackTradeoff, **kwargs):
		super(WindowOptimization, self).__init__(**kwargs)

		self.mIntroduction = None

		self.mDiagnoseProgress = 0
		self.mDiagnoseProgressInner = None
		self.mDiagnoseProgressOuter = None
		self.mDiagnoseProgressFill = None
		self.mDiagnoseProgressLabel = None

		self.mRatingDevice = None
		self.mRatingProcessor = None
		self.mRatingMemory = None
		self.mRatingStorage = None
		self.mRatingConnection = None
		self.mRatingHeading = None
		self.mRatingLabel = None

		self.mCategory = []
		self.mCategoryEnabled = navigationCategory
		self.mCategoryOptions = None
		self.mCategoryScrape = None
		self.mCategoryProvider = None
		self.mCategoryHeading = None
		self.mCategoryLabel = None

		self.mTradeoffOptions = None
		self.mTradeoffSpeed = None
		self.mTradeoffMixed = None
		self.mTradeoffResult = None
		self.mTradeoffHeading = None
		self.mTradeoffLabel = None

		self.mPreferencesHeading = None
		self.mPreferencesLabel = None
		self.mPreferencesSeparator1 = None
		self.mPreferencesSeparator2 = None

		self.mNavigationRow = None

		self.mStep = WindowOptimization.StepIntroduction
		self.mCallbackDiagnose = callbackDiagnose
		self.mCallbackTradeoff = callbackTradeoff

		self.mDataDiagnose = None
		self.mDataSettings = None

	@classmethod
	def show(self, wait = False, stepper = False, navigationCancel = True, navigationHelp = True, navigationBack = True, navigationNext = True, navigationCategory = True, callbackCancel = None, callbackHelp = None, callbackBack = None, callbackNext = None, callbackDiagnose = None, callbackTradeoff = None):
		return super(WindowOptimization, self).show(wait = wait, stepper = stepper, navigationCancel = navigationCancel, navigationHelp = navigationHelp, navigationBack = navigationBack, navigationNext = navigationNext, navigationCategory = navigationCategory, callbackCancel = callbackCancel, callbackHelp = callbackHelp, callbackBack = callbackBack, callbackNext = callbackNext, callbackDiagnose = callbackDiagnose, callbackTradeoff = callbackTradeoff)

	@classmethod
	def update(self, progress = None, finished = None, status = None, diagnoseProgress = None, diagnoseStatus = None, diagnoseData = None, diagnoseScrape = True, diagnoseProvider = True):
		instance = super(WindowOptimization, self).update(progress = progress, finished = finished, status = status)
		if diagnoseStatus:
			instance._setLabel(control = instance.mDiagnoseProgressLabel, text = diagnoseStatus, uppercase = True, bold = True)
		if diagnoseProgress:
			instance._progressUpdate(progressNew = diagnoseProgress, progressCurrent = instance.mDiagnoseProgress, controlFill = instance.mDiagnoseProgressFill, controlIcon = instance.mDiagnoseProgressInner)
			instance.mDiagnoseProgress = diagnoseProgress
		if diagnoseData:
			instance.mDataDiagnose = diagnoseData
			instance._actionDiagnostics()
			if diagnoseScrape: instance._actionCategory(control = instance.mCategoryScrape)
			if diagnoseProvider: instance._actionCategory(control = instance.mCategoryProvider)
			instance._actionTradeoff(control = instance.mTradeoffMixed)

	def _initializeStart2(self):
		super(WindowOptimization, self)._initializeStart2()
		self._toggleDiagnostics(visible = False)
		self._toggleRating(visible = False)
		self._togglePreferences(visible = False)
		self._toggleIntroduction(visible = True)

	def _initializeEnd2(self):
		super(WindowOptimization, self)._initializeEnd2()
		self.mCategoryOptions = [self.mCategoryScrape, self.mCategoryProvider]
		self.mTradeoffOptions = [self.mTradeoffSpeed, self.mTradeoffMixed, self.mTradeoffResult]

	def _actionFocus(self, action = None):
		if self.mStep == WindowOptimization.StepPreferences:
			if self.mNavigationRow is None: self.mNavigationRow = 2

			if action == WindowBase.ActionMoveUp: self.mNavigationRow -= 1
			elif action == WindowBase.ActionMoveDown: self.mNavigationRow += 1

			if self.mNavigationRow < 0: self.mNavigationRow = 2
			elif self.mNavigationRow > 2: self.mNavigationRow = 0

			if self.mNavigationRow == 2:
				super(WindowOptimization, self)._actionFocus(action = action, multiple = True)
			elif self.mNavigationRow == 1:
				maximum = len(self.mTradeoffOptions) - 1

				if self.mNavigationIndex is None: self.mNavigationIndex = maximum
				elif action == WindowBase.ActionMoveLeft: self.mNavigationIndex -= 1
				elif action == WindowBase.ActionMoveRight: self.mNavigationIndex += 1

				if self.mNavigationIndex < 0:
					if action in [WindowBase.ActionMoveUp, WindowBase.ActionMoveDown]: self.mNavigationIndex = 0
					else: self.mNavigationIndex = maximum
				if self.mNavigationIndex > maximum:
					if action in [WindowBase.ActionMoveUp, WindowBase.ActionMoveDown]: self.mNavigationIndex = maximum
					else: self.mNavigationIndex = 0

				self.focus(self.mTradeoffOptions[self.mNavigationIndex][0])
			elif self.mNavigationRow == 0:
				maximum = len(self.mCategoryOptions) - 1

				if self.mNavigationIndex is None: self.mNavigationIndex = maximum
				elif action == WindowBase.ActionMoveLeft: self.mNavigationIndex -= 1
				elif action == WindowBase.ActionMoveRight: self.mNavigationIndex += 1

				if self.mNavigationIndex < 0:
					if action in [WindowBase.ActionMoveUp, WindowBase.ActionMoveDown]: self.mNavigationIndex = 0
					else: self.mNavigationIndex = maximum
				if self.mNavigationIndex > maximum:
					if action in [WindowBase.ActionMoveUp, WindowBase.ActionMoveDown]: self.mNavigationIndex = maximum
					else: self.mNavigationIndex = 0

				self.focus(self.mCategoryOptions[self.mNavigationIndex][0])
		else:
			super(WindowOptimization, self)._actionFocus(action = action)

	def _actionBack(self):
		if self.mStep == WindowOptimization.StepRating:
			self.mStep = WindowOptimization.StepIntroduction
			self._toggleRating(visible = False)
			self._toggleIntroduction(visible = True)
		elif self.mStep == WindowOptimization.StepPreferences:
			self.mStep = WindowOptimization.StepRating
			self._togglePreferences(visible = False)
			self._toggleRating(visible = True)

	def actionNext(self):
		self._actionNext()
		if not self.mStep in [WindowOptimization.StepDiagnostics, WindowOptimization.StepPreferences]: self._actionRefocus()

	def _actionNext(self):
		if self.mStep == WindowOptimization.StepIntroduction:
			self.mStep = WindowOptimization.StepDiagnostics
			self._toggleIntroduction(visible = False)
			self._toggleDiagnostics(visible = True)
			self._progressClear(controlFill = self.mDiagnoseProgressFill, controlIcon = self.mDiagnoseProgressInner)
			self.mCallbackDiagnose()
		elif self.mStep == WindowOptimization.StepRating:
			self.mStep = WindowOptimization.StepPreferences
			self._toggleRating(visible = False)
			self._togglePreferences(visible = True)
		elif self.mStep == WindowOptimization.StepPreferences:
			if self.mCallbackNext:
				updateScrape = WindowOptimization.CategoryScrape in self.mCategory
				updateProvider =  WindowOptimization.CategoryProvider in self.mCategory
				self.mCallbackNext(data = self.mDataSettings, updateScrape = updateScrape, updateProvider = updateProvider)
			self.close()

	def _actionCategory(self, control):
		if not tools.Tools.isDictionary(control): control = self._get(control = control)
		try: control = control['control']
		except: pass

		if control == self.mCategoryScrape[0]:
			if WindowOptimization.CategoryScrape in self.mCategory:
				self._selectButton(control = self.mCategoryScrape, select = Window.SelectHide)
				self.mCategory.remove(WindowOptimization.CategoryScrape)
			else:
				self._selectButton(control = self.mCategoryScrape, select = Window.SelectYes)
				self.mCategory.append(WindowOptimization.CategoryScrape)
		elif control == self.mCategoryProvider[0]:
			if WindowOptimization.CategoryProvider in self.mCategory:
				self._selectButton(control = self.mCategoryProvider, select = Window.SelectHide)
				self.mCategory.remove(WindowOptimization.CategoryProvider)
			else:
				self._selectButton(control = self.mCategoryProvider, select = Window.SelectYes)
				self.mCategory.append(WindowOptimization.CategoryProvider)

		if WindowOptimization.CategoryScrape in self.mCategory and WindowOptimization.CategoryProvider in self.mCategory: label = 36145
		elif WindowOptimization.CategoryScrape in self.mCategory: label = 36143
		elif WindowOptimization.CategoryProvider in self.mCategory: label = 36144
		else: label = 36146
		self._setLabel(control = self.mCategoryLabel, text = interface.Translation.string(label), bold = True)

		self._actionTradeoff() # Update the settings labels.

	def _actionTradeoff(self, control = None):
		if control:
			label = None
			tradeoff = None

			if not tools.Tools.isDictionary(control): control = self._get(control = control)
			try: control = control['control']
			except: pass

			if control == self.mTradeoffSpeed[0]:
				label = 36053
				tradeoff = WindowOptimization.TradeoffSpeed
				self._selectButton(control = self.mTradeoffSpeed, select = Window.SelectYes)
			else:
				self._selectButton(control = self.mTradeoffSpeed, select = Window.SelectHide)

			if control == self.mTradeoffMixed[0]:
				label = 36055
				tradeoff = WindowOptimization.TradeoffMixed
				self._selectButton(control = self.mTradeoffMixed, select = Window.SelectYes)
			else:
				self._selectButton(control = self.mTradeoffMixed, select = Window.SelectHide)

			if control == self.mTradeoffResult[0]:
				label = 36054
				tradeoff = WindowOptimization.TradeoffResult
				self._selectButton(control = self.mTradeoffResult, select = Window.SelectYes)
			else:
				self._selectButton(control = self.mTradeoffResult, select = Window.SelectHide)

			self._setLabel(control = self.mTradeoffLabel, text = interface.Translation.string(label), bold = True)

			self.mDataSettings = self.mCallbackTradeoff(data = self.mDataDiagnose, tradeoff = tradeoff)

		if self.mDataSettings:
			label1 = []
			label2 = []
			if WindowOptimization.CategoryProvider in self.mCategory:
				label1.extend([(32345, self.mDataSettings['label']['providers'])])
			if WindowOptimization.CategoryScrape in self.mCategory:
				label1.extend([
					(33273, self.mDataSettings['label']['time']),
					(32035, self.mDataSettings['label']['query']),
					(35810, self.mDataSettings['label']['page']),
					#(36042, self.mDataSettings['label']['concurrency']),
				])
				label2.extend([
					(33167, self.mDataSettings['label']['pack']),
					(33881, self.mDataSettings['label']['title']),
					(35484, self.mDataSettings['label']['keyword']),
					(35830, self.mDataSettings['label']['mirror']),
				])
			label = ''
			if label1: label += self._labelDetails(label1)
			if label1 and label2: label += interface.Format.newline()
			if label2: label += self._labelDetails(label2)
			self._setLabel(control = self.mPreferencesLabel, text = label, bold = True)

	def _actionDiagnostics(self):
		label = [(36046, self.mDataDiagnose['performance']['processor']['label']['device']), (35004, self.mDataDiagnose['performance']['memory']['label']['device']), (33350, self.mDataDiagnose['performance']['storage']['label']['device']), (33404, self.mDataDiagnose['performance']['connection']['label']['device'])]
		self._setLabel(control = self.mRatingLabel, text = self._labelDetails(label), bold = True)

		font = interface.Skin.fontMassive(full = True)
		self._setLabel(control = self.mRatingDevice['middle'], text = self._labelRating(self.mDataDiagnose['performance']['label']['rating']), bold = not font['bold'])
		self._setLabel(control = self.mRatingDevice['bottom'], text = self._labelPerformance(self.mDataDiagnose['performance']['label']['performance']), bold = True)
		self._setLabel(control = self.mRatingProcessor['middle'], text = self._labelRating(self.mDataDiagnose['performance']['processor']['label']['rating']), bold = not font['bold'])
		self._setLabel(control = self.mRatingProcessor['bottom'], text = self._labelPerformance(self.mDataDiagnose['performance']['processor']['label']['performance']), bold = True)
		self._setLabel(control = self.mRatingMemory['middle'], text = self._labelRating(self.mDataDiagnose['performance']['memory']['label']['rating']), bold = not font['bold'])
		self._setLabel(control = self.mRatingMemory['bottom'], text = self._labelPerformance(self.mDataDiagnose['performance']['memory']['label']['performance']), bold = True)
		self._setLabel(control = self.mRatingStorage['middle'], text = self._labelRating(self.mDataDiagnose['performance']['storage']['label']['rating']), bold = not font['bold'])
		self._setLabel(control = self.mRatingStorage['bottom'], text = self._labelPerformance(self.mDataDiagnose['performance']['storage']['label']['performance']), bold = True)
		self._setLabel(control = self.mRatingConnection['middle'], text = self._labelRating(self.mDataDiagnose['performance']['connection']['label']['rating']), bold = not font['bold'])
		self._setLabel(control = self.mRatingConnection['bottom'], text = self._labelPerformance(self.mDataDiagnose['performance']['connection']['label']['performance']), bold = True)

		self._setButton(control = self.mNavigationNext, text = 33821, icon = 'next')

		self.mStep = WindowOptimization.StepRating
		self._toggleDiagnostics(visible = False)
		self._toggleRating(visible = True)

	def _toggleIntroduction(self, visible):
		self._visibleSet(control = self.mIntroduction, visible = visible)
		self._visibleSet(control = self.mNavigationBack, visible = self.mStepper)
		if visible: self._setButton(control = self.mNavigationNext, text = 36138, icon = 'diagnostic')

	def _toggleDiagnostics(self, visible):
		self._visibleSet(control = self.mNavigationBack, visible = not visible)
		self._visibleSet(control = self.mNavigationNext, visible = not visible)
		self._visibleSet(control = self.mDiagnoseProgressInner, visible = visible)
		self._visibleSet(control = self.mDiagnoseProgressOuter, visible = visible)
		self._visibleSet(control = self.mDiagnoseProgressLabel, visible = visible)

	def _toggleRating(self, visible):
		self._visibleSet(control = self.mRatingDevice, visible = visible)
		self._visibleSet(control = self.mRatingProcessor, visible = visible)
		self._visibleSet(control = self.mRatingMemory, visible = visible)
		self._visibleSet(control = self.mRatingStorage, visible = visible)
		self._visibleSet(control = self.mRatingConnection, visible = visible)
		self._visibleSet(control = self.mRatingHeading, visible = visible)
		self._visibleSet(control = self.mRatingLabel, visible = visible)
		if visible: self._setButton(control = self.mNavigationNext, text = 33821, icon = 'next')

	def _togglePreferences(self, visible):
		visibleCategory = visible and self.mCategoryEnabled

		self._visibleSet(control = self.mPreferencesSeparator1, visible = visibleCategory)
		self._visibleSet(control = self.mPreferencesSeparator2, visible = visible)
		self._visibleSet(control = self.mPreferencesHeading, visible = visible)
		self._visibleSet(control = self.mPreferencesLabel, visible = visible)

		self._visibleSet(control = self.mCategoryScrape, visible = visibleCategory)
		self._visibleSet(control = self.mCategoryProvider, visible = visibleCategory)
		self._visibleSet(control = self.mCategoryHeading, visible = visibleCategory)
		self._visibleSet(control = self.mCategoryLabel, visible = visibleCategory)

		self._visibleSet(control = self.mTradeoffSpeed, visible = visible)
		self._visibleSet(control = self.mTradeoffMixed, visible = visible)
		self._visibleSet(control = self.mTradeoffResult, visible = visible)
		self._visibleSet(control = self.mTradeoffHeading, visible = visible)
		self._visibleSet(control = self.mTradeoffLabel, visible = visible)

		if visible: self._setButton(control = self.mNavigationNext, text = 35269, icon = 'speed')

	def _labelRating(self, value):
		return value if value else '0%'

	def _labelPerformance(self, value):
		return value if value else interface.Translation.string(33387)

	def _labelDetails(self, values):
		return interface.Format.iconJoin(['%s %s' % (interface.Translation.string(i[0]) + ':', interface.Format.fontColor(self._labelPerformance(i[1]), color = interface.Format.colorPrimary())) for i in values])

	def _dimensionTradeoff(self):
		return [self._scaleWidth(1200), self._scaleHeight(200)]

	def _center(self):
		dimension = self._dimensionContent()
		x = self._scaleWidth((Window.SizeWidth - dimension[0]) / 2.0)
		y = self._offsetY() + int(dimension[1] / 2.0)
		y += self._scaleHeight(5)
		return x, y

	def _addContent(self):
		dimension = super(WindowOptimization, self)._addContent()
		self._addIntroduction(dimension = dimension)
		self._addDiagnostics(dimension = dimension)
		self._addRating(dimension = dimension)
		self._addPreferences(dimension = dimension)
		return dimension

	def _addIntroduction(self, dimension):
		height = self._scaleHeight(150)
		x, y = self._center()
		self.mIntroduction = self._addLabel(text = interface.Translation.string(35005), x = x, y = y - int(height / 2.0) + self._scaleHeight(10), width = dimension[0], height = height, alignment = Window.AlignmentCenter, size = interface.Skin.fontLarge(), bold = True)

	def _addDiagnostics(self, dimension):
		height = self._scaleHeight(20)
		x, y = self._center()
		_, self.mDiagnoseProgressInner, self.mDiagnoseProgressOuter, self.mDiagnoseProgressFill = self._addProgressBar(y = y - height)
		self.mDiagnoseProgressLabel = self._addLabel(text = '', x = x, y = y + height, width = dimension[0], height = height, alignment = Window.AlignmentCenter, size = interface.Skin.fontLarge(), color = self._colorHighlight(), uppercase = True, bold = True)

	def _addRating(self, dimension):
		width = WindowOptimization.SizeRating
		pad = 20
		x, y = self._center()
		spacing = self._scaleHeight(160)

		self.mRatingHeading = self._addLabel(text = interface.Translation.string(36140), x = x, y = y - spacing, width = dimension[0], height = self._scaleHeight(20), alignment = Window.AlignmentCenter, size = interface.Skin.fontLarge(), color = interface.Format.colorSecondary(), bold = True, uppercase = True)
		self._visibleSet(control = self.mRatingHeading, visible = False)

		offset = 0 if self.mStepper else 20
		self.mRatingDevice = self._addRatingSection(type = 'device', label = 35012, offsetX = -((width / 2.0) + (pad / 2.0)), offsetY = -(WindowOptimization.SizeIcon - offset))
		self.mRatingProcessor = self._addRatingSection(type = 'processor', label = 36046, offsetX = -(2 * (width + pad)))
		self.mRatingMemory = self._addRatingSection(type = 'memory', label = 35004, offsetX = -(width + (pad / 2.0)))
		self.mRatingStorage = self._addRatingSection(type = 'storage', label = 33350, offsetX = (pad / 2.0))
		self.mRatingConnection = self._addRatingSection(type = 'connection', label = 33404, offsetX = (width + pad))

		self.mRatingLabel = self._addLabel(text = '', x = x, y = y + spacing, width = dimension[0], height = self._scaleHeight(20), alignment = Window.AlignmentCenter, size = interface.Skin.fontSmall(), bold = True)

	def _addRatingSection(self, type, label, offsetX = 0, offsetY = 0, large = False):
		offsetX = self._scaleWidth(offsetX)
		offsetY = self._scaleHeight(offsetY)

		widthIcon = self._scaleWidth(WindowOptimization.SizeIcon)
		heightIcon = self._scaleHeight(WindowOptimization.SizeIcon)

		x, y = self._center()
		x = self._centerX(0) + offsetX
		y += offsetY

		if self.mStepper: y += self._scaleHeight(15)

		controlIcon = self._addImage(path = self._pathIcon(type, quality = interface.Icon.QualityLarge), x = x, y = y, width = widthIcon, height = heightIcon)

		x += widthIcon - self._scaleWidth(int(WindowOptimization.SizeIcon * 0.1))
		y += self._scaleHeight(Window.SeparatorLinePadding)
		width = self._scaleWidth(WindowOptimization.SizeRating)

		font = interface.Skin.fontMassive(full = True)
		try: offset = self._scaleHeight(70 - font['size']) # Try to accomodate different font sizes that have different label heights.
		except: offset = 0

		yNew = y + int(heightIcon * 0.0) + offset
		height = int(heightIcon * 0.15)
		controlTop = self._addLabel(text = interface.Translation.string(label), x = x, y = yNew, width = width, height = height, size = interface.Skin.fontSmall(), bold = True, color = interface.Format.colorSecondary())

		yNew = y + int(heightIcon * 0.07) + offset
		height = int(heightIcon * 0.5)
		controlMiddle = self._addLabel(text = '', x = x - 1, y = yNew, width = width, height = height, size = font['name'], bold = not font['bold'])

		yNew = y + height - int(heightIcon * 0.05)
		height = int(heightIcon * 0.15)
		controlBottom = self._addLabel(text = '', x = x, y = yNew, width = width, height = height, size = interface.Skin.fontSmall(), bold = True, color = interface.Format.colorPrimary())

		return {'icon' : controlIcon, 'top' : controlTop, 'middle' : controlMiddle, 'bottom' : controlBottom}

	def _addPreferences(self, dimension):
		x, y = self._center()
		self._addCategory(dimension = dimension)
		self.mPreferencesSeparator1, _ = self._addSeparator(y = y - self._scaleHeight(47 if self.mStepper else 50), control = True)
		self._addTradeoff(dimension = dimension)
		self.mPreferencesSeparator2, _ = self._addSeparator(y = y + self._scaleHeight(115 if self.mStepper else 125) - self._scaleHeight(0 if self.mCategoryEnabled else 100), control = True)
		self._addSettings(dimension = dimension)

	def _addCategory(self, dimension):
		x, y = self._center()

		y -= self._scaleHeight(202)
		if self.mStepper: y += self._scaleHeight(10)
		self.mCategoryHeading = self._addLabel(text = interface.Translation.string(36142), x = x, y = y, width = dimension[0], height = self._scaleHeight(20), alignment = Window.AlignmentCenter, size = interface.Skin.fontLarge(), color = interface.Format.colorSecondary(), bold = True, uppercase = True)

		xCenter = self._centerX(0)
		y += self._scaleHeight(50)
		self.mCategoryScrape = self._addButton(text = 35514, x = xCenter - self._scaleWidth(230), y = y, icon = 'scraper', select = Window.SelectHide, callback = self._actionCategory)
		self.mCategoryProvider = self._addButton(text = 32345, x = xCenter + self._scaleWidth(10), y = y, icon = 'provider', select = Window.SelectHide, callback = self._actionCategory)

		y += self._dimensionButton()[1] + self._scaleHeight(15)
		self.mCategoryLabel = self._addLabel(text = '', x = x, y = y, width = dimension[0], height = self._scaleHeight(20), alignment = Window.AlignmentCenter, size = interface.Skin.fontSmall(), color = interface.Format.colorPrimary(), bold = True)

	def _addTradeoff(self, dimension):
		x, y = self._center()

		y -= self._scaleHeight(30)
		if not self.mCategoryEnabled: y -= self._scaleHeight(150)
		self.mTradeoffHeading = self._addLabel(text = interface.Translation.string(36141), x = x, y = y, width = dimension[0], height = self._scaleHeight(20), alignment = Window.AlignmentCenter, size = interface.Skin.fontLarge(), color = interface.Format.colorSecondary(), bold = True, uppercase = True)

		xCenter = self._centerX(0)
		y += self._scaleHeight(50)
		if not self.mCategoryEnabled: y += self._scaleHeight(20)
		self.mTradeoffSpeed = self._addButton(text = 36050, x = xCenter - self._scaleWidth(310), y = y, icon = 'speed', select = Window.SelectHide, callback = self._actionTradeoff)
		self.mTradeoffMixed = self._addButton(text = 36052, x = xCenter - self._scaleWidth(83), y = y, icon = 'changelog', select = Window.SelectHide, callback = self._actionTradeoff)
		self.mTradeoffResult = self._addButton(text = 35815, x = xCenter + self._scaleWidth(145), y = y, icon = 'lists', select = Window.SelectHide, callback = self._actionTradeoff)

		y += self._dimensionButton()[1] + self._scaleHeight(15)
		if not self.mCategoryEnabled: y += self._scaleHeight(15)
		self.mTradeoffLabel = self._addLabel(text = '', x = x, y = y, width = dimension[0], height = self._scaleHeight(20), alignment = Window.AlignmentCenter, size = interface.Skin.fontSmall(), color = interface.Format.colorPrimary(), bold = True)

	def _addSettings(self, dimension):
		x, y = self._center()

		y += self._scaleHeight(145)
		if self.mStepper: y -= self._scaleHeight(15)
		if not self.mCategoryEnabled: y -= self._scaleHeight(80)
		self.mPreferencesHeading = self._addLabel(text = interface.Translation.string(36147), x = x, y = y, width = dimension[0], height = self._scaleHeight(20), alignment = Window.AlignmentCenter, size = interface.Skin.fontLarge(), color = interface.Format.colorSecondary(), bold = True, uppercase = True)

		y += self._scaleHeight(30)
		if not self.mCategoryEnabled: y += self._scaleHeight(35)
		self.mPreferencesLabel = self._addLabel(text = '', x = x, y = y, width = dimension[0], height = self._scaleHeight(50), alignment = Window.AlignmentCenter, size = interface.Skin.fontMedium(), bold = True)
