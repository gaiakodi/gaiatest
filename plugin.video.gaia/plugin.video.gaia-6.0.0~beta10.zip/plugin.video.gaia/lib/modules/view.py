# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.modules.tools import System, Time, File, Regex, Logger, Settings, Media
from lib.modules.database import Database
from lib.modules.interface import Directory, Translation, Format, Dialog, Loader, Skin
from lib.modules.concurrency import Pool

class View(object):

	ModeDefault = 0
	ModeFixed = 1
	ModeCustom = 2

	Fixed = {
		'skin.estuary' : {
			Directory.ContentGeneral : 55, # WideList
			Directory.ContentMovies : 51, # Poster
			Directory.ContentShows : 51, # Poster
			Directory.ContentSeasons : 50, # List
			Directory.ContentEpisodes : 55, # WideList
		},
		'skin.estouchy' : {
			Directory.ContentGeneral : 9000, # Unknown
			Directory.ContentMovies : 50, # Unknown
			Directory.ContentShows : 50, # Unknown
			Directory.ContentSeasons : 50, # Unknown
			Directory.ContentEpisodes : 50, # Unknown
		},
		'skin.confluence' : {
			Directory.ContentGeneral : 500, # Thumbnail
			Directory.ContentMovies : 515, # MediaInfo3
			Directory.ContentShows : 515, # MediaInfo3
			Directory.ContentSeasons : 2, # MediaInfo2
			Directory.ContentEpisodes : 2, # MediaInfo2
		},
		'skin.aeon.nox.silvo' : {
			Directory.ContentGeneral : 50, # List
			Directory.ContentMovies : 501, # LowList
			Directory.ContentShows : 501, # LowList
			Directory.ContentSeasons : 501, # LowList
			Directory.ContentEpisodes : 501, # LowList
		},
		'skin.arctic.horizon' : {
			Directory.ContentGeneral : 500, # SquareList
			Directory.ContentMovies : 52, # PosterRow
			Directory.ContentShows : 52, # PosterRow
			Directory.ContentSeasons : 53, # LandscapeIntegrated
			Directory.ContentEpisodes : 53, # LandscapeIntegrated
		},
	}

	@classmethod
	def add(self, media):
		try:
			skinId = Skin.id()
			skinPath = Skin.path()

			xml = File.joinPath(skinPath, 'addon.xml')
			data = File.readNow(xml).replace('\n', '')
			source = Regex.extract(data = data, expression = 'defaultresolution\s*=\s*[\\\'\\"](.+?)[\\\'\\"]')
			if not source: source = Regex.extract(data = data, expression = '<\s*res.+?folder\s*=\s*[\\\'\\"](.+?)[\\\'\\"]')
			source = File.joinPath(skinPath, source, 'MyVideoNav.xml')

			data = File.readNow(source).replace('\n', '')
			views = Regex.extract(data = data, expression = '<views>(.+?)</views>')
			views = [int(x) for x in views.split(',')]

			Loader.hide() # NB: Loader must be hidden, otherwise the info label below will not work.
			Time.sleep(0.1)
			viewId = int(System.infoLabel('System.CurrentControlID'))
			if viewId is None: return False
			viewName = System.infoLabel('Container.Viewmode')
			Loader.show()

			return {'id' : viewId, 'name' : viewName, 'skin' : skinId, 'layout' : self.settingsLayoutGet(media = media)}
		except:
			Logger.error()
			return False

	@classmethod
	def path(self):
		return System.infoLabel('Container.FolderPath')

	@classmethod
	def set(self, media, content = None, previous = None, views = None, thread = True):
		if thread: Pool.thread(target = self._set, kwargs = {'media' : media, 'content' : content, 'previous' : previous, 'views' : views}, start = True)
		else: self._set(media = media, content = content, previous = previous, views = views)

	@classmethod
	def _set(self, media, content = None, previous = None, views = None):
		try:
			skin = Skin.id()

			if not content: content = self.convert(media)
			layout = self.settingsLayoutGet(media = media)
			container = 'Container.Content(%s)' % layout

			view = None
			if views:
				try: view = views[skin]
				except: pass
			if not view:
				mode = self.settingsGet(media = media)
				if mode == View.ModeCustom:
					try: view = self.settingsTypeGet(media = media)[skin][content]['id']
					except: pass
				elif mode == View.ModeFixed:
					try: view = View.Fixed[skin][content]
					except: pass

			if view:
				command = 'Container.SetViewMode(%s)' % str(view)

				# Previous should always be set, so this should never be executed.
				# Wait here, because the if-statement in the loop will immediately set loaded = True.
				if not previous and not layout: Time.sleep(0.5)

				for i in range(0, 300):
					loaded = False
					if previous: loaded = not previous == self.path()
					elif layout: loaded = System.visible(container) # Do not wait if ContentGeneral, which will end up with Container.Content(), which always returns False.
					elif not layout: loaded = True # This should never execute.
					if loaded:
						System.execute(command)
						return True
					Time.sleep(0.05)

				System.execute(command) # Try setting it if the loop above did not succeed.
				return True
			return None
		except:
			Logger.error()
			return False

	@classmethod
	def settings(self, media = None, content = None, previous = None, settings = False):
		try:
			if content:
				Loader.show()
				id = 'navigation.view.%s.type' % media

				view = self.add(media = media)
				if view: self.settingsTypeSet(media = media, view = view)

				# Actions, like System.execute('Action(Back)') do not work, probably because Container.Update() was called from settings.xml.
				# This is the best we can do to reload the menu that was visible before the views menu.
				if previous:
					# When loading the previous command into the container, it still shows the old view, probably because it is cached.
					# This might make the user think that the settings update did not work.
					# Move to the main  menu to force the user to manually reload the menu.
					#System.executeContainer(command = previous)
					System.executeContainer(action = '')
					Time.sleep(0.5)

				Loader.hide()
				if view: Dialog.notification(title = 33586, message = Translation.string(33587) % Format.fontBold(view['name']), icon = Dialog.IconSuccess)
				if settings: self.settingsLaunch(media = media)
			else:
				title = Translation.string(32059)
				content = self.convert(media)
				previous = System.infoLabel('Container.FolderPath')
				link = System.command(action = 'settingsView', parameters = {'media' : media, 'content' : content, 'previous' : previous, 'settings' : settings})

				Loader.hide()
				Time.sleep(0.5) # 0.2 is too short.

				# Hide the Kodi left-hand sliding window if views was launched from there (through the settings dialog).
				# This is very unreliable and will only work if the language is English and the label is "Add-on settings".
				control = System.infoLabel('System.CurrentControl')
				if control and control.lower() == 'add-on settings': System.execute('Action(Menu)')

				directory = Directory(content = Directory.ContentSettings, media = media, cache = False, lock = False)
				for i in range(10):
					directory.add(label = title, link = link, info = ('video', {'title' : title}), icon = 'viewssave.png', iconDefault = 'DefaultProgram.png', fanart = True, folder = False)
				directory.finish()

				Dialog.confirm(title = 33012, message = 36201)
		except:
			Logger.error()

	@classmethod
	def settingsLaunch(self, media):
		Settings.launchData(self.settingsTypeId(media = media))

	@classmethod
	def settingsInitialize(self):
		# In case the skin was changed, change the view name/label in the settings.
		for media in [Directory.ContentGeneral, Media.TypeMovie, Media.TypeShow, Media.TypeSeason, Media.TypeEpisode]:
			settings = self.settingsTypeGet(media = media)
			try:
				view = settings[Skin.id()][self.settingsLayoutGet(media = media)]['name']
				self.settingsTypeSet(media = media, label = view)
			except:
				self.settingsTypeSet(media = media, label = False)

	@classmethod
	def settingsId(self, media):
		return 'navigation.view.%s' % media

	@classmethod
	def settingsGet(self, media):
		return Settings.getInteger(id = self.settingsId(media = media))

	@classmethod
	def settingsLayoutId(self, media):
		return 'navigation.view.%s.layout' % (media if media and not media == Directory.ContentGeneral else Directory.ContentGeneral)

	@classmethod
	def settingsLayoutGet(self, media = None, fallback = False):
		# Must be the same index-order as in settings.xml.
		if fallback:
			default = self.convert(media = media)
			if default == Directory.ContentGeneral: fallback = False

		order = [
			default if fallback else Directory.ContentDefault,
			Directory.ContentAddons,
			Directory.ContentFiles,
			Directory.ContentGames,
			Directory.ContentVideos,
			Directory.ContentMovies,
			Directory.ContentShows,
			Directory.ContentSeasons,
			Directory.ContentEpisodes,
		]
		try: return order[0 if self.settingsGet(media = media) == View.ModeFixed else Settings.getInteger(self.settingsLayoutId(media = media))]
		except: return Directory.ContentDefault

	@classmethod
	def settingsTypeId(self, media):
		return 'navigation.view.%s.type' % media

	@classmethod
	def settingsTypeGet(self, media):
		return Settings.getData(id = self.settingsTypeId(media = media))

	@classmethod
	def settingsTypeSet(self, media, data = None, view = None, label = None):
		if label:
			Settings.setLabel(id = self.settingsTypeId(media = media), value = label)
		elif label is False:
			Settings.defaultData(id = self.settingsTypeId(media = media))
		else:
			if data is None: data = self.settingsTypeGet(media = media)
			if not data: data = {}
			if not view['skin'] in data: data[view['skin']] = {}
			data[view['skin']][view['layout'] if view['layout'] else self.convert(media = media)] = {'id' : view['id'], 'name' : view['name']}
			Settings.setData(id = self.settingsTypeId(media = media), value = data, label = view['name'])

	@classmethod
	def convert(self, media):
		if media:
			if media.startswith('movie') or media.startswith('docu') or media.startswith('short'): return Directory.ContentMovies
			elif media.startswith('tvshow') or media.startswith('show'): return Directory.ContentShows
			elif media.startswith('season'): return Directory.ContentSeasons
			elif media.startswith('episode'): return Directory.ContentEpisodes
		return Directory.ContentGeneral
