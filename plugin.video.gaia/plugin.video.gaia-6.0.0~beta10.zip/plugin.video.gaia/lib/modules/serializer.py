# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from lib.modules.tools import Tools, Converter, Logger

class Serializer(object):

	def __init__(self):
		self.mData = None

	def data(self):
		return self.mData

	def dataSet(self, data):
		self.mData = data

	def dataUpdate(self, data, lists = False, unique = True):
		Tools.update(self.mData, data, lists = lists, unique = unique)

	def dataExport(self):
		try:
			data = self.dataExportBefore()
			result = self.dataCopy()
			self.dataExportAfter(data)
			return result
		except: Logger.error()
		return None

	# Pure Virtual
	def dataExportBefore(self):
		return None

	# Pure Virtual
	def dataExportAfter(self, data = None):
		pass

	def dataImport(self, data):
		try:
			if Tools.isString(data): data = Converter.jsonFrom(data)
			elif Tools.isInstance(data, Serializer): data = data.dataCopy()
			data = self.dataImportBefore(data = data)
			self.dataUpdate(data = data)
			self.dataImportAfter(data = data)
			return True
		except:
			Logger.error()
			return False

	# Virtual
	def dataImportBefore(self, data = None):
		return data

	# Virtual
	def dataImportAfter(self, data = None):
		pass

	def dataCopy(self):
		return Tools.copy(self.mData)

	def dataJson(self):
		return Converter.jsonTo(self.dataExport())

	@classmethod
	def dataSerialize(self, instance):
		if Tools.isArray(instance) and len(instance) > 0 and Tools.isInstance(instance[0], Serializer):
			return [self.dataSerialize(i) for i in instance]
		elif Tools.isInstance(instance, Serializer):
			# Make a deep copy.
			# Some classes, like Metadata, change/serialize their internal data during dataExportBefore(), that is changing Python objects to JSON objects.
			# If this function is called in a separate thread (eg: during caching), while another thread accesses the data between when dataExportBefore() and dataExportAfter() is called, code might fail since expected Python objects might temporarily be JSON.
			return {
				'__class__' : instance.__class__.__name__,
				'__module__' : Tools.getModule(instance),
				'__data__' : Tools.copy(instance, deep = True).dataExport(),
			}
		return None

	@classmethod
	def dataUnserialize(self, data):
		try:
			if Tools.isArray(data):
				result = []
				for i in data:
					item = self.dataUnserialize(i)
					result.append(i if item is None else item)
				return result
			else:
				instance = Tools.getInstance(data['__module__'], data['__class__'])
				instance.dataImport(data['__data__'])
				return instance
		except: pass
		return None

	# Tools.update()
	def get(self, key, default = None):
		try: return self.mData[key]
		except: return default

	# Tools.update()
	def items(self):
		try: return self.mData.items()
		except: return None

	def update(self, data):
		try: self.mData, Tools.update(self.mData, data, lists = True, unique = True)
		except: pass

	# Called from tools.Converter.jsonTo().
	def __json__(self):
		return self.dataExport()

	def __str__(self):
		return self.dataJson()

	def __getitem__(self, key):
		try: return self.mData[key]
		except: return None

	def __setitem__(self, key, value):
		self.mData[key] = value

	def __contains__(self, key):
		return key in self.mData
