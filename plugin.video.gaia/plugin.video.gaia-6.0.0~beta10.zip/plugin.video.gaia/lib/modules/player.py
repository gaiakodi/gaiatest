# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import xbmc
import xbmcvfs

from lib import debrid
from lib.modules import playcount
from lib.modules import trakt
from lib.modules.clean import Title
from lib.modules import tools
from lib.modules import interface
from lib.modules import window
from lib.modules import handler
from lib.modules import library
from lib.modules import orionoid
from lib.modules.vpn import Vpn
from lib.modules.playback import Playback
from lib.modules.stream import Stream
from lib.modules.theme import Theme
from lib.modules.concurrency import Pool, Lock

# If the player automatically closes/crashes because the EOF was reached while still downloading, the player instance is never deleted.
# Now the player keeps a constant lock on the played file and the file cannot be deleted (manually, or by the downloader). The lock is only release when Kodi exits.
# Use a thread and forcefully delete the instance. Although this is still no garantuee that Kodi will release the lock on the file, but it seems to work most of the time.
def playerDelete(instance):
	tools.Time.sleep(1)
	# Do not just use "del instance", since this will only call __del__() if the reference count drops to 0. Kodi still has a reference to the instance.
	try: instance.__del__()
	except: pass
	try: del instance
	except: pass

class Player(xbmc.Player):

	# Statuses
	StatusIdle = 0
	StatusPlaying = 1
	StatusPaused = 2
	StatusStopped = 3
	StatusEnded = 4

	# Download
	DownloadThresholdStart = 0.01 # If the difference between the download and the playback progress is lower than this percentage, buffering will start.
	DownloadThresholdStop = DownloadThresholdStart * 2 # If the difference between the download and the playback progress is higher than this percentage, buffering will stop.
	DownloadMinimum = 1048576 # 1 MB. The minimum number of bytes that must be available to avoid buffering. If the value is too small, the player with automatically stop/crash due to insufficient data available.
	DownloadFuture = 102400 # 100 KB. The number of bytes to read and update the progress with. Small values increase disk access, large values causes slow/jumpy progress.
	DownloadChunk = 8 # 8 B. The number of null bytes that are considered the end of file.
	DownloadNull = '\x00' * DownloadChunk

	BingeTime = 600 # Start binge scrape if 10 minutes are left on the current playback.

	ResumeTime = 10 # Resume playback a number of seconds before the recorded playback time, to catch up on the story.

	PropertyOverlay = 'GaiaPlayerOverlay'

	def __init__ (self, type = None, kids = None):
		from lib.modules import core
		xbmc.Player.__init__(self)
		self.type = type
		self.kids = kids
		self.status = Player.StatusIdle
		self.statusStarted = False
		self.core = core.Core(type = type, kids = kids)

	def __del__(self):
		self._downloadClear(delete = False)
		self.core.progressPlaybackClose()
		try: xbmc.Player.__del__(self)
		except: pass

	def run(self, type, title, year, season, episode, imdb, tmdb, tvdb, meta, downloadType = None, downloadId = None, source = None, binge = None, resume = None, autoplay = None):
		try:
			tools.Time.sleep(0.2)

			self.vpnMonitor = False
			if Vpn.settingsEnabled():
				if Vpn.statusConnectedGlobal(): self.vpnMonitor = True
				elif Vpn.killPlayback(initial = True): self.vpnMonitor = Vpn.statusConnectedGlobal() # User manually selected to continue without a VPN.
				else: return False

			self.navigationStreamsSpecial = tools.Settings.getInteger('interface.stream.interface') == 0

			self.typeMedia = type
			self.typeMovie = tools.Media.typeMovie(self.typeMedia)
			self.typeTelevision = tools.Media.typeTelevision(self.typeMedia)

			self.timeTotal = 0
			self.timeCurrent = 0

			self.idImdb = imdb
			self.idTmdb = tmdb
			self.idTvdb = tvdb

			self.autoplay = autoplay
			self.kodi = None
			self.metadata = meta
			self.title = title
			self.year = int(year) if year else year
			try: self.name = tools.Media.titleUniversal(metadata = meta)
			except: self.name = self.title

			try:
				self.season = int(season) if self.typeTelevision else None
				self.seasonString = '%01d' % self.season if self.typeTelevision else None
			except:
				self.season = None
				self.seasonString = None
			try:
				self.episode = int(episode) if self.typeTelevision else None
				self.episodeString = '%01d' % self.episode if self.typeTelevision else None
			except:
				self.episode = None
				self.episodeString = None

			self.binge = not episode is None and binge
			self.bingeDialogNone = tools.Binge.dialogNone()
			self.bingeDialogFull = tools.Binge.dialogFull()
			self.bingeDialogOverlay = tools.Binge.dialogOverlay()
			self.bingeDialogUpNext = tools.Binge.dialogUpNext()
			self.bingeSuppress = tools.Binge.suppress()
			self.bingeDelay = None
			self.bingeContinue = False
			self.bingePlay = False
			self.bingeFinishedScrape = False
			self.bingeFinishedCheck = False
			self.bingeFinishedShow = False
			self.bingeFinishedPlay = False
			self.bingeMetadata = None

			self.playback = Playback()
			self.progress = None
			self.progressBusy = False
			self.progressInitialized = False
			self.progressThread = None
			self.progressRetrieve()

			self.source = source
			self.source['stream'] = Stream.load(data = self.source['stream'])
			Audio.languageSet(self.source['stream'].metaLanguage())

			self.url = self.source['stream'].linkResolved()

			self.timeTotal = 0
			self.timeCurrent = 0
			self.timeProgress = 0
			self.sizeTotal = 0
			self.sizeCurrent = 0
			self.sizeProgress = 0
			self.resumeTime = resume
			self.dialog = None

			poster, thumb, fanart, banner, meta = self.metadataExtract(tools.Tools.copy(meta))
			meta = tools.Media.metadataClean(meta)

			# Kodi's player adds its own year and episode number, do not use the one created by tools.Media.title().
			# Otheriwse itr will show eg: Dune (2021)(2021)
			try: meta['title'] = meta['originaltitle']
			except: pass

			self.item = interface.Directory().item(path = self.url)
			self.item.setArt({'icon' : thumb, 'thumb' : thumb, 'poster' : poster, 'fanart' : fanart, 'banner' : banner, 'tvshow.poster' : poster, 'season.poster' : poster})
			self.item.setInfo(type = 'Video', infoLabels = meta)

			self.downloadCheck = False
			if downloadType and downloadId:
				from lib.modules import downloader
				self.download = downloader.Downloader(type = downloadType, id = downloadId)
				self.bufferCounter = 0
				self.bufferShow = True

				# Already check here, so that the player waits when the download is still queued/initialized.
				if not self._downloadCheck():
					return
			else:
				self.download = None
				self.bufferCounter = None
				self.bufferShow = None

			self.retryMessage = ''
			self.retryRemaining = 0
			self.retryTotal = 1
			self.retryDelay = 0
			if tools.Settings.getBoolean('playback.retry.enabled'):
				self.retryTotal += tools.Settings.getInteger('playback.retry.limit')
				self.retryDelay = tools.Settings.getInteger('playback.retry.delay')
			self.retryRemaining = self.retryTotal

			success = False
			xbmc.executebuiltin('Dialog.Close(notification,true)') # Hide the caching/download notification if still showing.
			while self.retryRemaining > 0:
				self._errorLog()
				self.retryRemaining -= 1
				self.error = False

				# When retrying, Kodi player might still try to play from the previous time (eg: stuck at connection timmeout).
				# Manually stop to ensure everything is cleared.
				self.stop()
				tools.Time.sleep(0.1)

				self.play(self.url, self.item)
				interface.Loader.hide()

				success = self.keepPlaybackAlive()
				if success or tools.System.aborted():
					self._closeFailure()
					break
				if self.retryRemaining > 0:
					if interface.Core.background() and not self.core.progressPlaybackEnabled():
						self.retryMessage = interface.Translation.string(35303)
					else:
						if self.retryRemaining == 1: self.retryMessage = interface.Translation.string(35294)
						elif self.retryRemaining > 1: self.retryMessage = interface.Translation.string(35293) % (self.retryRemaining + 1)

			self._errorLog(finish = True)

			if not success and self.retryRemaining == 0:
				self._closeFailure()
				interface.Dialog.notification(title = 33448, message = 33450, icon = interface.Dialog.IconError)

			# This should solve the issue of Gaia videos being played twice when launched from OpenMeta or widgets when using the directory structure.
			# Setting it to True will cause the video to play again after finishing playback, when launched from the local library.
			#tools.System.pluginResolvedSet(success = True, item = item)
			tools.System.pluginResolvedSet(success = False, item = self.item)

			ids = {}
			if imdb: ids['imdb'] = imdb
			if tmdb: ids['tmdb'] = tmdb
			if tvdb: ids['tvdb'] = tvdb
			tools.System.windowPropertySet('script.trakt.ids', tools.Converter.jsonTo(ids))
			tools.System.windowPropertyClear('script.trakt.ids')

			# Sometimes when stopping playback, the Kodi player does not fire the onPlayBackStopped/onPlayBackEnded events.
			# This causes the stream window not to reloaded.
			# Manually call the event in such a case.
			if not self.status == Player.StatusStopped and not self.status == Player.StatusEnded: self.onPlayBackEnded()

			return success
		except:
			tools.Logger.error()
			return False

	def metadataExtract(self, meta):
		try:
			poster = meta['poster'] if 'poster' in meta else meta['poster2'] if 'poster2' in meta else meta['poster3'] if 'poster3' in meta else None
			thumb = meta['thumb'] if 'thumb' in meta else meta['thumb2'] if 'thumb2' in meta else meta['thumb3'] if 'thumb3' in meta else poster
			fanart = meta['fanart'] if 'fanart' in meta else meta['fanart2'] if 'fanart2' in meta else meta['fanart3'] if 'fanart3' in meta else None
			banner = meta['banner'] if 'banner' in meta else None

			if not poster or poster == '0': poster = Theme.poster()
			if not thumb or thumb == '0': thumb = Theme.thumbnail()
			if not fanart or fanart == '0': fanart = Theme.fanart()
			if not banner or banner == '0': banner = Theme.banner()

			if not 'mediatype' in meta: meta.update({'mediatype': 'episode' if 'episode' in meta and meta['episode'] else 'movie'})

			return (poster, thumb, fanart, banner, meta)
		except: pass

		try:
			meta = self.metadataRetrieve(meta)

			poster = None
			try: poster = meta['show']['art']['poster']
			except:
				try: poster = meta['show']['thumbnail']
				except:
					try: poster = meta['art']['poster']
					except:
						try: poster = meta['thumbnail']
						except: pass

			thumb = None
			try: thumb = meta['thumbnail']
			except: thumb = poster

			fanart = None
			try: fanart = meta['art']['fanart']
			except:
				try: fanart = meta['fanart']
				except: pass

			banner = None
			try: banner = meta['art']['banner']
			except: banner = fanart

			return (poster, thumb, fanart, banner, meta)
		except: pass

		return (None, None, None, None, {'title': self.name})

	def metadataRetrieve(self, meta):
		result = None
		filter = {
			'or': [
				{'field': 'year', 'operator': 'is', 'value': str(self.year)},
				{'field': 'year', 'operator': 'is', 'value': str(self.year - 1)},
				{'field': 'year', 'operator': 'is', 'value': str(self.year + 1)}
			]
		}

		if self.typeMovie:
			try:
				metas = tools.System.executeJson(method = 'VideoLibrary.GetMovies',
					parameters = {
						'filter' : filter,
						'properties' : ['title', 'originaltitle', 'genre', 'year', 'rating', 'director', 'trailer', 'tagline', 'tag', 'plot', 'plotoutline', 'playcount', 'writer', 'studio', 'mpaa', 'country', 'runtime', 'votes', 'ratings', 'art', 'fanart', 'thumbnail', 'file', 'userrating', 'premiered', 'uniqueid']
					},
				)
				if 'result' in metas and 'movies' in metas['result']:
					result = self.metadataFilter(metas['result']['movies'])
					if result and not 'mediatype' in result: result.update({'mediatype' : 'movie'})
			except:
				tools.Logger.error()

		elif self.typeTelevision:
			try:
				metas = tools.System.executeJson(method = 'VideoLibrary.GetTVShows',
					parameters = {
						'filter' : filter,
						'properties' : ['title', 'originaltitle', 'year', 'uniqueid', 'file', 'art', 'thumbnail', 'fanart']
					},
				)
				if 'result' in metas and 'tvshows' in metas['result']:
					resultShow = self.metadataFilter(metas['result']['tvshows'])
					if resultShow:
						metas = tools.System.executeJson(method = 'VideoLibrary.GetEpisodes',
							parameters = {
								'tvshowid' : resultShow['tvshowid'],
								'filter' : {
									'and': [
										{'field': 'season', 'operator': 'is', 'value': self.seasonString},
										{'field': 'episode', 'operator': 'is', 'value': self.episodeString}
									]
								},
								'properties' : ['title', 'originaltitle', 'season', 'episode', 'showtitle', 'firstaired', 'rating', 'director', 'plot', 'playcount', 'writer', 'runtime', 'votes', 'ratings', 'art', 'fanart', 'thumbnail', 'file', 'userrating', 'uniqueid']
							},
						)
						if 'result' in metas and 'episodes' in metas['result']:
							result = metas['result']['episodes'][0]
							if result:
								if not 'mediatype' in result: result.update({'mediatype' : 'episode'})
								result['show'] = resultShow
			except:
				tools.Logger.error()

		if not 'plugin' in tools.System.infoLabel('Container.PluginName'): self.kodi = result
		return result

	def metadataFilter(self, metas):
		if self.idImdb:
			for meta in metas:
				try:
					if self.idImdb == meta['uniqueid']['imdb']: return meta
				except: pass

		if self.idTmdb:
			for meta in metas:
				try:
					if self.idTmdb == meta['uniqueid']['tmdb']: return meta
				except: pass

		if self.idTvdb:
			for meta in metas:
				try:
					if self.idTvdb == meta['uniqueid']['tvdb']: return meta
				except: pass

		if self.title and self.year:
			title = Title.clean(self.title)
			year = int(self.year)
			for meta in metas:
				try:
					if year == int(meta['year']) and (title == Title.clean(meta['title']) or title == Title.clean(meta['originaltitle'])): return meta
				except: pass

		return None

	def _showStreams(self):
		if (not self.binge or (self.binge and not self.bingeFinishedCheck)):
			if self.navigationStreamsSpecial and not self.autoplay:
				reload = tools.Settings.getInteger('interface.stream.interface.reload')
				if (reload == 1 or (reload == 2 and self.status == Player.StatusPaused)):
					# Reload streams in a separate process.
					# Otherwise we might end up in a long loop of play->reload->play->reload which might not clean up memory and increase the cahnce of running out of threads on low-end devices.
					#self.core.showStreams()
					self.core.showStreamsExternal(binge = self.binge, autoplay = self.autoplay)

	def _debridClear(self):
		debrid.Debrid.deletePlayback(link = self.url, source = self.source)

	def _downloadStop(self):
		self._downloadClear(delete = False)
		if not self.download == None:
			from lib.modules import downloader
			self.download.stop(cacheOnly = True)

	def _downloadClear(self, delete = True):
		try: self.dialog.close()
		except: pass

		if delete:
			thread = Pool.thread(target = playerDelete, args = (self,))
			thread.start()

	def _downloadUpdateSize(self):
		try:
			from lib.modules import downloader

			# Try using the progress from the downloader, since the below code mostly returns 0.
			# Through Python, you can get the total file size (including the empty padded space).

			file = xbmcvfs.File(self.url) # The file must be opened each time this function is called, otherwise it does not refrehs with the new content/size.
			current = self.download.sizeCompleted()
			if current > 0:
				self.sizeCurrent = current
			else:
				file.seek(self.sizeCurrent, 0)
				data = file.read(self.DownloadChunk)
				try: length = len(data)
				except: length = 0
				while not data == self.DownloadNull and not length == 0:
					self.sizeCurrent += self.DownloadFuture
					file.seek(self.sizeCurrent, 0)
					data = file.read(self.DownloadChunk)
					try: length = len(data)
					except: length = 0
			self.sizeTotal = max(self.sizeTotal, file.size())
			file.close()
			if self.sizeTotal > 0: self.sizeProgress = self.sizeCurrent / float(self.sizeTotal)
		except:
			pass
		return self.sizeProgress

	def _downloadUpdateTime(self):
		try: self.timeCurrent = max(self.timeCurrent, self.getTime())
		except: pass
		try: self.timeTotal = max(self.timeTotal, self.getTotalTime())
		except: pass

		if self.timeTotal > 0:
			self.timeProgress = self.timeCurrent / float(self.timeTotal)
		return self.timeProgress

	def _downloadProgressDifference(self):
		progressSize = self._downloadUpdateSize()
		progressTime = self._downloadUpdateTime()
		return max(0, progressSize - progressTime), progressSize

	def _downloadProgress(self):
		progress = ''
		if not self.download == None:
			from lib.modules import downloader
			progress = interface.Format.fontBold(interface.Translation.string(32403) + ': ')
			self.download.refresh()
			progress += self.download.progress()
			progress += ' - ' + self.download.speed() + interface.Format.newline()
		return progress

	def _downloadCheck(self):
		if self.download == None:
			return False

		# Ensures that only one process can access this function at a time. Otherwise this function is executed multiple times at the same time.
		if self.downloadCheck:
			return False

		# If the user constantly cancels the buffering dialog, the dialog will not be shown for the rest of the playback.
		if not self.bufferShow:
			return False

		try:
			self.downloadCheck = True

			# Close all old and other dialogs.
			# Leave this for now. Seems to actually close the cache dialog below.
			#xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
			#xbmc.executebuiltin('Dialog.Close(extendedprogressdialog,true)')
			#tools.Time.sleep(0.5) # Wait for the dialogs to close.

			# NB: The progress dialog pops up when the download is at 100%. Chack for the download progress (progressSize < 1).
			progressDifference, progressSize = self._downloadProgressDifference()
			if progressSize < 1 and progressDifference < self.DownloadThresholdStart or self.sizeCurrent < self.DownloadMinimum:
				paused = False
				try:
					if self.isPlaying():
						self.pause()
						paused = True
				except: pass

				title = interface.Translation.string(33368)
				message = interface.Translation.string(33369)
				interface.Core.create(type = interface.Core.TypeDownload, title = title, message = self._downloadProgress() + message, background = False)

				progressMinimum = progressDifference
				progressRange = self.DownloadThresholdStop - progressMinimum
				while progressSize < 1 and progressDifference < self.DownloadThresholdStop or self.sizeCurrent < self.DownloadMinimum:
					progress = max(1, int(((progressDifference - progressMinimum) / float(progressRange)) * 99))
					interface.Core.update(progress = progress, message = self._downloadProgress() + message)
					if interface.Core.canceled(): break
					tools.Time.sleep(1)
					if interface.Core.canceled(): break
					progressDifference, progressSize = self._downloadProgressDifference()

				canceled = interface.Core.canceled() # Will be reset after the dialog is closed below.
				interface.Core.update(progress = 100, message = message)
				interface.Core.close()
				tools.Time.sleep(0.2)

				if canceled:
					if self.isPlayback():
						self.bufferCounter += 1
						if self.bufferCounter % 3 == 0:
							if interface.Dialog.option(title = 33368, message = 33744):
								self.bufferShow = False
					else:
						self._downloadStop()
						return False

				try:
					if paused:
						self.pause() # Unpause
				except: pass

			self.downloadCheck = False
			return True
		except:
			tools.Logger.error()
			self.downloadCheck = False
			return False

	def _bingeDelay(self):
		if self.bingeDelay is None:
			self.bingeDelay = tools.Binge.delay()
			if self.bingeDelay == 0:
				try: self.bingeDelay = self.getTotalTime()
				except:
					try: self.bingeDelay = int(self.metadata['duration'])
					except: pass
				self.bingeDelay = 30 if self.bingeDelay == 0 else int(self.bingeDelay / 60.0)
				if tools.Binge.dialogFull(): self.bingeDelay = int(self.bingeDelay / 3.0)
				self.bingeDelay = min(90, self.bingeDelay)
		return self.bingeDelay

	def _bingeCheck(self):
		try:
			if self.binge:
				remaining = self.timeTotal - self.timeCurrent
				if not self.bingeFinishedScrape and remaining < Player.BingeTime:
					self.bingeFinishedScrape = True
					thread = Pool.thread(target = self._bingeScrape)
					thread.start()
				if not self.bingeFinishedCheck and self.bingeMetadata:
					if self.bingeDialogUpNext:
						if not self.bingeMetadata is None:
							# NB: AddonSignals cannot be called from a thread, otherwise the callback never fires.
							self.bingeFinishedCheck = True
							self._bingeUpNext()
					elif self.bingeDialogOverlay and remaining <= self._bingeDelay():
						self.bingeFinishedCheck = True
						self._bingeShow()
		except:
			tools.Logger.error()

	def _bingeScrape(self):
		try:
			from lib.indexers import episodes
			self.bingeMetadata = episodes.episodes().next(tvshowtitle = self.metadata['tvshowtitle'], year = self.metadata['year'], imdb = self.metadata['imdb'], tvdb = self.metadata['tvdb'], season = self.metadata['season'], episode = self.metadata['episode'])
			if self.bingeMetadata:
				tools.System.executePlugin(action = 'scrape', parameters = {
					'silent' : True,
					'type' : self.type,
					'kids' : self.kids,
					'binge' : tools.Binge.ModeBackground,
					'title' : self.bingeMetadata['title'],
					'tvshowtitle' : self.bingeMetadata['tvshowtitle'],
					'year' : self.bingeMetadata['year'],
					'imdb' : self.bingeMetadata['imdb'],
					'tvdb' : self.bingeMetadata['tvdb'],
					'season' : self.bingeMetadata['season'],
					'episode' : self.bingeMetadata['episode'],
					'premiered' : self.bingeMetadata['premiered'],
					'metadata' : tools.Converter.jsonTo(self.bingeMetadata),
				})
			elif not self.bingeSuppress:
				interface.Dialog.notification(title = 35580, message = 35587, icon = interface.Dialog.IconInformation)
		except:
			tools.Logger.error()

	def _bingeUpNext(self):
		episodeCurrent = {
			'episodeid' : tools.Media.titleUniversal(metadata = self.metadata),
			'tvshowid' : self.metadata['imdb'] if 'imdb' in self.metadata else '',
			'title' : self.metadata['title'] if 'title' in self.metadata else '',
			'showtitle' : self.metadata['tvshowtitle'] if 'tvshowtitle' in self.metadata else '',
			'season' : int(self.metadata['season']) if 'season' in self.metadata else '',
			'episode' : int(self.metadata['episode']) if 'episode' in self.metadata else '',
			'playcount' : self.metadata['playcount'] if 'playcount' in self.metadata else 0,
			'plot' : self.metadata['plot'] if ('plot' in self.metadata and not self.metadata['plot'] == '0') else '',
			'rating' : float(self.metadata['rating']) if ('rating' in self.metadata and not self.metadata['rating'] == '0') else 0,
			'firstaired' : self.metadata['premiered'] if ('premiered' in self.metadata and not self.metadata['premiered'] == '0') else '',
			'art' : {
				'tvshow.poster' : self.metadata['poster'] if ('poster' in self.metadata and not self.metadata['poster'] == '0') else '',
				'thumb' : self.metadata['thumb'] if ('thumb' in self.metadata and not self.metadata['thumb'] == '0') else '',
				'tvshow.fanart' : self.metadata['fanart'] if ('fanart' in self.metadata and not self.metadata['fanart'] == '0') else '',
				'tvshow.landscape' : self.metadata['landscape'] if ('landscape' in self.metadata and not self.metadata['landscape'] == '0') else self.metadata['banner'] if ('banner' in self.metadata and not self.metadata['banner'] == '0') else '',
				'tvshow.clearart' : self.metadata['clearart'] if ('clearart' in self.metadata and not self.metadata['clearart'] == '0') else '',
				'tvshow.clearlogo' : self.metadata['clearlogo'] if ('clearlogo' in self.metadata and not self.metadata['clearlogo'] == '0') else '',
			},
		}

		episodeNext = {
			'episodeid' : tools.Media.titleUniversal(metadata = self.bingeMetadata),
			'tvshowid' : self.bingeMetadata['imdb'] if 'imdb' in self.bingeMetadata else '',
			'title' : self.bingeMetadata['title'] if 'title' in self.bingeMetadata else '',
			'showtitle' : self.bingeMetadata['tvshowtitle'] if 'tvshowtitle' in self.bingeMetadata else '',
			'season' : int(self.bingeMetadata['season']) if 'season' in self.bingeMetadata else '',
			'episode' : int(self.bingeMetadata['episode']) if 'episode' in self.bingeMetadata else '',
			'playcount' : self.bingeMetadata['playcount'] if 'playcount' in self.bingeMetadata else 0,
			'plot' : self.bingeMetadata['plot'] if ('plot' in self.bingeMetadata and not self.bingeMetadata['plot'] == '0') else '',
			'rating' : float(self.bingeMetadata['rating']) if ('rating' in self.bingeMetadata and not self.bingeMetadata['rating'] == '0') else 0,
			'firstaired' : self.bingeMetadata['premiered'] if ('premiered' in self.bingeMetadata and not self.bingeMetadata['premiered'] == '0') else '',
			'art' : {
				'tvshow.poster' : self.bingeMetadata['poster'] if ('poster' in self.bingeMetadata and not self.bingeMetadata['poster'] == '0') else '',
				'thumb' : self.bingeMetadata['thumb'] if ('thumb' in self.bingeMetadata and not self.bingeMetadata['thumb'] == '0') else '',
				'tvshow.fanart' : self.bingeMetadata['fanart'] if ('fanart' in self.bingeMetadata and not self.bingeMetadata['fanart'] == '0') else '',
				'tvshow.landscape' : self.bingeMetadata['landscape'] if ('landscape' in self.bingeMetadata and not self.bingeMetadata['landscape'] == '0') else self.bingeMetadata['banner'] if ('banner' in self.bingeMetadata and not self.bingeMetadata['banner'] == '0') else '',
				'tvshow.clearart' : self.bingeMetadata['clearart'] if ('clearart' in self.bingeMetadata and not self.bingeMetadata['clearart'] == '0') else '',
				'tvshow.clearlogo' : self.bingeMetadata['clearlogo'] if ('clearlogo' in self.bingeMetadata and not self.bingeMetadata['clearlogo'] == '0') else '',
			},
		}

		infoNext = {
			'current_episode': episodeCurrent,
			'next_episode': episodeNext,
			'play_info': {},
		}

		try:
			import AddonSignals
			AddonSignals.sendSignal('upnext_data', infoNext, source_id = tools.System.id())
			AddonSignals.registerSlot('upnextprovider', tools.System.id() + '_play_action', self._bingeShowUpNext)
		except: tools.Logger.error()

	def _bingeShowUpNext(self, data):
		self.bingeContinue = True
		self._bingeShow()

	def _bingeShow(self):
		try:
			if self.binge and not self.bingeFinishedShow:
				self.bingeFinishedShow = True
				if not self.bingeDialogUpNext:
					self.bingeContinue = True
					if self.bingeSuppress:
						thread = Pool.thread(target = self._bingeSuppress)
						thread.start()
					if not self.bingeDialogNone:
						try: background = self.bingeMetadata['fanart'] if 'fanart' in self.bingeMetadata else self.bingeMetadata['fanart2'] if 'fanart2' in self.bingeMetadata else self.bingeMetadata['fanart3'] if 'fanart3' in self.bingeMetadata else None
						except: background = None
						try: poster = self.bingeMetadata['poster'] if 'poster' in self.bingeMetadata else self.bingeMetadata['poster2'] if 'poster2' in self.bingeMetadata else self.bingeMetadata['poster3'] if 'poster3' in self.bingeMetadata else None
						except: poster = None
						if self.bingeDialogFull:
							delay = self._bingeDelay()
							self.bingeContinue = window.WindowBingeFull.show(title = self.bingeMetadata['tvshowtitle'], season = self.bingeMetadata['season'], episode = self.bingeMetadata['episode'], duration = self.bingeMetadata['duration'], background = background, poster = poster, delay = delay)
						elif self.bingeDialogOverlay:
							try: delay = self.getTotalTime() - self.getTime()
							except: delay = 0
							self.bingeContinue = window.WindowBingeOverlay.show(title = self.bingeMetadata['tvshowtitle'], season = self.bingeMetadata['season'], episode = self.bingeMetadata['episode'], duration = self.bingeMetadata['duration'], background = background, poster = poster, delay = delay)
				if self.bingeContinue:
					if self.status == Player.StatusStopped:
						self._bingePlay()
					elif tools.Binge.actionContinue() == tools.Binge.ActionInterrupt:
						self.stop()
						self._bingePlay()
					else:
						self.bingePlay = True
				elif tools.Binge.actionCancel() == tools.Binge.ActionInterrupt:
					self.stop()
		except:
			tools.Logger.error()

	def _bingePlay(self):
		try:
			if self.binge and not self.bingeFinishedPlay:
				self.bingeFinishedPlay = True
				interface.Loader.show()

				# If the background scraping has not finished yet, show the scraping dialog of the current scrape process.
				# This should not happen often, but can happen if the device is really slow, not able to finish the scrape in 10 minutes, or if the user skips to the end of the video (eg: 10 seconds before the end of the video).
				if not self.core.propertyStatus() == self.core.StatusFinished:
					self.core.propertySilentSet(False)
				else:
					self.core.propertySilentSet('cancel')
					tools.System.executePlugin(action = 'scrape', parameters = {
						'type' : self.type,
						'kids' : self.kids,
						'binge' : tools.Binge.ModeContinue,
						'title' : self.bingeMetadata['title'],
						'tvshowtitle' : self.bingeMetadata['tvshowtitle'],
						'year' : self.bingeMetadata['year'],
						'imdb' : self.bingeMetadata['imdb'],
						'tvdb' : self.bingeMetadata['tvdb'],
						'season' : self.bingeMetadata['season'],
						'episode' : self.bingeMetadata['episode'],
						'premiered' : self.bingeMetadata['premiered'],
						'metadata' : tools.Converter.jsonTo(self.bingeMetadata),
					})
		except:
			tools.Logger.error()

	def _bingeSuppress(self):
		count = 0
		while count < 100:
			id = window.Window.current()
			if id > window.Window.IdMaximum and not window.Window.currentGaia():
				interface.Dialog.close(id)
				break
			count += 1
			tools.Time.sleep(0.1)

	def _closeFailure(self):
		# Close Kodi's "Playback Failed" dialog.

		# Do not check if the dialog is open first, since other dialogs (eg: Gaia stream connection dialog) might pop up on top, and then Kodi shows that dialog ID as being opened.
		#if window.Window.currentDialog(id = window.Window.IdWindowOk):
		#	window.Window.close(id = window.Window.IdWindowOk)

		window.Window.close(id = window.Window.IdWindowOk)

	def _errorId(self, imdb = None, tmdb = None, tvdb = None, season = None, episode = None, time = False):
		id = []
		if not imdb is None and not imdb == '' and not imdb == '0': id.append(imdb)
		elif not tmdb is None and not tmdb == '' and not tmdb == '0': id.append(tmdb)
		elif not tvdb is None and not tvdb == '' and not tvdb == '0': id.append(tvdb)
		if season: id.append(season)
		if episode: id.append(episode)
		if time: id.append(tools.Time.timestamp())
		return tools.Hash.sha1('_'.join([str(i) for i in id]))

	def _errorLog(self, finish = False):
		try:
			if self._errorSeparator: tools.Logger.log(self._errorSeparator)
			if finish: return
		except: pass

		id = self._errorId(imdb = self.idImdb, tmdb = self.idTmdb, tvdb = self.idTvdb, season = self.season, episode = self.episode, time = True) # Add time to always make unique.
		start = '[PLAYBACK %s /]' % id
		end = '[/ PLAYBACK %s]' % id

		self._errorLast = None
		self._errorSeparator = end
		self._errorExpression = '%s(.*?)(?:$|%s)' % (start.replace('[', '\[').replace(']', '\]').replace(' ', '\s').replace('/', '\/'), end.replace('[', '\[').replace(']', '\]').replace(' ', '\s').replace('/', '\/'))

		tools.Logger.log(start)

	def _errorCheck(self, force = False):
		# Kodi's internal player CURL can fail (eg: HTTP timeouts, HTTP errors, Cloudflare, etc).
		# These errors are not detectable in Python. None of the player functions, or even onPlayBackError(), give any indication to these kinds of errors.
		# The only way to detect them seems to be to read/process the log file.
		#	ERROR <general>: OpenDemuxStream - Error creating demuxer
		#	INFO <general>: CVideoPlayer::OnExit()
		#	INFO <general>: CVideoPlayer::CloseFile()
		#	INFO <general>: VideoPlayer: waiting for threads to exit
		#	INFO <general>: VideoPlayer: finished waiting
		# Or:
		#	VideoPlayer::OpenFile: https://somelink.com
		#	ERROR <general>: CCurlFile::Stat - Failed: Timeout was reached(28) for https://somelink.com
		#	INFO <general>: Creating InputStream
		#	ERROR <general>: CCurlFile::FillBuffer - Failed: Timeout was reached(28)
		#	ERROR <general>: CCurlFile::Open failed with code 0 for https://somelink.com:
		#	ERROR <general>: CCurlFile::Exists - Failed: Timeout was reached(28) for https://somelink.com/VIDEO_TS.IFO
		#	ERROR <general>: CCurlFile::Exists - Failed: Timeout was reached(28) for https://somelink.com/VIDEO_TS/VIDEO_TS.IFO
		#	ERROR <general>: CCurlFile::FillBuffer - Failed: Timeout was reached(28)
		#	ERROR <general>: CCurlFile::Open failed with code 0 for https://somelink.com:
		#	ERROR <general>: CFileCache::Open - <https://somelink.com> failed to open
		#	ERROR <general>: CVideoPlayer::OpenInputStream - error opening [https://somelink.com]
		#	INFO <general>: CVideoPlayer::OnExit()
		#	WARNING <general>: CDVDMessageQueue(player)::Put MSGQ_NOT_INITIALIZED
		#	INFO <general>: CVideoPlayer::CloseFile()
		#	INFO <general>: VideoPlayer: waiting for threads to exit
		#	INFO <general>: VideoPlayer: finished waiting

		try:
			current = tools.Time.timestamp() # Only check every few seconds, otherwise there is too much disk I/O.
			if force or not self._errorLast or (current - self._errorLast) >= 5:
				self._errorLast = current

				data = tools.Logger.data()
				if data:
					data = tools.Regex.extract(data = data, expression = self._errorExpression, flags = tools.Regex.FlagAllLines)
					if data: return tools.Regex.match(data = data, expression = 'VideoPlayer::OnExit')

		except: tools.Logger.error()
		return False

	def isVisible(self):
		return window.Window.visible(window.Window.IdWindowPlayer) or window.Window.visible(window.Window.IdWindowPlayerFull)

	def isPlayback(self, started = False):
		# Kodi often starts playback where isPlaying() is true and isPlayingVideo() is false, since the video loading is still in progress, whereas the play is already started.
		try: return self.isPlaying() and self.isPlayingVideo() and self.getTime() >= 0 and (not started or self.statusStarted)
		except: False

	def keepPlaybackWait(self, title, message, status, substatus1, substatus2, timeout):
		from lib.modules import core
		wasPlaying = False
		delay = 0.3
		iterations = int(timeout / delay)
		for i in range(0, iterations):
			self._closeFailure()

			if self.isPlaying(): wasPlaying = True
			elif wasPlaying: break # Was playing, but not anymore. This is when the video playback fails. Kodi for some reason does not trigger the onPlayBackError signal.

			if self.isPlayback() or self.error: break

			# Kodi sometimes does not fire the onPlayBackStopped/onPlayBackEnded events, causing the cleanup not to execute (eg: delete debrid file, reloading stream window, etc).
			# Seems to happen if the playback is manually stopped a few seconds after playback started.
			# This seems to be caused by deadlock (a Lock, from eg the Database class, was not released). This has been fixed, and this problem should not occur anymore.
			# If the problem reoccurs in the future, maybe it is better to use the threading option below, but start the thread globally before calling keepPlaybackAlive(), rather than calling it in this function.
			# Using _errorCheck() is inefficient, constantly reading from file.
			'''if self._errorCheck():
				if not self.status == Player.StatusStopped and not self.status == Player.StatusEnded: self.onPlayBackStopped()
				break'''
			'''def keepPlaybackCheck():
				while True:
					if tools.System.aborted() or (self.status == Player.StatusPlaying and not self.isPlaying()) or (self.status == Player.StatusStopped or self.status == Player.StatusEnded):
						if not self.status == Player.StatusStopped and not self.status == Player.StatusEnded: self.onPlayBackStopped()
						break
					tools.Time.sleep(0.5)
			Pool.thread(target = keepPlaybackCheck,start = True)'''

			if self.download is None:
				if self.core.progressPlaybackCanceled(): break
				interface.Loader.hide() # Busy icons pops up again in Kodi 18.
				progress = 50 + int((i / float(iterations)) * 50) # Only half the progress, since the other half is from sources __init__.py.
				self.core.progressPlaybackUpdate(progress = progress, title = title, message = message, status = status, substatus1 = substatus1, substatus2 = substatus2, total = self.retryTotal, remaining = self.retryRemaining, force = True)
			else:
				self._downloadCheck()
			tools.Time.sleep(delay)

	def keepPlaybackAlive(self):
		try:
			from lib.modules import core
			self._downloadCheck()

			tools.System.windowPropertyClear(Player.PropertyOverlay)

			if self.typeMovie:
				overlay = playcount.getMovieOverlay(playcount.getMovieIndicators(), self.idImdb)
			elif self.typeTelevision:
				overlay = playcount.getEpisodeOverlay(playcount.getShowIndicators(), self.idImdb, self.idTvdb, self.seasonString, self.episodeString)
			else:
				overlay = '6'

			title = interface.Translation.string(33451)
			status = interface.Translation.string(33452)
			substatus1 = interface.Translation.string(35474)
			substatus2 = interface.Translation.string(35303)
			message = self.retryMessage
			if not message == '':
				if interface.Core.background() and not self.core.progressPlaybackEnabled():
					message += ' - '
				else:
					message += '.' + interface.Format.newline()
			message += status
			interface.Loader.hide()

			self.core.progressPlaybackInitialize(title = title, message = message, metadata = self.metadata)
			timeout = tools.Settings.getCustom('playback.general.time')
			if not timeout: timeout = 600 # Technically unlimited.

			# Use a thread for Kodi 18, since the player freezes for a few seconds before starting playback.
			thread = Pool.thread(target = self.keepPlaybackWait, args = (title, message, status, substatus1, substatus2, timeout))
			thread.start()
			thread.join()

			if self.core.progressPlaybackCanceled():
				self.core.progressPlaybackClose()
				self.stop()
				self._debridClear()
				return True

			# Only show the notification if the player is not able to load the file at all.
			if not self.isPlayback():
				self.core.progressPlaybackUpdate(progress = 100, title = title, message = message, status = status, substatus1 = substatus1, substatus2 = substatus2)
				if self.retryRemaining > 0: tools.Time.sleep(self.retryDelay)
				self.stop()
				self.core.progressPlaybackUpdate(progress = 100, message = '', status = None, force = True) # Must be set to 100 for background dialog, otherwise it shows up in a later dialog.
				tools.System.windowPropertyClear(Player.PropertyOverlay)
				return False

			if self.resumeTime: self.resume(self.resumeTime, offset = True)

			#self.core.progressPlaybackClose()
			addLibrary = tools.Settings.getBoolean('library.general.watched')

			playbackEnd = 80
			if tools.Settings.getBoolean('playback.track.enabled'): playbackEnd = tools.Settings.getInteger('playback.track.end')
			playbackEnd = playbackEnd / 100.0

			streamsHas = False
			visibleWas = False

			if self.vpnMonitor: Vpn.killPlayback()
			while self.isPlayingVideo():
				self.timeTotal = self.getTotalTime()
				self.timeCurrent = self.getTime()

				# On some hosters (eg: VidLox), if videos are taken down, they replace it with a short 404 video clip.
				# If the video clip is below 30 seconds, assume it is not a valid one, and do not mark progress, binge watch, etc.
				if self.timeTotal and self.timeTotal > 30:
					try:
						watcher = (self.timeCurrent / self.timeTotal >= playbackEnd)
						value = tools.System.windowPropertyGet(Player.PropertyOverlay)

						if watcher and not value == '7':
							try: orionoid.Orionoid().streamVote(idItem = self.source['stream'].idOrionItem(), idStream = self.source['stream'].idOrionStream(), vote = orionoid.Orionoid.VoteUp)
							except: pass
							tools.System.windowPropertySet(Player.PropertyOverlay, '7')
							if self.typeMovie:
								playcount.markMovieDuringPlayback(imdb = self.idImdb, tmdb = self.idTmdb, watched = '7')
								if addLibrary: library.Library(type = self.typeMedia).add(title = self.title, year = self.year, imdb = self.idImdb, tmdb = self.idTmdb, metadata = self.metadata)
							else:
								playcount.markEpisodeDuringPlayback(imdb = self.idImdb, tvdb = self.idTvdb, season = self.seasonString, episode = self.episodeString, watched = '7')
								if addLibrary: library.Library(type = self.typeMedia).add(title = self.title, year = self.year, imdb = self.idImdb, tvdb = self.idTvdb, metadata = self.metadata)
						elif not watcher and not value == '6':
							tools.System.windowPropertySet(Player.PropertyOverlay, '6')
							# Gaia
							# Do not mark as unwatched, otherwise if the video was previously watched and later rewatched, if will mark it as unwatched when played the second time.
							# Trakt can set multiple watches so that you can track on how many times you watched something.
							#playcount.markMovieDuringPlayback(imdb = self.idImdb, tmdb = self.idTmdb, watched = '6')
							#playcount.markEpisodeDuringPlayback(imdb = self.idImdb, tvdb = self.idTvdb, season = self.seasonString, episode = self.episodeString, watched = '6')
					except: pass

					self.progressUpdate()
					self._bingeCheck()

				self.streamSubtitle()

				if self.navigationStreamsSpecial:
					for i in range(4):
						visible = self.isVisible()
						playback = self.isPlayback()
						if not visibleWas and visible: visibleWas = True
						if not streamsHas and playback and visibleWas and not visible:
							streamsHas = True
							self._showStreams()
						elif streamsHas and visible:
							streamsHas = False
							interface.Dialog.closeAll()
						if not self.download is None: self._downloadCheck()
						if i % 2 == 0: self.streamSubtitle()
						tools.Time.sleep(1)
				else:
					if self.download is None:
						tools.Time.sleep(2)
					else:
						for i in range(4):
							self._downloadCheck()
							tools.Time.sleep(0.5)

			tools.System.windowPropertyClear(Player.PropertyOverlay)
			return True
		except:
			tools.Logger.error()
			tools.System.windowPropertyClear(Player.PropertyOverlay)
			return False

	def progressRetrieve(self):
		if tools.Settings.getBoolean('playback.track.enabled') and tools.Settings.getInteger('playback.track.resume') > 0: self.progressThread = Pool.thread(target = self._progressRetrieve, start = True)
		else: self.progress = 0

	def _progressRetrieve(self):
		self.progress = self.playback.progress(media = self.typeMedia, imdb = self.idImdb, tmdb = self.idTmdb, tvdb = self.idTvdb, season = self.season, episode = self.episode, adjust = True)

	def progressUpdate(self, action = None):
		if self.progressInitialized and not self.progressBusy:
			if action is None:
				if self.status == Player.StatusPlaying: action = Playback.ActionStart
				elif self.status == Player.StatusPaused: action = Playback.ActionPause
				elif self.status == Player.StatusStopped or self.status == Player.StatusEnded: action = Playback.ActionStop
			if action: self.playback.progressUpdate(action = action, current = self.timeCurrent, duration = self.timeTotal, media = self.typeMedia, imdb = self.idImdb, tmdb = self.idTmdb, tvdb = self.idTvdb, season = self.season, episode = self.episode)

	def progressInitialize(self):
		try:
			if self.timeTotal == 0: self.timeTotal = self.getTotalTime()
			if self.timeCurrent == 0: self.timeCurrent = self.getTime()
		except:
			# When Kodi's player is not playing anything, it throws an exception when calling self.getTotalTime()
			return

		if not self.progressInitialized:
			self.progressInitialized = True
			self.progressBusy = True
			if self.progressThread:
				self.progressThread.join()
				self.progressThread = None

			if not self.resumeTime and self.progress > 0:
				if self.timeTotal > 0:
					paused = False
					seconds = self.progress * self.timeTotal
					if seconds > 0:
						if tools.Settings.getBoolean('playback.track.enabled'):
							resume = tools.Settings.getInteger('playback.track.resume')
							if resume == 2 or resume == 3:
								paused = True
								self.pause()
								timeMinutes, timeSeconds = divmod(float(seconds), 60)
								timeHours, timeMinutes = divmod(timeMinutes, 60)
								label = '%02d:%02d:%02d' % (timeHours, timeMinutes, timeSeconds)
								label = interface.Translation.string(32502) % label
								if resume == 3: label += ' ' + interface.Translation.string(34372)
								choice = interface.Dialog.option(title = 32344, message = label, labelConfirm = 32501, labelDeny = 32503, timeout = 10000 if resume == 3 else None)
								if choice: seconds = 0

					if seconds > 0: self.resume(seconds, offset = True)
					if paused:
						self.pause()
						tools.Time.sleep(0.1) # Otherwise the onPlaybackResumed() can fire AFTER self.progressBusy is reset below.

			self.progressBusy = False

		self.progressUpdate()

	def _updateLibrary(self):
		if self.kodi:
			try:
				try: playcount = self.kodi['playcount'] + 1
				except: playcount = 1

				if self.typeMovie: tools.System.executeJson(method = 'VideoLibrary.SetMovieDetails', parameters = {'movieid' : str(self.kodi['movieid']), 'playcount' : playcount})
				elif self.typeTelevision: tools.System.executeJson(method = 'VideoLibrary.SetEpisodeDetails', parameters = {'episodeid' : str(self.kodi['episodeid']), 'playcount' : playcount})

				interface.Directory.refresh()
			except:
				tools.Logger.error()

	def streamSelect(self):
		Audio.select() # Must be before subtitles, since the subtitles might need the current audio stream/language.
		Subtitle.select(name = self.name, imdb = self.idImdb, title = self.title, season = self.seasonString, episode = self.episodeString, source = self.source['stream'])

	def streamSubtitle(self):
		Subtitle.internal(name = self.name, imdb = self.idImdb, title = self.title, season = self.seasonString, episode = self.episodeString, source = self.source['stream'])

	def streamStop(self):
		Subtitle.stop()

	def resume(self, seconds, offset = False):
		self.seekTime(max(0, seconds - (Player.ResumeTime if offset else 0)))

	def onPlayBackStarted(self):
		tools.Logger.log('Playback Started')

		self.status = Player.StatusPlaying
		interface.Loader.hide()

		for i in range(0, 600):
			# Check "started" as well, otherwise the playback window is closed too quickly and the background menus are visible for a second.
			# It seems that Kodi fixed the issue that onAvStarted() was not called, should now be correctly executed.
			if self.isPlayback(started = True) or self.status == Player.StatusPaused: break
			tools.Time.sleep(0.1)
		interface.Dialog.closeAll()

		# Make sure progressInitialize() and streamSelect() are not executed at the same time.
		# Otherise the resume and subtitles dialog might pop up at the same time.
		self.progressInitialize()
		self.streamSelect()

	def onPlayBackPaused(self):
		tools.Logger.log('Playback Paused')

		self.status = Player.StatusPaused
		self.progressUpdate()

	def onPlayBackResumed(self):
		tools.Logger.log('Playback Resumed')

		self.status = Player.StatusPlaying
		self.progressUpdate()

	def onPlayBackStopped(self):
		tools.Logger.log('Playback Stopped')

		self.status = Player.StatusStopped

		self.progressUpdate()
		self.streamStop()

		self._downloadStop()
		self._debridClear()
		self._showStreams()

		if tools.System.windowPropertyGet(Player.PropertyOverlay) == '7':
			trakt.rateManual(imdb = self.idImdb, tvdb = self.idTvdb, season = self.season, episode = self.episode)
		if self.binge:
			if self.bingePlay:
				self._bingePlay()
			elif self.bingeDialogNone or self.bingeDialogFull:
				self._bingeShow()

	def onPlayBackEnded(self):
		tools.Logger.log('Playback Ended')

		self.onPlayBackStopped()
		self.status = Player.StatusEnded

		self._updateLibrary()
		self._downloadClear()
		self._debridClear()

	def onPlayBackError(self):
		tools.Logger.log('Playback Error')

		self.error = True

	def onAVStarted(self):
		self.statusStarted = True
		tools.Logger.log('Playback AV Started')

	def onAVChange(self):
		tools.Logger.log('Playback AV Changed')

	def onPlayBackSeek(self, time, seekOffset):
		tools.Logger.log('Playback Seek')
		self.progressUpdate()

	def onPlayBackSeekChapter(self, chapter):
		tools.Logger.log('Playback Seek Chapter')
		self.progressUpdate()


class Streamer(object):

	Player = None
	Language = None

	# Must correspond with settings.xml.
	LanguageAutomatic = 0
	LanguageCustom = 1

	@classmethod
	def id(self):
		return self.name().lower()

	@classmethod
	def name(self):
		return self.__name__

	@classmethod
	def player(self):
		if Streamer.Player is None: Streamer.Player = interface.Player()
		return Streamer.Player

	@classmethod
	def playerPause(self):
		player = self.player()
		if not player.status() == interface.Player.StatusPaused: player.pause()

	@classmethod
	def playerUnpause(self):
		player = self.player()
		if player.status() == interface.Player.StatusPaused: player.pause()

	@classmethod
	def streams(self, unknown = False):
		return self._streamRetrieve(retrieve = interface.Player.RetrieveAll, unknown = unknown)

	@classmethod
	def streamDefault(self, unknown = False):
		return self._streamRetrieve(retrieve = interface.Player.RetrieveDefault, unknown = unknown)

	@classmethod
	def streamCurrent(self, unknown = False):
		return self._streamRetrieve(retrieve = interface.Player.RetrieveCurrent, unknown = unknown)

	@classmethod
	def streamKnown(self, unknown = True):
		try:
			current = self.streamCurrent(unknown = unknown)
			if current:
				settings = self._settingsLanguage()
				if settings: return current['language'][tools.Language.Code][tools.Language.CodeStream] in settings
		except: tools.Logger.error()
		return False

	@classmethod
	def _streamRetrieve(self, retrieve, unknown = False):
		return self._stream(player = self.player(), retrieve = retrieve, process = True, unknown = self.language() if unknown is True else unknown if unknown else None)

	@classmethod
	def log(self, message, stream = None):
		message = '[%s] %s' % (self.name().upper(), message)
		if stream:
			if tools.Tools.isArray(stream): tools.Logger.log('%s: %s' % (message, ' | '.join(['%s (%s)' % (str(i['language'][tools.Language.Name][tools.Language.NameDefault] if i['language'] else None), str(i['name'] if i['name'] else None)) for i in stream])))
			else: tools.Logger.log('%s: %s (%s)' % (message, str(stream['language'][tools.Language.Name][tools.Language.NameDefault] if stream['language'] else None), str(stream['name'] if stream['name'] else None)))
		else:
			if not stream is None: message + ': None'
			tools.Logger.log(message)

	@classmethod
	def language(self):
		return Streamer.Language

	@classmethod
	def languageSet(self, language):
		Streamer.Language = tools.Language.language(language)

	@classmethod
	def _settingsLanguage(self, log = False):
		result = []

		setting = 'playback.%s.language' % self.id()
		if tools.Settings.getInteger(setting) == Streamer.LanguageAutomatic: languages = tools.Language.settings()
		else: languages = tools.Language.settingsCustoms(id = setting, code = False)

		# OpenSubtitles has variations or some languages.
		# Eg: Simplified vs traditional vs bilingual Chinese.
		# Eg: Standard vs Brazilian Portuguese.
		variations = tools.Language.variations()
		for language in languages:
			result.append(language)
			for variation in variations:
				if language[tools.Language.Code][tools.Language.CodePrimary] == variation[tools.Language.Original]:
					result.append(variation)

		if log:
			if result: values = ' | '.join([i[tools.Language.Name][tools.Language.NameDefault] for i in result])
			else: values = 'None'
			self.log('Language preferences: %s' % values)
		return [i[tools.Language.Code][tools.Language.CodeStream] for i in result]


class Audio(Streamer):

	# Must correspond with settings.xml.
	StreamDefault = 0
	StreamAutomatic = 1

	@classmethod
	def _stream(self, player, retrieve, process, unknown):
		return player.audioStream(retrieve = retrieve, process = process, unknown = unknown)

	@classmethod
	def select(self, unknown = False):
		try:
			settings = self._settingsLanguage(log = not unknown)
			streams = self.streams(unknown = unknown)
			current = self.streamCurrent(unknown = unknown)

			if not unknown: self.log('Available streams', streams if streams else [])

			if tools.Settings.getInteger('playback.audio.stream') == Audio.StreamDefault:
				self.log('Using default stream', current)
			elif not streams:
				self.log('No audio streams detected.')
			else:
				best = None
				for code in settings:
					for stream in streams:
						if code == stream['language'][tools.Language.Code][tools.Language.CodeStream]:
							if best is None:
								best = stream
							else:
								better = False
								if stream['channels'] and best['channels']:
									if stream['channels'] > best['channels']: better = True
									elif stream['bitrate'] and best['bitrate'] and stream['channels'] == best['channels'] and stream['bitrate'] > best['bitrate']: better = True
									if better and stream['name']: # Ingore commentary audio.
										lower = stream['name'].lower()
										if 'comment' in lower or 'director' in lower: better = False
								if better: best = stream
					if best: break
				if best:
					self.log('Using %s stream' % ('unknown' if unknown else 'preferred'), best)
					self.player().audioSelect(best)
				else:
					undefined = False
					if not unknown:
						for stream in streams:
							if stream['language'][tools.Language.Code][tools.Language.CodeDefault] == tools.Language.UniversalCode:
								undefined = True
								break
					if undefined:
						assumed = self.language()
						if assumed:
							self.log('Unknown stream detected. Assuming the language: ' + str(assumed[tools.Language.Name][tools.Language.NameDefault]))
							return self.select(unknown = True)

					self.log('No preferred stream detected. Falling back to default stream.')
					self.log('Using default stream', current)
		except: tools.Logger.error()


class Subtitle(Streamer):

	# Must correspond with settings.xml.
	StreamDisabled = 0
	StreamDefault = 1
	StreamForced = 2
	StreamAutomatic = 3
	StreamFixed = 4

	# Must correspond with settings.xml.
	SelectionManual = 0
	SelectionAutomatic = 1
	SelectionChoice = 2
	SelectionExact = 3

	# Must correspond with settings.xml.
	NotificationsDisabled = 0
	NotificationsStandard = 1
	NotificationsExtended = 2

	# Must correspond with settings.xml.
	DialogAutomatic = 0
	DialogPlain = 1
	DialogDetails = 2

	StatusCanceled = 'canceled'
	StatusLoaded = 'loaded'
	StatusFailed = 'failed'
	StatusError = 'error'
	StatusUnavailable = 'unavailable'
	StatusDisabled = 'disabled'
	StatusForced = 'forced'
	StatusDefault = 'default'
	StatusIntegrated = 'integrated'

	# Must correspond with the file names in script.gaia.resources.
	InternalDisable = 'GAIA Disable Subtitles'
	InternalSelect = 'GAIA Select Subtitles'
	InternalIntegrated = None
	InternalPrevious = None
	InternalValid = None
	InternalStop = None
	InternalInitial = None
	InternalExternal = None

	Lock = Lock()

	@classmethod
	def _stream(self, player, retrieve, process, unknown):
		return player.subtitleStream(retrieve = retrieve, process = process, unknown = unknown)

	@classmethod
	def _notification(self, title, message, icon = interface.Dialog.IconInformation, essential = True):
		notifications = tools.Settings.getInteger('playback.subtitle.notifications')
		if notifications == Subtitle.NotificationsExtended or (notifications == Subtitle.NotificationsStandard and essential):
			interface.Dialog.notification(title = title, message = message, icon = icon)

	@classmethod
	def _load(self, subtitle):
		success = False

		if subtitle['integrated']:
			self.player().subtitleSelect(id = subtitle['id'])
			success = True
			self.log('Integrated subtitles loaded: ' + subtitle['name'])
		else:
			# Issues with decoding the subtitles.
			# This means that the subtitles will not show at all, or show, but with a weird/incorrect encoding.
			decoded = 'decoded' in subtitle and subtitle['decoded'] is False

			if not 'path' in subtitle:
				from lib.modules.subtitle import Subtitle as Subtitler
				self.log('Downloading external subtitles.')
				subtitle = Subtitler.download(subtitle = subtitle)

			# Do not load if there were decoding problems.
			# Only do this the first time. If the user selects the subtitles a second time, just display them as is.
			if not decoded and 'decoded' in subtitle and subtitle['decoded'] is False:
				success = False
				self.log('Subtitles decoding failed.')
			elif 'path' in subtitle:
				self.player().subtitleSelect(path = subtitle['path'])
				success = True
				self.log('External subtitles loaded: ' + subtitle['name'])

		return success, subtitle

	@classmethod
	def stop(self):
		Subtitle.InternalStop = True

	@classmethod
	def internal(self, name, imdb, title, season, episode, source):
		# The process of detecting, downloading, and selecting subtitles can take some time.
		# This can cause this function to be executed again before the previous execution is done, since it is called in a loop.
		# Only allow a single execution of the select function() at any give time.
		if Subtitle.Lock.locked(): return

		# Make sure internal() only executes AFTER the initial select() is called once playback starts.
		if not Subtitle.InternalInitial: return

		# Reduce the load by only executing if the subtitles changed.
		current = self.streamCurrent()
		if current and not Subtitle.InternalPrevious == current:
			Subtitle.InternalPrevious = current
			if current['name'].startswith(Subtitle.InternalSelect): # Note that Kodi formats the filename of the subtitles, removes language codes, symbols, etc.
				self.select(name = name, imdb = imdb, title = title, season = season, episode = episode, source = source, internal = True)
			else:
				Subtitle.InternalValid = current # Last valid subtitles that are not InternalSelect.

	@classmethod
	def select(self, name, imdb, title, season, episode, source, wait = False, internal = False):
		thread = Pool.thread(target = self._select, kwargs = {'name' : name, 'imdb' : imdb, 'title' : title, 'season' : season, 'episode' : episode, 'source' : source, 'internal' : internal})
		thread.start()
		if wait: thread.join()

	@classmethod
	def _select(self, name, imdb, title, season, episode, source, internal = False):
		unpause = False
		try:
			if Subtitle.Lock.locked(): return None
			else: Subtitle.Lock.acquire()

			from lib.modules.subtitle import Subtitle as Subtitler

			settingsStream = tools.Settings.getInteger('playback.subtitle.stream')
			settingsSelection = tools.Settings.getInteger('playback.subtitle.selection')
			settingsDownload = tools.Settings.getBoolean('playback.subtitle.download')
			settingsNotifications = tools.Settings.getInteger('playback.subtitle.notifications')

			settingsDialog = tools.Settings.getInteger('playback.subtitle.dialog')
			if settingsDialog == Subtitle.DialogAutomatic: settingsDialog = Subtitle.DialogDetails if interface.Skin.supportDialogDetail() else Subtitle.DialogPlain

			settingsLanguage = self._settingsLanguage(log = True)
			if not settingsLanguage:
				assumed = tools.Language.language(tools.Language.EnglishCode)
				settingsLanguage = [assumed[tools.Language.Code][tools.Language.CodeStream]]
				self.log('No subtitle language preferences. Assuming the language: ' + str(assumed[tools.Language.Name][tools.Language.NameDefault]))

			player = self.player()
			streams = self.streams()
			current = self.streamCurrent()
			self.log('Available streams', streams if streams else [])

			pathDisable = tools.File.joinPath(tools.System.pathResources(), 'resources', 'media', 'subtitle', Subtitle.InternalDisable + '.srt')
			pathSelect = tools.File.joinPath(tools.System.pathResources(), 'resources', 'media', 'subtitle', Subtitle.InternalSelect + '.srt')
			if internal:
				settingsSelection = Subtitle.SelectionManual # Always manually select if the user opens the subtitle dialog again.
				player.subtitleSelect(path = pathDisable, enable = False)
				interface.Dialog.closeAll() # Close the Kodi subtitle dialog.
				tools.Time.sleep(0.1)
			else:
				# Use the cached integrated subtitles, otherwise newley downloaded subtitles will be listed as "integrated" in the dialog if opened again.
				if Subtitle.InternalIntegrated is None:
					if streams: Subtitle.InternalIntegrated = [Subtitler.process(data = i, integrated = True) for i in streams]
					else: Subtitle.InternalIntegrated = False

				player.subtitleSelect(path = pathDisable, enable = False)
				player.subtitleSelect(path = pathSelect, enable = False)
				player.subtitleSelect(path = pathDisable, enable = False) # Add again to make sure the "select" subtitle is not enabled/selected by default.

				# Kodi needs some time until subtitles are loaded from file. Wait, otherwise any other subtitle loading or info retrieval might be wrong.
				# This often results in "pathSelect" to show up in the Kodi player subtitle dialog as the selected subtitles, although the code later on loads a different subtitle.
				# NB: Just wiatimh: tools.Time.sleep(0.5), is sometimes not enough. Sometimes everything loads in a few ms, but sometimes we need more time. Check the subs instead.
				for i in range(30):
					loaded = 0
					loadedStreams = self.streams()
					if loadedStreams:
						for stream in loadedStreams:
							if stream['name'].startswith(Subtitle.InternalDisable) or stream['name'].startswith(Subtitle.InternalSelect):
								loaded += 1
								if loaded >= 2: break
						if loaded >= 2: break
					tools.Time.sleep(0.1)

				if current: player.subtitleSelect(id = current['id']) # Reset to default.

			if not internal:
				if settingsStream == Subtitle.StreamDisabled:
					player.subtitleDisable()
					self.log('Disabling subtitles.')
					return self._finish(status = Subtitle.StatusDisabled)
				elif settingsStream == Subtitle.StreamDefault:
					self.log('Leaving default subtitles.')
					return self._finish(status = Subtitle.StatusDefault, subtitle = current)
				elif settingsStream == Subtitle.StreamForced:
					if current and current['forced']:
						self.log('Leaving forced subtitles.')
						return self._finish(status = Subtitle.StatusForced, subtitle = current)
					else:
						player.subtitleDisable()
						self.log('Disabling subtitles.')
						return self._finish(status = Subtitle.StatusDisabled)
				elif settingsStream == Subtitle.StreamAutomatic:
					if Audio.streamKnown():
						if current and current['forced']:
							self.log('Audio stream known. Leaving forced subtitles.')
							return self._finish(status = Subtitle.StatusForced, subtitle = current)
						else:
							self.log('Audio stream known. Disabling subtitles.')
							player.subtitleDisable()
							return self._finish(status = Subtitle.StatusDisabled)

				if settingsSelection == Subtitle.SelectionExact or settingsSelection == Subtitle.SelectionAutomatic:
					# Already do this here, so that we can avoid a call to OpenSubtitles if we in any case use the integrated subtitles.
					if Subtitle.InternalIntegrated:
						for stream in Subtitle.InternalIntegrated:
							if stream['language'][tools.Language.Code][tools.Language.CodeStream] in settingsLanguage:
								success, _ = self._load(subtitle = stream)
								if success: return self._finish(status = Subtitle.StatusIntegrated, subtitle = stream)

			subtitles = []
			failure = False
			if Subtitle.InternalIntegrated: subtitles.extend(Subtitle.InternalIntegrated)
			if settingsDownload:
				# If external subtitles are loaded on the initial run, and reopened with InternalSelect, the dialog shows quickly, since the search results are cached.
				# However, if during the initital run integrated subtitles are selected and the user later selects InternalSelect, a new search is done which can take time.
				# Notify the user.
				if not Subtitle.InternalExternal and internal:
					unpause = True
					self.playerPause()
					self._notification(title = 36127, message = 36128, icon = interface.Dialog.IconInformation)
				Subtitle.InternalExternal = True

				self.log('Searching external subtitles.')
				subsubtitles = Subtitler.search(language = settingsLanguage, imdb = imdb, title = title, season = season, episode = episode)
				if subsubtitles: subtitles.extend(subsubtitles)
				elif subsubtitles is None: failure = True
			if len(subtitles) == 0: return self._finish(status = Subtitle.StatusUnavailable, notification = not failure, unpause = unpause) # OpenSubntitles error already showing if there were server issues.

			filename = source.fileName()
			year = source.metaYear()
			filenameLower = filename.lower()
			extensions = tools.Video.extensions(list = True, dot = True)
			for i in range(len(subtitles)):
				subtitle = subtitles[i]
				name = subtitle['name']
				nameLower = name.lower()

				# Match ratio.
				if subtitle['integrated']: match = 1.0
				elif filename and name:
					match = tools.Matcher.levenshtein(filename, name, ignoreCase = True, ignoreSpace = True, ignoreNumeric = False, ignoreSymbol = True)

					# Check if there is a perfect match with the extension removed.
					# Eg: "No.Time.to.Die.2021.720p.HDCAM.SLOTSLIGHTS" vs "No.Time.to.Die.2021.720p.HDCAM.SLOTSLIGHTS.mkv"
					if match < 1 and match > 0.75:
						filenameNew = filenameLower
						nameNew = nameLower

						for extension in extensions:
							if filenameNew.endswith(extension):
								filenameNew = filenameNew.rstrip(extension)
								nameNew = nameNew.rstrip(extension)
								matchNew = tools.Matcher.levenshtein(filenameNew, nameNew, ignoreCase = True, ignoreSpace = True, ignoreNumeric = False, ignoreSymbol = True)
								if matchNew >= 1: match = matchNew
								break

						# Some symbols that were replaced.
						# Eg: "No.Time.to.Die.1080p.AMZN.WEB-DL.DDP5.1.H.264-CMRG" vs "No Time to Die 1080p AMZN WEB-DL DDP5 1 H 264-CMRG"

						if match < 1 and match > 0.75:
							filenameNew = tools.Tools.replaceNotAlphaNumeric(data = filenameNew, replace = ' ')
							nameNew = tools.Tools.replaceNotAlphaNumeric(data = nameNew, replace = ' ')
							matchNew = tools.Matcher.levenshtein(filenameNew, nameNew, ignoreCase = True, ignoreSpace = True, ignoreNumeric = False, ignoreSymbol = True)
							if matchNew >= 1: match = matchNew

						# Sometimes the year is not included.
						# Eg: "No.Time.to.Die.1080p.AMZN.WEB-DL.DDP5.1.H.264-CMRG" vs "No Time to Die 2021 1080p AMZN WEB-DL DDP5 1 H 264-CMRG"
						if match < 1 and match > 0.75 and year:
							year = str(year)
							filenameNew = filenameNew.replace(year, '')
							nameNew = nameNew.replace(year, '')
							matchNew = tools.Matcher.levenshtein(filenameNew, nameNew, ignoreCase = True, ignoreSpace = True, ignoreNumeric = False, ignoreSymbol = True)
							if matchNew >= 1: match = matchNew

				else: match = 0.0
				subtitles[i]['match'] = match

				# Sort value.
				sort = match

				try:
					index = settingsLanguage.index(subtitle['language'][tools.Language.Code][tools.Language.CodeStream])
					if index >= 0: sort += (10 - index) * 1000
				except: pass
				if subtitle['integrated']: sort += 100000 # Make sure integrated subtitles are always on top.
				elif match == 1: sort += 100 # Make sure perfect matches are always on top.
				if subtitle['foreign']: sort += 0.15
				if subtitle['default']: sort += 0.1
				if subtitle['featured']: sort += 0.1
				if subtitle['trusted']: sort += 0.05
				if subtitle['impaired']: sort -= 0.05
				if subtitle['automatic']: sort -= 0.1
				if subtitle['defective']: sort -= 0.2
				try: sort += subtitle['rating'] * 0.3
				except: pass
				try: sort += min(1, subtitle['downloads'] / 10000.0) * 0.2
				except: pass
				try: sort += min(1, subtitle['votes'] / 1000.0) * 0.1
				except: pass
				subtitles[i]['sort'] = sort

			success = False
			subtitles = tools.Tools.listSort(data = subtitles, key = lambda i : i['sort'], reverse = True)

			if settingsSelection == Subtitle.SelectionChoice:
				self.playerPause()
				choice = interface.Dialog.options(title = 32353, message = 35144, labelConfirm = 33110, labelDeny = 33800, labelCustom = 33743)
				if choiceSelection == interface.Dialog.ChoiceCustom or choiceSelection == interface.Dialog.ChoiceCancelled:
					return self._finish(status = Subtitle.StatusCanceled, unpause = True)
				if choice == interface.Dialog.ChoiceYes:
					settingsSelection = Subtitle.SelectionManual
				elif choice == interface.Dialog.ChoiceNo:
					settingsSelection = Subtitle.SelectionAutomatic
					self.playerUnpause()

			if settingsSelection == Subtitle.SelectionExact:
				success = False
				for i in range(len(subtitles)):
					subtitle = subtitles[i]
					if subtitle['match'] >= 1 and subtitle['language'][tools.Language.Code][tools.Language.CodeStream] in settingsLanguage:
						success, subtitles[i] = self._load(subtitle = subtitle)
						if success: break
				if not success: settingsSelection = Subtitle.SelectionManual

			if settingsSelection == Subtitle.SelectionAutomatic:
				success = False
				for subtitle in subtitles:
					success = self._load(subtitle = subtitle)
					if success: break
				if not success: # Try again with decode-failed subtitles.
					for i in range(len(subtitles)):
						subtitle = subtitles[i]
						if 'decoded' in subtitle and subtitle['decoded'] is False:
							success, subtitles[i] = self._load(subtitle = subtitle)
							if success: break

			if settingsSelection == Subtitle.SelectionManual:
				details = settingsDialog == Subtitle.DialogDetails
				self.playerPause()
				while True:
					if Subtitle.InternalStop: break # Eg: User stopped the video before the subtitle dialog shows up.
					choice = interface.Dialog.select(title = 32353, items = self._items(subtitles = subtitles, details = details), details = details)
					if choice < 0: return self._finish(status = Subtitle.StatusCanceled, unpause = True)
					subtitle = subtitles[choice]
					success, subtitle = self._load(subtitle = subtitle)
					subtitles[choice] = subtitle
					if success: break
					elif 'decoded' in subtitle and subtitle['decoded'] is False: self._notification(title = 35860, message = 35861, icon = interface.Dialog.IconWarning)

			return self._finish(status = Subtitle.StatusLoaded if success else Subtitle.StatusFailed, subtitle = subtitle, unpause = True)
		except:
			tools.Logger.error()
			return self._finish(status = Subtitle.StatusError, unpause = unpause)

	@classmethod
	def _items(self, subtitles, details):
		items = []
		directory = interface.Directory()
		gradient = interface.Format.colorGradientIncrease(count = 1000)

		iconDown = interface.Format.iconDown(bold = True)
		if details: supportIcon = interface.Skin.supportDialogDetailIcon(default = True)
		else: supportIcon = True

		for i in range(len(subtitles)):
			subtitle = subtitles[i]

			# Flag icon.
			icon = tools.Language.flag(subtitle['language'][tools.Language.Code][tools.Language.CodePrimary], quality = interface.Icon.QualityLarge if supportIcon else interface.Icon.QualitySmall, subtitle = not subtitle['integrated'])

			# Label line 1.
			label = subtitle['name']
			defective = subtitle['defective'] or ('decoded' in subtitle and subtitle['decoded'] is False)
			if not label: label = interface.Format.fontItalic(interface.Translation.string(35248))
			if defective: label = interface.Format.fontItalic(label)

			# Label line 2.
			info = []
			if subtitle['integrated'] and tools.Language.NameUniversal in subtitle['language'][tools.Language.Name]: language = subtitle['language'][tools.Language.Name][tools.Language.NameUniversal]
			else: language = subtitle['language'][tools.Language.Name][tools.Language.NameDefault]
			info.append(interface.Format.fontBold(language))
			if subtitle['format']: info.append(subtitle['format'])
			if subtitle['integrated']: info.append(interface.Format.fontColor(33336, color = interface.Format.colorExcellent()))
			if defective: info.append(interface.Format.fontColor(35360, color = interface.Format.colorBad()))
			match = subtitle['match']
			if match >= 1.0: matchLabel = 36107
			elif match >= 0.75: matchLabel = 36108
			elif match >= 0.50: matchLabel = 36109
			else: matchLabel = 36110
			info.append(interface.Format.fontColor('%s (%.0f%%)' % (interface.Translation.string(matchLabel), match * 100), color = interface.Format.colorGradientPick(value = match * 1000, gradient = gradient)))
			if subtitle['automatic']: info.append(interface.Format.fontColor(35432, color = interface.Format.colorBad()))
			if subtitle['featured']: info.append(interface.Format.fontColor(35505, color = interface.Format.colorAlternative()))
			if subtitle['trusted']: info.append(interface.Format.fontColor(35531, color = interface.Format.colorAlternative()))
			if subtitle['impaired']: info.append(interface.Format.fontColor(33922, color = interface.Format.colorSpecial()))
			if subtitle['foreign']: info.append(interface.Format.fontColor(35414, color = interface.Format.colorSpecial()))
			if subtitle['default']: info.append(interface.Format.fontColor(33564, color = interface.Format.colorSpecial()))
			if not subtitle['rating'] is None:
				rating = interface.Format.iconRating(count = max(1, tools.Math.roundUp(subtitle['rating'] * 5)), color = interface.Format.colorGradientPick(value = subtitle['rating'] * 100, gradient = gradient))
				if not subtitle['integrated']: rating += ' (%s)' % tools.Math.thousand(subtitle['votes'] if subtitle['votes'] else 0)
				info.append(rating)
			if not subtitle['downloads'] is None:
				info.append(interface.Format.fontColor('%s%s' % (iconDown, tools.Math.thousand(subtitle['downloads'])), color = interface.Format.colorGradientPick(value = subtitle['downloads'] / 6.0, gradient = gradient)))
			info = interface.Format.iconJoin(info, pad = '  ')

			if details:
				if (subtitle['integrated'] or subtitle['match'] >= 1): label = interface.Format.fontBold(label)
				label2 = info
			else:
				label = interface.Format.iconJoin([info, label])
				label2 = None

			items.append(directory.item(label = label, label2 = label2, icon = icon))

		return items

	@classmethod
	def _finish(self, status, subtitle = False, unpause = False, notification = True):
		if notification:

			if not subtitle is False:
				if subtitle:
					name = subtitle['name']
					if not name: name = interface.Format.fontItalic(interface.Translation.string(35248))
					subtitle = interface.Format.iconJoin([interface.Format.fontBold(subtitle['language'][tools.Language.Name][tools.Language.NameDefault]), name])
				else: subtitle = 36122

			if status == Subtitle.StatusLoaded: self._notification(title = 35140, message = subtitle, icon = interface.Dialog.IconSuccess)
			elif status == Subtitle.StatusFailed: self._notification(title = 35145, message = 36117, icon = interface.Dialog.IconWarning)
			elif status == Subtitle.StatusUnavailable: self._notification(title = 35145, message = 35146, icon = interface.Dialog.IconWarning)
			elif status == Subtitle.StatusDisabled: self._notification(title = 36118, message = 36119, icon = interface.Dialog.IconInformation, essential = False)
			elif status == Subtitle.StatusForced: self._notification(title = 36120, message = subtitle, icon = interface.Dialog.IconInformation, essential = False)
			elif status == Subtitle.StatusDefault: self._notification(title = 36121, message = subtitle, icon = interface.Dialog.IconInformation, essential = False)
			elif status == Subtitle.StatusIntegrated: self._notification(title = 35549, message = subtitle, icon = interface.Dialog.IconInformation, essential = False)
			elif status == Subtitle.StatusError: self._notification(title = 36123, message = 36124, icon = interface.Dialog.IconError)

		# Reset to the previously selected subtitles before the user selected InternalSelect.
		if status == Subtitle.StatusCanceled:
			if Subtitle.InternalValid: self.player().subtitleSelect(id = Subtitle.InternalValid['id'])

		if unpause: self.playerUnpause()

		try: Subtitle.Lock.release()
		except: pass

		Subtitle.InternalInitial = True

		return status
