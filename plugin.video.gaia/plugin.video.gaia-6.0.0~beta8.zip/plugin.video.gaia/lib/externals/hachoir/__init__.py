VERSION = (3, 1, 2)
__version__ = ".".join(map(str, VERSION))
