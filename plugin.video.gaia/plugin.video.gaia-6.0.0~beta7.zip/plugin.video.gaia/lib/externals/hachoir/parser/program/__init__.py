from lib.externals.hachoir.parser.program.elf import ElfFile  # noqa
from lib.externals.hachoir.parser.program.exe import ExeFile  # noqa
from lib.externals.hachoir.parser.program.macho import MachoFile, MachoFatFile  # noqa
from lib.externals.hachoir.parser.program.python import PythonCompiledFile  # noqa
from lib.externals.hachoir.parser.program.java import JavaCompiledClassFile  # noqa
from lib.externals.hachoir.parser.program.prc import PRCFile  # noqa
from lib.externals.hachoir.parser.program.nds import NdsFile  # noqa
from lib.externals.hachoir.parser.program.java_serialized import JavaSerializedFile  # noqa
