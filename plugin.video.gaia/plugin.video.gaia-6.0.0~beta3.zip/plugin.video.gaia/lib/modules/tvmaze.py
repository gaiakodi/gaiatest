# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import json
from lib.modules import cache
from lib.modules import tools
from lib.modules import network
from lib.modules.parser import Raw

class tvMaze:
	def __init__(self, show_id = None):
		self.api_url = 'http://api.tvmaze.com/%s%s'
		self.show_id = show_id


	def showID(self, show_id = None):
		if (show_id != None):
			self.show_id = show_id
			return show_id

		return self.show_id


	def request(self, endpoint, query = None):
		try:
			# Encode the queries, if there is any...
			if (query != None):
				query = '?' + network.Networker.linkEncode(query)
			else:
				query = ''

			# Make the request
			url = self.api_url % (endpoint, query)

			# Send the request and get the response
			# Get the results from cache if available
			result = cache.Cache.instance().cacheMedium(network.Networker().requestJson, link = url)

			# Retrun the result as a dictionary
			return result
		except:
			pass

		return {}


	def showLookup(self, type, id):
		try:
			result = self.request('lookup/shows', {type: id})

			# Storing the show id locally
			if ('id' in result):
				self.show_id = result['id']

			return result
		except:
			pass

		return {}


	def shows(self, show_id = None, embed = None):
		try:
			if (not self.showID(show_id)):
				raise Exception()

			result = self.request('shows/%d' % self.show_id)

			# Storing the show id locally
			if ('id' in result):
				self.show_id = result['id']

			return result
		except:
			pass

		return {}


	def showSeasons(self, show_id = None):
		try:
			if (not self.showID(show_id)):
				raise Exception()

			result = self.request('shows/%d/seasons' % int( self.show_id ))

			if (len(result) > 0 and 'id' in result[0]):
				return result
		except:
			pass

		return []


	def showSeasonList(self, show_id):
		return {}


	def showEpisodeList(self, show_id = None, specials = False):
		try:
			if (not self.showID(show_id)):
				raise Exception()

			result = self.request('shows/%d/episodes' % int( self.show_id ), 'specials=1' if specials else '')

			if (len(result) > 0 and 'id' in result[0]):
				return result
		except:
			pass

		return []


	@classmethod
	def getTVShowTranslation(self, thetvdb, lang):
		try:
			from lib.metadata.manager import Manager
			return Manager(Manager.ProviderTvdb).translation(idTvdb = thetvdb, language = lang, limit = 1)
		except:
			pass
