import re
import json
import time
import operator

from lib import debrid
from lib.modules import interface
from lib.modules import network
from lib.modules import tools
from lib.modules.parser import Parser
from lib.modules.concurrency import Pool, Lock
#from lib.providers import provider as providerx #gaiaremove

# Verify account and provider access.

class Verification(object):

	# Keep order for sorting.
	StatusFailure = 0
	StatusLimited = 1
	StatusCloudflare = 2
	StatusOperational = 3
	StatusDisabled = 4

	def __init__(self):
		self.mResults = []
		self.mLock = Lock()

	def verifyAccounts(self):
		type = 'accounts'
		try:
			progressDialog = interface.Dialog.progress(33018, title = 33018)
			progressDialog.update(0, self.__info(type, True))

			threads = self.__threads()
			[i.start() for i in threads]
			timeout = 30
			for i in range(0, timeout * 2):
				try:
					if tools.System.aborted(): return tools.System.exit()
					try:
						if progressDialog.iscanceled(): break
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 50), self.__info(type, True))
					except:
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 50), self.__info(type, True))
					if all(i == False for i in [j.is_alive() for j in threads]): break
					time.sleep(0.5)
				except:
					pass

			# Run all thread a second & third time, because sometimes the request fails for some reason. Try a second time.
			# Do not run all threads at once, need some time inbetween the same requests.
			# Operational accounts are not checked again.

			threads = self.__threads()
			[i.start() for i in threads]
			timeout = 30
			for i in range(0, timeout * 2):
				try:
					if tools.System.aborted(): return tools.System.exit()
					try:
						if progressDialog.iscanceled(): break
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 25) + 50, self.__info(type, True))
					except:
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 25) + 50, self.__info(type, True))
					if all(i == False for i in [j.is_alive() for j in threads]): break
					time.sleep(0.5)
				except:
					pass

			canceled = False
			threads = self.__threads()
			[i.start() for i in threads]
			timeout = 30
			for i in range(0, timeout * 2):
				try:
					if tools.System.aborted(): return tools.System.exit()
					try:
						if progressDialog.iscanceled():
							canceled = True
							break
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 25) + 75, self.__info(type, True))
					except:
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 25) + 75, self.__info(type, True))
					if all(i == False for i in [j.is_alive() for j in threads]): break
					time.sleep(0.5)
				except:
					pass

			try: progressDialog.close()
			except: pass

			self.__showResults(type)
		except:
			tools.Logger.error()
			self.__showError(type)

	def verifyProviders(self, dialog = True): #gaiaremove
		type = 'providers'
		try:
			from lib.modules import core
			from lib.providers.core.base import ProviderBase

			progressDialog = interface.Dialog.progress(33019, title = 33019)
			progressDialog.update(0, self.__info(type, False))

			timeout = ProviderBase.limitTimeout()

			# Add imdb for providers like YIFY who dependt on that.
			itemsMovies = [
				{'title' : 'Titanic', 'year' : '1997', 'imdb' : 'tt0120338'},
				{'title' : 'Avatar', 'year' : '2009', 'imdb' : 'tt0499549'},
				{'title' : 'Star Wars', 'year' : '1977', 'imdb' : 'tt0076759'},
				{'title' : 'Harry Potter', 'year' : '2001', 'imdb' : 'tt0241527'},
			]
			itemsShows = [
				{'tvshowtitle' : 'The Big Bang Theory', 'season' : '10', 'episode' : '1', 'imdb' : 'tt0898266'},
				{'tvshowtitle' : 'Game of Thrones', 'season' : '6', 'episode' : '10', 'imdb' : 'tt0944947'},
				{'tvshowtitle' : 'Rick and Morty', 'season' : '2', 'episode' : '10', 'imdb' : 'tt2861424'},
				{'tvshowtitle' : 'The Sopranos', 'season' : '6', 'episode' : '1', 'imdb' : 'tt0141842'}
			]

			sourcesObject = core.Core()
			sourcesObject.getConstants()
			hosters = sourcesObject.hosters
			hostersPremium = sourcesObject.hostersPremium

			providerx.Provider.initialize(forceAll = True) # Make sure all disabled providers show during verification.
			providers = providerx.Provider.providers(enabled = False, local = False)
			threads = []

			#gaiaremove
			'''developers = tools.System.developer()
			developersCode = tools.System.developerCode()
			for provider in providers:
				# Do not include developer providers
				if not developers:
					visible = tools.Settings.raw(id = provider['id'], parameter = 'visible')
					if visible and developersCode in visible:
						continue
					if provider['id'] == 'rarbg':
						continue

				items = []
				if provider['group'] == providerx.Provider.GroupMovies:
					items = itemsMovies
				elif provider['group'] == providerx.Provider.GroupTvshows:
					items = itemsShows
				else:
					items = itemsMovies[:int(len(itemsMovies)/2)] + itemsShows[:int(len(itemsShows)/2)]

				threads.append(Pool.thread(target = self.__verifyProvider, args = (provider, items, hosters, hostersPremium)))
			'''
			canceled = False
			[i.start() for i in threads]
			for i in range(0, timeout * max(len(itemsMovies), len(itemsShows)) * 2):
				try:
					if tools.System.aborted(): return tools.System.exit()
					if progressDialog.iscanceled():
						canceled = True
						break
					disabled = self.__count(disabled = True)
					progressDialog.update(int(((len([i for i in threads if i.is_alive() == False]) - disabled) / float(len(threads) - disabled)) * 100), self.__info(type, False))
					if all(i == False for i in [j.is_alive() for j in threads]): break
					time.sleep(0.5)
				except:
					pass

			# Providers still running.
			for i in range(len(threads)):
				if threads[i].is_alive():
					self.__append(id = providers[i]['id'], name = providers[i]['name'], status = Verification.StatusFailure)

			try: progressDialog.close()
			except: pass

			if dialog:
				self.__showResults(type)
				if interface.Dialog.option(title = 33019, message = 35458):
					countSuccess = 0
					countFailure = 0
					for i in self.mResults:
						if i['status'] == Verification.StatusFailure:
							providerx.Provider.disable(i['id'])
							countFailure += 1
						elif i['status'] == Verification.StatusOperational or i['status'] == Verification.StatusLimited:
							countSuccess += 1
						else:
							countFailure += 1
					interface.Dialog.notification(title = 33019, message = interface.Translation.string(35459) % (countSuccess, countFailure), icon = interface.Dialog.IconSuccess)

			return self.mResults
		except:
			tools.Logger.error()
			self.__showError(type)

	def __verifyProvider(self, provider, items, hosters, hostersPremium):
		status = Verification.StatusFailure
		try:
			if provider['enabled']:
				object = provider['object']
				link = provider['link']
				if link:
					networker = network.Networker()
					data = networker.request(link = link)
					dataText = networker.responseDataText()
					if data['error']['type'] == network.Networker.ErrorCloudflare:
						status = Verification.StatusCloudflare
					else:
						success = dataText and (data['success'] or (provider['id'] == 'torrentapi' and data['error']['code'] == 403) or (provider['id'] == 'popcorntime' and data['error']['code'] == 404))
						if not success: # Just in case, try a second time.
							networker = network.Networker()
							data = networker.request(link = link)
							success = dataText and (data['success'] or (provider['id'] == 'torrentapi' and data['error']['code'] == 403) or (provider['id'] == 'popcorntime' and data['error']['code'] == 404))
						if success:
							status = Verification.StatusLimited
							try:
								functionVerify = getattr(object, 'verify')
								if callable(functionVerify) and functionVerify():
									status = Verification.StatusOperational
							except:
								for item in items:
									linkProvider = network.Networker.linkEncode(item)
									result = object.sources(linkProvider, hosters, hostersPremium)

									# In case the first domain fails, try the other ones in the domains list.
									if len(result) == 0 and tools.System.developer() and tools.Settings.getBoolean('scrape.mirror.domain'):
										checked = [link]
										for link in provider['links']:
											object.base_link = link
											result = object.sources(linkProvider, hosters, hostersPremium)
											if len(result) > 0:
												break

									if len(result) > 0:
										status = Verification.StatusOperational
										break
			else:
				status = Verification.StatusDisabled
		except:
			pass
		self.__append(id = provider['id'], name = provider['label'], status = status)

	def __info(self, type, inProgress, list = False):
		try:
			if inProgress:
				results = [i for i in self.mResults if not i['status'] == Verification.StatusFailure] # Because the second retry may solve this.
			else:
				results = self.mResults

			results = sorted(results, key = operator.itemgetter('status', 'name')) # Sort

			percentageOperational = 0
			percentageLimited = 0
			percentageCloudflare = 0
			percentageFailure = 0
			percentageDisabled = 0
			if len(results) > 0:
				percentageFailure = int(round(len([i for i in results if i['status'] == Verification.StatusFailure]) / (len(results) / 100.0)))
				percentageLimited = int(round(len([i for i in results if i['status'] == Verification.StatusLimited]) / (len(results) / 100.0)))
				percentageCloudflare = int(round(len([i for i in results if i['status'] == Verification.StatusCloudflare]) / (len(results) / 100.0)))
				percentageDisabled = int(round(len([i for i in results if i['status'] == Verification.StatusDisabled]) / (len(results) / 100.0)))
				percentageOperational = 100 - percentageFailure - percentageLimited - percentageCloudflare - percentageDisabled # Always calculate in case of rounding errors, must add up to 100.

			if list:
				list = []
				list.append(interface.Translation.string(33025) + ': ' + interface.Format.fontColor('%.0f%%' % min(100, max(0, percentageOperational)), interface.Format.colorExcellent()))
				list.append(interface.Translation.string(33024) + ': ' + interface.Format.fontColor('%.0f%%' % min(100, max(0, percentageLimited)), interface.Format.colorMedium()))
				list.append(interface.Translation.string(35689) + ': ' + interface.Format.fontColor('%.0f%%' % min(100, max(0, percentageCloudflare)), interface.Format.colorPoor()))
				list.append(interface.Translation.string(33023) + ': ' + interface.Format.fontColor('%.0f%%' % min(100, max(0, percentageFailure)), interface.Format.colorBad()))
				list.append(interface.Translation.string(33022) + ': ' + interface.Format.fontColor('%.0f%%' % min(100, max(0, percentageDisabled)), interface.Format.colorMain()))
				list.append('')
				for result in results:
					list.append(result['name'] + ': ' + self.__color(result['status']))
				return list
			else:
				status = ''
				for result in results:
					status += interface.Format.fontNewline() + '     ' + result['name'] + ': ' + self.__color(result['status'])
				message = interface.Translation.string(33025) + ': ' + interface.Format.fontColor('%.0f%%' % min(100, max(0, percentageOperational)), interface.Format.colorExcellent())
				message += ', ' + interface.Translation.string(33024) + ': ' + interface.Format.fontColor('%.0f%%' % min(100, max(0, percentageLimited)), interface.Format.colorMedium())
				message += ', ' + interface.Translation.string(35689) + ': ' + interface.Format.fontColor('%.0f%%' % min(100, max(0, percentageCloudflare)), interface.Format.colorPoor())
				message += ', ' + interface.Translation.string(33023) + ': ' + interface.Format.fontColor('%.0f%%' % min(100, max(0, percentageFailure)), interface.Format.colorBad())
				message += ', ' + interface.Translation.string(33022) + ': ' + interface.Format.fontColor('%.0f%%' % min(100, max(0, percentageDisabled)), interface.Format.colorMain())
				return message + status
		except:
			tools.Logger.error()

	def __showResults(self, type):
		interface.Dialog.select(self.__info(type, False, list = True), title = 33020)

	def __showError(self, type):
		if type == 'accounts':
			message = interface.Translation.string(33026)
		elif type == 'providers':
			message = interface.Translation.string(33027)
		interface.Dialog.notification(message, icon = interface.Dialog.IconError, title = 33021)

	def __isUrl(self, url):
		return url.startswith('http://') or url.startswith('https://') or url.startswith('ftp://')

	def __threads(self):
		threads = []

		threads.append(Pool.thread(target = self._verifyAccountsFanart))

		threads.append(Pool.thread(target = self._verifyAccountsTrakt))
		threads.append(Pool.thread(target = self._verifyAccountsImdb))
		threads.append(Pool.thread(target = self._verifyAccountsTmdb))

		threads.append(Pool.thread(target = self._verifyAccountsOpensubtitles))
		threads.append(Pool.thread(target = self._verifyAccountsYoutube))

		threads.append(Pool.thread(target = self._verifyAccountsPremiumize))
		threads.append(Pool.thread(target = self._verifyAccountsOffcloud))
		threads.append(Pool.thread(target = self._verifyAccountsRealdebrid))
		threads.append(Pool.thread(target = self._verifyAccountsAlldebrid))
		threads.append(Pool.thread(target = self._verifyAccountsRapidPremium))
		threads.append(Pool.thread(target = self._verifyAccountsEasynews))

		threads.append(Pool.thread(target = self._verifyAccountsTorrentLeech))

		threads.append(Pool.thread(target = self._verifyAccountsNzbfinder))
		threads.append(Pool.thread(target = self._verifyAccountsUsenetcrawler))
		threads.append(Pool.thread(target = self._verifyAccountsNzbndx))
		threads.append(Pool.thread(target = self._verifyAccountsNzbgeek))

		#threads.append(Pool.thread(target = self._verifyAccountsAlluc))
		#threads.append(Pool.thread(target = self._verifyAccountsProntv))

		#threads.append(Pool.thread(target = self._verifyAccountsT411))
		threads.append(Pool.thread(target = self._verifyAccountsYggtorrent))

		threads.append(Pool.thread(target = self._verifyAccountsEmby))
		threads.append(Pool.thread(target = self._verifyAccountsJellyfin))

		return threads

	def __enabled(self, entry):
		return tools.Settings.getBoolean(entry)

	def __color(self, status):
		if status == Verification.StatusDisabled:
			return interface.Format.fontColor(interface.Translation.string(33022), interface.Format.colorMain())
		elif status == Verification.StatusFailure:
			return interface.Format.fontColor(interface.Translation.string(33023), interface.Format.colorBad())
		elif status == Verification.StatusCloudflare:
			return interface.Format.fontColor(interface.Translation.string(35689), interface.Format.colorPoor())
		elif status == Verification.StatusLimited:
			return interface.Format.fontColor(interface.Translation.string(33024), interface.Format.colorMedium())
		elif status == Verification.StatusOperational:
			return interface.Format.fontColor(interface.Translation.string(33025), interface.Format.colorExcellent())

	def __append(self, name, status, id = None):
		self.mLock.acquire()
		if any(i['name'] == name for i in self.mResults):
			for i in range(0, len(self.mResults)):
				if self.mResults[i]['name'] == name:
					if self.mResults[i]['status'] == Verification.StatusFailure:
						self.mResults[i]['status'] = status
					break
		else:
			self.mResults.append({'id' : id, 'name' : name, 'status' : status})
		self.mLock.release()
		return status

	def __count(self, disabled = False):
		if disabled:
			count = 0
			self.mLock.acquire()
			for i in range(0, len(self.mResults)):
				if self.mResults[i]['status'] == Verification.StatusDisabled:
					count += 1
			self.mLock.release()
			return count
		else:
			return len(self.mResults)

	def __done(self, name):
		for result in self.mResults:
			if result['name'] == name and not result['status'] == Verification.StatusFailure:
				return True
		return False

	# NB: Only one _ in front of the function name, if two __, cannot be called settings.py
	def _verifyAccountsFanart(self, checkDisabled = True, key = None):
		name = 'Fanart'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.artwork.fanart.enabled'):
				if key == None: key = tools.Settings.getString('account.artwork.fanart.api')
				# Seems like FanartTv currently does not check the client key at all. Do some manual validation.
				if re.match('^[a-fA-F0-9]{32}$', key): # 32 character hash.
					link = 'http://webservice.fanart.tv/v3/movies/tt0076759?api_key=%s&client_key=%s' % ('NzY0YTY1MWJmZmE5YmM3OTRlNzY1OTkzZmY0ZGRkMjI='.decode('base64'), key)
					data = network.Networker().request(link = link)
					if data['error']['type'] == network.Networker.ErrorCloudflare:
						status = Verification.StatusCloudflare
					else:
						data = data['json']
						if data and 'name' in data:
							status = Verification.StatusOperational
						else:
							status = Verification.StatusFailure
				else:
					status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsTrakt(self, checkDisabled = True):
		name = 'Trakt'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.trakt.enabled'):
				from lib.modules import trakt
				data = trakt.verify()
				if data:
					status = Verification.StatusOperational
				else:
					status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsImdb(self, checkDisabled = True, user = None):
		name = 'IMDb'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.informants.imdb.enabled'):
				if user == None: user = tools.Settings.getString('account.informants.imdb.user').replace('ur', '')
				link = 'http://www.imdb.com/user/ur%s/watchlist' % user
				networker = network.Networker()
				data = networker.request(link = link)
				if data['error']['type'] == network.Networker.ErrorCloudflare:
					status = Verification.StatusCloudflare
				else:
					data = networker.responseDataText()
					if data:
						indexStart = data.find('IMDbReactInitialState.push(') # Somtimes the page is not fully rendered yet and the JSON is still in a JS tag.
						if indexStart < 0: # Data was rendered into the HTML.
							data = Parser(data)
							if len(data.find_all('div', class_ = 'error_code_404')) > 0:
								status = Verification.StatusFailure
							elif len(data.find_all('div', id = 'unavailable')) > 0:
								status = Verification.StatusLimited
							elif len(data.find_all('div', class_ = 'lister-widget')) > 0:
								status = Verification.StatusOperational
							else:
								status = Verification.StatusFailure
						else: # Data still in JS.
							indexStart += 27
							indexEnd = data.find(');', indexStart)
							data = json.loads(data[indexStart : indexEnd])
							if 'titles' in data and len(data['titles'].values()) > 0:
								status = Verification.StatusOperational
							else:
								status = Verification.StatusLimited
					else: # Wrong user ID, returns 404 error.
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsTmdb(self, checkDisabled = True):
		name = 'TMDb'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.informants.tmdb.enabled'):
				link = 'http://api.themoviedb.org/3/movie/tt0076759?api_key=%s' % tools.Settings.getString('account.informants.tmdb.api')
				data = network.Networker().request(link = link)
				if data['error']['type'] == network.Networker.ErrorCloudflare:
					status = Verification.StatusCloudflare
				else:
					data = data['json']
					if data and 'title' in data:
						status = Verification.StatusOperational
					else:
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsOpensubtitles(self, checkDisabled = True):
		name = 'OpenSubtitles'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.informants.opensubtitles.enabled'):
				from lib.modules import subtitles
				data = subtitles.Subtitles.verify()
				if data:
					status = Verification.StatusOperational
				else:
					status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsYoutube(self, checkDisabled = True):
		name = 'YouTube'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.youtube.enabled'):
				from lib.modules import video
				data = video.Video.verify()
				if data:
					status = Verification.StatusOperational
				else:
					status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsPremiumize(self, checkDisabled = True):
		name = 'Premiumize'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.debrid.premiumize.enabled'):
				if debrid.premiumize.Core().accountVerify():
					status = Verification.StatusOperational
				else:
					status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsOffcloud(self, checkDisabled = True):
		name = 'OffCloud'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.debrid.offcloud.enabled'):
				if debrid.offcloud.Core().accountVerify():
					status = Verification.StatusOperational
				else:
					status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsRealdebrid(self, checkDisabled = True):
		name = 'RealDebrid'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.debrid.realdebrid.enabled'):
				if debrid.realdebrid.Core().accountVerify():
					status = Verification.StatusOperational
				else:
					status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsAlldebrid(self, checkDisabled = True):
		name = 'AllDebrid'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.debrid.alldebrid.enabled'):
				data = {'action': 'login', 'login_login': tools.Settings.getString('account.debrid.alldebrid.user'), 'login_password': tools.Settings.getString('account.debrid.alldebrid.pass')}
				link = 'http://alldebrid.com/register/?%s' % network.Networker.linkEncode(data)
				networker = network.Networker()
				data = networker.request(link = link)
				if data['error']['type'] == network.Networker.ErrorCloudflare:
					status = Verification.StatusCloudflare
				else:
					data = networker.responseDataText()
					if 'control panel' in data.lower():
						status = Verification.StatusOperational
					else:
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsRapidPremium(self, checkDisabled = True):
		name = 'RapidPremium'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.debrid.rapidpremium.enabled'):
				data = {'username': tools.Settings.getString('account.debrid.rapidpremium.user'), 'password': tools.Settings.getString('account.debrid.rapidpremium.api'), 'action': 'generate'}
				link = 'http://premium.rpnet.biz/client_api.php?%s' % network.Networker.linkEncode(data)
				data = network.Networker().request(link = link)
				if data['error']['type'] == network.Networker.ErrorCloudflare:
					status = Verification.StatusCloudflare
				else:
					data = data['json']
					if data:
						if 'error' in data and not data['error'][0] == 'Missing required parameter: links':
							status = Verification.StatusFailure
						else:
							status = Verification.StatusOperational
					else:
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsEasynews(self, checkDisabled = True):
		name = 'EasyNews'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.debrid.easynews.enabled'):
				if debrid.easynews.Core().accountVerify():
					status = Verification.StatusOperational
				else:
					status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsTorrentLeech(self, checkDisabled = True):
		name = 'TorrentLeech'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.providers.torrentleech.enabled'):
				link = 'https://www.torrentleech.org/user/account/login/'
				data = {'username': tools.Settings.getString('account.providers.torrentleech.user'), 'password': tools.Settings.getString('account.providers.torrentleech.pass'), 'submit': 'submit'}
				data = network.Networker().request(link = link, data = data)
				if data['error']['type'] == network.Networker.ErrorCloudflare:
					status = Verification.StatusCloudflare
				else:
					cookies = data['cookies']
					if cookies and 'member_id' in cookies:
						status = Verification.StatusOperational
					else:
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsNzbfinder(self, checkDisabled = True):
		name = 'NZBFinder'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.providers.nzbfinder.enabled'):
				link = 'https://nzbfinder.ws/api?o=json&t=movie&imdbid=0076759&apikey=%s' % tools.Settings.getString('account.providers.nzbfinder.api')
				data = network.Networker().request(link = link)
				if data['error']['type'] == network.Networker.ErrorCloudflare:
					status = Verification.StatusCloudflare
				else:
					data = data['json']
					if data and 'title' in data: # If an error, nzbfinder returns XML instead of JSON.
						status = Verification.StatusOperational
					else:
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsUsenetcrawler(self, checkDisabled = True):
		name = 'UsenetCrawler'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.providers.usenetcrawler.enabled'):
				link = 'https://www.usenet-crawler.com/login'
				data = {'username': tools.Settings.getString('account.providers.usenetcrawler.user'), 'password': tools.Settings.getString('account.providers.usenetcrawler.pass'), 'rememberme' : 'on', 'submit': 'Login'} # Must have rememberme, otherwise cannot login (UsenetCrawler bug).
				data = network.Networker().request(link = link, data = data)
				if data['error']['type'] == network.Networker.ErrorCloudflare:
					status = Verification.StatusCloudflare
				else:
					cookies = data['cookies']
					if cookies:
						data = network.Networker().request(link = link, cookies = cookies)
						if data['error']['type'] == network.Networker.ErrorCloudflare:
							status = Verification.StatusCloudflare
						else:
							data = data['data']['text']#gaiaremove
							if data and 'logout' in data.lower():
								status = Verification.StatusOperational
							else:
								status = Verification.StatusFailure
					else:
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			tools.Logger.error()
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsNzbndx(self, checkDisabled = True):
		name = 'NZBndx'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.providers.nzbndx.enabled'):
				link = 'https://www.nzbndx.com/login'
				headers = {'X-Requested-With': 'XMLHttpRequest'}
				data = {'username': tools.Settings.getString('account.providers.nzbndx.user'), 'password': tools.Settings.getString('account.providers.nzbndx.pass'), 'submit' : 'Login'}
				data = network.Networker().request(link = link, data = data)
				if data['error']['type'] == network.Networker.ErrorCloudflare:
					status = Verification.StatusCloudflare
				else:
					cookies = data['cookies']
					if cookies and 'phpsessid' in cookies:
						# If success or failure, in both cases a session ID is returned. So check the returned HTML.
						data = network.Networker().request(link = link, cookies = cookies)
						if data['error']['type'] == network.Networker.ErrorCloudflare:
							status = Verification.StatusCloudflare
						else:
							data = data['data']['text']#gaiaremove
							if data and 'incorrect username or password' in data.lower():
								status = Verification.StatusFailure
							else:
								status = Verification.StatusOperational
					else:
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			tools.Logger.error()
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsNzbgeek(self, checkDisabled = True):
		name = 'NZBgeek'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.providers.nzbgeek.enabled'):
				link = 'https://api.nzbgeek.info/api?o=json&apikey=%s' % tools.Settings.getString('account.providers.nzbgeek.api')
				data = network.Networker().request(link = link)
				if data['error']['type'] == network.Networker.ErrorCloudflare:
					status = Verification.StatusCloudflare
				else:
					data = data['data']['text']#gaiaremove
					if data and 'invalid api key' in data.lower():
						status = Verification.StatusFailure
					else:
						status = Verification.StatusOperational
			else:
				status = Verification.StatusDisabled
		except:
			tools.Logger.error()
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	# Called from settings wizard.
	def _verifyAccountsAlluc(self, checkDisabled = True, key = None):
		name = 'Alluc'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.providers.alluc.enabled'):
				from lib.modules import settings
				if key == None: keys = settings.Alluc.apiKeys()
				else: keys = [key]
				counter = 0
				limited = False
				status = None

				for i in keys:
					link = 'https://www.alluc.ee/api/search/download/?apikey=%s&query=dummy&count=1' % i
					data = network.Networker().request(link = link)
					if data['error']['type'] == network.Networker.ErrorCloudflare:
						status = Verification.StatusCloudflare
						break
					else:
						data = data['json']
						if data and 'status' in data:
							if data['status'] == 'success':
								counter += 1
							elif 'limit' in data['message'].lower() and data['fetchedtoday'] > 0:
								limited = True

				if not status:
					if len(keys) == counter:
						status = Verification.StatusOperational
					elif counter > 0 or limited:
						status = Verification.StatusLimited
					else:
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	# Called from settings wizard.
	def _verifyAccountsProntv(self, checkDisabled = True, key = None):
		name = 'PronTv'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.providers.prontv.enabled'):
				from lib.modules import settings
				if key == None: keys = settings.Prontv.apiKeys()
				else: keys = [key]
				counter = 0
				limited = False
				status = None

				for i in keys:
					link = 'https://www.pron.tv/api/search/download/?apikey=%s&query=dummy&count=1' % i
					result = network.Networker().request(link = link)
					if data['error']['type'] == network.Networker.ErrorCloudflare:
						status = Verification.StatusCloudflare
						break
					else:
						data = data['json']
						if result and 'status' in result:
							if result['status'] == 'success':
								counter += 1
							elif 'limit' in result['message'].lower() and result['fetchedtoday'] > 0:
								limited = True

				if not status:
					if len(keys) == counter:
						status = Verification.StatusOperational
					elif counter > 0 or limited:
						status = Verification.StatusLimited
					else:
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsT411(self, checkDisabled = True):
		name = 'T411'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.providers.t411.enabled'):
				link = 'https://api.t411.al/auth'
				data = {'username': tools.Settings.getString('account.providers.t411.user'), 'password': tools.Settings.getString('account.providers.t411.pass')}
				data = network.Networker().request(link = link, data = data)
				if data['error']['type'] == network.Networker.ErrorCloudflare:
					status = Verification.StatusCloudflare
				else:
					data = data['json']
					if data and 'token' in data and not data['token'] == None and not data['token'] == '':
						status = Verification.StatusOperational
					else:
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			tools.Logger.error()
			status = Verification.StatusFailure
		return self.__append(name = name, status = status)

	def _verifyAccountsYggtorrent(self, checkDisabled = True):
		name = 'YggTorrent'
		if self.__done(name): return
		try:
			if not checkDisabled or self.__enabled('account.providers.yggtorrent.enabled'):
				link = 'https://www2.yggtorrent.se/user/login'
				data = {'id': tools.Settings.getString('account.providers.yggtorrent.user'), 'pass': tools.Settings.getString('account.providers.yggtorrent.pass')}
				data = network.Networker().request(link = link, data = data)
				if data['error']['type'] == network.Networker.ErrorCloudflare:
					status = Verification.StatusCloudflare
				else:
					cookies = data['cookies']
					if cookies and 'ygg_' in cookies:
						status = Verification.StatusOperational
					else:
						status = Verification.StatusFailure
			else:
				status = Verification.StatusDisabled
		except:
			tools.Logger.error()
			status = Verification.StatusLimited
		return self.__append(name = name, status = status)

	def _verifyAccountsEmby(self, checkDisabled = True):
		from lib.centers import emby
		handle = emby.Emby()
		name = emby.Emby.Name
		if self.__done(name): return
		if not checkDisabled or handle.enabled():
			result = handle.verify()
			if result is None: status = Verification.StatusLimited
			elif result: status = Verification.StatusOperational
			else: status = Verification.StatusFailure
		else:
			status = Verification.StatusDisabled
		return self.__append(name = name, status = status)

	def _verifyAccountsJellyfin(self, checkDisabled = True):
		from lib.centers import jellyfin
		handle = jellyfin.Jellyfin()
		name = jellyfin.Jellyfin.Name
		if self.__done(name): return
		if not checkDisabled or handle.enabled():
			result = handle.verify()
			if result is None: status = Verification.StatusLimited
			elif result: status = Verification.StatusOperational
			else: status = Verification.StatusFailure
		else:
			status = Verification.StatusDisabled
		return self.__append(name = name, status = status)
