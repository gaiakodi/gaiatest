# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
from ast import literal_eval

from lib.modules.tools import Time, Hash, Logger, System, Converter
from lib.modules.database import Database
from lib.modules.serializer import Serializer
from lib.modules.concurrency import Pool, Lock

class Cache(Database):

	Name = Database.NameCache # The name of the file. Update version number of the database structure changes.
	NameTrakt = 'trakt'
	NameExpression = 'expression'

	Skip = '[GAIACACHESKIP]' # If a function returns this value, it will not be cached.

	ModeSynchronous = 1		# If expired, wait until the new data has been retrieved, and return the new data.
	ModeAsynchronous = 2	# If expired, retrieve the new data in the background, and immediately return the old data.
	ModeDefault = ModeAsynchronous

	StorageAll = 1		# Cache all data to the database.
	StorageFull = 2		# Only cache non-empty data to the database.
	StorageDefault = StorageAll

	SettingsLimit = 'general.cache.limit'

	TimeoutMinute1 = 60 # 1 Minute.
	TimeoutMinute5 = 300 # 5 Minutes.
	TimeoutMinute10 = 600 # 10 Minutes.
	TimeoutMinute15 = 900 # 15 Minutes.
	TimeoutMinute20 = 1200 # 20 Minutes.
	TimeoutMinute25 = 1500 # 25 Minutes.
	TimeoutMinute30 = 1800 # 30 Minutes.
	TimeoutMinute45 = 2700 # 45 Minutes.

	TimeoutHour1 = 3600 # 1 Hour.
	TimeoutHour2 = 7200 # 2 Hours.
	TimeoutHour3 = 10800 # 3 Hours.
	TimeoutHour4 = 14400 # 4 Hours.
	TimeoutHour5 = 18000 # 5 Hours.
	TimeoutHour6 = 21600 # 6 Hours.
	TimeoutHour9 = 32400 # 9 Hours.
	TimeoutHour12 = 43200 # 12 Hours.
	TimeoutHour18 = 64800 # 18 Hours.

	TimeoutDay1 = 86400 # 1 Day.
	TimeoutDay2 = 172800 # 2 Days.
	TimeoutDay3 = 259200 # 3 Days.
	TimeoutDay4 = 345600 # 4 Days.
	TimeoutDay5 = 432000 # 5 Days.
	TimeoutDay6 = 518400 # 6 Days.

	TimeoutWeek1 = 604800 # 1 Week.
	TimeoutWeek2 = 1209600 # 2 Weeks.
	TimeoutWeek3 = 1814400 # 3 Weeks.

	TimeoutMonth1 = 2592000 # 1 Month (30 Days).
	TimeoutMonth2 = 5270400 # 2 Months (61 Days).
	TimeoutMonth3 = 7862400 # 3 Months (91 Days).
	TimeoutMonth4 = 10540800 # 4 Months (122 Days).
	TimeoutMonth5 = 13132800 # 5 Months (152 Days).
	TimeoutMonth6 = 15811200 # 6 Months (183 Days).
	TimeoutMonth9 = 23673600 # 9 Months (274 Days).

	TimeoutYear1 = 31536000 # 1 Year (365 Days).
	TimeoutYear2 = 63072000 # 2 Years (730 Days).
	TimeoutYear3 = 94608000 # 3 Years (1095 Days).

	# Keep the timeout as short as possible.
	# The idea is to always update the data in the background on each request.
	# This can cause too many requests if the same cache is access multiple times per second/minute.
	TimeoutClear = -1 # Force refresh the data, but wait until the new data comes in (ModeSynchronous).
	TimeoutRefresh = 0 # Force refresh the data, but still return the current cached data (ModeAsynchronous).
	TimeoutReset = TimeoutMonth1 # 30 Days. Maximum timeout. If values are greater than this, the timeout will be set to TimeoutClear.
	TimeoutMini = TimeoutMinute10  # 10 Minutes.
	TimeoutShort = TimeoutHour1 # 1 Hour.
	TimeoutMedium = TimeoutHour6 # 6 Hours.
	TimeoutLong = TimeoutDay3 # 3 Days.

	Instance = None
	Id = None
	Lock = Lock()
	Updated = False

	def __init__(self, mode = ModeDefault, storage = StorageDefault, timeout = None, internal = False):
		if not internal:
			Logger.log('The Cache class is a singleton and should only be created through the instance() function.', type = Logger.TypeFatal, prefix = True)
			System.exit(log = True)

		Database.__init__(self, Cache.Name)
		self.mMode = mode
		self.mStorage = storage
		self.mTimeout = timeout
		self.mData = {}

	# NB: Always use a single instance of Cache.
	# If creating separate instance using the constructor, each instance will create its own OS file handle to the .db file and establish a seaprate database connection.
	# If too many instances of Cache are created/used (eg: when retrieving metadata, such as retrieving multiple shows and for each show retrieve all the episodes), too many threads will have open database files/connections.
	# This causes SQLite to fail with after too many accesses with the error: "OperationalError: unable to open database file".
	# This problem seems to solved when using a single Cache instance.
	@classmethod
	def instance(self):
		if Cache.Instance is None:
			Cache.Lock.acquire()
			if Cache.Instance is None: Cache.Instance = Cache(internal = True)
			Cache.Lock.release()
		return Cache.Instance

	##############################################################################
	# DATABASE
	##############################################################################

	def _initialize(self):
		self._create('''
			CREATE TABLE IF NOT EXISTS %s
			(
				id TEXT,
				time INTEGER,
				data TEXT,
				UNIQUE(id)
			);
			'''
		)
		self._create('''
			CREATE TABLE IF NOT EXISTS %s
			(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				time INTEGER,
				link TEXT,
				data TEXT
			);
			''' % Cache.NameTrakt
		)
		self._create('''
			CREATE TABLE IF NOT EXISTS %s
			(
				id TEXT,
				val TEXT,
				versionKodi TEXT,
				versionAddon TEXT,
				data TEXT,
				UNIQUE(id)
			);
			''' % Cache.NameExpression
		)

	def _insert(self, query, parameters = None, commit = True):
		Cache.Updated = True
		return Database._insert(self, query = query, parameters = parameters, commit = commit)

	##############################################################################
	# ID
	##############################################################################

	def id(self, function, *args, **kwargs):
		kwargs = self._cacheArguments(function, *args, **kwargs)
		return self._id(function, kwargs)

	def _id(self, function, kwargs):
		if function:
			init = self._idInitialize()
			id = init['expression2'].sub('', init['expression1'].sub('', repr(function))) + '_'
		else:
			id = ''
		id += '_'.join([str(key) + '=' + str(value) for key, value in kwargs.items()])
		return Hash.sha512(id)

	def _idInitialize(self):
		if Cache.Id is None: Cache.Id = {'kodi' : System.versionKodi(full = True), 'addon' : System.version(), 'expression1' : re.compile('.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+'), 'expression2' : re.compile('>')}
		return Cache.Id

	##############################################################################
	# EXECUTE
	##############################################################################

	def execute(self, function, *args, **kwargs):
		kwargs = self._cacheArguments(function, *args, **kwargs)
		return function(**kwargs)

	##############################################################################
	# CACHE
	##############################################################################

	def cacheSelect(self, id): # For direct public access.
		result = self._cacheSelect(id = self._id(function = None, kwargs = {'id' : id}))
		if result: result = result[2]
		return result

	def cacheUpdate(self, id, data): # For direct public access.
		return self._cacheUpdate(id = self._id(function = None, kwargs = {'id' : id}), data = data)

	def _cacheSelect(self, id):
		try: return self.mData[id]
		except: return self._selectSingle('SELECT 0, time, data FROM %s WHERE id = ?;', parameters = (id,)) # Select "0" to indicate the data is not yet unserialized.

	def _cacheUpdate(self, id, data, serialize = False, thread = False):
		time = Time.timestamp()
		self.mData[id] = (serialize, time, data)

		# The longest part of a cache process is writing to disk.
		# This is even more problematic on slow disks, like HDDs.
		# Run in a separate thread and immediately return that the calling process can continue.
		# Do not start in a thread if we are already inside a thread from a asynchronous call.
		if thread: self.__cacheUpdate(id = id, time = time, data = data, serialize = serialize)
		else: Pool.thread(target = self.__cacheUpdate, kwargs = {'id' : id, 'time' : time, 'data' : data, 'serialize' : serialize}, start = True)

	def __cacheUpdate(self, id, time, data, serialize = False):
		if serialize: data = self._cacheDataTo(data)
		self._insert('INSERT OR IGNORE INTO %s (id) VALUES (?);', (id,))
		return self._update('UPDATE %s SET time = ?, data = ? WHERE id = ?;', parameters = (time, data, id))

	def _cacheDelete(self, id):
		try: del self.mData[id]
		except: pass
		return self._update('DELETE FROM %s WHERE id = ?;', parameters = (id,))

	def _cacheDataTo(self, data):
		try:
			serial = Serializer.dataSerialize(data)
			if serial: data = serial
		except: pass
		return repr(data)

	def _cacheDataFrom(self, data):
		if data is None: return data
		value = data[2]
		if data[0] or value is None: return value
		value = literal_eval(value)
		try:
			serial = Serializer.dataUnserialize(value)
			if serial: value = serial
		except: pass
		return value

	def _cacheDataValid(self, data):
		if data is None or data == [] or data == {} or data == '': return False
		elif data == 'None' or data == '[]' or data == '{}': return False
		else: return True

	def _cacheArguments(self, function, *args, **kwargs):
		# Convert args to kwargs.
		try: parameters = function.__code__.co_varnames # Python 3
		except: parameters = function.func_code.co_varnames # Python 2
		parameters = (parameter for parameter in parameters if not parameter == 'self')
		kwargs.update(dict(zip(parameters, args)))
		return kwargs

	def _cache(self, id, function, kwargs, thread = False):
		try:
			data = function(**kwargs)
			if data == Cache.Skip:
				return None
			else:
				if self.mStorage == Cache.StorageAll or self._cacheDataValid(data): self._cacheUpdate(id = id, data = data, thread = thread, serialize = True)
				return data
		except:
			Logger.error()
			return None

	def cache(self, mode, timeout, refresh, function, *args, **kwargs):
		try:
			kwargs = self._cacheArguments(function, *args, **kwargs)
			id = self._id(function, kwargs)

			if mode is None: mode = self.mMode
			if timeout is None: timeout = self.mTimeout

			if timeout >= Cache.TimeoutRefresh:
				cache = self._cacheSelect(id)
				if cache:
					try:
						difference = Time.timestamp() - cache[1]
						if difference > Cache.TimeoutReset: timeout = Cache.TimeoutClear
						elif (refresh and difference <= refresh) or difference <= timeout:
							data = self._cacheDataFrom(cache)
							if data is None: timeout = Cache.TimeoutClear # Sometimes the cached data is None. Refresh the request in such a case.
							elif not refresh: return data
					except: # If cache[0] is None.
						timeout = Cache.TimeoutClear
			else:
				cache = None

			if timeout == Cache.TimeoutClear or mode == Cache.ModeSynchronous or not cache:
				return self._cache(id, function, kwargs)
			else:
				Pool.thread(target = self._cache, kwargs = {'id' : id, 'function' : function, 'thread' : True, 'kwargs' : kwargs}, start = True)
				return self._cacheDataFrom(cache)
		except:
			Logger.error('Cache Failed: ' + str(function))
		return None

	def cacheRetrieve(self, function, *args, **kwargs):
		try:
			kwargs = self._cacheArguments(function, *args, **kwargs)
			id = self._id(function, kwargs)
			return self._cacheDataFrom(self._cacheSelect(id))
		except:
			return None

	def cacheExists(self, function, *args, **kwargs):
		return bool(self.cacheRetrieve(function, *args, **kwargs))

	# Delete the entire cache entry.
	def cacheDelete(self, function, *args, **kwargs):
		kwargs = self._cacheArguments(function, *args, **kwargs)
		id = self._id(function, kwargs)
		self._cacheDelete(id)

	# Use the timeout set in the constructor.
	def cacheFixed(self, function, *args, **kwargs):
		return self.cache(None, None, function, *args, **kwargs)

	# Force refresh the data, but wait until the new data comes in (ModeSynchronous).
	def cacheClear(self, function, *args, **kwargs):
		return self.cache(None, Cache.TimeoutClear, None, function, *args, **kwargs)

	# Force refresh the data, but still return the current cached data (ModeAsynchronous).
	def cacheRefresh(self, function, *args, **kwargs):
		return self.cache(None, Cache.TimeoutRefresh, None, function, *args, **kwargs)

	# Force refresh the data, but still return the current cached data (ModeAsynchronous).
	def cacheRefreshSeconds(self, timeout, function, *args, **kwargs):
		return self.cache(None, Cache.TimeoutRefresh, timeout, function, *args, **kwargs)

	# Force refresh the data, but still return the current cached data (ModeAsynchronous).
	# Will wait to force refresh if the cached data is older than TimeoutMini (ModeSynchronous).
	def cacheRefreshMini(self, function, *args, **kwargs):
		return self.cache(None, Cache.TimeoutRefresh, Cache.TimeoutMini, function, *args, **kwargs)

	# Force refresh the data, but still return the current cached data (ModeAsynchronous).
	# Will wait to force refresh if the cached data is older than TimeoutShort (ModeSynchronous).
	def cacheRefreshShort(self, function, *args, **kwargs):
		return self.cache(None, Cache.TimeoutRefresh, Cache.TimeoutShort, function, *args, **kwargs)

	# Force refresh the data, but still return the current cached data (ModeAsynchronous).
	# Will wait to force refresh if the cached data is older than TimeoutMedium (ModeSynchronous).
	def cacheRefreshMedium(self, function, *args, **kwargs):
		return self.cache(None, Cache.TimeoutRefresh, Cache.TimeoutMedium, function, *args, **kwargs)

	# Force refresh the data, but still return the current cached data (ModeAsynchronous).
	# Will wait to force refresh if the cached data is older than TimeoutLong (ModeSynchronous).
	def cacheRefreshLong(self, function, *args, **kwargs):
		return self.cache(None, Cache.TimeoutRefresh, Cache.TimeoutLong, function, *args, **kwargs)

	def cacheSynchronousSeconds(self, timeout, function, *args, **kwargs):
		return self.cache(Cache.ModeSynchronous, timeout, None, function, *args, **kwargs)

	def cacheSynchronousMinutes(self, timeout, function, *args, **kwargs):
		return self.cache(Cache.ModeSynchronous, timeout * 60, None, function, *args, **kwargs)

	def cacheSynchronousHours(self, timeout, function, *args, **kwargs):
		return self.cache(Cache.ModeSynchronous, timeout * 3600, None, function, *args, **kwargs)

	def cacheSynchronousDays(self, timeout, function, *args, **kwargs):
		return self.cache(Cache.ModeSynchronous, timeout * 86400, None, function, *args, **kwargs)

	def cacheSynchronousMini(self, function, *args, **kwargs):
		return self.cache(Cache.ModeSynchronous, Cache.TimeoutMini, None, function, *args, **kwargs)

	def cacheSynchronousShort(self, function, *args, **kwargs):
		return self.cache(Cache.ModeSynchronous, Cache.TimeoutShort, None, function, *args, **kwargs)

	def cacheSynchronousMedium(self, function, *args, **kwargs):
		return self.cache(Cache.ModeSynchronous, Cache.TimeoutMedium, None, function, *args, **kwargs)

	def cacheSynchronousLong(self, function, *args, **kwargs):
		return self.cache(Cache.ModeSynchronous, Cache.TimeoutLong, None, function, *args, **kwargs)

	def cacheSeconds(self, timeout, function, *args, **kwargs):
		return self.cache(None, timeout, None, function, *args, **kwargs)

	def cacheMinutes(self, timeout, function, *args, **kwargs):
		return self.cache(None, timeout * 60, None, function, *args, **kwargs)

	def cacheHours(self, timeout, function, *args, **kwargs):
		return self.cache(None, timeout * 3600, None, function, *args, **kwargs)

	def cacheDays(self, timeout, function, *args, **kwargs):
		return self.cache(None, timeout * 86400, None, function, *args, **kwargs)

	def cacheMini(self, function, *args, **kwargs):
		return self.cache(None, Cache.TimeoutMini, None, function, *args, **kwargs)

	def cacheShort(self, function, *args, **kwargs):
		return self.cache(None, Cache.TimeoutShort, None, function, *args, **kwargs)

	def cacheMedium(self, function, *args, **kwargs):
		return self.cache(None, Cache.TimeoutMedium, None, function, *args, **kwargs)

	def cacheLong(self, function, *args, **kwargs):
		return self.cache(None, Cache.TimeoutLong, None, function, *args, **kwargs)

	##############################################################################
	# CLEAR
	##############################################################################

	# Delete old entries, older than a specific time, or until a specific file size has been reached.
	def clearOld(self, time = None, size = None, force = False):
		if time:
			# Ignore if the given time is within the past 24 hours.
			# Otherwise entries are constantly deleted and filled up again immediately.
			if not force: time = min(time, Time.past(days = 1))
			self._delete('DELETE FROM %s WHERE time <= ?;', parameters = (time,), commit = True, compress = True)

		elif size:
			if not force: size = max(size, 5242880) # 5 MB

			time = Time.past(days = 365)
			yesterday = Time.past(days = 1)

			day = 86400
			week = 604800
			month = 2592000

			self._compress() # Compress before checking the size for the first time.
			while self._size() > size and time <= yesterday:
				self._delete('DELETE FROM %s WHERE time <= ?;', parameters = (time,), commit = True, compress = True)

				# Reduce the number of queries and therefore disk I/O.
				remaining = yesterday - time
				if remaining > (month * 3): increase = month
				elif remaining > (week * 2): increase = week
				else: increase = day
				time += increase

	##############################################################################
	# LIMIT
	##############################################################################

	def limit(self):
		from lib.modules.tools import Settings
		limit = Settings.getCustom(id = Cache.SettingsLimit)
		return limit if limit else 0

	def limitClear(self, force = False, log = False):
		if force or Cache.Updated:
			limit = self.limit()
			if limit:
				if log: Logger.log('CACHE: Cleanup Started')
				self.clearOld(size = limit)
				if log: Logger.log('CACHE: Cleanup Finished')

	##############################################################################
	# TRAKT
	##############################################################################

	def traktCache(self, link, data = None, timestamp = None):
		# Only cache the requests that change something on the Trakt account.
		# Trakt uses JSON post data to set things and only uses GET parameters to retrieve things.
		if data is None: return None
		if timestamp is None: timestamp = Time.timestamp()
		self._insert('INSERT INTO %s (time, link, data) VALUES (?, ?, ?);' % Cache.NameTrakt, parameters = (timestamp, link, self._cacheDataTo(data)))

	def traktRetrieve(self):
		self._lock() # Execute the select and delete as atomic operations.
		result = self._selectSingle('SELECT id, time, link, data FROM %s ORDER BY time ASC LIMIT 1;' % Cache.NameTrakt)
		if not result:
			self._unlock()
			return None
		self._delete('DELETE FROM %s WHERE id = ?;' % Cache.NameTrakt, parameters = (result[0],))
		self._unlock()
		return {'time' : result[1], 'link' : result[2], 'data' : self._cacheDataFrom([False, result[1], result[3]])}

	##############################################################################
	# EXPRESSION
	##############################################################################

	def expressionCache(self, id, data):
		init = self._idInitialize()
		return self._insert('INSERT OR IGNORE INTO %s (id, versionKodi, versionAddon, data) VALUES (?, ?, ?, ?);' % Cache.NameExpression, (id, init['kodi'], init['addon'], data))

	def expressionRetrieve(self, id):
		init = self._idInitialize()
		return self._selectValue('SELECT data FROM %s WHERE id = ? AND versionKodi = ? AND versionAddon = ?;' % Cache.NameExpression, parameters = (id, init['kodi'], init['addon']))

	def expressionClean(self):
		init = self._idInitialize()
		return self._delete('DELETE FROM %s WHERE versionKodi <> ? OR versionAddon <> ?;' % Cache.NameExpression, parameters = (init['kodi'], init['addon']), compress = True)


# The idea behind this local memory cache is as follows:
#	1. Try to load the cached value from a class variable.
#	2. If not available, try to load the value from a global Kodi window property.
#	3. If not available, let the calling class decide what to do.
# This can drastically improve processing time, especially where values are accessed multiple times during an execution, such as various menu loading.
# This class might have to be rethought if <reuselanguageinvoker> is used in addon.xml in the future.
class Memory(object):

	Property	= 'GaiaCache_'
	Uncached	= 'GaiaCacheUncached'
	Data		= {}

	@classmethod
	def id(self, id):
		return Memory.Property + id

	@classmethod
	def get(self, id, uncached = False):
		id = self.id(id)
		try:
			return Memory.Data[id]
		except:
			value = System.windowPropertyGet(id)
			if value:
				value = Converter.jsonFrom(value)['value']
				Memory.Data[id] = value
			else:
				value = Memory.Uncached if uncached else None
			return value

	@classmethod
	def set(self, id, value):
		id = self.id(id)
		Memory.Data[id] = value
		System.windowPropertySet(id, Converter.jsonTo({'value' : value})) # Always save as a JSON object, so we can preserve the data type and deal with "empty" values.
		return value

	@classmethod
	def clear(self, id):
		id = self.id(id)
		try: del Memory.Data[id]
		except: pass
		System.windowPropertyClear(id)

	@classmethod
	def has(self, id, local = True, kodi = True):
		id = self.id(id)
		if local and id in Memory.Data: return True
		if kodi and System.windowPropertyGet(id): return True
		return False

	@classmethod
	def cached(self, value):
		return not value == Memory.Uncached

	@classmethod
	def uncached(self, value):
		return value == Memory.Uncached
