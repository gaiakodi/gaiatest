
import sys

if sys.version_info[0] == 2:
	from lib.externals.cpuinfo import *
else:
	from lib.externals.cpuinfo.cpuinfo import *


