from lib.externals.hachoir.metadata.metadata import extractMetadata  # noqa

# Just import the module,
# each module use registerExtractor() method
import lib.externals.hachoir.metadata.archive  # noqa
import lib.externals.hachoir.metadata.audio  # noqa
import lib.externals.hachoir.metadata.file_system  # noqa
import lib.externals.hachoir.metadata.image  # noqa
import lib.externals.hachoir.metadata.jpeg  # noqa
import lib.externals.hachoir.metadata.misc  # noqa
import lib.externals.hachoir.metadata.program  # noqa
import lib.externals.hachoir.metadata.riff  # noqa
import lib.externals.hachoir.metadata.video  # noqa
import lib.externals.hachoir.metadata.cr2 # noqa