#!/usr/bin/env python3
from lib.externals.hachoir.subfile.main import main
main()
