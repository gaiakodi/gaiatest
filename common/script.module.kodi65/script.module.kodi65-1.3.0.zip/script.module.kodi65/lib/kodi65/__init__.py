# -*- coding: utf8 -*-

# Copyright (C) 2016 - Philipp Temminghoff <phil65@kodi.tv>
# This program is Free Software see LICENSE file for details

from kodi65.kodiaddon import Addon

addon = Addon()

from kodi65.listitem import ListItem, VideoItem, AudioItem
from kodi65.itemlist import ItemList
from kodi65.actionhandler import ActionHandler
from kodi65.busyhandler import busyhandler as busy
from kodi65.kodilogging import KodiLogHandler, config
from kodi65.dialogbaselist import DialogBaseList
from kodi65.localdb import LocalDB
from kodi65.player import VideoPlayer
from kodi65.abs_last_fm import AbstractLastFM

import sys

# PIL uses numpy if it is available.
# numpy can NOT be loaded multiple times in a sub-interpreter.
# Since numpy is optional, force it to NEVER be imported.

sys.modules['numpy'] = None

local_db: LocalDB = LocalDB(last_fm=AbstractLastFM())
player = VideoPlayer()
